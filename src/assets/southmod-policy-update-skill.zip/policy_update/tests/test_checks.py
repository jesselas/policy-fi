#!/usr/bin/env python3
"""Synthetic tests for the checking scripts (no real data). Run: python3 tests/test_checks.py"""
import csv, gzip, hashlib, os, subprocess, sys, tempfile, unittest, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.join(HERE, '..', 'scripts')


def run(script, *args):
    p = subprocess.run([sys.executable, os.path.join(S, script), *args], capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


def sha(path):
    return hashlib.sha256(open(path, 'rb').read()).hexdigest()


def write(path, text, gz=False):
    data = text.encode()
    if gz:
        with gzip.open(path, 'wb') as f:
            f.write(data)
    else:
        open(path, 'wb').write(data)
    return path


def table(head, rows, eol='\r\n'):
    return eol.join(['\t'.join(head)] + ['\t'.join(map(str, r)) for r in rows]) + eol


class ReplaceYds(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.inp = write(os.path.join(self.d, 'in.txt'), table(
            ['idhh', 'idperson', 'yds', 'xhh', 'dwt'],
            [[1, 101, '100.5', '50', '1.25'], [1, 102, '0', '50', '1.25'], [2, 201, '300', '80', '2']]))
        self.out = write(os.path.join(self.d, 'out.txt'), table(
            ['idperson', 'ils_dispyki', 'ils_con'],
            [[101, '100.50', '50.00'], [102, '0.00', '50.00'], [201, '300.00', '80.00']], '\n'))

    def out_with(self, rows):
        return write(os.path.join(self.d, 'out2.txt'), table(['idperson', 'ils_dispyki', 'ils_con'], rows, '\n'))

    def test_pass(self):
        c, o = run('replace_yds.py', '--check', self.inp, self.out)
        self.assertEqual(c, 0, o); self.assertIn('PASS', o)

    def test_precision_tolerance(self):
        ok = self.out_with([[101, '100.51', '50'], [102, '0.00', '50'], [201, '300.00', '80']])
        self.assertEqual(run('replace_yds.py', '--check', self.inp, ok)[0], 0)
        bad = self.out_with([[101, '100.52', '50'], [102, '0.00', '50'], [201, '300.00', '80']])
        c, o = run('replace_yds.py', '--check', self.inp, bad)
        self.assertEqual(c, 1, o); self.assertIn('FAIL', o)

    def test_check_is_read_only(self):
        h = sha(self.inp)
        bad = self.out_with([[101, '999', '50'], [102, '0', '50'], [201, '300', '80']])
        self.assertEqual(run('replace_yds.py', '--check', self.inp, bad)[0], 1)
        self.assertEqual(sha(self.inp), h)

    def test_unmatched_people(self):
        h = sha(self.inp)
        part = self.out_with([[101, '100.5', '50'], [102, '0', '50']])
        for mode in ('--check', '--replace'):
            c, o = run('replace_yds.py', mode, self.inp, part)
            self.assertEqual(c, 2, o); self.assertIn('populations differ', o)
        self.assertEqual(sha(self.inp), h)

    def test_duplicate_ids(self):
        dup_out = self.out_with([[101, '1', '50'], [101, '1', '50'], [201, '300', '80']])
        self.assertIn('duplicate', run('replace_yds.py', '--check', self.inp, dup_out)[1])
        dup_in = write(os.path.join(self.d, 'dup.txt'), table(['idperson', 'yds'], [[101, 1], [101, 1], [201, 2]]))
        c, o = run('replace_yds.py', '--replace', dup_in, self.out)
        self.assertEqual(c, 2, o)

    def test_missing_id_and_nonfinite(self):
        miss = write(os.path.join(self.d, 'm.txt'), table(['idperson', 'yds'], [['', 1], [102, 0], [201, 3]]))
        self.assertEqual(run('replace_yds.py', '--check', miss, self.out)[0], 2)
        nan = write(os.path.join(self.d, 'n.txt'), table(['idperson', 'yds'], [[101, 'nan'], [102, 0], [201, 'inf']]))
        c, o = run('replace_yds.py', '--replace', nan, self.out)
        self.assertEqual(c, 2, o); self.assertIn('nonfinite', o)

    def test_replace_changes_only_yds_and_copies(self):
        gz = write(os.path.join(self.d, 'in.txt.gz'), open(self.inp, newline='').read(), gz=True)
        new = self.out_with([[101, '110.25', '50'], [102, '0.00', '50'], [201, '310.00', '80']])
        before = open(self.inp, 'rb').read()
        c, o = run('replace_yds.py', '--replace', self.inp, new, '--also', gz)
        self.assertEqual(c, 0, o)
        after = open(self.inp, 'rb').read()
        self.assertEqual(gzip.decompress(open(gz, 'rb').read()), after)
        a, b = before.decode().split('\r\n'), after.decode().split('\r\n')
        self.assertEqual(len(a), len(b))
        for x, y in zip(a, b):
            x, y = x.split('\t'), y.split('\t')
            self.assertEqual([t for j, t in enumerate(x) if j != 2], [t for j, t in enumerate(y) if j != 2])
        self.assertIn('110.25', b[1])
        self.assertEqual(run('replace_yds.py', '--check', self.inp, new)[0], 0)
        self.assertFalse([f for f in os.listdir(self.d) if f.startswith('.yds_tmp_')])

    def test_replace_refuses_differing_copy(self):
        other = write(os.path.join(self.d, 'copy.txt'), open(self.inp, newline='').read().replace('300', '301'))
        h1, h2 = sha(self.inp), sha(other)
        new = self.out_with([[101, '1', '50'], [102, '0', '50'], [201, '3', '80']])
        c, o = run('replace_yds.py', '--replace', self.inp, new, '--also', other)
        self.assertEqual(c, 2, o)
        self.assertEqual((sha(self.inp), sha(other)), (h1, h2))

    def test_consumption_only_informational_unless_requested(self):
        con = self.out_with([[101, '100.50', '55'], [102, '0.00', '55'], [201, '300.00', '80']])
        c, o = run('replace_yds.py', '--check', self.inp, con)
        self.assertEqual(c, 0, o); self.assertIn('information only', o)
        c, o = run('replace_yds.py', '--check', self.inp, con, '--con-check', '--tol-con', '0.5')
        self.assertEqual(c, 1, o)


class PfLines(unittest.TestCase):
    HEAD = ['idhh', 'idperson', 'ils_taxco', 'ils_benco', 'ils_con', 'ses', 'spl', 'drgn1', 'dwt']

    def setUp(self):
        self.d = tempfile.mkdtemp()

    def out(self, rows, head=None):
        return write(os.path.join(self.d, 'o.txt'), table(head or self.HEAD, rows, '\n'))

    def base(self):
        # two people per household, ses as per-person halves (sum = 2); household eq. consumption = 100
        rows = []
        for h, (tax, con) in enumerate([(10, 200), (20, 202), (4, 400)], start=1):
            for k in range(2):
                rows.append([h, h * 10 + k, tax / 2, 0, con / 2, 1.0, 100, 1, 1])
        return rows

    def test_value_and_fixed_point(self):
        f = self.out(self.base())
        c, o = run('pf_povlines.py', f, '--ses-agg', 'sum', '--compare', '92.50')
        self.assertEqual(c, 0, o); self.assertIn('FIXED POINT', o)   # 100 - mean(5, 10) = 92.5
        c, o = run('pf_povlines.py', f, '--ses-agg', 'sum', '--compare', '92.60')
        self.assertEqual(c, 1, o); self.assertIn('MOVED', o)

    def test_ses_convention_required_and_checked(self):
        f = self.out(self.base())
        self.assertEqual(run('pf_povlines.py', f)[0], 2)            # argparse: --ses-agg required
        c, o = run('pf_povlines.py', f, '--ses-agg', 'household')     # accepted, but the wrong scale empties the band
        self.assertEqual(c, 2, o); self.assertIn('0 households in band', o)
        rows = self.base(); rows[0][5] = 1.5
        c, o = run('pf_povlines.py', self.out(rows), '--ses-agg', 'household')
        self.assertEqual(c, 2, o); self.assertIn('varies within', o)

    def test_empty_band(self):
        rows = self.base()
        for r in rows:
            r[6] = 1000
        c, o = run('pf_povlines.py', self.out(rows), '--ses-agg', 'sum')
        self.assertEqual(c, 2, o); self.assertIn('0 households in band', o)

    def test_groups_and_compare_validation(self):
        rows = self.base(); rows[-1][7] = rows[-2][7] = 2
        f = self.out(rows)
        self.assertEqual(run('pf_povlines.py', f, '--ses-agg', 'sum', '--group', 'drgn1', '--band', '0.5')[0], 2)
        c, o = run('pf_povlines.py', f, '--ses-agg', 'sum', '--group', 'drgn1', '--band', '5', '--compare', '1')
        self.assertEqual(c, 2, o)
        c, o = run('pf_povlines.py', f, '--ses-agg', 'sum', '--group', 'drgn1', '--band', '0.9', '--compare', '92.5')
        self.assertEqual(c, 2, o); self.assertIn('2 groups', o)
        c, o = run('pf_povlines.py', f, '--ses-agg', 'sum', '--group', 'drgn1', '--band', '0.9',
                   '--compare', '1=92.5', '3=98')
        self.assertEqual(c, 2, o); self.assertIn('do not match', o)

    def test_inconsistent_lines(self):
        rows = self.base(); rows[0][6] = 101
        self.assertIn('varies within', run('pf_povlines.py', self.out(rows), '--ses-agg', 'sum')[1])
        rows = self.base(); rows[4][6] = rows[5][6] = 101
        c, o = run('pf_povlines.py', self.out(rows), '--ses-agg', 'sum')
        self.assertEqual(c, 2, o); self.assertIn('--group', o)

    def test_missing_values(self):
        rows = self.base(); rows[2][2] = ''
        self.assertEqual(run('pf_povlines.py', self.out(rows), '--ses-agg', 'sum')[0], 2)
        rows = self.base(); rows[0][5] = rows[1][5] = 0
        self.assertEqual(run('pf_povlines.py', self.out(rows), '--ses-agg', 'sum')[0], 2)
        head = [h for h in self.HEAD if h != 'ils_benco']
        rows = [r[:3] + r[4:] for r in self.base()]
        f = self.out(rows, head)
        self.assertEqual(run('pf_povlines.py', f, '--ses-agg', 'sum')[0], 2)
        self.assertEqual(run('pf_povlines.py', f, '--ses-agg', 'sum', '--no-benco')[0], 0)


NS = ('xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
      'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
      'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"')


def para(*runs):
    return '<w:p>' + ''.join(runs) + '</w:p>'


def r(t):
    return f'<w:r><w:t xml:space="preserve">{t}</w:t></w:r>'


def ins(t, i, a='Upd'):
    return f'<w:ins w:id="{i}" w:author="{a}" w:date="2026-01-01T00:00:00Z">{r(t)}</w:ins>'


def dele(t, i, a='Upd'):
    return (f'<w:del w:id="{i}" w:author="{a}" w:date="2026-01-01T00:00:00Z"><w:r><w:delText xml:space="preserve">'
            f'{t}</w:delText></w:r></w:del>')


def pic(rid):
    return f'<w:r><w:drawing><a:blip r:embed="{rid}"/></w:drawing></w:r>'


def docx(path, body, endnotes=None, media=b'PNG1'):
    with zipfile.ZipFile(path, 'w') as z:
        z.writestr('[Content_Types].xml', '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>')
        z.writestr('word/document.xml', f'<w:document {NS}><w:body>{body}</w:body></w:document>')
        if endnotes is not None:
            z.writestr('word/endnotes.xml', f'<w:endnotes {NS}><w:endnote w:id="1">{endnotes}</w:endnote></w:endnotes>')
        z.writestr('word/_rels/document.xml.rels',
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId9" Type="image" Target="media/image1.png"/></Relationships>')
        z.writestr('word/media/image1.png', media)
    return path


class ReportQA(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.prev = docx(os.path.join(self.d, 'prev.docx'),
                         para(r('VAT is 10 per cent.')) + para(pic('rId9')), para(r('Source: law 1.')))

    def draft(self, body, endnotes=para(r('Source: law 1.')), media=b'PNG1'):
        return docx(os.path.join(self.d, 'draft.docx'), body, endnotes, media)

    def test_clean_tracked_draft(self):
        f = self.draft(para(r('VAT is '), dele('10', 1), ins('8', 2), r(' per cent.')) + para(pic('rId9')),
                       para(r('Source: law 1'), ins(' and law 2', 3), r('.')))
        c, o = run('report_qa.py', self.prev, f)
        self.assertEqual(c, 0, o); self.assertIn('word/endnotes.xml: IDENTICAL', o)

    def test_tracked_new_paragraph(self):
        newp = f'<w:p><w:pPr><w:rPr><w:ins w:id="5" w:author="Upd" w:date="2026-01-01T00:00:00Z"/></w:rPr></w:pPr>{ins("New text.", 6)}</w:p>'
        f = self.draft(newp + para(r('VAT is 10 per cent.')) + para(pic('rId9')))
        self.assertEqual(run('report_qa.py', self.prev, f)[0], 0)

    def test_inserted_mark_with_untracked_text(self):
        # a copied paragraph whose mark is tracked but whose text is not: Word's reject view merges it into the next
        newp = f'<w:p><w:pPr><w:rPr><w:ins w:id="5" w:author="Upd" w:date="2026-01-01T00:00:00Z"/></w:rPr></w:pPr>{r("VAT is 10 per cent.")}</w:p>'
        f = self.draft(newp + para(r('VAT is 10 per cent.')) + para(pic('rId9')))
        c, o = run('report_qa.py', self.prev, f)
        self.assertEqual(c, 1, o)

    def test_untracked_endnote_change(self):
        f = self.draft(para(r('VAT is 10 per cent.')) + para(pic('rId9')), para(r('Source: law 2.')))
        c, o = run('report_qa.py', self.prev, f)
        self.assertEqual(c, 1, o); self.assertIn('word/endnotes.xml: 2 differing', o)

    def test_untracked_body_change(self):
        f = self.draft(para(r('VAT is 8 per cent.')) + para(pic('rId9')))
        self.assertEqual(run('report_qa.py', self.prev, f)[0], 1)

    def test_removed_part(self):
        f = self.draft(para(r('VAT is 10 per cent.')) + para(pic('rId9')), endnotes=None)
        c, o = run('report_qa.py', self.prev, f)
        self.assertEqual(c, 1, o); self.assertIn('story part removed', o)

    def test_figure_replaced_untracked(self):
        f = self.draft(para(r('VAT is 10 per cent.')) + para(pic('rId9')), media=b'PNG2')
        c, o = run('report_qa.py', self.prev, f)
        self.assertEqual(c, 1, o); self.assertIn('figures DIFFER', o)

    def test_duplicate_revision_ids(self):
        f = self.draft(para(r('VAT is '), dele('10', 7), ins('8', 7), r(' per cent.')) + para(pic('rId9')))
        c, o = run('report_qa.py', self.prev, f)
        self.assertEqual(c, 1, o)

    def test_author_mode_with_revisions_in_previous(self):
        prev = docx(os.path.join(self.d, 'prev2.docx'),
                    para(r('VAT is '), dele('12', 1, 'Old'), ins('10', 2, 'Old'), r(' per cent.')) + para(pic('rId9')),
                    para(r('Source: law 1.')))
        f = self.draft(para(r('VAT is '), dele('12', 1, 'Old'), ins('10', 2, 'Old'),
                            ins(' (8 from 2026)', 4), r(' per cent.')) + para(pic('rId9')))
        c, o = run('report_qa.py', prev, f, '--author', 'Upd')
        self.assertEqual(c, 0, o)
        bad = self.draft(para(r('VAT is 10 per cent.')) + para(pic('rId9')))   # previous revisions accepted
        self.assertEqual(run('report_qa.py', prev, bad, '--author', 'Upd')[0], 0)  # accepted baseline = same text
        self.assertEqual(run('report_qa.py', prev, bad)[0], 1)                     # reject-all baseline differs


class CompareInput(unittest.TestCase):
    def test_counts_do_not_inherit_money_tolerance(self):
        d = tempfile.mkdtemp()
        t = write(os.path.join(d, 't.txt'), table(['idperson', 'xhh', 'xcount'], [[1, '10.00', 2], [2, '5.00', 1]], '\n'))
        b = write(os.path.join(d, 'b.txt'), table(['idperson', 'xhh', 'xcount'], [[1, '10.004', 2.004], [2, '5.00', 1]], '\n'))
        self.assertEqual(run('compare_input_data.py', t, b, '--out', os.path.join(d, 'c'))[0], 1)
        c, o = run('compare_input_data.py', t, b, '--out', os.path.join(d, 'c'), '--tol', 'xhh=0.005')
        self.assertEqual(c, 1, o); self.assertIn('xcount', o)
        self.assertEqual(run('compare_input_data.py', t, b, '--out', os.path.join(d, 'c'),
                             '--tol', 'xhh=0.005', 'xcount=0.01')[0], 0)
        dup = write(os.path.join(d, 'd.txt'), table(['idperson', 'xhh'], [[1, 1], [1, 1]], '\n'))
        self.assertEqual(run('compare_input_data.py', t, dup, '--out', os.path.join(d, 'c'))[0], 2)


# ---------------------------------------------------------------- synthetic country model
CNS = 'http://euromod.com/CountryConfig.xsd'


def par(pid, fid, name, value, order, group=''):
    g = f'<Group>{group}</Group>' if group else '<Group />'
    return (f'        <Parameter>\r\n          <ID>{pid}</ID>\r\n          <FunctionID>{fid}</FunctionID>\r\n'
            f'          <Name>{name}</Name>\r\n          <Comment><![CDATA[]]></Comment>\r\n'
            f'          <Value><![CDATA[{value}]]></Value>\r\n          <Order>{order}</Order>\r\n          {g}\r\n        </Parameter>\r\n')


def fun(fid, polid, name, order, switch, params, comment=''):
    return (f'      <Function>\r\n        <ID>{fid}</ID>\r\n        <PolicyID>{polid}</PolicyID>\r\n        <Name>{name}</Name>\r\n'
            f'        <Comment><![CDATA[{comment}]]></Comment>\r\n        <Order>{order}</Order>\r\n        <Switch>{switch}</Switch>\r\n'
            + ''.join(params) + '      </Function>\r\n')


def guid(sys_i, k):
    return f'{sys_i:08x}-0000-4000-8000-{k:012x}'


def system(i, name, year, order, cc='XX'):
    sid = guid(i, 0)
    P = lambda k: guid(i, k)
    pols = []
    # 1. constdef: two constants, one unused
    pols.append((P(1), 'constdef_xx', 1, [fun(P(2), P(1), 'DefConst', 1, 'on',
                 [par(P(3), P(2), '$rate', '0.15', 1), par(P(4), P(2), '$unused_c', '500#y', 2)])]))
    # 2. tin: ArithOp using $rate, and a literal
    pols.append((P(10), 'tin_xx', 2, [fun(P(11), P(10), 'ArithOp', 1, 'on',
                 [par(P(12), P(11), 'Formula', 'yem*$rate + 2500#m', 1), par(P(13), P(11), 'Output_Var', 'tin_s', 2),
                  par(P(14), P(11), 'TAX_UNIT', 'tu_individual_xx', 3)], 'income tax'),
                  fun(P(15), P(10), 'ArithOp', 2, 'switch',
                 [par(P(16), P(15), 'Formula', 'yem*0.1', 1), par(P(17), P(15), 'Output_Add_Var', 'tin_s', 2)], 'fya')]))
    # 3. output: DefOutput (file + repeated VarGroup) and a ChangeParam renaming the file
    pols.append((P(20), 'output_std_xx', 3, [
        fun(P(21), P(20), 'DefOutput', 1, 'on', [par(P(22), P(21), 'file', f'{name}_hh_std', 1),
            par(P(23), P(21), 'VarGroup', 'id*', 2), par(P(24), P(21), 'VarGroup', 'y*', 3)]),
        fun(P(25), P(20), 'ChangeParam', 2, 'on', [par(P(26), P(25), 'Param_Id', P(22), 1, '1'),
            par(P(27), P(25), 'Param_NewVal', f'{name.lower()}_variant', 2, '1'),
            par(P(28), P(25), 'Comment_note', 'xx_2019_a1', 3)])]))
    body = ''.join(f'    <Policy>\r\n      <ID>{pid}</ID>\r\n      <SystemID>{sid}</SystemID>\r\n      <Name>{pn}</Name>\r\n'
                   f'      <Order>{po}</Order>\r\n      <Switch>on</Switch>\r\n' + ''.join(fs) + '    </Policy>\r\n'
                   for pid, pn, po, fs in pols)
    return (f'    <System>\r\n      <ID>{sid}</ID>\r\n      <Name>{name}</Name>\r\n      <Order>{order}</Order>\r\n'
            f'      <Year>{year}</Year>\r\n      <Comment><![CDATA[]]></Comment>\r\n' + body + '    </System>\r\n')


EXT = 'eeeeeeee-0000-4000-8000-000000000001'


def model(dirpath, bind_systems=(1, 2), bind_param_systems=(1, 2)):
    """Two systems; system 1 (XX_2024) is FIRST in the file although its Order is higher."""
    cdir = os.path.join(dirpath, 'XMLParam', 'Countries', 'XX'); os.makedirs(cdir, exist_ok=True)
    cfg = os.path.join(dirpath, 'XMLParam', 'Config'); os.makedirs(cfg, exist_ok=True)
    systems = system(1, 'XX_2024', 2024, 2) + system(2, 'XX_2023', 2023, 1)
    ext = ''.join(f'  <Extension_Function>\r\n    <ExtensionID>{EXT}</ExtensionID>\r\n    <FunctionID>{guid(i, 15)}</FunctionID>\r\n'
                  f'    <BaseOff>false</BaseOff>\r\n  </Extension_Function>\r\n' for i in bind_systems)
    ext += ''.join(f'  <Extension_Parameter>\r\n    <ExtensionID>{EXT}</ExtensionID>\r\n    <ParameterID>{guid(i, 16)}</ParameterID>\r\n'
                   f'    <BaseOff>false</BaseOff>\r\n  </Extension_Parameter>\r\n' for i in bind_param_systems)
    cf = (f'  <ConditionalFormat>\r\n    <ID>cccccccc-0000-4000-8000-000000000001</ID>\r\n    <BackColor>FFFFC000</BackColor>\r\n'
          f'    <BaseSystemName>XX_2023</BaseSystemName>\r\n    <ConditionalFormat_Systems>\r\n'
          f'      <ConditionalFormatID>cccccccc-0000-4000-8000-000000000001</ConditionalFormatID>\r\n'
          f'      <SystemName>XX_2024</SystemName>\r\n    </ConditionalFormat_Systems>\r\n  </ConditionalFormat>\r\n')
    xml = (f'﻿<?xml version="1.0" encoding="utf-8"?>\r\n<CountryConfig xmlns="{CNS}">\r\n' + cf +
           f'  <Country>\r\n    <ID>c0000000-0000-4000-8000-000000000000</ID>\r\n    <Name>XX</Name>\r\n' + systems +
           '  </Country>\r\n' + ext + '</CountryConfig>\r\n')
    open(os.path.join(cdir, 'XX.xml'), 'wb').write(xml.encode('utf-8'))
    dbs = ''.join(f'    <DBSystemConfig>\r\n      <SystemID>{guid(i, 0)}</SystemID>\r\n      <SystemName>{n}</SystemName>\r\n'
                  f'      <DataBaseID>dddddddd-0000-4000-8000-000000000001</DataBaseID>\r\n      <BestMatch>yes</BestMatch>\r\n'
                  f'      <PolicySwitch>\r\n        <SwitchablePolicyID>{EXT}</SwitchablePolicyID>\r\n        <SystemID>{guid(i, 0)}</SystemID>\r\n'
                  f'        <DataBaseID>dddddddd-0000-4000-8000-000000000001</DataBaseID>\r\n        <Value><![CDATA[off]]></Value>\r\n'
                  f'      </PolicySwitch>\r\n    </DBSystemConfig>\r\n' for i, n in ((1, 'XX_2024'), (2, 'XX_2023')))
    dc = ('﻿<?xml version="1.0" encoding="utf-8"?>\r\n<DataConfig xmlns="http://tempuri.org/DataConfig.xsd">\r\n'
          '  <DataBase>\r\n    <ID>dddddddd-0000-4000-8000-000000000001</ID>\r\n    <Name>xx_2023_a1</Name>\r\n' + dbs +
          '  </DataBase>\r\n  <Extension>\r\n    <ID>' + EXT + '</ID>\r\n    <Name>Full year</Name>\r\n    <ShortName>FYA</ShortName>\r\n'
          '  </Extension>\r\n</DataConfig>\r\n')
    open(os.path.join(cdir, 'XX_dataconfig.xml'), 'wb').write(dc.encode('utf-8'))
    open(os.path.join(cfg, 'ExchangeRatesConfig.xml'), 'wb').write(
        '﻿<ExchangeRatesConfig>\r\n  <ExchangeRates>\r\n    <ValidFor>xx_2024, xx_2023</ValidFor>\r\n  </ExchangeRates>\r\n</ExchangeRatesConfig>\r\n'.encode())
    return os.path.join(cdir, 'XX.xml')


class ModelScripts(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()

    def test_binding_check_partial_and_first_system(self):
        x = model(self.d)
        c, o = run('ext_binding_check.py', x)
        self.assertEqual(c, 0, o); self.assertIn('first system in file: XX_2024', o)
        x = model(self.d, bind_systems=(2,), bind_param_systems=(1, 2))   # misses the first system
        c, o = run('ext_binding_check.py', x)
        self.assertEqual(c, 1, o); self.assertIn("first system in file (XX_2024) bound: False", o)
        x = model(self.d, bind_param_systems=(2,))
        c, o = run('ext_binding_check.py', x)
        self.assertEqual(c, 1, o); self.assertIn('tin_xx function 2 parameter 1 Formula', o)

    def test_add_system_bindings_outputs_variant_name(self):
        x = model(self.d)
        c, o = run('add_system.py', self.d, 'XX', 'XX_2024', 'XX_2025_reform')
        self.assertEqual(c, 0, o)
        self.assertIn('1 Extension_Function + 1 Extension_Parameter', o)
        raw = open(x, 'rb').read()
        self.assertTrue(raw.startswith(b'\xef\xbb\xbf')); self.assertNotIn(b'\n', raw.replace(b'\r\n', b''))
        txt = raw.decode('utf-8-sig')
        self.assertIn('<Year>2025</Year>', txt)
        self.assertIn('XX_2025_reform_hh_std', txt)                 # DefOutput file renamed
        self.assertIn('xx_2025_reform_variant', txt)                # ChangeParam output name renamed
        self.assertEqual(txt.count('xx_2019_a1'), 3)                 # other values untouched
        self.assertIn('<BaseSystemName>XX_2024</BaseSystemName>', txt)  # new comparison entry
        self.assertTrue(txt.index('<Name>XX_2025_reform</Name>') > txt.index('<Name>XX_2023</Name>'))  # appended last
        c, o = run('ext_binding_check.py', x)
        self.assertEqual(c, 0, o)
        self.assertEqual(run('add_system.py', self.d, 'XX', 'XX_2024', 'XX_2025_reform')[0], 1)  # exists

    def test_unused_constants(self):
        x = model(self.d)
        c, o = run('unused_constants.py', x, 'XX_2024', '--literals')
        self.assertEqual(c, 1, o)
        self.assertIn('$unused_c', o); self.assertNotIn('UNUSED  $rate', o); self.assertIn('2500#m', o)

    def test_edit_model_occurrence_and_insert_after(self):
        x = model(self.d)
        csvp = write(os.path.join(self.d, 'e.csv'), 'op,system,policy,fun,parameter,group,value,comment\n'
                     'set_value,XX_2024,output_std_xx,3.1,VarGroup[2],,x*,\n'
                     'copy_function_after,XX_2024,tin_xx,2.2,2.1,,on,copy\n')
        c, o = run('edit_model.py', self.d, 'XX', csvp)
        self.assertEqual(c, 0, o)
        sp = os.path.join(HERE, '..', '..', 'southmod', 'scripts', 'spine.py')
        if os.path.exists(sp):
            out = subprocess.run([sys.executable, sp, x, 'XX_2023', 'tin_xx'], capture_output=True, text=True).stdout
            self.assertIn('2.2  ArithOp [n/a]  copy', out); self.assertIn('2.3  ArithOp [switch] {EXT:FYA', out)
        bad = write(os.path.join(self.d, 'b.csv'), 'op,system,policy,fun,parameter,group,value,comment\n'
                    'set_value,XX_2024,output_std_xx,3.1,VarGroup,,x*,\n')
        c, o = run('edit_model.py', self.d, 'XX', bad, '--dry-run')
        self.assertNotEqual(c, 0); self.assertIn('2 matches', o)


class LocateValues(unittest.TestCase):
    def test_variants_and_locate(self):
        sys.path.insert(0, S)
        import locate_values as L
        self.assertIn('600,000', L.strings(600000)); self.assertIn('600.000', L.strings(600000))
        self.assertEqual(L.to_float('1.234,5'), 1234.5); self.assertEqual(L.to_float('1,234.5'), 1234.5)
        self.assertEqual(L.to_float('15%'), 15.0)
        forms = dict((lab, v) for v, lab in L.numbers('0.15'))
        self.assertAlmostEqual(forms['x100 (per cent)'], 15.0)
        self.assertAlmostEqual(dict((lab, v) for v, lab in L.numbers('6000#y'))['monthly'], 500.0)
        d = tempfile.mkdtemp()
        x = model(d)
        doc = write(os.path.join(d, 'law.txt'), 'The rate is 15 per cent. A deduction of 6,000 per year.')
        c, o = run('locate_values.py', 'locate', x, 'XX_2024', doc, '--policy', 'constdef_xx', '--out', os.path.join(d, 'h.csv'))
        self.assertEqual(c, 0, o)
        rows = list(csv.DictReader(open(os.path.join(d, 'h.csv'))))
        self.assertTrue(any(r['parameter'] == '$rate' and r['string'] == '15' for r in rows))


if __name__ == '__main__':
    unittest.main(verbosity=1)
