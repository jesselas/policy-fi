---
name: policy_update
description: End-to-end annual policy update of a SOUTHMOD / EUROMOD country model (VNMOD, RWAMOD, UGAMOD, ZANMOD, GHAMOD, TAZMOD, MOZMOD, ETMOD, etc.) to a new policy year - online legal research, new policy systems and XML edits, uprating, EUROMOD reruns, base-year yds, post-fiscal poverty lines, input-data and do-file corrections, DRD sumstats, SM_LOG, the country report in Word tracked changes (Sections 1-4 and Annex, with major online research), national-team workbooks and emails, and a clean final package. Use when someone asks to "update <MODEL> to <year>", "add the <year> policy system", "do the SOUTHMOD policy update", "handle the whole update", or to update a SOUTHMOD country report, SM_LOG, post-fiscal lines or yds after model changes. Requires the southmod skill for model knowledge.
---

# policy_update

Runs the whole annual SOUTHMOD policy update for one (or several) country models, from the previous release to a
finished, documented new version: model, data, report, logs and team package. It is the procedure, the rules and
the tools learned from the 2026 update of VNMOD, RWAMOD and UGAMOD (bundle A5.0).

**Load the `southmod` skill first** and keep its rules in force (matrix thinking, `<Order>` numbering with
`spine.py`, reading comments, no invented values). This skill adds the update workflow on top of it.

## The request you will get

Typically: *"Work on ZANMOD update for 2026. I have the DRD, input-data do-files, the recent Country Report and the
recent SOUTHMOD bundle with ZANMOD input datasets. Handle the whole thing."* Start with **Phase 0 (intake)** in
`references/01_intake_and_setup.md`: confirm the files, ask the few decisions only the user can make, set up the
workspace and write `PLAN.md`. Then work autonomously through the phases, stopping only at the gates below.

## Phases and gates

| Phase | What | Reference | Gate (stop and ask the user) |
|---|---|---|---|
| 0 | Intake: files, decisions, workspace, PLAN.md, git | 01 | Missing essentials; time point; target years |
| 1 | Inventory of the previous model: systems, datasets, spine, constants, VAT/excise lists, uprating, extensions | 01, 03 | none |
| 2 | Policy research, two independent passes, verified sources; T1 policy-change document | 02 | Modelling decisions with no default (e.g. whether to add a new instrument) |
| 3 | Model edits: new system(s), parameters, uprating, exchange rates, corrections to past systems | 03 | none (all edits reviewable CSVs) |
| 4 | EUROMOD runs (the user runs them), output checks, base-year yds, post-fiscal lines, fixed-point loop | 04 | Each run request |
| 5 | External statistics research; validation tables (T6 code); Section 4 / Annex numbers | 06 | none |
| 6 | Country report update in tracked changes: Sections 1, 2, 3, 4 and Annex, references | 05 | Wording choices only if contentious |
| 7 | Input-data corrections, do-files, DRD sumstats | 07 | Any change to input data (it triggers reruns) |
| 8 | Team package: T1, T2 parameter workbook, T3 external statistics workbook, email; remaining-questions prompt for an online AI and applying its answers | 08 | Sending emails (never send yourself) |
| 9 | SM_LOG audit against the previous version, final organisation, handover | 09 | none |

Phases 2-3 and 5-6 overlap; phase 4 recurs after every change that moves results. `references/10_pitfalls.md`
lists the mistakes that cost the most time in practice; read it before phase 3 and before phase 6.

## Non-negotiable rules

1. **Evidence.** Every rule value, date and statistic has a source (law, gazette, ministry, revenue authority,
   statistics office first; firms' tax summaries and news only as backup, labelled). Record source, article/table,
   page, URL, access date and status (final / provisional / budget estimate). Never guess; write "not found".
2. **Time point.** Know the model's policy time point (e.g. 1 July for fiscal-year countries, 1 January for
   calendar-year countries) and model within-year changes consistently (e.g. a Full Year Adjustment extension,
   pro-rated by months in force). Write the convention into T1 and the report.
3. **Model edits only through reviewable edit CSVs** applied with `scripts/edit_model.py`; dry-run first; validate
   the XML; diff every parameter against the previous commit; keep BOM and CRLF. Never regex across XML elements.
4. **Extensions bind whole rows** (every system's cell, including the first). Run `scripts/ext_binding_check.py`
   after adding any extension-controlled row, and verify in the output that the row actually ran.
5. **After every change that moves results:** rerun, compare every fiscal aggregate (`scripts/diff_outputs.py`),
   check base-year `yds = ils_dispyki` (`scripts/replace_yds.py --check`), recompute post-fiscal lines
   (`scripts/pf_povlines.py`) until they are fixed points, rerun validation tables, update report numbers.
6. **Country report: tracked changes only**, author "UNU-WIDER" (or as agreed), with `scripts/tracked_edit.py`;
   the report stands on its own (no "previous version", "corrected", "changed method" wording); after each pass
   `scripts/report_qa.py` must show that rejecting all changes gives exactly the previous report.
7. **SM_LOG** gets an entry for every model and data change; audit it against the previous version with
   `scripts/audit_vs_previous.py` before calling the update finished.
8. **Never send emails or publish.** Draft them; the user sends.
9. **Commit and push often** (if the work is in git), with clear messages. Unpushed work can be lost.
10. **Writing:** concise, technical, UN English; no semicolons or em dashes in new report prose; no filler.

## Scripts (`scripts/`, Python 3 with lxml, pandas, openpyxl, python-docx)

| Script | Use |
|---|---|
| `extract_params.py` | Every policy/function/parameter cell of a country XML to a long CSV (GUI numbering) |
| `compare_systems.py` | Cells that differ between two systems (e.g. new year vs previous year) |
| `add_system.py` | Clone a system into a new year (new GUIDs, extensions, dataconfig, exchange rates) |
| `edit_model.py` | Apply an edit CSV (set_value, set_switch, set_comment, set_name, add_param, add_param_all, copy_function_all, uprate); `--dry-run` prints old -> new |
| `fya.py` | Add extension-controlled (e.g. FYA) functions to a policy in every system |
| `ext_binding_check.py` | Rows bound to an extension in only some systems (they silently do not run) |
| `audit_vs_previous.py` | All changes vs the previous version, by element ID, with SM_LOG coverage |
| `diff_outputs.py` | Before/after comparison of two outputs: all fiscal aggregates and changed columns |
| `replace_yds.py` | Check or set base-year `yds = ils_dispyki` |
| `pf_povlines.py` | Post-fiscal poverty lines from an output (per group), with comparison to model constants |
| `compare_input_data.py` | Rebuilt vs target input dataset, by idperson (for do-file reproduction) |
| `docx_track.py` | Low-level Word tracked-change helpers |
| `tracked_edit.py` | Safe report edits (in place inside own insertions, tracked otherwise), table cells by header year, edit log |
| `report_qa.py` | Reject-all view = previous report; duplicate revision ids; style check |
| `fix_reject_view.py` | Repair paragraphs whose reject view is garbled or lost |
| `team_workbook.py` | Styling helpers for the team workbooks (grey model / blue proposal / green team columns) |
| `examples/` | Country-specific versions from the 2026 update (post-fiscal line tools for VN/RW/UG, T2/T3 builders, the VN 1-January/FYA conversion, COICOP VAT table, inventory): adapt, do not run as is |

Call scripts as `python3 <this skill's dir>/scripts/<name>.py ...` (`$SKILL` in the docstrings).

## References

- `references/01_intake_and_setup.md`: files to request, questions, workspace layout, PLAN.md template, inventory.
- `references/02_policy_research.md`: research method, two-pass verification, what to cover, T1 template.
- `references/03_model_editing.md`: new systems, parameters, uprating, extensions/FYA, corrections, checks.
- `references/04_runs_checks_yds_pf.md`: run requests, output checks, yds, post-fiscal lines, fixed points.
- `references/05_country_report.md`: section-by-section update, tracked-change mechanics, QA, references.
- `references/06_external_stats_validation.md`: external statistics, validation tables, Section 4 text.
- `references/07_data_prep_and_drd.md`: input-data corrections, do-file versioning, reproduction, DRD.
- `references/08_team_package.md`: T1/T2/T3, emails, remaining-questions prompt, applying answers.
- `references/09_smlog_audit_and_final_package.md`: SM_LOG format and audit, final layout, handover.
- `references/10_pitfalls.md`: lessons learned (read before editing the model and the report).
