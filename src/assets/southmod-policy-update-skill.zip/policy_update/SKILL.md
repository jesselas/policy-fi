---
name: policy_update
description: Annual policy update of a SOUTHMOD / EUROMOD country model to a new policy year, or any part of it - legal research, new policy systems and XML edits, uprating, run requests and run acceptance, base-year yds, post-fiscal poverty lines, input-data and preparation-code corrections, DRDs, SM_LOG, the country report in Word tracked changes, national-team workbooks and emails, and a clean shareable package. Use when someone asks to "update <MODEL> to <year>", "add the <year> policy system", "do the SOUTHMOD policy update", or to update a SOUTHMOD country report, SM_LOG, DRD, post-fiscal lines or yds after model changes. Uses the southmod skill for model knowledge.
---

# policy_update

The procedure, rules and checking tools for updating one or several SOUTHMOD country models from the previous
release to a documented new version: model, data, report, logs and team package. Examples in the references
come from real updates of particular models; treat them as examples, and read each model's own conventions.

Placeholders: `<CC>`/`<cc>` country code, `<MODEL>` model name, `<release>` bundle release, `<year>` policy
year, `<author>` the agreed report and log author, `<project_root>` the workspace. `$SKILL` is this skill's
folder.

## Dependencies

- **southmod skill** (model knowledge: matrix thinking, `<Order>` numbering with `spine.py`, reading comments;
  how functions evaluate their parameters in `references/functions_and_syntax.md`; running models from
  Python or Stata in `references/connectors.md`). Load it first. If it is not available, read the model XML directly, number rows by `<Order>` (never by
  position in the file), and check every matrix cell for the system in question.
- Python 3 with lxml, pandas, numpy, openpyxl, python-docx for the scripts; `pdftotext` (poppler) or pypdf for PDFs.
- Optional: LibreOffice (rendering reports), a PDF-reading skill, a prose-editing skill.
- EUROMOD, Stata or R: inspect what is available; the user usually runs EUROMOD.

## Scope and decisions

Start with intake (`references/01_intake_and_setup.md`): confirm the files, ask only the decisions with no
default, write `PLAN.md`. If the user asks for one part (report only, SM_LOG only, one system), do that part
and do not widen it. Decisions the user has made stay in force; ask again only when evidence contradicts one
or a new choice falls outside it.

## Phases and gates

| Phase | What | Reference | Gate (stop and ask) |
|---|---|---|---|
| 0 | Intake: scope, files, decisions, workspace, PLAN.md | 01 | Missing essentials; time point; target years |
| 1 | Inventory of the previous model | 01, 03 | none |
| 2 | Policy research (two passes, verified sources); T1 | 02 | Modelling choices with no default |
| 3 | Model edits via reviewable edit CSVs | 03 | none |
| 4 | Run requests, run acceptance, yds, post-fiscal lines, fixed points | 04 | Each run request |
| 5 | External statistics; validation tables (T6) | 06 | none |
| 6 | Country report in tracked changes | 05 | Contentious wording |
| 7 | Input data, preparation code, versions, DRDs | 07 | Any change to input data |
| 8 | Team package: T1, T2, T3, emails; applying answers | 08 | Sending anything (never send yourself) |
| 9 | SM_LOG audit, public package checks, archive, handover | 09 | Deleting anything not clearly generated |

Phase 4 recurs after every change that moves results. Read `references/10_pitfalls.md` before phases 3 and 6.

## Rules

1. **Evidence.** Every rule value, date and statistic has a source (law, gazette, ministry, revenue authority,
   statistics office first; secondary sources labelled). Record source, article/table, page, URL, access date
   and status (final / provisional / budget estimate). Never guess; write "not found".
2. **Time point.** Know the model's policy time point (30 June/1 July in most models, 1 January in some, e.g.
   VNMOD) and model within-year changes consistently (e.g. a full year adjustment extension, pro-rated by months
   in force). State the convention in T1 and the report.
3. **Model edits only through reviewable edit CSVs** (`edit_model.py`, dry-run first); validate the XML; diff
   every cell against the previous commit; keep BOM and line endings. Never regex across XML elements.
4. **Extensions bind whole rows** (policies, functions, parameters) in every system, above all the first
   `<System>` in the file. Run `ext_binding_check.py`; verify in the output that the row ran. Never script-edit
   a model EUROMOD has open (`*_in_use.txt`).
5. **Runs count only with provenance**: log, scenario, input and model hashes (04); connector runs also record
   the package and engine versions and the bundled-engine flag. A file name or timestamp is not evidence.
6. **After every change that moves results:** compare every fiscal aggregate, check base-year yds, recompute
   post-fiscal lines with explicit conventions until they are fixed points, rerun T6, update report numbers.
   A check that exits nonzero is a failure, not a warning.
7. **Country report: tracked changes only**, author `<author>`, with `tracked_edit.py`; the report describes the
   current model only; `report_qa.py` must pass for every story part, and the changed pages are inspected.
8. **Versions:** a substantively changed released input gets a new version everywhere at once; keep an
   old-to-new map with hashes (07).
9. **Public vs internal:** shipped models, code, logs and team files work and read correctly without the
   internal workspace: no private paths, internal file references or development history (09).
10. **SM_LOG** entry for every model and data change; audit with `audit_vs_previous.py` before finishing.
11. **Never send emails or publish.** Draft them; the user sends.
12. **Commit often** (if the work is in git), with clear messages.
13. **Writing:** concise, technical, UN English; no semicolons or em dashes in new report prose.
14. **Verification.** The law arbitrates between sources; agreement between the model and its own report is
   not evidence. Check t-1 as well as t, test every mismatch for a year shift and for units, and record
   discrepancies by type (02). Team answers are checked the same way before they are applied (08).

## Scripts (`scripts/`)

| Script | Use |
|---|---|
| `extract_params.py` | Every policy/function/parameter cell of a country XML to a long CSV (GUI numbering) |
| `compare_systems.py` | Cells that differ between two systems (`--quiet` hides output names and GUIDs) |
| `add_system.py` | Clone a system into a new year or variant (new GUIDs, policy/function/parameter extension bindings, dataconfig, exchange rates, output names, colour comparison) |
| `edit_model.py` | Apply an edit CSV (set_value, set_switch, set_comment, set_name, add_param, add_param_all, copy_function_all, copy_function_after, uprate; repeated parameters as `name[n]` or `N.M.K`); `--dry-run` |
| `fya.py` | Add extension-controlled (e.g. FYA) functions to a policy in every system, bound in every system |
| `ext_binding_check.py` | Rows (policies, functions, parameters) bound in only some systems or differently; first system in the file; dataconfig switch consistency |
| `unused_constants.py` | Constants defined but never used; numbers typed into formulas (`--literals`) |
| `cite_inventory.py` | Laws and URLs cited in the report and model comments; link check |
| `locate_values.py` | Where model values appear in laws and reports (`locate`); report parameter tables vs model (`tables`) |
| `wayback.py` | Archived copies of sources nearest the policy time point |
| `audit_vs_previous.py` | All changes vs the previous version, by element ID, with SM_LOG coverage |
| `diff_outputs.py` | Before/after comparison of two outputs: fiscal aggregates and changed columns |
| `replace_yds.py` | Check or set base-year `yds = ils_dispyki`; strict IDs/populations/values; verified atomic replacement |
| `pf_povlines.py` | Post-fiscal poverty lines with explicit conventions; fixed-point test at stored precision |
| `compare_input_data.py` | Rebuilt vs target input dataset by person ID, per-variable tolerances |
| `docx_track.py`, `tracked_edit.py` | Tracked-change editing of the report (own insertions edited in place) |
| `report_qa.py` | Reject view = baseline for all story parts, structure and figures; revision ids; style |
| `fix_reject_view.py` | Repair paragraphs whose reject view is garbled |
| `team_workbook.py` | Styling helpers for team workbooks |
| `examples/` | Model-specific tools from a past update: adapt, do not run as is |

Exit codes of the checking scripts: 0 pass, 1 check failed, 2 invalid input. `tests/test_checks.py` runs
synthetic tests of the checking scripts.

## References

- `references/01_intake_and_setup.md`: scope, files, questions, workspace layout, PLAN.md, inventory.
- `references/02_policy_research.md`: research method, two-pass verification, arbitration and discrepancy types,
  getting the text of sources (access ladder, archives, OCR), T1 template.
- `references/03_model_editing.md`: new systems, parameters, uprating, extensions/FYA, corrections, checks.
- `references/04_runs_checks_yds_pf.md`: run requests, run acceptance, yds, post-fiscal lines, fixed points.
- `references/05_country_report.md`: section-by-section update, tracked-change mechanics, QA.
- `references/06_external_stats_validation.md`: external statistics, validation tables, Section 4 text.
- `references/07_data_prep_and_drd.md`: data corrections, raw reproduction, versions, preparation package, DRDs.
- `references/08_team_package.md`: T1/T2/T3, questions, emails, applying answers.
- `references/09_smlog_audit_and_final_package.md`: SM_LOG, audit, public packages, archive, handover.
- `references/10_pitfalls.md`: lessons learned.
