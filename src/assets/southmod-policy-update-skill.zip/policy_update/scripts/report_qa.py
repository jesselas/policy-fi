#!/usr/bin/env python3
"""QA of a tracked country-report draft against the previous published report.

Checks: (1) rejecting all tracked changes in the draft gives exactly the previous report, paragraph by
paragraph (document and footnotes); (2) no duplicate revision ids; (3) new inserted prose has no
semicolons or em dashes (style rule); lists the paragraphs that fail with their original, reject-view and
accept-view text. If the previous report itself still contains tracked changes, reject is applied to both.

usage: python3 $SKILL/scripts/report_qa.py PREVIOUS.docx DRAFT.docx
Fix failing paragraphs with fix_reject_view.py.
"""
import zipfile, sys, difflib, collections, re
from lxml import etree
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'

def reject_texts(xml):
    root = etree.fromstring(xml)
    for tr in list(root.iter(W + 'tr')):
        if tr.find(W + 'trPr/' + W + 'ins') is not None: tr.getparent().remove(tr)
    for tc in list(root.iter(W + 'tc')):
        if tc.find(W + 'tcPr/' + W + 'cellIns') is not None: tc.getparent().remove(tc)
    for p in list(root.iter(W + 'p')):
        if p.find(W + 'pPr/' + W + 'rPr/' + W + 'ins') is not None: p.getparent().remove(p)
    for e in list(root.iter(W + 'ins')):
        if e.getparent() is not None and e.getparent().tag != W + 'rPr': e.getparent().remove(e)
    for t in root.iter(W + 'delText'): t.tag = W + 't'
    return [''.join(t.text or '' for t in p.iter(W + 't')) for p in root.iter(W + 'p')]

za, zb = zipfile.ZipFile(sys.argv[1]), zipfile.ZipFile(sys.argv[2]); ok = True
for part in ['word/document.xml', 'word/footnotes.xml']:
    if part not in za.namelist(): continue
    a, b = reject_texts(za.read(part)), reject_texts(zb.read(part))
    dd = [l for l in difflib.unified_diff(a, b, lineterm='', n=0) if not l.startswith(('---', '+++', '@@'))]
    print(part, 'IDENTICAL after reject' if not dd else f'{len(dd)} differing lines:')
    for l in dd[:40]: print('   ', l[:300])
    ok &= not dd
ids = collections.Counter(); bad_style = []
for part in [n for n in zb.namelist() if n.startswith('word/') and n.endswith('.xml')]:
    r = etree.fromstring(zb.read(part))
    for tag in ('ins', 'del'):
        for e in r.iter(W + tag): ids[e.get(W + 'id')] += 1
    for e in r.iter(W + 'ins'):
        s = ''.join(t.text or '' for t in e.iter(W + 't'))
        prose = re.sub(r'\([^()]*\)', '', s)   # citations in parentheses may use ';'
        if (';' in prose and 'http' not in prose) or ('\u2014' in s and len(s.strip()) > 1): bad_style.append(s[:120])
dup = [k for k, v in ids.items() if v > 1]
print('duplicate revision ids:', dup[:10]); ok &= not dup
print('inserted text with ";" or em dash (check; citations with ";" may be legitimate):', len(bad_style))
for s in bad_style[:15]: print('   ', s)
sys.exit(0 if ok else 1)
