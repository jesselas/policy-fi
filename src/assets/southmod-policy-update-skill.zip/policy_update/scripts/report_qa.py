#!/usr/bin/env python3
"""QA of a tracked country-report draft against the agreed previous report (the baseline).

Rule: rejecting the update's revisions in the draft must give the baseline. Checked for every story part
(document, footnotes, endnotes, headers, footers), paragraph by paragraph, plus structure (tables, rows,
cells, figures by image content, note references, sections, hyperlinks) and added/removed parts.

Which revisions belong to the update, and what the baseline is:
  default          reject ALL revisions in both files (use when the previous report may still hold its own
                   revisions and they were carried into the draft unchanged)
  --author NAME    reject only revisions by NAME in the draft and accept all others; the baseline is the
                   previous report with all its revisions accepted (use when the previous report's own
                   revisions count as agreed). Warns if the previous report already holds revisions by NAME.

This is a text-and-structure check. It does not prove that formatting, figure placement or layout are
unchanged: formatting revisions and changed style parts are listed, and the changed paragraphs are printed
so that the pages holding them can be inspected visually (Word, or --render with LibreOffice if installed:
--render writes the accepted view, all revisions accepted, as a PDF; LibreOffice would otherwise show markup).

Also checked: duplicate revision ids; style of inserted prose (semicolons outside parentheses, em dashes).

usage: python3 $SKILL/scripts/report_qa.py PREVIOUS.docx DRAFT.docx [--author NAME] [--render OUT.pdf]
exit codes: 0 pass (warnings may remain: read them); 1 fail. Fix failing paragraphs with fix_reject_view.py.
"""
import argparse, collections, difflib, hashlib, posixpath, re, shutil, subprocess, sys, tempfile, zipfile, os
from lxml import etree

W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
R = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
PR = '{http://schemas.openxmlformats.org/package/2006/relationships}'
A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
V = '{urn:schemas-microsoft-com:vml}'
STORY = re.compile(r'^word/(document|footnotes|endnotes|header\d*|footer\d*)\.xml$')
FORMAT_REV = ['rPrChange', 'pPrChange', 'sectPrChange', 'tblPrChange', 'trPrChange', 'tcPrChange',
              'tblGridChange', 'numberingChange']
REV = ['ins', 'del', 'moveFrom', 'moveTo', 'cellIns', 'cellDel', 'cellMerge'] + FORMAT_REV
STYLE_PARTS = ['word/styles.xml', 'word/numbering.xml', 'word/settings.xml', 'word/theme/theme1.xml']


def rels(z, part):
    rp = posixpath.join(posixpath.dirname(part), '_rels', posixpath.basename(part) + '.rels')
    if rp not in z.namelist():
        return {}
    out = {}
    for r in etree.fromstring(z.read(rp)).iter(PR + 'Relationship'):
        t = r.get('Target')
        if r.get('TargetMode') != 'External':
            t = posixpath.normpath(posixpath.join(posixpath.dirname(part), t))
        out[r.get('Id')] = (t, r.get('TargetMode') == 'External')
    return out


def view(z, part, reject):
    """Paragraph texts and structure counts of `part` after rejecting revisions where reject(el) is True
    and accepting all others."""
    root = etree.fromstring(z.read(part))
    rl = rels(z, part)

    def drop(e):
        if e.getparent() is not None:
            e.getparent().remove(e)
    for tr in list(root.iter(W + 'tr')):
        i, d = tr.find(W + 'trPr/' + W + 'ins'), tr.find(W + 'trPr/' + W + 'del')
        if (i is not None and reject(i)) or (d is not None and not reject(d)):
            drop(tr)
    for tc in list(root.iter(W + 'tc')):
        i, d = tc.find(W + 'tcPr/' + W + 'cellIns'), tc.find(W + 'tcPr/' + W + 'cellDel')
        if (i is not None and reject(i)) or (d is not None and not reject(d)):
            drop(tc)
    for e in list(root.iter(W + 'ins', W + 'moveTo')):
        if e.getparent() is not None and e.getparent().tag != W + 'rPr' and reject(e):
            drop(e)
    for e in list(root.iter(W + 'del', W + 'moveFrom')):
        if e.getparent() is not None and e.getparent().tag != W + 'rPr' and not reject(e):
            drop(e)
    for t in root.iter(W + 'delText'):
        t.tag = W + 't'
    paras, buf = [], ''
    for p in root.iter(W + 'p'):
        txt = ''.join('\t' if t.tag == W + 'tab' else (t.text or '') for t in p.iter(W + 't', W + 'tab')
                      if next(t.iterancestors(W + 'p')) is p)
        mi, md = p.find(W + 'pPr/' + W + 'rPr/' + W + 'ins'), p.find(W + 'pPr/' + W + 'rPr/' + W + 'del')
        merge = (mi is not None and reject(mi)) or (md is not None and not reject(md))
        buf += txt
        if not merge:
            paras.append(buf); buf = ''
    if buf:
        paras.append(buf)
    media = collections.Counter()
    for b in root.iter(A + 'blip', V + 'imagedata'):
        rid = b.get(R + 'embed') or b.get(R + 'id')
        tgt = rl.get(rid)
        if tgt and not tgt[1] and tgt[0] in z.namelist():
            media[hashlib.sha256(z.read(tgt[0])).hexdigest()[:12]] += 1
        else:
            media['unresolved:' + str(rid)] += 1
    links = collections.Counter(rl.get(h.get(R + 'id'), ('?', 0))[0] for h in root.iter(W + 'hyperlink')
                                if h.get(R + 'id') and ''.join(t.text or '' for t in h.iter(W + 't')))
    struct = dict(tables=len(list(root.iter(W + 'tbl'))), rows=len(list(root.iter(W + 'tr'))),
                  cells=len(list(root.iter(W + 'tc'))),
                  drawings=len(list(root.iter(W + 'drawing', W + 'pict', W + 'object'))),
                  footnote_refs=len(list(root.iter(W + 'footnoteReference'))),
                  endnote_refs=len(list(root.iter(W + 'endnoteReference'))),
                  sections=len(list(root.iter(W + 'sectPr'))),
                  fields=len([f for f in root.iter(W + 'fldChar') if f.get(W + 'fldCharType') == 'begin'])
                  + len(list(root.iter(W + 'fldSimple'))))
    return paras, struct, media, links



def accepted_copy(src, out):
    """Copy of `src` with every revision accepted, for rendering (LibreOffice shows markup otherwise)."""
    def accept(root):
        def drop(e):
            if e.getparent() is not None:
                e.getparent().remove(e)
        for tr in list(root.iter(W + 'tr')):
            if tr.find(W + 'trPr/' + W + 'del') is not None:
                drop(tr)
        for tc in list(root.iter(W + 'tc')):
            if tc.find(W + 'tcPr/' + W + 'cellDel') is not None:
                drop(tc)
        for p in list(root.iter(W + 'p')):  # deleted paragraph marks: merge with the next paragraph
            d = p.find(W + 'pPr/' + W + 'rPr/' + W + 'del')
            if d is None:
                continue
            drop(d)
            nxt = p.getnext()
            if nxt is not None and nxt.tag == W + 'p':
                for c in list(nxt):
                    if c.tag != W + 'pPr':
                        p.append(c)
                drop(nxt)
        for e in list(root.iter(W + 'del', W + 'moveFrom')):
            drop(e)
        for tag in ('rPrChange', 'pPrChange', 'sectPrChange', 'tblPrChange', 'trPrChange', 'tcPrChange',
                    'tblGridChange', 'numberingChange', 'cellIns', 'moveFromRangeStart', 'moveFromRangeEnd',
                    'moveToRangeStart', 'moveToRangeEnd'):
            for e in list(root.iter(W + tag)):
                drop(e)
        for e in list(root.iter(W + 'ins', W + 'moveTo')):
            par = e.getparent()
            if par is None:
                continue
            if par.tag in (W + 'rPr', W + 'trPr'):
                drop(e); continue
            i = par.index(e)
            for c in list(e):
                par.insert(i, c); i += 1
            drop(e)
        return root
    story = re.compile(r'word/(document|footnotes|endnotes|comments|header\d*|footer\d*)\.xml$')
    with zipfile.ZipFile(src) as zi, zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zo:
        for it in zi.infolist():
            d = zi.read(it.filename)
            if story.match(it.filename):
                d = etree.tostring(accept(etree.fromstring(d)), xml_declaration=True, encoding='UTF-8',
                                   standalone=True)
            zo.writestr(it, d)

def canon(b):
    try:
        return etree.tostring(etree.fromstring(b), method='c14n')
    except Exception:
        return b


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('previous'); ap.add_argument('draft'); ap.add_argument('--author')
    ap.add_argument('--render'); ap.add_argument('--max-lines', type=int, default=40)
    a = ap.parse_args(argv)
    za, zb = zipfile.ZipFile(a.previous), zipfile.ZipFile(a.draft)
    na, nb = set(za.namelist()), set(zb.namelist())
    ok, warn = True, []
    if a.author:
        rej_draft = lambda e: e.get(W + 'author') == a.author
        rej_prev = lambda e: False
        n_prev = sum(1 for p in na if STORY.match(p) for e in etree.fromstring(za.read(p)).iter(*[W + t for t in REV])
                     if e.get(W + 'author') == a.author)
        if n_prev:
            warn.append(f'previous report already holds {n_prev} revisions by "{a.author}": the baseline is ambiguous')
        print(f'baseline: previous report, all its revisions accepted; draft: revisions by "{a.author}" rejected, '
              'others accepted')
    else:
        rej_draft = rej_prev = lambda e: True
        print('baseline: previous report with all revisions rejected; draft: all revisions rejected')
    sa, sb = sorted(p for p in na if STORY.match(p)), sorted(p for p in nb if STORY.match(p))
    for p in sorted(set(sa) ^ set(sb)):
        print(f'FAIL story part {"added" if p in nb else "removed"}: {p}'); ok = False
    for part in [p for p in sa if p in nb]:
        pa, sta, ma, la = view(za, part, rej_prev)
        pb, stb, mb, lb = view(zb, part, rej_draft)
        dd = [l for l in difflib.unified_diff(pa, pb, lineterm='', n=0) if not l.startswith(('---', '+++', '@@'))]
        bad_struct = {k: (sta[k], stb[k]) for k in sta if sta[k] != stb[k]}
        status = 'IDENTICAL after reject' if not dd else f'{len(dd)} differing paragraph lines'
        print(f'{part}: {status}; structure {"same" if not bad_struct else "DIFFERS " + str(bad_struct)}; '
              f'figures {"same" if ma == mb else "DIFFER"}; hyperlinks {"same" if la == lb else "DIFFER"}')
        for l in dd[:a.max_lines]:
            print('   ', l[:300])
        if ma != mb:
            print('    figure content (sha256 prefixes) baseline', dict(ma), 'draft', dict(mb))
        if la != lb:
            print('    hyperlink targets baseline', dict(la - lb), 'draft', dict(lb - la))
        ok &= not dd and not bad_struct and ma == mb and la == lb
    # other package parts
    for p in sorted((na ^ nb) - set(sa) - set(sb)):
        (warn if p.startswith('word/media/') and p in nb else warn).append(
            f'part {"added" if p in nb else "removed"}: {p}' + (' (fine if a tracked inserted figure uses it)'
                                                               if p.startswith('word/media/') else ''))
    for p in sorted(na & nb):
        if p.startswith('word/media/') and za.read(p) != zb.read(p):
            warn.append(f'media file changed in place: {p} (checked above only where a figure in the reject view uses it)')
        if p in STYLE_PARTS and canon(za.read(p)) != canon(zb.read(p)):
            warn.append(f'{p} differs: possible untracked formatting change; inspect visually')
    # revision ids, formatting revisions, style of inserted prose, changed paragraphs for visual inspection
    ids, fmt, bad_style, changed = collections.Counter(), collections.Counter(), [], []
    for part in sorted(p for p in nb if p.startswith('word/') and p.endswith('.xml')):
        r = etree.fromstring(zb.read(part))
        for e in r.iter(*[W + t for t in REV]):
            if e.get(W + 'id') is not None:
                ids[e.get(W + 'id')] += 1
            if etree.QName(e).localname in FORMAT_REV and (not a.author or e.get(W + 'author') == a.author):
                fmt[etree.QName(e).localname] += 1
        for e in r.iter(W + 'ins'):
            if a.author and e.get(W + 'author') != a.author:
                continue
            s = ''.join(t.text or '' for t in e.iter(W + 't'))
            prose = re.sub(r'\([^()]*\)', '', s)
            if (';' in prose and 'http' not in prose) or ('—' in s and len(s.strip()) > 1):
                bad_style.append(s[:120])
        if STORY.match(part):
            acc = view(zb, part, lambda e: False)[0]
            rej = view(zb, part, rej_draft)[0]
            sm = difflib.SequenceMatcher(None, rej, acc, autojunk=False)
            changed += [(part, j1, (acc[j1] if j1 < len(acc) else '')[:80]) for op, i1, i2, j1, j2 in sm.get_opcodes()
                        if op != 'equal']
    dup = [k for k, v in ids.items() if v > 1]
    print('duplicate revision ids:', dup[:10] or 'none'); ok &= not dup
    if fmt:
        warn.append(f'formatting revisions (not verified by this check): {dict(fmt)}')
    print(f'inserted text with ";" or em dash (citations may legitimately use ";"): {len(bad_style)}')
    for s in bad_style[:15]:
        print('   ', s)
    print(f'paragraphs changed by the update (inspect these pages visually): {len(changed)}')
    for c in changed[:a.max_lines]:
        print('   ', c)
    for w in warn:
        print('WARN', w)
    if a.render:
        exe = shutil.which('soffice') or shutil.which('libreoffice') or next(
            (x for x in ('/Applications/LibreOffice.app/Contents/MacOS/soffice',
                         r'C:\Program Files\LibreOffice\program\soffice.exe') if os.path.exists(x)), None)
        if not exe:
            print('WARN --render: LibreOffice not found; open the draft in Word and inspect the changed pages')
        else:
            with tempfile.TemporaryDirectory() as td:
                src = os.path.join(td, 'accepted.docx')
                accepted_copy(a.draft, src)
                subprocess.run([exe, '-env:UserInstallation=file://' + os.path.join(td, 'profile').replace(os.sep, '/'),
                                '--headless', '--convert-to', 'pdf', '--outdir', td, src], check=False,
                               capture_output=True)
                pdf = os.path.join(td, 'accepted.pdf')
                if os.path.exists(pdf):
                    shutil.move(pdf, a.render); print('rendered (all revisions accepted)', a.render)
                else:
                    print('WARN --render failed')
    print('PASS (text and structure)' if ok else 'FAIL')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
