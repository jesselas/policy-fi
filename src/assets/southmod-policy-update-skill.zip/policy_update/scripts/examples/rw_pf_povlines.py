#!/usr/bin/env python3
"""RWAMOD post-fiscal poverty lines, one pair per system (Python version of the PFI pov lines step).

For each system: collapse the output to households (sum ils_con, ils_taxco, ils_benco; first spl; ses),
take equivalised consumption ils_con/ses, and subtract from the line the UNWEIGHTED mean equivalised NET
indirect tax (ils_taxco - ils_benco)/ses of households within +/-2.5% of the line. Done for the basic line
($povline -> $povline_indir) and the extreme line ($povline_extr -> $povline_extr_indir). The basic line
of the system is spl from the output (the CPI-uprated $povline); the extreme line is spl * $povline_extr /
$povline. The result is the system's NOMINAL post-fiscal line, written as an annual value (#y); spl_rw
10.3 and 10.5 use it without CPI uprating (since the 2026 update). Reproduces the RW_2017 constants
exactly with ils_benco = 0.

usage: python3 $SKILL/scripts/examples/rw_pf_povlines.py --outdir _internal/SOUTHMOD_A4.0_Bundle/Output --years 2017-2026 \
           --csv _internal/RW/Update_2026/T7_rw_edits_e_pf_povlines.csv
Constants are read from the model XML (constdef_rw 9.1) for each system.
"""
import argparse, csv, os, xml.etree.ElementTree as ET
import pandas as pd

N = '{http://euromod.com/CountryConfig.xsd}'
XML = 'RW/SOUTHMOD_A4.0_RW/XMLParam/Countries/RW/RW.xml'


def constants():
    out = {}
    for s in ET.parse(XML).getroot().iter(N + 'System'):
        c = {}
        for pol in s.iter(N + 'Policy'):
            if pol.findtext(N + 'Name') != 'constdef_rw':
                continue
            for p in pol.iter(N + 'Parameter'):
                nm = p.findtext(N + 'Name') or ''
                if nm.startswith('$povline'):
                    c[nm] = float(p.findtext(N + 'Value').split('#')[0])
        out[s.findtext(N + 'Name')] = c
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--outdir', required=True)
    ap.add_argument('--years', default='2017-2026')
    ap.add_argument('--csv', default='_internal/RW/Update_2026/T7_rw_edits_e_pf_povlines.csv')
    a = ap.parse_args()
    y0, y1 = map(int, a.years.split('-'))
    k = constants(); rows = []
    for y in range(y0, y1 + 1):
        c = k[f'RW_{y}']
        d = pd.read_csv(os.path.join(a.outdir, f'rw_{y}_std.txt'), sep='\t', low_memory=False,
                        usecols=lambda v: v in ('idhh', 'ils_con', 'ils_taxco', 'ils_benco', 'spl', 'ses'))
        if 'ils_benco' not in d:
            d['ils_benco'] = 0.0
        h = d.groupby('idhh').agg(con=('ils_con', 'sum'), tax=('ils_taxco', 'sum'), ben=('ils_benco', 'sum'),
                                  spl=('spl', 'first'), ses=('ses', 'max'))
        cpi = h.spl.iloc[0] / c['$povline']
        eq = h.con / h.ses
        net = (h.tax - h.ben) / h.ses
        for line, target in (('$povline', '$povline_indir'), ('$povline_extr', '$povline_extr_indir')):
            s = c[line] * cpi
            band = (eq >= s * 0.975) & (eq <= s * 1.025)
            v = (s - net[band].mean()) * 12          # nominal, annual (#y)
            print(f'RW_{y} {target}: {c[target]:.4f} -> {v:.4f} ({(v / c[target] - 1) * 100:+.2f}%, '
                  f'households in band: {int(band.sum())})')
            rows.append(dict(op='set_value', system=f'RW_{y}', policy='constdef_rw', fun='9.1', parameter=target,
                             group='', value=f'{v:.4f}#y', comment=''))
    with open(a.csv, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    print(f'written {a.csv} {len(rows)} edits')


if __name__ == '__main__':
    main()
