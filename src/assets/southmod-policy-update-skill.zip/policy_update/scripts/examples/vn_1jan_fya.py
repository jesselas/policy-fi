#!/usr/bin/env python3
"""VNMOD 1 January time point: full-year adjustment (FYA) structure. Run once, after
_internal/VN/Update_2026/T7_vn_edits_d_1jan_base.csv has been applied.

Default (FYA off): every system holds the rules in force on 1 January.
FYA on: within-year changes are added, pro-rated by the months of the calendar year in which
they applied (sources: _internal/VN/Update_2026/work/vn_1jan_history.md, vn_1jan_edits.csv).

1. Time-varying constants move from their DefConst rows (constdef_vn 10.1, tinna_vn 17.2) to two new
   DefConst functions at the end of constdef_vn:
     "1 January values" (on in base, BaseOff = true: switched off when FYA is on) and
     "FYA: full-year averages" (switch, runs only when FYA is on).
2. Additive FYA functions: VAT and SCT on fuels and chemicals (2025, 2026); poor elderly aged 75-80
   moving to the 2.0 coefficient (Decree 335/2026, 3/12 in 2026).
3. Existing elements put under FYA: social pension (poa01_vn 20.4) in VN_2025 at 6/12; COVID policies
   bsacv01_vn, bsacv02_vn in VN_2020 (already pro-rated x 3/12 in their formulas).
4. FYA default 'off' for every system and dataset in VN_dataconfig.xml (VN_2020 was 'on').
UNTESTED IN EUROMOD.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from edit_model import Model, NS, t as tx
from fya import add_ext_function, attach_existing, ensure_ext_switches

B = Path('VN/SOUTHMOD_A4.0_VN/XMLParam/Countries/VN')
m = Model(B / 'VN.xml')

# ---- 1. time-varying constants: (name, where defined now, {system: (1 Jan value, FYA value, note)})
C = {
    '$tscer_r': ('constdef_vn', '10.1', {
        'VN_2017': ('0.22', '0.22-0.005*7/12', 'OA/OD 1% -> 0.5% from 1 Jun 2017 (Decree 44/2017)'),
        'VN_2021': ('0.215', '0.215-0.005*6/12-0.01*3/12', 'OA/OD 0% from 1 Jul 2021, employer UI 0% from 1 Oct 2021 (Res. 68/NQ-CP, 116/NQ-CP)'),
        'VN_2022': ('0.20', '0.20+0.005*6/12+0.01*3/12', 'OA/OD restored 1 Jul 2022, employer UI 1 Oct 2022')}),
    '$tinta01': ('tinna_vn', '17.2', {
        'VN_2013': ('4000#m', '6500#m', '9m from 1 Jul 2013: annual 78m = 4m x 6 + 9m x 6 (Official Letter 336/TCT-TNCN)')}),
    '$tinta02': ('tinna_vn', '17.2', {
        'VN_2013': ('1600#m', '2600#m', '3.6m from 1 Jul 2013')}),
    '$vat_r3': ('constdef_vn', '10.1', {
        'VN_2022': ('0.10', '0.10-0.02*11/12', '8% from 1 Feb 2022 (Res. 43/2022/QH15, Decree 15/2022)'),
        'VN_2023': ('0.10', '0.10-0.02*6/12', '8% from 1 Jul 2023 (Res. 101/2023/QH15, Decree 44/2023)')}),
    '$bed01_amount': ('constdef_vn', '10.1', {
        'VN_2021': ('100#m*(9/12)', '100#m*(9/12)+50#m*(4/12)', '150,000 from school year 2021/22 (Decree 81/2021): Sep-Dec')}),
    '$bot01_amount': ('constdef_vn', '10.1', {
        'VN_2017': ('45#m', '45#m+1.95#m*1/12', 'tier 1 1,549 from 1 Dec 2017'),
        'VN_2019': ('46#m', '46#m+3.87#m*9/12', 'tier 1 1,678 from 20 Mar 2019'),
        'VN_2023': ('50.34#m', '50.34#m+1.50#m*8/12+2.34#m*2/12', 'tier 1 1,728 from 4 May 2023, 1,806 from 9 Nov 2023'),
        'VN_2024': ('54.18#m', '54.18#m+2.61#m*3/12', 'tier 1 1,893 from 11 Oct 2024'),
        'VN_2025': ('56.79#m', '56.79#m+2.73#m*8/12', 'tier 1 1,984 from 10 May 2025')}),
    '$poa01_amount_aged_60_80': ('constdef_vn', '10.1', {
        'VN_2021': ('1.5*270#m', '1.5*(270#m+90#m*6/12)', 'standard 360,000 from 1 Jul 2021 (Decree 20/2021)'),
        'VN_2024': ('1.5*360#m', '1.5*(360#m+140#m*6/12)', 'standard 500,000 from 1 Jul 2024 (Decree 76/2024)'),
        'VN_2026': ('1.5*500#m', '1.5*(500#m+40#m*3/12)', 'standard 540,000 (Decree 335/2026, in force 5 Oct 2026): 3/12')}),
    '$poa01_amount_aged_over_80': ('constdef_vn', '10.1', {
        'VN_2021': ('2*270#m', '2*(270#m+90#m*6/12)', 'standard 360,000 from 1 Jul 2021'),
        'VN_2024': ('2*360#m', '2*(360#m+140#m*6/12)', 'standard 500,000 from 1 Jul 2024'),
        'VN_2026': ('2*500#m', '2*(500#m+40#m*3/12)', 'standard 540,000: 3/12')}),
    '$poa01_amount_aged_75_80_ethnic': ('constdef_vn', '10.1', {
        'VN_2021': ('0#m', '360#m*6/12', 'group created from 1 Jul 2021 (Decree 20/2021)'),
        'VN_2024': ('1*360#m', '1*(360#m+140#m*6/12)', 'standard 500,000 from 1 Jul 2024'),
        'VN_2026': ('1*500#m', '1*(500#m+40#m*3/12)', 'standard 540,000: 3/12')}),
    '$bsaoa_amount': ('constdef_vn', '10.1', {
        'VN_2026': ('500#m', '500#m+40#m*3/12', 'social pension 540,000 (Decree 335/2026): 3/12')}),
}
targets = sorted({s for _, _, d in C.values() for s in d})
params_base, params_fya, vb, vf = [], [], {}, {}
for name, (pol, fun, d) in C.items():
    params_base.append((name, 'n/a', 'formula', '', f'1 January value (time point). Within-year change under FYA'))
    params_fya.append((name, 'n/a', 'formula', '', 'Full-year average (FYA on)'))
    for s in targets:
        b, f, note = d.get(s, ('n/a', 'n/a', ''))
        vb.setdefault(s, {})[(name, '')] = b
        vf.setdefault(s, {})[(name, '')] = f
for s in targets:  # functions are on only where at least one constant is defined
    pass
n1 = add_ext_function(m, 'constdef_vn', 'DefConst',
                      'Time-varying constants: values on 1 January (switched off when FYA is on). 2026 update',
                      params_base, targets, values_by_system=vb, switch='on', base_off=True)
n2 = add_ext_function(m, 'constdef_vn', 'DefConst',
                      'FYA: full-year averages of time-varying constants (pro-rated by months in force). 2026 update',
                      params_fya, targets, values_by_system=vf, switch='switch')
# remove the moved constants from their original rows (else they would be defined twice)
import csv
log = []
for name, (pol, fun, d) in C.items():
    for s in d:
        p = m.param(m.function(m.policy(s, pol), fun), name, '')
        old = tx(p, 'Value')
        m.replace_child(p, 'Value', 'n/a')
        p = m.param(m.function(m.policy(s, pol), fun), name, '')
        m.replace_child(p, 'Comment', (tx(p, 'Comment') + ' | ' if tx(p, 'Comment') else '') +
                        '2026 update: defined in constdef_vn (1 January value / FYA average)')
        log.append((s, pol, fun, name, old))

# ---- 2. additive FYA functions
fuel_chem = 'x045301+x045302+x045303+x045304+x045305+x131201+x131202+x131203+x131204+x131205+x05611'
add_ext_function(m, 'tva_vn', 'ArithOp', 'FYA: within-year VAT changes (2025: 8% on fuels, LPG and chemicals from 1 Jul, 6/12; 2026: no VAT on diesel, kerosene, mazut 16 Apr-30 Sep, 6/12). 2026 update',
    [('Formula', '0', 'formula', '', 'Negative = VAT saved during the months of the change'),
     ('Output_Add_Var', 'tva_s', 'variable', '', ''),
     ('TAX_UNIT', 'tu_household_vn', 'taxunit', '', '')],
    ['VN_2025', 'VN_2026'],
    values_by_system={'VN_2025': {('Formula', ''): f'-({fuel_chem})*($vat_r2-$vat_r3)*6/12'},
                      'VN_2026': {('Formula', ''): '-(x045301+x045302+x045303)*$vat_r3*6/12'}})
add_ext_function(m, 'tex_vn', 'ArithOp', 'FYA: within-year VAT change on petrol (2025: 8% from 1 Jul, 6/12; 2026: no VAT 26 Mar-30 Sep, 6/12). 2026 update',
    [('Formula', '0', 'formula', '', ''), ('Output_Add_Var', 'tva_s', 'variable', '', ''),
     ('TAX_UNIT', 'tu_individual_vn', 'taxunit', '', '')],
    ['VN_2025', 'VN_2026'],
    values_by_system={'VN_2025': {('Formula', ''): '-(x045211+tex04_s)*($vat_r2-$vat_r3)*6/12'},
                      'VN_2026': {('Formula', ''): '-(x045211+tex04_s)*$vat_r3*6/12'}})
add_ext_function(m, 'tex_vn', 'ArithOp', 'FYA: petrol SCT 2026 (0% 26 Mar-30 Jun, 3/12; E5/E10 average 7.5% from 1 Jul, 6/12; annual 6.25% instead of 10%). 2026 update',
    [('Formula', '-x045211*(0.10*3/12+0.025*6/12)', 'formula', '', 'VAT on the SCT change not adjusted (small)'),
     ('Output_Add_Var', 'tex_s', 'variable', '', ''), ('TAX_UNIT', 'tu_individual_vn', 'taxunit', '', '')],
    ['VN_2026'])
add_ext_function(m, 'poa01_vn', 'BenCalc', 'FYA: Decree 335/2026 moves poor elderly aged 75-80 without support from coefficient 1.5 to 2.0 (in force 5 Oct 2026, 3/12). 2026 update',
    [('Comp_Cond', '(dag>=75 & dag<=80) & i_aged_16_59#1=0 & (i_poor_hh_urban_up=1 | i_poor_hh_rural_up=1)', 'condition', '1', ''),
     ('Comp_perTU', '(2-1.5)*540#m*3/12', 'formula', '1', ''),
     ('#_Level', 'tu_household_vn', 'taxunit', '1', ''),
     ('Output_Add_Var', 'poa01_s', 'variable', '', ''), ('TAX_UNIT', 'tu_individual_vn', 'taxunit', '', '')],
    ['VN_2026'])

# ---- 3. existing elements under FYA
attach_existing(m, 'Function', 'VN_2025', 'poa01_vn', '20.4')
for g in ('1', '2'):
    p = m.param(m.function(m.policy('VN_2025', 'poa01_vn'), '20.4'), 'Comp_perTU', g)
    m.replace_child(p, 'Value', '$bsaoa_amount*6/12')
    p = m.param(m.function(m.policy('VN_2025', 'poa01_vn'), '20.4'), 'Comp_perTU', g)
    m.replace_child(p, 'Comment', '2026 update: from 1 Jul 2025 only (FYA): 6/12 of the monthly amount')
for pol in ('bsacv01_vn', 'bsacv02_vn'):
    attach_existing(m, 'Policy', 'VN_2020', pol)
m.save()

# ---- 4. dataconfig
print('FYA switches added/forced:', ensure_ext_switches(B / 'VN_dataconfig.xml', 'FYA', 'off', force=True))
print('constants moved:', len(log), '| base/FYA constant functions in', n1, n2, 'systems')
with open('_internal/VN/Update_2026/work/vn_1jan_moved_constants.csv', 'w', newline='') as fh:
    w = csv.writer(fh); w.writerow(['system', 'policy', 'fun', 'constant', 'old_value_in_row']); w.writerows(log)
