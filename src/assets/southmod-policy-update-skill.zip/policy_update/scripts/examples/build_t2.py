#!/usr/bin/env python3
"""Build the task 2 parameter-confirmation workbook for a national team.

Usage: python3 _internal/tools/build_t2.py CC
Reads the edited single-country bundle (<CC>/SOUTHMOD_A4.0_<CC>), the COICOP table, the input
data (for average spending per item), and _internal/<CC>/Update_2026/work/t2_config_<cc>.json:
  {"model": "UGAMOD", "systems": ["UG_2024","UG_2025"], "new": ["UG_2026"],
   "data": "ug_2024_a1", "timepoint": "1 July 2026 (FY2026/27)",
   "cpi_years": [2022, ...], "cpi_note": "...", "questions": ["...", ...],
   "labels": {"policy": "Instrument name"}, "extra_rows": [[...]]}
Writes <CC>/Update_2026/T2_<MODEL>_2026_parameters_for_team.xlsx.
"""
import csv, json, os, re, subprocess, sys, tempfile
import pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
import team_workbook as tw

cc = sys.argv[1].upper(); lc = cc.lower()
W = f'{cc}/Update_2026'
INTERNAL = f'_internal/{cc}/Update_2026'
cfg = json.load(open(f'{INTERNAL}/work/t2_config_{lc}.json'))
xml = f'{cc}/SOUTHMOD_A4.0_{cc}/XMLParam/Countries/{cc}/{cc}.xml'
tmp = tempfile.mktemp(suffix='.csv')
subprocess.run([sys.executable, '_internal/tools/extract_params.py', xml, tmp], check=True)
d = pd.read_csv(tmp, dtype=str).fillna('')
os.remove(tmp)
old, new = cfg['systems'], cfg['new']
allsys = old + new
# edit comments (the proposals' sources)
notes = {}
import glob
for ed in sorted(glob.glob(f'{INTERNAL}/T7_{lc}_edits*.csv')):
    if open(ed, encoding='utf-8-sig').readline().startswith('# SUPERSEDED'):
        continue
    for r in csv.DictReader(open(ed, encoding="utf-8-sig")):
        if r['op'] in ('set_value', 'add_param_all') and r['comment']:
            k = (r['policy'], r['parameter'], r['group'])
            tag = '' if r['system'] in new else f"{r['system']}: "
            if k not in notes or r['system'] in new:
                notes[k] = (tag + r['comment'])[:300]

# ---------- parameters sheet
num = re.compile(r'^-?[\d\.,]+\s*(#[mywqd]\d?)?$')
lit = re.compile(r'(?<![\w$])(\d+(\.\d+)?|\.\d+)(#[mywqd])?(?![\w])')
skip_pol = re.compile(r'(uprate|ilsdef|ildef|output|tudef|neg|lma|setdefault|xhhadj|random|ses|spl|tva|tex)', re.I)
x = d[d.system.isin(allsys) & ~d.policy.str.match(skip_pol)]
x = x[x.function.str.lower() != 'defvar']
x = x[~x.parameter.isin(['TAX_UNIT', 'nDecimals', 'Seed', 'Output_Var', 'Output_Add_Var', 'Name', 'Var_Monetary'])]
cond = x.parameter.str.contains('Cond', case=False)
keep = x.value.str.strip().str.match(num) | (x.value.apply(lambda v: bool(lit.search(v))) & x.parameter.str.contains('Cond|perTU|perElig|Formula|Band|Base', case=False))
keep &= ~cond | x.value.str.contains(r'#|dag', regex=True)
keys = x[keep][['pol_no', 'policy', 'pol_comment', 'fun_no', 'fun_comment', 'parameter', 'group']].drop_duplicates(['policy', 'fun_no', 'parameter', 'group'])
# only rows that are active (not n/a) in the latest old or any new system
rows, cur = [], None
labels = cfg.get('labels', {})
for _, k in keys.iterrows():
    sub = d[(d.policy == k.policy) & (d.fun_no == k.fun_no) & (d.parameter == k.parameter) & (d.group == k.group)]
    vals = {s: sub[sub.system == s] for s in allsys}
    def val(s):
        v = vals[s]
        if v.empty: return ''
        v = v.iloc[0]
        return 'n/a' if 'n/a' in (v.pol_switch, v.fun_switch) or v.value == 'n/a' else v.value
    if all(val(s) in ('', 'n/a') for s in [old[-1]] + new):
        continue
    if k.policy != cur:
        cur = k.policy
        rows.append([f'## {labels.get(k.policy, k.pol_comment)} ({k.policy})'])
    ref = sub[sub.system == old[-1]] if not sub[sub.system == old[-1]].empty else sub
    com = (ref.par_comment.iloc[0] or ref.fun_comment.iloc[0]).split(' | 2026 update')[0]
    nv = [val(s) for s in new]
    changed = any(v != val(old[-1]) for v in nv)
    note = notes.get((k.policy, k.parameter, k.group), 'No change found' if not changed else 'Changed (see T1 document)')
    rows.append([f'{k.fun_no} {k.parameter}' + (f' #{k.group}' if k.group else ''), com] + [val(s) for s in old] + nv + [note])
cols = ['Model row, parameter', 'Description (model comment)'] + [f'{s} (model)' for s in old] + [f'{s} proposed' for s in new] + ['Basis of proposal']
kinds = ['grey', 'grey'] + ['grey'] * len(old) + ['blue'] * len(new) + ['blue']
for extra in cfg.get('extra_rows', []):
    rows.append(extra)

wb = tw.new_workbook()
tw.readme(wb, f"{cfg['model']} 2026 update: policy parameters to confirm",
          [f"PURPOSE", f"Please confirm or correct the rules in force on {cfg['timepoint']}, as proposed by UNU-WIDER from online research.",
           "Only recent systems are shown. Older systems appear only where we propose a correction.",
           "", "HOW TO FILL IN",
           "1. In each green column choose Confirm, Change or Not sure (dropdown).",
           "2. If Change: write the correct value and the legal source (act, gazette, URA/RRA/GDT notice, page).",
           "3. Add anything we missed on the sheet 'New or missing'.", "4. Answer the questions on the sheet 'Questions'.", "",
           "COLOURS"] + tw.legend_lines() + ["", "SHEETS",
           "Parameters: tax, contribution and benefit parameters by model row.",
           "COICOP_VAT_excise: every expenditure item with its VAT status and excise treatment.",
           "CPI: consumer price indices used for uprating.", "New or missing: space for changes not listed.",
           "Questions: specific questions from our research.", "",
           "Model conventions: #y = per year, #m = per month; amounts in national currency; rates as shares (0.18 = 18%)."])
tw.table(wb, 'Parameters', f"{cfg['model']}: parameters by policy (rules on {cfg['timepoint']})",
         'Grey = current model; blue = our proposal; green = your answer.', cols, rows, kinds,
         widths=[26, 50] + [16] * (len(old) + len(new)) + [45])

# ---------- COICOP sheet
ct = pd.read_csv(f'{INTERNAL}/work/{lc}_coicop_vat_excise.csv', dtype=str).fillna('')
base = set(ct.variable)
ct = ct[~ct.variable.apply(lambda v: v.startswith('x3') and ('x' + v[2:]) in base)]  # drop formal-outlet copies
# average monthly spending per household (weighted) for priority
inp = f"{cc}/SOUTHMOD_A4.0_{cc}/Input/{cfg['data']}.txt"
hdr = open(inp).readline().rstrip('\n').split('\t')
use = ['idhh', 'dwt'] + [v for v in ct.variable if v in hdr]
df = pd.read_csv(inp, sep='\t', usecols=use)
hh = df.groupby('idhh').first()
w = hh.dwt
mean = {v: (hh[v] * w).sum() / w.sum() for v in use[2:]}
tot = sum(mean.values())
last = old[-1]
exc_col = f'excise {last}'
vat_col_x = f'VAT via excise policy {last}'
consts = d[(d.system.isin([last] + new)) & (d.function.str.lower() == 'defconst')]
cval = {(s, p): v for s, p, v in zip(consts.system, consts.parameter, consts.value)}
crow = []
VATLAB = cfg.get('vat_labels', {})
def vstat(r, s_):
    v = r.get(s_, '')
    if r.get(f'VAT via excise policy {s_}', ''): return 'VAT charged with excise'
    if not v: return ''
    if 'exempt' in v: return 'Exempt or zero-rated'
    il = v.split(' (')[0]
    return VATLAB.get(il, 'Standard rated')
for _, r in ct.iterrows():
    ex = r.get(exc_col, '')
    exc_consts = sorted(set(re.findall(r'\$\w+', ex)))
    rate_last = '; '.join(f'{c}={cval.get((last, c), "")}' for c in exc_consts)
    ex_new = r.get(f'excise {new[-1]}', ex)
    exc_new = sorted(set(re.findall(r'\$\w+', ex_new)))
    rate_new = '; '.join(f'{c}={cval.get((new[-1], c), "")}' for c in exc_new)
    vs_new = [vstat(r, s_) for s_ in new]
    prop = cfg.get('coicop_proposals', {}).get(r.variable)
    if prop:
        vs_new = [prop[0] or v for v in vs_new]; rate_new = prop[1]
    share = mean.get(r.variable)
    crow.append([r.variable, r.label, round(share, 1) if share is not None else '', round(100 * share / tot, 2) if share else 0,
                 vstat(r, last), re.sub(r'\s*\[.*?\]', '', ex), rate_last] + vs_new + [rate_new])
ccols = ['Variable', 'Item', f'Average spending per household per month ({cfg["data"]}, before uprating)', 'Share of spending on listed items (%)',
         f'VAT status {last} (model)', 'Excise function in model', f'Excise rate {last} (model)'] + [f'VAT status {s_} proposed' for s_ in new] + [f'Excise rate {new[-1]} proposed']
tw.table(wb, 'COICOP_VAT_excise', f"{cfg['model']}: VAT status and excise by expenditure item",
         'Exempt and zero-rated items are treated the same in the model. Please check the items with the largest shares first.',
         ccols, crow, ['grey'] * 7 + ['blue'] * (len(new) + 1), widths=[12, 45, 16, 12, 22, 40, 30] + [22] * len(new) + [30])

# ---------- CPI sheet
up = pd.read_csv(f'{INTERNAL}/work/{lc}_uprating_indices.csv', dtype=str).fillna('') if False else None
from xml.etree import ElementTree as ET
ns = '{http://euromod.com/CountryConfig.xsd}'
root = ET.parse(xml).getroot()
yrs = [str(y) for y in cfg['cpi_years']]
prow = []
for u in root.iter(ns + 'UpratingIndex'):
    yv = dict(p.split('|') for p in (u.findtext(ns + 'YearValues') or '').split('°') if '|' in p)
    prow.append([u.findtext(ns + 'Reference'), u.findtext(ns + 'Description'), (u.findtext(ns + 'Comment') or '').strip()] +
                [yv.get(y, '') for y in yrs[:-len(new)]] + [yv.get(y, '') for y in yrs[-len(new):]] + [cfg.get('cpi_note', '')])
tw.table(wb, 'CPI', f"{cfg['model']}: uprating indices", cfg.get('cpi_instruction', 'Please confirm the index values and the month used.'),
         ['Index', 'Description', 'Model comment'] + yrs[:-len(new)] + [f'{y} proposed' for y in yrs[-len(new):]] + ['Source of proposal'],
         prow, ['grey'] * (3 + len(yrs) - len(new)) + ['blue'] * (len(new) + 1), widths=[22, 30, 40] + [10] * len(yrs) + [40])

# ---------- corrections to earlier systems (optional)
if cfg.get('corrections'):
    cr = [list(x) for x in cfg['corrections']]
    tw.table(wb, 'Earlier systems', 'Corrections we propose for earlier systems',
             'Please confirm or correct. These change the results of earlier years.',
             ['System(s)', 'Policy, row, parameter', 'Old value', 'New value (1 January)', 'Full-year adjustment (FYA)', 'Source / reason'],
             cr, ['grey', 'grey', 'grey', 'blue', 'blue', 'blue'], widths=[14, 34, 20, 22, 40, 60])

# ---------- new/missing and questions
tw.table(wb, 'New or missing', 'Changes we missed (new taxes, benefits, rates, exemptions)',
         'One row per change. Please give the legal source and the date it took effect.',
         ['Instrument', 'Description of change', 'Old value', 'New value', 'Effective date', 'Legal source'],
         [[''] * 6 for _ in range(15)], ['green'] * 6, team=False, widths=[25, 50, 15, 15, 15, 40])
tw.table(wb, 'Questions', 'Questions from our research', 'Please answer in the green column.',
         ['#', 'Question'], [[i + 1, q] for i, q in enumerate(cfg['questions'])], ['grey', 'grey'], widths=[5, 110])
ws = wb['Questions']
out = f"{W}/T2_{cfg['model']}_2026_parameters_for_team.xlsx"
wb.save(out)
print('written', out, '| parameter rows', len(rows), '| items', len(crow), '| indices', len(prow))
