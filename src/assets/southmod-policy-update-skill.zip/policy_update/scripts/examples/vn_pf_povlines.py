#!/usr/bin/env python3
"""VNMOD post-fiscal poverty lines (Python version of VHLSS20XX Step 7 - Calculate post-fiscal pov lines.do).

For each system year and area (urban dur==1, rural dur==0): collapse the EUROMOD output to households
(sum ils_taxco, ils_benco, ils_con; first spl, ses), take equivalised consumption ils_con/ses and equivalised
NET indirect taxes (ils_taxco - ils_benco)/ses, and subtract the UNWEIGHTED mean equivalised net indirect tax of households
whose equivalised consumption is within +/-2.5% of spl from spl (as in the Stata code). Indirect benefits
(ils_benco, the fuel subsidy bof_s from 2022) enter with a minus sign, matching ils_dispy_pf = ils_dispy - ils_taxco + ils_benco.
Lower lines use the POV-off output (spl = lower line); upper lines use the POV-on output (spl = upper line).

Usage:
  python3 _internal/tools/vn_pf_povlines.py --outdir _internal/SOUTHMOD_A4.0_Bundle/Output --years 2018-2026 \
      [--pov-on-suffix _POVon] [--csv _internal/VN/Update_2026/T7_vn_edits_j_pf_povlines.csv]
POV-off files: vn_<year>_std.txt; POV-on files: vn_<year>_std<suffix>.txt (rename after the POV-on run).
Writes an edit CSV for _internal/tools/edit_model.py that sets $pline_{urban,rural}_pf and _pf_up in constdef_vn 10.1.
Values are monthly (thousand VND) and written with #m, as in the model.
"""
import argparse, csv, os
import pandas as pd

COLS = ['idhh', 'idperson', 'dur', 'ils_taxind', 'ils_taxco', 'ils_benco', 'ils_con', 'spl', 'ses']


def pf_line(path, urban):
    d = pd.read_csv(path, sep='\t', low_memory=False, usecols=lambda c: c.lower() in COLS)
    d.columns = [c.lower() for c in d.columns]
    if 'ils_taxind' not in d.columns:  # indirect taxes are in ils_taxco in current VNMOD outputs
        d['ils_taxind'] = d['ils_taxco']
    if 'ils_benco' not in d.columns:
        d['ils_benco'] = 0.0
    d['ils_taxind'] = d['ils_taxind'] - d['ils_benco']  # net indirect tax
    d = d[d.dur == (1 if urban else 0)].sort_values(['idhh', 'idperson'])
    h = d.groupby('idhh').agg(ils_taxind=('ils_taxind', 'sum'), ils_con=('ils_con', 'sum'),
                              spl=('spl', 'first'), ses=('ses', 'first'))
    eq_exp = h.ils_con / h.ses
    eq_tax = h.ils_taxind / h.ses
    band = (eq_exp >= h.spl * 0.975) & (eq_exp <= h.spl * 1.025)
    spl = h.spl.iloc[0]
    return spl - eq_tax[band].mean(), spl, int(band.sum())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--outdir', required=True)
    ap.add_argument('--years', default='2018-2026')
    ap.add_argument('--pov-on-suffix', default='_POVon')
    ap.add_argument('--csv', default='_internal/VN/Update_2026/T7_vn_edits_j_pf_povlines.csv')
    a = ap.parse_args()
    y0, y1 = map(int, a.years.split('-'))
    rows = []
    for y in range(y0, y1 + 1):
        off = os.path.join(a.outdir, f'vn_{y}_std.txt')
        on = os.path.join(a.outdir, f'vn_{y}_std{a.pov_on_suffix}.txt')
        for label, path, up in (('lower', off, False), ('upper', on, True)):
            if not os.path.exists(path):
                print(f'{y} {label}: {path} missing, skipped')
                continue
            for urban in (True, False):
                v, spl, n = pf_line(path, urban)
                area = 'urban' if urban else 'rural'
                const = f'$pline_{area}_pf' + ('_up' if up else '')
                print(f'{y} {label:5s} {area}: spl {spl:.2f} -> post-fiscal {v:.2f} (households in band: {n})')
                rows.append(dict(op='set_value', system=f'VN_{y}', policy='constdef_vn', fun='10.1', parameter=const,
                                 group='', value=f'{v:.2f}#m',
                                 comment=f'2026 update: post-fiscal line recomputed (_internal/tools/vn_pf_povlines.py; {n} households within 2.5% of spl)'))
    with open(a.csv, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['op', 'system', 'policy', 'fun', 'parameter', 'group', 'value', 'comment'])
        w.writeheader(); w.writerows(rows)
    print('written', a.csv, len(rows), 'edits (apply with: python3 _internal/tools/edit_model.py VN/SOUTHMOD_A4.0_VN VN', a.csv + ')')


if __name__ == '__main__':
    main()
