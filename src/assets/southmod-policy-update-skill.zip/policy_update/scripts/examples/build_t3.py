#!/usr/bin/env python3
"""Build the task 3 external statistics workbook (team-facing and read by the task 6 code).

Usage: python3 $SKILL/scripts/examples/build_t3.py CC
Inputs:
  _internal/<CC>/Update_2026/work/T6_<cc>_test_external_data.xlsx  sheet `data`: the keys (table_id, row_id,
      indicator, unit, year) the task 6 code expects, with the current CR values.
  _internal/<CC>/Update_2026/work/<cc>_external_stats.csv            online research (new and revised values).
  _internal/<CC>/Update_2026/work/t3_config_<cc>.json                {"model", "years": [...],
      "map": {"<research table_id>|<research indicator>": "<table_id>|<row_id>", ...},
      "instructions": [...]}
Selection per (table_id, row_id, year): best research value by status rank
(final > provisional > estimate), else the CR value. Partial-year, target, budget, projection,
alternative-source and upper-bound values never become `value`; they are listed under
`alternatives` for the team.
Output: <CC>/Update_2026/T3_<MODEL>_external_statistics.xlsx with sheets README, one overview
per table (wide, read-only), and `data` (long; contract columns + team columns).
"""
import json, os, re, sys
import pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
import team_workbook as tw
from openpyxl.styles import Font

cc = sys.argv[1].upper(); lc = cc.lower()
W = f'{cc}/Update_2026'
INTERNAL = f'_internal/{cc}/Update_2026'
cfg = json.load(open(f'{INTERNAL}/work/t3_config_{lc}.json'))
keys = pd.read_excel(f'{INTERNAL}/work/T6_{lc}_test_external_data.xlsx', sheet_name='data', dtype={'table_id': str, 'row_id': str})
res = pd.read_csv(f'{INTERNAL}/work/{lc}_external_stats.csv', dtype=str).fillna('')
res = res[~res.status.str.startswith('CR')]
years = cfg['years']
for t_, rid_, ind_, unit_ in cfg.get('extra_rows', []):
    keys = pd.concat([keys, pd.DataFrame([{'table_id': t_, 'row_id': rid_, 'indicator': ind_, 'unit': unit_, 'year': years[0],
                                           'value': None, 'status': 'missing', 'source': None, 'note': 'Second source (added 2026 update)'}])], ignore_index=True)

EXCL = re.compile(r'low confidence|partial|target|budget|projection|alt\.? source|upper bound|not like-for-like|Q1-Q3|quarterly', re.I)
def rank(st):
    s = st.lower()
    if EXCL.search(s): return None
    if s.startswith('final') or 'audited' in s or 'outturn' in s or s.startswith('reported') or s == 'revised': return 1
    if 'provisional' in s or 'preliminary' in s or 'press' in s: return 2
    if 'estimate' in s or 'modelled' in s or 'model-based' in s: return 3
    if s == 'missing': return None
    return 4

cand = {}
for _, r in res.iterrows():
    k = cfg['map'].get(f'{r.table_id}|{r.indicator}')
    if not k: continue
    t, rid = k.split('|')
    try: y = int(float(r.year))
    except ValueError: continue
    if f'{r.table_id}|{r.indicator}' in cfg.get('fill_only', []):
        r = r.copy(); r['fill_only'] = True
    ov = cfg.get('status_override', {}).get(f'{r.table_id}|{r.indicator}')
    if ov:
        r = r.copy(); r['status'] = ov
    cand.setdefault((t, rid, y), []).append(r)

rows = []
base = keys.copy()
# make sure every row_id has every year
full = []
for (t, rid), g in base.groupby(['table_id', 'row_id'], sort=False):
    g0 = g.iloc[0]
    for y in years:
        m = g[g.year == y]
        full.append(m.iloc[0].to_dict() if len(m) else {**g0.to_dict(), 'year': y, 'value': None, 'status': 'missing', 'source': None})
for r in full:
    t, rid, y = r['table_id'], r['row_id'], int(r['year'])
    cr_val = r['value'] if r.get('status') == 'CR' else None
    drop = cfg.get('drop_cr', {}).get(f'{t}|{rid}', {})
    if str(y) in drop:
        cr_val = None
        r = {**r, 'value': None, 'status': 'missing', 'note': drop[str(y)]}
    cs = cand.get((t, rid, y), [])
    good = sorted([c for c in cs if rank(c.status)], key=lambda c: rank(c.status))
    alts = '; '.join(f'{c.value} ({c.status}, {c.source_short})' for c in cs if not rank(c.status))
    has_cr = cr_val is not None and not pd.isna(cr_val)
    if has_cr:  # an estimate or another source's series never replaces a published value
        is_est = [rank(c.status) >= 3 or c.get('fill_only', False) is True for c in good]
        est = [c for c, e in zip(good, is_est) if e]
        good = [c for c, e in zip(good, is_est) if not e]
        alts = '; '.join(filter(None, [alts] + [f'{c.value} ({c.status}, {c.source_short})' for c in est]))
    if good:
        b = good[0]
        val, st, src = float(b.value) if b.value not in ('', None) else None, b.status, b.source_short
        url, note = b.source_url, b.note
        diff = ''
        if cr_val is not None and val is not None and cr_val and abs(val / cr_val - 1) > 0.01:
            diff = f"Revised: current report has {cr_val}"
    else:
        val, st = (cr_val, 'CR') if cr_val is not None and not pd.isna(cr_val) else (None, 'missing')
        src, url, note, diff = (r.get('source') if st == 'CR' else None), None, r.get('note'), ''
    rows.append([t, rid, r['indicator'], r['unit'], y, val, st, src, (note or '') if not isinstance(note, float) else '',
                 url or '', diff, alts])

cols = ['table_id', 'row_id', 'indicator', 'unit', 'year', 'value', 'status', 'source', 'note',
        'source_url', 'change_vs_current_report', 'alternatives']
df = pd.DataFrame(rows, columns=cols)
for src, dst in cfg.get('cell_moves', {}).items():  # "table|row|year" -> "table|row"
    t0, r0, y0 = src.split('|'); t1, r1 = dst.split('|')
    a = (df.table_id == t0) & (df.row_id == r0) & (df.year == int(y0))
    b = (df.table_id == t1) & (df.row_id == r1) & (df.year == int(y0))
    if a.any() and b.any():
        for c in ['value', 'status', 'source', 'note', 'source_url']:
            df.loc[b, c] = df.loc[a, c].values
        df.loc[a, ['value', 'status', 'source', 'note', 'source_url']] = [None, 'missing', None, f'moved to {r1} (different coverage)', '']

wb = tw.new_workbook()
tw.readme(wb, f"{cfg['model']} 2026 update: external statistics for the country report", cfg['instructions'] + [''] + tw.legend_lines())
# overview sheets
for t, g in df.groupby('table_id', sort=False):
    wide = g.pivot_table(index=['row_id', 'indicator', 'unit'], columns='year', values='value', aggfunc='first', sort=False)
    stat = g.pivot_table(index=['row_id', 'indicator', 'unit'], columns='year', values='status', aggfunc='first', sort=False)
    order = list(dict.fromkeys(zip(g.row_id, g.indicator, g.unit)))
    orows = []
    for key in order:
        vals = [wide.loc[key].get(y) if key in wide.index else None for y in years]
        sts = [stat.loc[key].get(y) if key in stat.index else '' for y in years]
        orows.append([key[1], key[2]] + [('' if v is None or pd.isna(v) else v) for v in vals] +
                     ['; '.join(f'{y}: {s}' for y, s in zip(years, sts) if s and s != 'CR')])
    tw.table(wb, f'Table {t}', f'Table {t}: external statistics (overview)',
             'Overview only. Please correct values on the sheet "data" (green columns).',
             ['Indicator', 'Unit'] + [str(y) for y in years] + ['Status of new values'], orows,
             ['grey', 'grey'] + ['blue'] * len(years) + ['grey'], team=False, widths=[40, 16] + [11] * len(years) + [50])
ws = tw.table(wb, 'data', 'External statistics: one row per value (read by the validation code)',
              '(header in row 1 so the validation code can read it) Blue = our tentative value. If a value is wrong or missing, write the correct one in "Team: correct value" with its source.',
              cols, df.values.tolist(), ['grey'] * 5 + ['blue'] * 7, widths=[8, 10, 34, 14, 6, 12, 18, 22, 40, 30, 24, 40], top=1)
out = f"{W}/T3_{cfg['model']}_external_statistics.xlsx"
wb.save(out)
print('written', out, '| rows', len(df), '| filled', df.value.notna().sum(), '| new/revised', (~df.status.isin(['CR', 'missing'])).sum(),
      '| missing', (df.status == 'missing').sum())
