# Examples from a past update (adapt, do not run as is)

They assume the workspace layout of `references/01_intake_and_setup.md` (`_internal/<CC>/...`) and the
conventions of particular models (VNMOD, RWAMOD, UGAMOD). Check every convention against your model, and note
that the post-fiscal examples predate the explicit-convention checks of `../pf_povlines.py`.
- `vn_pf_povlines.py`, `rw_pf_povlines.py`, `ug_pf_povlines.py`: post-fiscal lines per country (urban/rural with
  POV-on upper lines; basic and extreme lines read from constants; eight regional groups). The generic
  `../pf_povlines.py` covers the method; these show how results were written back as edit CSVs.
- `build_t2.py`, `build_t3.py`: team workbook builders (config JSON per country; T3 merges research values with
  the report's current values by status rank).
- `vn_1jan_fya.py`: converting a model from a 1 July to a 1 January time point, with full-year-adjustment rows.
- `coicop_table.py`, `inventory.py`: VAT status and excise by COICOP item and system; constants and uprating tables.
