# Examples from the 2026 VNMOD / RWAMOD / UGAMOD update (adapt, do not run as is)

They contain repository paths and country specifics of that project (`_internal/<CC>/...`, `VN/SOUTHMOD_A4.0_VN`).
- `vn_pf_povlines.py`, `rw_pf_povlines.py`, `ug_pf_povlines.py`: post-fiscal lines per country (urban/rural with
  POV-on upper lines; basic and extreme lines read from constants; eight regional groups). The generic
  `../pf_povlines.py` covers the method; these show how results were written back as edit CSVs.
- `build_t2.py`, `build_t3.py`: team workbook builders (config JSON per country; T3 merges research values with
  the report's current values by status rank).
- `vn_1jan_fya.py`: converting a model from a 1 July to a 1 January time point, with full-year-adjustment rows.
- `coicop_table.py`, `inventory.py`: VAT status and excise by COICOP item and system; constants and uprating tables.
