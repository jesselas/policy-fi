#!/usr/bin/env python3
"""Build model inventory tables for one country from the long parameter CSV and the XML.

Usage: python3 $SKILL/scripts/examples/inventory.py CC  (reads _internal/SOUTHMOD_A4.0_Bundle, writes _internal/CC/Update_2026/work/)
Outputs: <cc>_constants_wide.csv, <cc>_vat_status.csv, <cc>_excise_functions.csv, <cc>_uprating_indices.csv
"""
import re, sys, pandas as pd, xml.etree.ElementTree as ET
cc = sys.argv[1].upper(); lc = cc.lower()
W = f'_internal/{cc}/Update_2026/work'
d = pd.read_csv(f'{W}/{lc}_parameters_all_systems.csv', dtype=str).fillna('')
systems = list(dict.fromkeys(d.system))
systems = sorted(systems)

# 1. constants (DefConst parameters), wide by system
c = d[d.function.str.lower() == 'defconst']
c = c[~c.parameter.isin(['Condition', 'TAX_UNIT', 'Run_Cond'])]
c = c.assign(value=c.value.where(~((c.pol_switch == 'n/a') | (c.fun_switch == 'n/a')), 'n/a'))
key = ['policy', 'fun_no', 'fun_comment', 'parameter', 'par_comment']
# comments can differ by system; take the latest system's comment
cw = c.pivot_table(index=['policy', 'fun_no', 'parameter'], columns='system', values='value', aggfunc='first')
com = c.sort_values('system').groupby(['policy', 'fun_no', 'parameter']).agg(fun_comment=('fun_comment', 'last'), par_comment=('par_comment', 'last'))
cw = com.join(cw).reset_index()
cw.to_csv(f'{W}/{lc}_constants_wide.csv', index=False)

# 2. VAT status: DefIl functions inside tva_<cc> policy
v = d[(d.policy == f'tva_{lc}') & (d.function.str.lower() == 'defil') & (d.parameter != 'Name')]
names = d[(d.policy == f'tva_{lc}') & (d.function.str.lower() == 'defil') & (d.parameter == 'Name')][['system', 'fun_no', 'value']].rename(columns={'value': 'il_name'})
v = v.merge(names, on=['system', 'fun_no'])
v = v[(v.pol_switch != 'n/a') & (v.fun_switch != 'n/a')]
v['col'] = v.system + ':' + v.il_name
vw = v.pivot_table(index='parameter', columns='col', values='value', aggfunc='first').fillna('')
lab = v.sort_values('system').groupby('parameter').par_comment.last()
vw.insert(0, 'label', lab)
vw.reset_index().rename(columns={'parameter': 'variable'}).to_csv(f'{W}/{lc}_vat_status.csv', index=False)

# 3. excise functions
e = d[d.policy.str.match(rf'tex\d*_{lc}$') & d.parameter.isin(['Formula', 'Output_Var', 'Output_Add_Var', 'Comp_perTU', 'Comp_Cond'])]
e = e[(e.pol_switch != 'n/a')]
e.pivot_table(index=['policy', 'fun_no', 'function', 'parameter'], columns='system', values='value', aggfunc='first').reset_index() \
    .merge(e.sort_values('system').groupby(['policy', 'fun_no']).fun_comment.last().reset_index(), on=['policy', 'fun_no']) \
    .to_csv(f'{W}/{lc}_excise_functions.csv', index=False)

# 4. uprating indices
root = ET.parse(f'_internal/SOUTHMOD_A4.0_Bundle/XMLParam/Countries/{cc}/{cc}.xml').getroot()
rows = []
ns = root.tag[:root.tag.index('}')+1] if root.tag.startswith('{') else ''
for u in root.iter(ns + 'UpratingIndex'):
    g = lambda n: (u.findtext(ns + n) or '').strip()
    for yv in g('YearValues').split('°'):
        if '|' in yv:
            y, val = yv.split('|'); rows.append(dict(reference=g('Reference'), description=g('Description'), comment=g('Comment'), year=y, value=val))
pd.DataFrame(rows).pivot_table(index=['reference', 'description', 'comment'], columns='year', values='value', aggfunc='first').reset_index().to_csv(f'{W}/{lc}_uprating_indices.csv', index=False)
print(cc, 'constants', len(cw), 'vat vars', len(vw), 'excise rows', len(e), 'uprating rows', len(rows))
