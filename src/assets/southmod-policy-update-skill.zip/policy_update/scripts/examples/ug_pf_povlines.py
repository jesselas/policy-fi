#!/usr/bin/env python3
"""UGAMOD post-fiscal poverty lines by region and system (Python version of Stage 10 / 10b).

Same steps as "Stage 10b - Post fiscal poverty lines for 2016 2020 2024.do": collapse the output to
households (sum ils_taxco, ils_benco, xhh, ils_con, ses; first drgn5, spl), equivalise with the summed ses,
and for each region drgn5 subtract from spl the UNWEIGHTED mean equivalised NET indirect tax
(ils_taxco - ils_benco)/ses of households within +/-2.5% of spl. spl is taken from the output, so it is
the system's CPI-uprated basic needs line. The result is the nominal monthly post-fiscal line of that
system, written to $indirect_basic_povline in spl_ug (DefConst, group by region); spl_ug then uses it
without CPI uprating.

usage: python3 $SKILL/scripts/examples/ug_pf_povlines.py --outdir _internal/SOUTHMOD_A4.0_Bundle/Output --years 2016-2026 \
           [--csv _internal/UG/Update_2026/T7_ug_edits_e_pf_povlines.csv] [--check]
--check only prints the base-year lines (spl fixed at the base line) to compare with the model.
"""
import argparse, csv, os
import pandas as pd

REGIONS = [10, 11, 20, 21, 30, 31, 40, 41]   # DefConst groups 1-8 in spl_ug, same order


def lines(path):
    d = pd.read_csv(path, sep='\t', low_memory=False,
                    usecols=lambda c: c in ('idhh', 'idperson', 'ils_taxco', 'ils_benco', 'xhh', 'ils_con', 'ses', 'drgn5', 'spl'))
    if 'ils_benco' not in d:
        d['ils_benco'] = 0.0
    d = d.sort_values(['idhh', 'idperson'])
    h = d.groupby('idhh').agg(tax=('ils_taxco', 'sum'), ben=('ils_benco', 'sum'), con=('ils_con', 'sum'),
                              ses=('ses', 'sum'), drgn5=('drgn5', 'first'), spl=('spl', 'first'))
    eq = h.con / h.ses
    net = (h.tax - h.ben) / h.ses
    band = (eq >= h.spl * 0.975) & (eq <= h.spl * 1.025)
    out = {}
    for g in REGIONS:
        m = band & (h.drgn5 == g)
        s = h.spl[h.drgn5 == g].iloc[0]
        out[g] = (s - net[m].mean(), s, int(m.sum()))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--outdir', required=True)
    ap.add_argument('--years', default='2016-2026')
    ap.add_argument('--csv', default='_internal/UG/Update_2026/T7_ug_edits_e_pf_povlines.csv')
    a = ap.parse_args()
    y0, y1 = map(int, a.years.split('-'))
    rows = []
    for y in range(y0, y1 + 1):
        res = lines(os.path.join(a.outdir, f'ug_{y}_std.txt'))
        for i, g in enumerate(REGIONS, 1):
            v, s, n = res[g]
            print(f'UG_{y} drgn5={g}: spl {s:.2f} -> post-fiscal {v:.2f} (households in band: {n})')
            rows.append(dict(op='set_value', system=f'UG_{y}', policy='spl_ug', fun='9.1', parameter='$indirect_basic_povline',
                             group=str(i), value=f'{v:.2f}', comment=''))
    with open(a.csv, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    print(f'written {a.csv} {len(rows)} edits')


if __name__ == '__main__':
    main()
