#!/usr/bin/env python3
"""COICOP item table: label, VAT status and excise treatment per system.

Usage: python3 $SKILL/scripts/examples/coicop_table.py CC SYS1 [SYS2 ...]
Writes _internal/CC/Update_2026/work/<cc>_coicop_vat_excise.csv. VAT status per system: the name of the
active VAT DefIl list containing the item with '+', or 'exempt/zero' if listed as n/a.
"""
import os, re, sys, pandas as pd
cc = sys.argv[1].upper(); lc = cc.lower(); systems = sys.argv[2:]
W = f'_internal/{cc}/Update_2026/work'
d = pd.read_csv(os.environ.get('PARAMS', f'{W}/{lc}_parameters_all_systems.csv'), dtype=str).fillna('')
act = d[(d.pol_switch == 'on') & (d.fun_switch == 'on')]
out = {}
labels = {}
for s in systems:
    v = act[(act.system == s) & (act.policy == f'tva_{lc}') & (act.function.str.lower() == 'defil')]
    for fno, g in v.groupby('fun_no'):
        il = g[g.parameter == 'Name'].value.iloc[0]
        tag = f'{il} ({g.fun_comment.iloc[0][:60]})'
        for _, r in g[g.parameter != 'Name'].iterrows():
            labels.setdefault(r.parameter, r.par_comment)
            cur = out.setdefault(r.parameter, {}).get(s)
            ex = 'exempt/zero-rated (n/a)'
            if r.value == '+':
                st = tag if (not cur or cur == ex) else cur + ' + ' + tag
            else:
                st = cur or ex
            out[r.parameter][s] = st
    # excise: which variables appear in excise formulas
    e = act[(act.system == s) & act.policy.str.match(rf'tex_{lc}$') & (act.parameter == 'Formula')]
    for _, r in e.iterrows():
        for var in re.findall(r'\b([xq]\d{4,})\b', r.value):
            var = 'x' + var[1:]  # quantity-based duty applies to the matching expenditure item
            key = f'excise {s}'
            consts = sorted(set(re.findall(r'\$\w+', r.value)))
            out.setdefault(var, {})
            if 'vat' in ' '.join(consts).lower() or 'tva' in r.value:
                out[var].setdefault(f'VAT via excise policy {s}', f'{r.fun_no} {r.fun_comment[:50]}')
            else:
                prev = out[var].get(key, '')
                out[var][key] = (prev + '; ' if prev else '') + f'{r.fun_no} {r.fun_comment[:50]} [{" ".join(consts)}]'
            labels.setdefault(var, '')
t = pd.DataFrame.from_dict(out, orient='index')
t.insert(0, 'label', pd.Series(labels))
t.index.name = 'variable'
t = t.sort_index()
t.to_csv(f'{W}/{lc}_coicop_vat_excise.csv')
print(cc, t.shape); print(t.columns.tolist())
