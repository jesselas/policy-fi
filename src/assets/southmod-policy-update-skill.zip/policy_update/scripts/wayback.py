#!/usr/bin/env python3
"""Find and fetch archived copies of a source (Internet Archive Wayback Machine) near a policy date.

Official pages and PDFs (budget statements, finance acts, revenue-authority notices) move or disappear.
An archived snapshot close to the model's policy time point also shows what a page said at that date.

usage:
  python3 $SKILL/scripts/wayback.py closest <URL> <YYYYMMDD>          # snapshot nearest the date
  python3 $SKILL/scripts/wayback.py list <URL> <FROM_YYYY> <TO_YYYY>  # all 200-status captures in a window
  python3 $SKILL/scripts/wayback.py list <URL_PREFIX>* <FROM> <TO>    # every capture under a folder
                                                                      # (e.g. a ministry's uploads/)
  python3 $SKILL/scripts/wayback.py fetch <URL> <YYYYMMDD> <out_file> # original bytes of the nearest
                                                                      # capture (raw `id_` mode)
Prints the capture timestamp and archive URL; `fetch` also prints the SHA-256 of the saved file.
Record the timestamp, archive URL and hash in the source index (02). Never treat a capture as the
current law without checking for later amendments.
Exit codes: 0 found, 1 nothing archived, 2 invalid input or network error.
"""
import hashlib
import json
import sys
import time
import urllib.parse
import urllib.request

UA = {'User-Agent': 'policy-update-source-check/1.0'}


def get(url, binary=False, tries=3):
    """GET with retries and backoff (the archive's search API is often slow)."""
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=90) as r:
                data = r.read()
            return data if binary else data.decode('utf-8', 'replace')
        except Exception:
            if k == tries - 1:
                raise
            time.sleep(5 * (k + 1))


def closest(url, ts):
    """Nearest capture with HTTP status 200, via the CDX API (sorted by distance to ts)."""
    q = urllib.parse.urlencode({'url': url, 'output': 'json', 'filter': 'statuscode:200',
                                'closest': ts, 'sort': 'closest', 'limit': '1',
                                'fl': 'timestamp,original,mimetype,digest'})
    rows = json.loads(get('https://web.archive.org/cdx/search/cdx?' + q) or '[]')
    if len(rows) < 2:
        return None
    return dict(zip(rows[0], rows[1]))


def listing(url, y0, y1):
    params = {'url': url.rstrip('*'), 'output': 'json', 'filter': 'statuscode:200', 'from': y0, 'to': y1,
              'fl': 'timestamp,original,mimetype,digest', 'collapse': 'digest'}
    if url.endswith('*'):
        params['matchType'] = 'prefix'
    rows = json.loads(get('https://web.archive.org/cdx/search/cdx?' + urllib.parse.urlencode(params)) or '[]')
    return [dict(zip(rows[0], r)) for r in rows[1:]]


def main():
    a = sys.argv[1:]
    try:
        if len(a) == 3 and a[0] == 'closest':
            c = closest(a[1], a[2])
            if not c:
                print('no archived capture'); return 1
            print(f"{c['timestamp']}  {c['mimetype']}  https://web.archive.org/web/{c['timestamp']}/{c['original']}")
            return 0
        if len(a) == 4 and a[0] == 'list':
            rows = listing(a[1], a[2], a[3])
            for c in rows:
                print(f"{c['timestamp']}  {c['mimetype']:24s}  {c['original']}")
            print(f'{len(rows)} distinct captures')
            return 0 if rows else 1
        if len(a) == 4 and a[0] == 'fetch':
            c = closest(a[1], a[2])
            if not c:
                print('no archived capture'); return 1
            raw = f"https://web.archive.org/web/{c['timestamp']}id_/{c['original']}"
            data = get(raw, binary=True)
            open(a[3], 'wb').write(data)
            kind = 'PDF' if data[:5] == b'%PDF-' else c['mimetype']
            print(f"{c['timestamp']}  {kind}  {raw}\nsaved {a[3]} ({len(data)} bytes) sha256 {hashlib.sha256(data).hexdigest()}")
            return 0
    except Exception as ex:
        print(f'error: {ex}'); return 2
    print(__doc__); return 2


if __name__ == '__main__':
    sys.exit(main())
