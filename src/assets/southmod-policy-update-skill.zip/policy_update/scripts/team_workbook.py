#!/usr/bin/env python3
"""Helpers to build the Excel workbooks sent to national teams (tasks 2 and 3).

Layout conventions (same in every sheet):
  - Row 1: sheet title; row 2: one-line instruction; row 4: header; data from row 5.
  - Grey columns: model / current values (do not edit).
  - Blue columns: our proposal (tentative, from online research), with its source.
  - Green columns: for the team (dropdown "Confirm / Change / Not sure", corrected value,
    source, comment).
  - Frozen header and first columns, filters on, wrapped text.
"""
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

GREY = PatternFill('solid', fgColor='EDEDED')
BLUE = PatternFill('solid', fgColor='DDEBF7')
GREEN = PatternFill('solid', fgColor='E2EFDA')
HEAD = PatternFill('solid', fgColor='1F4E78')
SECTION = PatternFill('solid', fgColor='FFF2CC')
THIN = Side(style='thin', color='BFBFBF')
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(wrap_text=True, vertical='top')

TEAM_COLS = ['Team: Confirm / Change / Not sure', 'Team: correct value (if Change)',
             'Team: source or legal reference', 'Team: comment']


def new_workbook():
    wb = Workbook()
    wb.remove(wb.active)
    return wb


def readme(wb, title, paragraphs):
    ws = wb.create_sheet('README')
    ws['A1'] = title
    ws['A1'].font = Font(bold=True, size=14)
    r = 3
    for p in paragraphs:
        if isinstance(p, tuple):  # (label, fill) legend line
            ws.cell(r, 1, p[0]).fill = p[1]
        else:
            ws.cell(r, 1, p)
            if p and p.isupper():
                ws.cell(r, 1).font = Font(bold=True)
        ws.cell(r, 1).alignment = Alignment(wrap_text=True, vertical='top')
        r += 1
    ws.column_dimensions['A'].width = 130
    return ws


def table(wb, name, title, instruction, columns, rows, kinds, widths=None, team=True,
          sections_col=None, freeze_cols=2, top=4):
    """Write a table sheet.

    columns: list of header strings (excluding team columns, which are appended when team=True)
    rows:    list of lists (same length as columns); a row whose first element starts with '##'
             is a section header spanning the table
    kinds:   list with 'grey' | 'blue' | 'plain' per column (colour of the data cells)
    """
    ws = wb.create_sheet(name[:31])
    if top > 1:
        ws['A1'] = title
        ws['A1'].font = Font(bold=True, size=13)
        ws['A2'] = instruction
        ws['A2'].alignment = Alignment(wrap_text=False)
    cols = list(columns) + (TEAM_COLS if team else [])
    kinds = list(kinds) + (['green'] * len(TEAM_COLS) if team else [])
    fills = {'grey': GREY, 'blue': BLUE, 'green': GREEN, 'plain': None}
    for j, c in enumerate(cols, 1):
        cell = ws.cell(top, j, c)
        cell.font = Font(bold=True, color='FFFFFF')
        cell.fill = HEAD
        cell.alignment = Alignment(wrap_text=True, vertical='center')
        cell.border = BOX
    ws.row_dimensions[top].height = 45
    r = top + 1
    data_rows = []
    for row in rows:
        if isinstance(row[0], str) and row[0].startswith('##'):
            cell = ws.cell(r, 1, row[0][2:].strip())
            cell.font = Font(bold=True)
            for j in range(1, len(cols) + 1):
                ws.cell(r, j).fill = SECTION
                ws.cell(r, j).border = BOX
            r += 1
            continue
        vals = list(row) + ([''] * len(TEAM_COLS) if team else [])
        for j, v in enumerate(vals, 1):
            cell = ws.cell(r, j, v if v != '' else None)
            f = fills[kinds[j - 1]]
            if f is not None:
                cell.fill = f
            cell.border = BOX
            cell.alignment = WRAP
        data_rows.append(r)
        r += 1
    if team and data_rows:
        dv = DataValidation(type='list', formula1='"Confirm,Change,Not sure"', allow_blank=True)
        ws.add_data_validation(dv)
        c = get_column_letter(len(columns) + 1)
        for rr in data_rows:
            dv.add(f'{c}{rr}')
    widths = widths or []
    for j in range(1, len(cols) + 1):
        w = widths[j - 1] if j - 1 < len(widths) else (18 if j > len(columns) else 14)
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = ws.cell(top + 1, freeze_cols + 1)
    ws.auto_filter.ref = f'A{top}:{get_column_letter(len(cols))}{max(r - 1, top)}'
    return ws


def legend_lines():
    return [('Grey cells: current model values (for information).', GREY),
            ('Blue cells: our proposed value for the new system(s), from online research. Tentative.', BLUE),
            ('Green cells: for you. Choose Confirm, Change or Not sure; if Change, give the correct value and a source.', GREEN)]
