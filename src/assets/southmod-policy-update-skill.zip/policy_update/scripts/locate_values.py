#!/usr/bin/env python3
"""Locate model values in source documents, and check report tables against the model.

A LOCATOR, not a verdict: it shows where (file, page, context) each model value appears in laws, gazettes or
the country report, in the number formats those documents use. A value that is not found may still be
right (another unit, rounding, wording); a value that is found may be a coincidence. Read every hit.

usage:
  python3 $SKILL/scripts/locate_values.py locate <CC>.xml <SYSTEM> <doc> [<doc> ...]
          [--policy P ...] [--changed-vs <PREV_SYSTEM>] [--out hits.csv]
      For each numeric parameter value of SYSTEM (active policies/functions; optionally only one policy or
      only cells that differ from PREV_SYSTEM), search the documents (.pdf, .docx, .txt, .md) for its
      variants and list the hits with page and context.
  python3 $SKILL/scripts/locate_values.py tables <CC>.xml <SYSTEM> <report.docx> <YEAR> [--out cells.csv]
      For every report table with a header cell containing YEAR, read the numbers in that column and check
      that each equals some numeric parameter value of SYSTEM or an uprating-index value for YEAR (in any of
      the variants below). Only parameter tables are judged: tables where at least --min-share (default
      0.3) of the numbers match the model; the others (statistics, validation) are listed as skipped. In a
      parameter table, a cell with no match is a stale figure, a typo, or a value the model does not hold.
      Run it on the updated report for each new system's year column.

Variants of a value v (with period suffix #y, #m, ...; see southmod functions_and_syntax.md §4):
  the number as written; thousands separators "," "." " " (also no-break spaces); decimal comma;
  rates (v <= 1 without a monetary suffix, or #..r) also as v*100 ("15", "15%", "15 per cent", "15,5");
  #y amounts also /12 (monthly), #m amounts also *12 (annual), #w/#d/#l amounts also as their monthly
  equivalent; large amounts also in millions/thousands ("1.2 million", "1,200 thousand").
Exit codes: 0 done (locate) / all table cells matched (tables), 1 unmatched table cells, 2 invalid input.
"""
import csv
import re
import subprocess
import sys
import zipfile
import html
import xml.etree.ElementTree as ET
from pathlib import Path

INACTIVE = {'off', 'n/a'}
FACT = {'y': 1 / 12, 'q': 1 / 3, 'w': 4.34, 'd': 30.5, 'l': 21.73, 's': 26.07, 'm': 1, 'c': 1}
NUMVAL = re.compile(r'^\s*(-?\d+(?:\.\d+)?)\s*(?:#([a-z])(r?))?\s*$', re.I)
SPACES = '   '


def loc(t):
    return t.rsplit('}', 1)[-1]


def tx(e, n):
    for c in e:
        if loc(c.tag) == n:
            return (c.text or '').strip()
    return ''


def kids(e, n):
    return [c for c in e if loc(c.tag) == n]


def ok(e):
    try:
        return float(tx(e, 'Order') or 0)
    except ValueError:
        return 0.0


def cells(xml, system, policies=None):
    """{(policy, N.M.K, parameter, group): value} for active cells of a system."""
    root = ET.parse(xml).getroot()
    s = next((x for x in root.iter() if loc(x.tag) == 'System' and tx(x, 'Name') == system), None)
    if s is None:
        raise SystemExit(f'system {system} not found')
    out = {}
    for n, p in enumerate(sorted(kids(s, 'Policy'), key=ok), 1):
        if tx(p, 'Switch').lower() in INACTIVE or (policies and tx(p, 'Name').lower() not in policies):
            continue
        for m, f in enumerate(sorted(kids(p, 'Function'), key=ok), 1):
            if tx(f, 'Switch').lower() in INACTIVE:
                continue
            for k, par in enumerate(sorted(kids(f, 'Parameter'), key=ok), 1):
                out[(tx(p, 'Name'), f'{n}.{m}.{k}', tx(par, 'Name'), tx(par, 'Group'))] = tx(par, 'Value')
    return out


def fmt(x, dec):
    s = f'{x:.{dec}f}'
    return s.rstrip('0').rstrip('.') if '.' in s else s


def group(s, sep, dsep='.'):
    neg = s.startswith('-')
    s = s.lstrip('-')
    i, _, d = s.partition('.')
    g = ''
    while len(i) > 3:
        g = sep + i[-3:] + g
        i = i[:-3]
    return ('-' if neg else '') + i + g + (dsep + d if d else '')


def numbers(v):
    """Numeric forms (floats) of a model value, with labels."""
    m = NUMVAL.match(v or '')
    if not m:
        return []
    x = float(m.group(1))
    per, rate = (m.group(2) or '').lower(), bool(m.group(3))
    forms = [(x, 'as written')]
    if (not per and abs(x) <= 1) or rate:
        forms.append((x * 100, 'x100 (per cent)'))
    if per == 'y':
        forms.append((x / 12, 'monthly'))
    elif per == 'm':
        forms.append((x * 12, 'annual'))
    elif per in FACT and per not in ('c',):
        forms.append((x * FACT[per], 'monthly (engine factor)'))
    return forms


def strings(x):
    out = set()
    for dec in (0, 1, 2, 3, 4):
        if abs(round(x, dec) - x) > 1e-9 and dec < 4:
            continue
        s = fmt(x, dec)
        out.add(s)
        out.add(s.replace('.', ','))
        for sep in (',', ' ', ' ', ' '):
            out.add(group(s, sep))
        out.add(group(s, '.', ','))
        break
    if abs(x) >= 1e5:
        out.add(fmt(x / 1e6, 2) + ' million')
        out.add(fmt(x / 1e6, 1) + ' million')
    return {s for s in out if len(s.strip('-')) >= 2 or s in ('5', '7', '8', '9')}


def to_float(s):
    s = s.strip().replace('%', '')
    for c in SPACES + ' ':
        s = s.replace(c, '')
    if re.fullmatch(r'-?\d{1,3}(\.\d{3})+(,\d+)?', s):
        s = s.replace('.', '').replace(',', '.')
    elif re.fullmatch(r'-?\d{1,3}(,\d{3})+(\.\d+)?', s):
        s = s.replace(',', '')
    elif re.fullmatch(r'-?\d+,\d+', s):
        s = s.replace(',', '.')
    try:
        return float(s)
    except ValueError:
        return None


def pages(path):
    p = Path(path)
    if p.suffix.lower() == '.pdf':
        t = subprocess.run(['pdftotext', '-layout', str(p), '-'], capture_output=True, text=True).stdout
        return list(enumerate(t.split('\f'), 1))
    if p.suffix.lower() in ('.docx', '.docm'):
        x = zipfile.ZipFile(p).read('word/document.xml').decode('utf-8', 'replace')
        paras = [html.unescape(re.sub(r'<[^>]+>', '', s)) for s in re.split(r'</w:p>', re.sub(r'<w:tab/>', ' ', x))]
        return [(f'para {i}', s) for i, s in enumerate(paras, 1) if s.strip()]
    return [('', p.read_text(encoding='utf-8', errors='replace'))]


def cmd_locate(a):
    xml, system, docs = a.pos[0], a.pos[1], a.pos[2:]
    cur = cells(xml, system, a.policies)
    if a.changed:
        prev = cells(xml, a.changed, a.policies)
        cur = {k: v for k, v in cur.items() if prev.get(k) != v}
    corpus = [(Path(d).name, pg, re.sub(r'[ \t]+', ' ', t)) for d in docs for pg, t in pages(d)]
    rows = []
    for key, v in cur.items():
        forms = numbers(v)
        if not forms:
            continue
        found = 0
        for x, label in forms:
            for s in strings(x):
                pat = re.compile(r'(?<![\d.,])' + re.escape(s) + r'(?![\d]|[.,]\d)')
                for name, pg, t in corpus:
                    for m in pat.finditer(t):
                        found += 1
                        ctx = t[max(0, m.start() - 70):m.end() + 70].replace('\n', ' ')
                        rows.append([*key, v, label, s, name, pg, ctx])
        if not found:
            rows.append([*key, v, '', '', '', '', 'NOT FOUND'])
    write(a.out, ['policy', 'row', 'parameter', 'group', 'value', 'form', 'string', 'file', 'page', 'context'], rows)
    nf = sum(1 for r in rows if r[-1] == 'NOT FOUND')
    print(f'{len(cur)} cells checked; {len(rows) - nf} hits; {nf} values not found -> {a.out}')
    return 0


def cmd_tables(a):
    from docx import Document
    xml, system, report, year = a.pos[:4]
    model = set()
    for v in cells(xml, system).values():
        for x, _ in numbers(v):
            model.add(round(x, 4))
    for u in (e for e in ET.parse(xml).getroot().iter() if loc(e.tag) == 'UpratingIndex'):
        for pair in tx(u, 'YearValues').split('°'):
            yv = pair.split('|')
            if len(yv) == 2 and yv[0] == str(year):
                try:
                    model.add(round(float(yv[1]), 4))
                except ValueError:
                    pass
    doc = Document(report)
    rows, unmatched = [], 0

    def walk(tables, path):
        nonlocal unmatched
        for ti, tb in enumerate(tables, 1):
            label = f'{path}{ti}'
            hdr = None
            for ri, row in enumerate(tb.rows[:3]):
                for ci, c in enumerate(row.cells):
                    if re.search(rf'\b{year}\b', c.text):
                        hdr = (ri, ci)
                        break
                if hdr:
                    break
            if hdr:
                first = tb.rows[0].cells[0].text.strip()[:40]
                for ri, row in enumerate(tb.rows[hdr[0] + 1:], hdr[0] + 2):
                    if hdr[1] >= len(row.cells):
                        continue
                    txt = row.cells[hdr[1]].text
                    for mnum in re.finditer(r'-?\d[\d.,   ]*\d|\d', txt):
                        x = to_float(mnum.group(0))
                        if x is None:
                            continue
                        hit = any(abs(x - y) <= max(1e-6, 0.005 * abs(y)) for y in model)
                        rows.append([label, first, ri, row.cells[0].text.strip()[:60], mnum.group(0), 'ok' if hit else 'NOT IN MODEL'])
            for row in tb.rows:
                for c in row.cells:
                    if c.tables:
                        walk(c.tables, f'{label}.')

    walk(doc.tables, 'table ')
    share = {}
    for r in rows:
        n, k = share.get(r[0], (0, 0))
        share[r[0]] = (n + 1, k + (r[-1] == 'ok'))
    judged = {tb for tb, (n, k) in share.items() if k / n >= a.min_share}
    for r in rows:
        if r[0] not in judged:
            r[-1] = 'skipped (not a parameter table)'
        elif r[-1] != 'ok':
            unmatched += 1
    write(a.out, ['table', 'first cell', 'row', 'row label', 'number', 'status'], rows)
    print(f'{len(rows)} numbers in {year} columns of {len(share)} tables; {len(judged)} parameter tables judged; '
          f'{unmatched} cells there not equal to any {system} value -> {a.out}')
    for tb, (n, k) in share.items():
        print(f'  {tb}: {k}/{n} numbers match' + ('' if tb in judged else '  (skipped)'))
    for r in rows:
        if r[-1] == 'NOT IN MODEL':
            print(f'  CHECK {r[0]} row {r[2]} "{r[3]}": {r[4]}')
    return 1 if unmatched else 0


def write(path, head, rows):
    with open(path, 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(head)
        w.writerows(rows)


class Args:
    pass


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ('locate', 'tables'):
        print(__doc__); return 2
    a = Args()
    a.pos, a.policies, a.changed, a.out, a.min_share = [], set(), None, f'{sys.argv[1]}_values.csv', 0.3
    it = iter(sys.argv[2:])
    for x in it:
        if x == '--policy':
            a.policies.add(next(it).lower())
        elif x == '--changed-vs':
            a.changed = next(it)
        elif x == '--out':
            a.out = next(it)
        elif x == '--min-share':
            a.min_share = float(next(it))
        else:
            a.pos.append(x)
    need = 3 if sys.argv[1] == 'locate' else 4
    if len(a.pos) < need:
        print(__doc__); return 2
    return cmd_locate(a) if sys.argv[1] == 'locate' else cmd_tables(a)


if __name__ == '__main__':
    sys.exit(main())
