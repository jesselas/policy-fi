#!/usr/bin/env python3
"""Compare two EUROMOD outputs of the same system (before/after a change): every fiscal aggregate.

A change's fiscal effect is never just the edited instrument. This prints annual weighted totals
(monthly x 12, in billions) of ils_dispy, ils_tax, ils_sic, ils_ben, ils_taxco, ils_benco, ils_con and any
extra variables, and the list of columns that changed at all. Explain every movement.

usage: python3 $SKILL/scripts/diff_outputs.py OLD.txt[.gz] NEW.txt[.gz] [--vars tva_s tex_s bsf_s ...]
"""
import argparse
import pandas as pd
ap = argparse.ArgumentParser(); ap.add_argument('old'); ap.add_argument('new'); ap.add_argument('--vars', nargs='*', default=[])
a = ap.parse_args()
o = pd.read_csv(a.old, sep='\t', low_memory=False); n = pd.read_csv(a.new, sep='\t', low_memory=False)
print('rows', len(o), len(n), '| same person order:', len(o) == len(n) and (o.idperson.values == n.idperson.values).all())
for v in ['ils_dispy', 'ils_tax', 'ils_sic', 'ils_ben', 'ils_taxco', 'ils_benco', 'ils_con'] + a.vars:
    if v in o and v in n:
        x = (o[v] * o.dwt).sum() * 12 / 1e9; y = (n[v] * n.dwt).sum() * 12 / 1e9
        flag = '' if abs(y - x) < 1e-9 else f'  diff {y - x:+.3f} ({(y / x - 1) * 100 if x else 0:+.2f}%)'
        print(f'  {v:12s} {x:14.3f} -> {y:14.3f}{flag}')
num = [c for c in n.columns if c in o and n[c].dtype.kind in 'fi' and o[c].dtype.kind in 'fi']
print('columns changed:', [c for c in num if len(o) == len(n) and (abs(n[c] - o[c]) > 1e-6).any()])
