#!/usr/bin/env python3
"""Check extension bindings row by row (policies and functions, GUI numbering by <Order>).

An extension (FYA, POV, FOR, ...) must bind a WHOLE ROW: an Extension_Policy/Extension_Function entry for
that row's element in every system (cells where the row does not apply can be n/a but must still be
bound). A binding that covers only some systems' cells, in particular one that misses the first system,
is ignored by EUROMOD 3 and the row does not run, silently (no log warning). Found in practice: FYA rows
bound only in the two newest systems never ran.

usage: python3 $SKILL/scripts/ext_binding_check.py <CC>.xml
Prints every row that is bound in some systems but not all. Fix by adding the missing
Extension_Function entries (same ExtensionID and BaseOff) for the unbound cells, then rerun and verify
the row's effect in the output.
"""
import sys
from lxml import etree
N = '{http://euromod.com/CountryConfig.xsd}'
r = etree.parse(sys.argv[1]).getroot()
bind = {}
for tag, idt in [('Extension_Function', 'FunctionID'), ('Extension_Policy', 'PolicyID')]:
    for e in r.iter(N + tag):
        bind[e.find(N + idt).text] = (e.find(N + 'ExtensionID').text[:8], e.find(N + 'BaseOff').text)
o = lambda e: float(e.find(N + 'Order').text or 0)
rows = {}
for s in r.iter(N + 'System'):
    sn = s.find(N + 'Name').text
    for p in sorted(s.findall(N + 'Policy'), key=o):
        pn = p.find(N + 'Name').text
        rows.setdefault((pn,), []).append((sn, p.find(N + 'Switch').text, bind.get(p.find(N + 'ID').text)))
        for k, f in enumerate(sorted(p.findall(N + 'Function'), key=o), 1):
            rows.setdefault((pn, k), []).append((sn, f.find(N + 'Switch').text, bind.get(f.find(N + 'ID').text)))
bad = 0
for key, cells in rows.items():
    b = [c for c in cells if c[2]]
    if b and len(b) < len(cells):
        bad += 1
        print(f'{key}: bound in {[c[0] for c in b]}; first system bound: {bool(cells[0][2])}; binding {sorted({c[2] for c in b})}')
print(f'rows bound in only some systems: {bad} (of {sum(1 for c in rows.values() if any(x[2] for x in c))} bound rows)')
