#!/usr/bin/env python3
"""Check extension bindings row by row (policies, functions and parameters; GUI numbering by <Order>),
and the extension switches in the dataconfig.

An extension (FYA, POV, FOR, ...) must bind a WHOLE ROW: an Extension_Policy/Extension_Function/
Extension_Parameter entry for that row's element in every system (cells where the row does not apply
can be n/a but must still be bound). EUROMOD's EM3 copy takes row identity and bindings from the FIRST
<System> IN THE FILE (not necessarily the earliest year); a binding missing there is ignored and the row
does not run, silently (no log warning). Found in practice: FYA rows bound only in the two newest systems
never ran.

usage: python3 $SKILL/scripts/ext_binding_check.py <CC>.xml [<CC>_dataconfig.xml]
  (the dataconfig defaults to <CC>_dataconfig.xml next to the model, if present)

Reports
  - rows bound in some systems but not all (and whether the first system in the file is bound);
  - rows whose bindings differ between systems (extension or BaseOff);
  - dataconfig: DBSystemConfig blocks with more than one PolicySwitch for an extension, PolicySwitch
    SystemID/DataBaseID that do not match the parent block, switches for undeclared extensions, and
    bindings in the model to extensions not declared in the dataconfig.
Exit codes: 0 clean, 1 problems found, 2 invalid input.
Fix partial bindings by adding the missing entries (same ExtensionID and BaseOff) for the unbound cells,
then rerun and verify the row's effect in the output.
"""
import sys
from collections import Counter
from pathlib import Path
from lxml import etree

N = '{http://euromod.com/CountryConfig.xsd}'


def txt(e, tag):
    c = e.find(N + tag)
    return (c.text or '').strip() if c is not None and c.text else ''


def order(e):
    try:
        return float(txt(e, 'Order') or 0)
    except ValueError:
        return 0.0


def local(tag):
    return etree.QName(tag).localname


def main():
    if len(sys.argv) < 2:
        print(__doc__); return 2
    xml = Path(sys.argv[1])
    try:
        r = etree.parse(str(xml)).getroot()
    except Exception as ex:
        print(f'cannot parse {xml}: {ex}'); return 2
    bind = {}
    for tag, idt in [('Extension_Policy', 'PolicyID'), ('Extension_Function', 'FunctionID'),
                     ('Extension_Parameter', 'ParameterID')]:
        for e in r.iter(N + tag):
            bind.setdefault(txt(e, idt), set()).add((txt(e, 'ExtensionID'), txt(e, 'BaseOff').lower()))
    systems = list(r.iter(N + 'System'))
    if not systems:
        print('no <System> found'); return 2
    first = txt(systems[0], 'Name')
    rows = {}
    for s in systems:
        sn = txt(s, 'Name')
        for p in sorted(s.findall(N + 'Policy'), key=order):
            pn = txt(p, 'Name')
            rows.setdefault((pn,), []).append((sn, bind.get(txt(p, 'ID'))))
            for k, f in enumerate(sorted(p.findall(N + 'Function'), key=order), 1):
                rows.setdefault((pn, k), []).append((sn, bind.get(txt(f, 'ID'))))
                for j, par in enumerate(sorted(f.findall(N + 'Parameter'), key=order), 1):
                    rows.setdefault((pn, k, j, txt(par, 'Name'), txt(par, 'Group')), []).append(
                        (sn, bind.get(txt(par, 'ID'))))

    def label(key):
        if len(key) == 1:
            return key[0]
        if len(key) == 2:
            return f'{key[0]} function {key[1]}'
        return f'{key[0]} function {key[1]} parameter {key[2]} {key[3]}' + (f' #{key[4]}' if key[4] else '')

    problems = 0
    bound_rows = 0
    for key, cells in rows.items():
        b = [c for c in cells if c[1]]
        if not b:
            continue
        bound_rows += 1
        first_bound = next((bool(c[1]) for c in cells if c[0] == first), False)
        if len(b) < len(cells):
            problems += 1
            missing = [c[0] for c in cells if not c[1]]
            print(f'PARTIAL  {label(key)}: unbound in {missing}; first system in file ({first}) bound: {first_bound}')
        kinds = {frozenset(c[1]) for c in b}
        if len(kinds) > 1:
            problems += 1
            print(f'MIXED    {label(key)}: bindings differ between systems: {sorted(map(sorted, kinds))}')

    ext_ids = set()
    dc = Path(sys.argv[2]) if len(sys.argv) > 2 else xml.with_name(xml.stem + '_dataconfig.xml')
    if dc.exists():
        d = etree.parse(str(dc)).getroot()
        ext_ids = {next(((x.text or '').strip() for x in e if local(x.tag) == 'ID'), '')
                   for e in d.iter() if local(e.tag) == 'Extension'}
        for db in (e for e in d.iter() if local(e.tag) == 'DBSystemConfig'):
            sid, dbid, sname = (next((x.text or '').strip() for x in db if local(x.tag) == t)
                                for t in ('SystemID', 'DataBaseID', 'SystemName'))
            switches = [x for x in db if local(x.tag) == 'PolicySwitch']
            ids = Counter()
            for ps in switches:
                f = {local(x.tag): (x.text or '').strip() for x in ps}
                ids[f.get('SwitchablePolicyID')] += 1
                if f.get('SystemID') != sid or f.get('DataBaseID') != dbid:
                    problems += 1
                    print(f'SWITCH   {sname}: PolicySwitch {f.get("SwitchablePolicyID", "")[:8]} has SystemID/DataBaseID '
                          f'not matching its DBSystemConfig')
                if f.get('SwitchablePolicyID') not in ext_ids:
                    problems += 1
                    print(f'SWITCH   {sname}: PolicySwitch for undeclared extension {f.get("SwitchablePolicyID")}')
            for eid, n in ids.items():
                if n > 1:
                    problems += 1
                    print(f'SWITCH   {sname} (dataset {dbid[:8]}): {n} PolicySwitch entries for extension {eid[:8]}')
        used = {e for v in bind.values() for e, _ in v}
        for eid in sorted(used - ext_ids):
            problems += 1
            print(f'UNDECLARED extension {eid} is bound in the model but not declared in {dc.name}')
    else:
        print(f'(no dataconfig checked: {dc} not found)')

    print(f'first system in file: {first}; bound rows: {bound_rows}; problems: {problems}')
    return 1 if problems else 0


if __name__ == '__main__':
    sys.exit(main())
