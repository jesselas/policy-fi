#!/usr/bin/env python3
"""Tracked-change editing of Word documents with python-docx (w:ins / w:del markup).

Every edit made through these helpers shows in Word as a tracked change by AUTHOR, so the
country teams can accept or reject it. Formatting of the run where an edit starts is copied
to inserted text.

Main helpers
  replace_tracked(par, old, new)        replace text inside a paragraph (can span runs)
  insert_text_tracked(par, text, after=None)  insert text at the end or after a substring
  delete_paragraph_tracked(par)         mark a whole paragraph as deleted
  insert_paragraph_after(par, text, style=None)   new paragraph, fully tracked as inserted
  set_cell_tracked(cell, new_text)      replace a table cell's text
  add_table_column_tracked(table, header_texts, values, after_col) add a column to a table
  find_paragraph(doc, startswith|contains)
"""
import copy, datetime, itertools, os, re
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph

# Revision author shown in Word: the institution or name agreed for the report. Set REPORT_AUTHOR or
# call set_author() before editing.
AUTHOR = os.environ.get('REPORT_AUTHOR', '<author>')


def set_author(name):
    global AUTHOR
    AUTHOR = name
DATE = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
_ids = itertools.count(9000)


def _mark(tag):
    el = OxmlElement(tag)
    el.set(qn('w:id'), str(next(_ids)))
    el.set(qn('w:author'), AUTHOR)
    el.set(qn('w:date'), DATE)
    return el


def _run_like(src_r, text, deleted=False):
    """New w:r with src_r's rPr and the given text (w:t or w:delText)."""
    r = OxmlElement('w:r')
    if src_r is not None:
        rpr = src_r.find(qn('w:rPr'))
        if rpr is not None:
            r.append(copy.deepcopy(rpr))
    t = OxmlElement('w:delText' if deleted else 'w:t')
    t.set(qn('xml:space'), 'preserve')
    t.text = text
    r.append(t)
    return r


def _runs(p_el):
    """Direct text runs of a paragraph element, including those inside hyperlinks / smartTags, in order,
    skipping runs already inside w:del."""
    out = []
    for r in p_el.iter(qn('w:r')):
        anc = r.getparent()
        skip = False
        while anc is not None and anc is not p_el:
            if anc.tag == qn('w:del'):
                skip = True
            anc = anc.getparent()
        if not skip and r.find(qn('w:t')) is not None:
            out.append(r)
    return out


def _rtext(r):
    return ''.join(t.text or '' for t in r.findall(qn('w:t')))


def _split_run(r, pos):
    """Split run r at character pos; return (left, right). left keeps the original element."""
    txt = _rtext(r)
    if pos <= 0 or pos >= len(txt):
        return (r, None) if pos >= len(txt) else (None, r)
    right = copy.deepcopy(r)
    for t in r.findall(qn('w:t'))[1:]:
        r.remove(t)
    r.find(qn('w:t')).text = txt[:pos]
    r.find(qn('w:t')).set(qn('xml:space'), 'preserve')
    for t in right.findall(qn('w:t'))[1:]:
        right.remove(t)
    right.find(qn('w:t')).text = txt[pos:]
    right.find(qn('w:t')).set(qn('xml:space'), 'preserve')
    r.addnext(right)
    return r, right


def replace_tracked(par, old, new, occurrence=1):
    """Replace the `occurrence`-th instance of `old` in paragraph `par` by `new`, tracked.
    Returns True if replaced."""
    p = par._p if hasattr(par, '_p') else par
    runs = _runs(p)
    full = ''.join(_rtext(r) for r in runs)
    start = -1
    for _ in range(occurrence):
        start = full.find(old, start + 1)
        if start < 0:
            return False
    end = start + len(old)
    # isolate the runs covering [start, end)
    pos = 0
    covered = []
    for r in list(runs):
        txt = _rtext(r)
        r0, r1 = pos, pos + len(txt)
        pos = r1
        if r1 <= start or r0 >= end:
            continue
        cur = r
        if r0 < start:
            _, cur = _split_run(cur, start - r0)
            r0 = start
        if r1 > end:
            cur, _ = _split_run(cur, end - r0)
        covered.append(cur)
    first = covered[0]
    anchor_parent = first.getparent()
    d = _mark('w:del')
    first.addprevious(d)
    for r in covered:
        txt = _rtext(r)
        dr = _run_like(r, txt, deleted=True)
        d.append(dr)
        r.getparent().remove(r)
    if new:
        ins = _mark('w:ins')
        ins.append(_run_like(covered[0], new))
        d.addnext(ins)
    return True


def insert_text_tracked(par, text, after=None):
    """Insert `text` at the end of the paragraph, or right after the first occurrence of `after`."""
    p = par._p if hasattr(par, '_p') else par
    runs = _runs(p)
    ins = _mark('w:ins')
    if after is None:
        src = runs[-1] if runs else None
        ins.append(_run_like(src, text))
        if src is not None:
            # place after the last run's top-level container
            node = src
            while node.getparent() is not p:
                node = node.getparent()
            node.addnext(ins)
        else:
            p.append(ins)
        return True
    full = ''.join(_rtext(r) for r in runs)
    k = full.find(after)
    if k < 0:
        return False
    cut = k + len(after)
    pos = 0
    for r in runs:
        txt = _rtext(r)
        if pos + len(txt) >= cut:
            left, _ = _split_run(r, cut - pos)
            ins.append(_run_like(r, text))
            (left if left is not None else r).addnext(ins) if left is not None else r.addprevious(ins)
            return True
        pos += len(txt)
    return False


def delete_paragraph_tracked(par):
    p = par._p
    for r in _runs(p):
        d = _mark('w:del')
        r.addprevious(d)
        d.append(_run_like(r, _rtext(r), deleted=True))
        r.getparent().remove(r)
    # mark paragraph mark as deleted so the paragraphs merge when accepted
    ppr = p.get_or_add_pPr()
    rpr = ppr.find(qn('w:rPr'))
    if rpr is None:
        rpr = OxmlElement('w:rPr'); ppr.append(rpr)
    rpr.append(_mark('w:del'))


def insert_paragraph_after(par, text, style=None, copy_format_from=None):
    """Insert a new paragraph after `par`, tracked as inserted. Returns the new Paragraph."""
    new_p = OxmlElement('w:p')
    src = copy_format_from if copy_format_from is not None else par
    ppr = src._p.find(qn('w:pPr'))
    if ppr is not None:
        new_p.append(copy.deepcopy(ppr))
    par._p.addnext(new_p)
    np_ = Paragraph(new_p, par._parent)
    if style is not None:
        np_.style = style
    ppr = new_p.get_or_add_pPr()
    for old in ppr.findall(qn('w:rPr')):
        ppr.remove(old)
    rpr = OxmlElement('w:rPr'); rpr.append(_mark('w:ins')); ppr.append(rpr)
    src_runs = _runs(src._p)
    ins = _mark('w:ins')
    ins.append(_run_like(src_runs[0] if src_runs else None, text))
    new_p.append(ins)
    return np_


def set_cell_tracked(cell, new_text):
    """Replace the whole text of a table cell (first paragraph), tracked."""
    par = cell.paragraphs[0]
    old = ''.join(_rtext(r) for r in _runs(par._p))
    if old == new_text:
        return
    if old:
        replace_tracked(par, old, new_text)
    else:
        insert_text_tracked(par, new_text)
    for extra in cell.paragraphs[1:]:
        if extra.text:
            delete_paragraph_tracked(extra)


def add_table_column_tracked(table, after_col, values):
    """Insert a column after column index `after_col`; `values` = list of cell texts per row.
    The new cells are copies of the cells in `after_col` with their text tracked as inserted,
    and the grid column is marked as inserted (w:ins on each cell's tcPr)."""
    tbl = table._tbl
    grid = tbl.tblGrid
    gcols = grid.findall(qn('w:gridCol'))
    grid_new = copy.deepcopy(gcols[min(after_col, len(gcols) - 1)])
    gcols[min(after_col, len(gcols) - 1)].addnext(grid_new)
    for row, val in zip(table.rows, values):
        tcs = row._tr.findall(qn('w:tc'))
        # map logical column to tc accounting for gridSpan
        idx, target = 0, tcs[-1]
        for tc in tcs:
            span = tc.tcPr.find(qn('w:gridSpan')) if tc.tcPr is not None else None
            n = int(span.get(qn('w:val'))) if span is not None else 1
            if idx <= after_col < idx + n:
                target = tc; break
            idx += n
        new_tc = copy.deepcopy(target)
        tcpr = new_tc.get_or_add_tcPr()
        for gs in tcpr.findall(qn('w:gridSpan')):
            tcpr.remove(gs)
        tcpr.append(_mark('w:cellIns'))
        ps = new_tc.findall(qn('w:p'))
        for extra in ps[1:]:
            new_tc.remove(extra)
        p = ps[0]
        for r in list(p):
            if r.tag != qn('w:pPr'):
                p.remove(r)
        src_runs = _runs(target.findall(qn('w:p'))[0])
        if val:
            ins = _mark('w:ins'); ins.append(_run_like(src_runs[0] if src_runs else None, val)); p.append(ins)
        target.addnext(new_tc)


def find_paragraph(doc, startswith=None, contains=None, after=None):
    """First paragraph (in body order) matching; `after` = a paragraph to start after."""
    started = after is None
    for p in doc.paragraphs:
        if not started:
            started = p._p is after._p
            continue
        t = p.text
        if (startswith and t.strip().startswith(startswith)) or (contains and contains in t):
            return p
    return None
