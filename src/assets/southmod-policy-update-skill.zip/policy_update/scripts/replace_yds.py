#!/usr/bin/env python3
"""Base-year consistency (Essential): set yds = ils_dispyki, person by person, in a base-year input dataset.

In a base-year system (system year = dataset year) the input yds must equal the simulated ils_dispyki
of that system's default output, so that ils_con = xhh. Redo after any model or data change that moves
disposable income in a base-year system, then rerun that system and check again.

usage:
  python3 $SKILL/scripts/replace_yds.py --check   <input .txt|.txt.gz> <base-year output .txt|.txt.gz>
  python3 $SKILL/scripts/replace_yds.py --replace <input .txt|.txt.gz> <base-year output .txt|.txt.gz> [--also <copy.txt> ...]
--replace rewrites the input (and every --also copy, e.g. the unpacked model Input/ file). Only the yds
column changes; every other byte is kept (line endings included). Pass: max |yds - ils_dispyki| < 1
currency unit and max |xhh - ils_con| < 1 after the rerun.
"""
import gzip, os, sys

def opener(p, mode):
    return gzip.open(p, mode + 't', newline='') if p.endswith('.gz') else open(p, mode, newline='')

def cols(path, names):
    with opener(path, 'r') as f:
        head = f.readline().rstrip('\r\n').split('\t')
        ix = [head.index(n) for n in names]
        out = {}
        for ln in f:
            c = ln.rstrip('\r\n').split('\t')
            if len(c) > 1:
                out[c[ix[0]]] = [c[j] for j in ix[1:]]
        return out

def main(argv):
    if len(argv) < 3 or argv[0] not in ('--check', '--replace'):
        sys.exit(__doc__)
    mode, inp, outp = argv[:3]
    also = argv[4:] if len(argv) > 3 and argv[3] == '--also' else []
    sim = cols(outp, ['idperson', 'ils_dispyki', 'ils_con'])
    with opener(inp, 'r') as f:
        lines = f.read().split('\n')
    head = lines[0].rstrip('\r').split('\t')
    i, k, x = head.index('idperson'), head.index('yds'), head.index('xhh')
    dmax = cmax = 0.0; changed = missing = 0
    for n in range(1, len(lines)):
        ln = lines[n]
        if not ln.strip():
            continue
        cr = ln.endswith('\r')
        c = ln.rstrip('\r').split('\t')
        s = sim.get(c[i])
        if s is None:
            missing += 1; continue
        d = abs(float(c[k]) - float(s[0])); dmax = max(dmax, d)
        cmax = max(cmax, abs(float(c[x]) - float(s[1])))
        if d > 1e-6:
            changed += 1
            c[k] = s[0]
            lines[n] = '\t'.join(c) + ('\r' if cr else '')
    print(f'{os.path.basename(inp)}: {changed} persons with yds != ils_dispyki (max |diff| {dmax:.4g}); '
          f'max |xhh - ils_con| {cmax:.4g}; {missing} persons not in output')
    if mode == '--replace' and changed:
        txt = '\n'.join(lines)
        for p in [inp] + also:
            with opener(p, 'w') as f:
                f.write(txt)
            print('  rewritten', p)

if __name__ == '__main__':
    main(sys.argv[1:])
