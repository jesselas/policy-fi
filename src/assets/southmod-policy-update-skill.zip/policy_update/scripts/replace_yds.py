#!/usr/bin/env python3
"""Base-year consistency: check or set yds = ils_dispyki, person by person, in a base-year input dataset.

In a base-year system (system year = dataset year) the input yds must equal the simulated ils_dispyki of
that system's default output. Redo after any model or data change that moves disposable income in a
base-year system, then rerun that system and check again.

usage:
  python3 $SKILL/scripts/replace_yds.py --check   INPUT OUTPUT [options]
  python3 $SKILL/scripts/replace_yds.py --replace INPUT OUTPUT [--also COPY ...] [options]
INPUT/OUTPUT/COPY: tab-separated .txt or .txt.gz (EUROMOD input dataset; base-year output).

options:
  --id idperson   person identifier (both files)
  --tol X         pass tolerance for |yds - ils_dispyki|, in dataset currency units. Default: one unit of
                  the last decimal exported in the output's ils_dispyki (export precision); always printed.
  --con-check     also gate on |xhh - ils_con| (needs --tol-con). Use it only after verifying in the model
                  that its ils_con equals xhh in a base year. Without it the consumption difference is
                  printed for information and does NOT count as a consumption check.
  --tol-con X     tolerance for the consumption check, in dataset units.

Before anything is written: required columns exist exactly once; IDs are nonmissing and unique in both
files; both files contain the same people; required values are finite numbers. --check never writes.
--replace puts the output's ils_dispyki tokens into yds in a temporary file, verifies that only yds tokens
changed (every other token, line ending and the line count kept) and that yds now matches, then replaces
the file atomically. Every --also copy must hold the same content as INPUT (e.g. the .txt.gz archive and
the unpacked Input/ .txt); all copies are written and verified before any is replaced.

exit codes: 0 pass (check) or replaced and verified; 1 check failed (differences beyond tolerance);
2 invalid input (columns, IDs, populations, values, copies differ). Files are unchanged on exit 1 or 2.
"""
import argparse, gzip, math, os, sys, tempfile

MISSING = ('', '.', 'NA', 'NaN', 'nan')


class Invalid(Exception):
    pass


def read_text(path):
    raw = open(path, 'rb').read()
    if path.endswith('.gz'):
        raw = gzip.decompress(raw)
    return raw.decode('utf-8')


def write_tmp(path, text):
    d = os.path.dirname(os.path.abspath(path))
    fd, tmp = tempfile.mkstemp(dir=d, prefix='.yds_tmp_', suffix='.gz' if path.endswith('.gz') else '.txt')
    os.close(fd)
    data = text.encode('utf-8')
    if path.endswith('.gz'):
        with gzip.GzipFile(tmp, 'wb', mtime=0) as g:
            g.write(data)
    else:
        with open(tmp, 'wb') as f:
            f.write(data)
    return tmp


def split_lines(text):
    body, ends = [], []
    for ln in text.splitlines(keepends=True):
        s = ln.rstrip('\r\n')
        body.append(s); ends.append(ln[len(s):])
    return body, ends


def parse(text, name, idcol, need):
    """Return header, lines, line ends, {id: {var: (float, token)}}, {id: line index}."""
    body, ends = split_lines(text)
    if not body:
        raise Invalid(f'{name}: empty file')
    head = body[0].split('\t')
    dup = sorted({c for c in head if head.count(c) > 1})
    if dup:
        raise Invalid(f'{name}: duplicate column names {dup}')
    miss = [c for c in [idcol] + need if c not in head]
    if miss:
        raise Invalid(f'{name}: missing columns {miss}')
    ix = {c: head.index(c) for c in [idcol] + need}
    rows, where, dups, bad = {}, {}, [], []
    for n in range(1, len(body)):
        if body[n] == '':
            continue
        c = body[n].split('\t')
        if len(c) != len(head):
            raise Invalid(f'{name}: line {n + 1} has {len(c)} fields, header has {len(head)}')
        pid = c[ix[idcol]].strip()
        if pid in MISSING:
            raise Invalid(f'{name}: missing {idcol} on line {n + 1}')
        if pid in where:
            dups.append(pid); continue
        where[pid] = n
        vals = {}
        for v in need:
            tok = c[ix[v]]
            try:
                x = float(tok)
            except ValueError:
                x = float('nan')
            if not math.isfinite(x):
                bad.append(f'{v}={tok!r} ({idcol} {pid}, line {n + 1})')
            vals[v] = (x, tok)
        rows[pid] = vals
    if dups:
        raise Invalid(f'{name}: {len(dups)} duplicate {idcol} values, e.g. {dups[:5]}')
    if bad:
        raise Invalid(f'{name}: {len(bad)} missing or nonfinite required values, e.g. {bad[:5]}')
    return head, body, ends, rows, where


def decimals(tokens):
    d = 0
    for t in tokens:
        t = t.strip().lower()
        if '.' in t and 'e' not in t:
            d = max(d, len(t.split('.', 1)[1]))
    return d


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--check', action='store_true'); g.add_argument('--replace', action='store_true')
    ap.add_argument('input'); ap.add_argument('output')
    ap.add_argument('--also', nargs='*', default=[]); ap.add_argument('--id', default='idperson')
    ap.add_argument('--tol', type=float); ap.add_argument('--con-check', action='store_true')
    ap.add_argument('--tol-con', type=float)
    a = ap.parse_args(argv)
    if a.con_check and a.tol_con is None:
        ap.error('--con-check needs --tol-con (in dataset units)')
    if a.check and a.also:
        ap.error('--also is only used with --replace')
    try:
        itext, otext = read_text(a.input), read_text(a.output)
        ineed = ['yds', 'xhh'] if a.con_check else ['yds']
        oneed = ['ils_dispyki', 'ils_con'] if a.con_check else ['ils_dispyki']
        ihead, body, ends, irows, where = parse(itext, 'INPUT', a.id, ineed)
        ohead, _, _, orows, _ = parse(otext, 'OUTPUT', a.id, oneed)
        only_i, only_o = sorted(set(irows) - set(orows)), sorted(set(orows) - set(irows))
        if only_i or only_o:
            raise Invalid(f'populations differ: {len(only_i)} {a.id} only in INPUT (e.g. {only_i[:5]}), '
                          f'{len(only_o)} only in OUTPUT (e.g. {only_o[:5]})')
        diffs = {p: abs(irows[p]['yds'][0] - orows[p]['ils_dispyki'][0]) for p in irows}
        worst = max(diffs, key=diffs.get)
        prec = decimals(v['ils_dispyki'][1] for v in orows.values())
        tol = a.tol if a.tol is not None else 10.0 ** (-prec)
        basis = 'given' if a.tol is not None else f'export precision, {prec} decimals in ils_dispyki'
        slack = tol * 1e-9 + 1e-12   # binary floating point, not a wider tolerance
        over = [p for p, d in diffs.items() if d > tol + slack]
        print(f'{os.path.basename(a.input)}: {len(irows)} persons, same population in both files')
        print(f'  max |yds - ils_dispyki| = {diffs[worst]:.6g} ({a.id} {worst}); '
              f'{len(over)} persons above tolerance {tol:g} ({basis})')
        cmax = None
        if a.con_check:
            cmax = max(abs(irows[p]['xhh'][0] - orows[p]['ils_con'][0]) for p in irows)
            print(f'  max |xhh - ils_con| = {cmax:.6g} (tolerance {a.tol_con:g})')
        elif 'xhh' in ihead and 'ils_con' in ohead:
            try:
                ic = parse(itext, 'INPUT', a.id, ['xhh'])[3]; oc = parse(otext, 'OUTPUT', a.id, ['ils_con'])[3]
                info = max(abs(ic[p]['xhh'][0] - oc[p]['ils_con'][0]) for p in ic)
                print(f'  max |xhh - ils_con| = {info:.6g}: information only, not a consumption check '
                      f'(verify the model\'s ils_con definition, then use --con-check --tol-con)')
            except Invalid as e:
                print(f'  consumption comparison not possible: {e}')
        passed = not over and (cmax is None or cmax <= a.tol_con + 1e-12)
        if a.check:
            print('PASS' if passed else 'FAIL')
            return 0 if passed else 1
        for p in a.also:
            if read_text(p) != itext:
                raise Invalid(f'--also copy differs from INPUT: {p}')
        if not over:
            print('nothing to replace: yds within tolerance' + ('' if passed else '; consumption check FAILED'))
            return 0 if passed else 1
        k = ihead.index('yds')
        new_body = list(body)
        for pid, n in where.items():
            c = new_body[n].split('\t'); c[k] = orows[pid]['ils_dispyki'][1]; new_body[n] = '\t'.join(c)
        new_text = ''.join(b + e for b, e in zip(new_body, ends))
        nb, ne = split_lines(new_text)
        if ne != ends or len(nb) != len(body):
            raise Invalid('internal check failed: line structure changed')
        for n in range(len(body)):
            x, y = body[n].split('\t'), nb[n].split('\t')
            if len(x) != len(y) or any(x[j] != y[j] for j in range(len(x)) if n == 0 or j != k):
                raise Invalid(f'internal check failed: a non-yds token changed on line {n + 1}')
        chk = parse(new_text, 'NEW INPUT', a.id, ['yds'])[3]
        if any(abs(chk[p]['yds'][0] - orows[p]['ils_dispyki'][0]) > tol + slack for p in chk):
            raise Invalid('internal check failed: yds does not match after replacement')
        tmps = []
        try:
            for p in [a.input] + a.also:
                t = write_tmp(p, new_text); tmps.append((t, p))
                if read_text(t) != new_text:
                    raise Invalid(f'temporary file for {p} does not verify')
        except Exception:
            for t, _ in tmps:
                if os.path.exists(t):
                    os.remove(t)
            raise
        for t, p in tmps:
            os.replace(t, p)
            print('  replaced yds in', p)
        print(f'REPLACED {len(over)} yds values; verified that only yds changed. '
              f'Rerun the base-year system and run --check on the new output.')
        return 0
    except (Invalid, OSError, UnicodeDecodeError, EOFError, gzip.BadGzipFile) as e:
        print('INVALID:', e, file=sys.stderr)
        print('FAIL (nothing written)', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
