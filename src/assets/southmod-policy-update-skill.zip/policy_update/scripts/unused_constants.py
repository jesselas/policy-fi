#!/usr/bin/env python3
"""Find constants that are defined but never used, and numbers hard-coded in formulas.

An updated constant that no formula reads hides the fact that the value actually used (a number typed
into a formula, or another constant) was not updated. Run it before and after the update edits.

usage: python3 $SKILL/scripts/unused_constants.py <CC>.xml [SYSTEM ...] [--literals] [--csv out.csv]

For each system (default: all):
  UNUSED   a `$name` defined by an active DefConst (or DefVar-style constant) parameter whose name is not
           referenced in any active function of that system (references are matched case-insensitively
           as `$name` followed by a non-word character);
  LITERAL  (with --literals) numbers written directly in formulas, conditions and amounts of active policy
           functions (ArithOp, BenCalc, SchedCalc, Elig, Allocate, Min, Max), other than 0, 1, 12 and
           100, with or without a period suffix (`5000#m`, `0.15`). Review them: legal values usually
           belong in constants.
Active = the policy and function switches are not off/n/a in that system. Uprating factors (`$f_*`) are
defined by uprating indices, not DefConst, and are not checked.
Exit codes: 0 nothing unused, 1 unused constants found, 2 invalid input.
"""
import csv
import re
import sys
import xml.etree.ElementTree as ET

INACTIVE = {'off', 'n/a'}
POLICY_FUNS = {'arithop', 'bencalc', 'schedcalc', 'elig', 'allocate', 'min', 'max'}
SKIP_PARS = {'tax_unit', 'output_var', 'output_add_var', 'result_var', 'elig_var', 'who_must_be_elig'}
NUM = re.compile(r'(?<![\w$.#])(\d+(?:\.\d+)?)(#[a-z]{1,2}r?)?(?![\w.])', re.I)


def loc(t):
    return t.rsplit('}', 1)[-1]


def tx(e, n):
    for c in e:
        if loc(c.tag) == n:
            return (c.text or '').strip()
    return ''


def kids(e, n):
    return [c for c in e if loc(c.tag) == n]


def ok(e):
    try:
        return float(tx(e, 'Order') or 0)
    except ValueError:
        return 0.0


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    out = None
    if '--csv' in sys.argv:
        out = sys.argv[sys.argv.index('--csv') + 1]
        args = [a for a in args if a != out]
    if not args:
        print(__doc__); return 2
    try:
        root = ET.parse(args[0]).getroot()
    except Exception as ex:
        print(f'cannot parse {args[0]}: {ex}'); return 2
    want = set(args[1:])
    rows, n_unused = [], 0
    systems = [s for s in root.iter() if loc(s.tag) == 'System']
    if want - {tx(s, 'Name') for s in systems}:
        print(f'unknown systems: {sorted(want - {tx(s, "Name") for s in systems})}'); return 2
    for s in systems:
        sn = tx(s, 'Name')
        if want and sn not in want:
            continue
        defs, refs_text = [], []
        for n, p in enumerate(sorted(kids(s, 'Policy'), key=ok), 1):
            if tx(p, 'Switch').lower() in INACTIVE:
                continue
            for m, f in enumerate(sorted(kids(p, 'Function'), key=ok), 1):
                if tx(f, 'Switch').lower() in INACTIVE:
                    continue
                fname = tx(f, 'Name').lower()
                for k, par in enumerate(sorted(kids(f, 'Parameter'), key=ok), 1):
                    pname, val = tx(par, 'Name'), tx(par, 'Value')
                    if val.lower() == 'n/a':
                        continue
                    where = f'{n}.{m}.{k}'
                    if fname == 'defconst' and pname.startswith('$'):
                        defs.append((pname, tx(p, 'Name'), where, val))
                        refs_text.append(val)          # a constant may be built from other constants
                        continue
                    refs_text.append(val)
                    if '--literals' in sys.argv and fname in POLICY_FUNS and pname.lower() not in SKIP_PARS:
                        for mm in NUM.finditer(val):
                            if mm.group(1) in ('0', '1', '12', '100') and not mm.group(2):
                                continue
                            rows.append([sn, 'LITERAL', mm.group(0), tx(p, 'Name'), where, pname, val])
        blob = '\n'.join(refs_text)
        seen = set()
        for name, pol, where, val in defs:
            if name.lower() in seen:
                continue
            seen.add(name.lower())
            if not re.search(re.escape(name) + r'(?!\w)', blob, re.I):
                n_unused += 1
                rows.append([sn, 'UNUSED', name, pol, where, name, val])
    for r in rows:
        print(f'{r[0]}  {r[1]:7s} {r[2]:24s} {r[3]} {r[4]}  {r[5]} = {r[6][:80]}')
    print(f'unused constants: {n_unused}; literals listed: {sum(1 for r in rows if r[1] == "LITERAL")}')
    if out:
        with open(out, 'w', newline='', encoding='utf-8') as fh:
            w = csv.writer(fh)
            w.writerow(['system', 'kind', 'item', 'policy', 'row', 'parameter', 'value'])
            w.writerows(rows)
    return 1 if n_unused else 0


if __name__ == '__main__':
    sys.exit(main())
