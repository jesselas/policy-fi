#!/usr/bin/env python3
"""Audit every change between the previous model version and the current one, and its SM_LOG coverage.

Matches elements by their <ID> (stable across edits), so row renumbering does not create false
differences. Reports, per policy: parameter value changes, parameter name changes (e.g. income-list
members renamed), parameters/functions/policies added or removed, switch changes, uprating indices
changed, and whether the policy appears in the SM_LOG entries CSV. Systems that exist only in the new
version are listed separately (log them as "system added").

usage: python3 $SKILL/scripts/audit_vs_previous.py PREVIOUS/<CC>.xml CURRENT/<CC>.xml [SM_LOG_entries.csv] [--detail POLICY ...]
"""
import sys, csv, re, collections
from lxml import etree
N = '{http://euromod.com/CountryConfig.xsd}'

def load(X):
    r = etree.parse(X).getroot(); par, el = {}, {}
    o = lambda e: float(e.find(N + 'Order').text or 0)
    for s in r.iter(N + 'System'):
        sn = s.find(N + 'Name').text
        for p in sorted(s.findall(N + 'Policy'), key=o):
            pn = p.find(N + 'Name').text
            el[(sn, p.find(N + 'ID').text)] = (pn, '', p.find(N + 'Switch').text)
            for k, f in enumerate(sorted(p.findall(N + 'Function'), key=o), 1):
                el[(sn, f.find(N + 'ID').text)] = (pn, k, f.find(N + 'Switch').text)
                for x in f.findall(N + 'Parameter'):
                    par[(sn, x.find(N + 'ID').text)] = (pn, k, x.find(N + 'Name').text, (x.find(N + 'Value').text or '').strip())
    up = {u.find(N + 'Reference').text: u.find(N + 'YearValues').text for u in r.iter(N + 'UpratingIndex')}
    return par, el, up

args = [a for a in sys.argv[1:] if not a.startswith('--')]
detail = sys.argv[sys.argv.index('--detail') + 1:] if '--detail' in sys.argv else []
if detail: args = args[:len(args) - len(detail)]
op, oe, ou = load(args[0]); np_, ne, nu = load(args[1])
osys = {k[0] for k in op} | {k[0] for k in oe}; nsys = {k[0] for k in np_} | {k[0] for k in ne}
common = osys & nsys
print('systems added:', sorted(nsys - osys), '| removed:', sorted(osys - nsys))
chg = collections.defaultdict(set); det = []
for k, v in np_.items():
    if k[0] not in common: continue
    o = op.get(k)
    if o is None: chg[(v[0], 'parameter added')].add(k[0]); det.append((k[0], v, None))
    else:
        if o[3] != v[3]: chg[(v[0], 'value')].add(k[0]); det.append((k[0], v, o))
        if o[2] != v[2]: chg[(v[0], 'name')].add(k[0]); det.append((k[0], v, o))
for k, v in op.items():
    if k[0] in common and k not in np_: chg[(v[0], 'parameter removed')].add(k[0]); det.append((k[0], None, v))
for k, v in ne.items():
    if k[0] not in common: continue
    if k in oe:
        if oe[k][2] != v[2]: chg[(v[0], 'switch')].add(k[0])
    else: chg[(v[0], 'function/policy added')].add(k[0])
for k, v in oe.items():
    if k[0] in common and k not in ne: chg[(v[0], 'function/policy removed')].add(k[0])
logged = set()
if len(args) > 2:
    for r in csv.DictReader(open(args[2], encoding='utf-8')):
        for p in re.split(r'[,; ]+', r.get('Policy', '')): logged.add(p.strip())
for (pol, kind), ys in sorted(chg.items()):
    tag = '' if len(args) < 3 else ('  logged' if pol in logged else '  NOT IN SM_LOG')
    print(f'{pol:20s} {kind:24s} {",".join(sorted(y[-4:] for y in ys))}{tag}')
print('uprating indices changed:', [k for k in nu if nu[k] != ou.get(k)])
for sysn, new, old in det:
    pol = (new or old)[0]
    if pol in detail: print('  ', sysn, 'new:', new, '| old:', old)
