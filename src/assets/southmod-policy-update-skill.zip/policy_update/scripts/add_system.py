#!/usr/bin/env python3
"""Add a new policy system to a SOUTHMOD country model by cloning an existing one.

Works on the text of the legacy XML (keeps BOM, CRLF line ends and formatting), so the
diff against the original shows only the added blocks.

Usage:
  python3 $SKILL/scripts/add_system.py <bundle_dir> <CC> <SOURCE_SYS> <NEW_SYS> [--comment TEXT] [--cf new|join]

NEW_SYS may be a variant name (<CC>_2025_PIT_reform): the year is the first 4-digit group after the
country code.

What it does (all in <bundle_dir>/XMLParam/...):
  Countries/<CC>/<CC>.xml
    - copies the <System> block of SOURCE_SYS, gives every element in it a new GUID
      (system, policies, functions, parameters; internal references remapped), sets
      Name/Year/Order/Comment, and inserts it after the last <System>.
    - duplicates each <Extension_Policy>/<Extension_Function>/<Extension_Parameter> entry pointing
      to an element of SOURCE_SYS, so extension bindings cover the new system (row-level bindings
      must exist in every system).
    - renames output files: every DefOutput `file` parameter whose value is SOURCE_SYS or starts with
      SOURCE_SYS_ (case-insensitive; e.g. <SRC>_std, <SRC>_hh_std, <SRC>_std_hh), and every ChangeParam
      `Param_NewVal` that targets such a `file` parameter (e.g. an output renamed for a variant).
      Nothing else is renamed by prefix (dataset names and other values stay).
    - conditional formats (GUI colour comparison): by default adds a new entry comparing NEW_SYS with
      SOURCE_SYS (the usual SOUTHMOD pattern: each year against the previous one). --cf join instead
      adds NEW_SYS to the entries that list SOURCE_SYS (what copy-paste in the GUI does).
    - appends the new system after the last <System> in the file; never before the first one (EUROMOD's
      EM3 copy takes row identity and extension bindings from the first <System> in the file).
  Countries/<CC>/<CC>_dataconfig.xml
    - for every <DataBase> with a <DBSystemConfig> for SOURCE_SYS, adds one for NEW_SYS
      (same BestMatch and extension switches).
  Config/ExchangeRatesConfig.xml
    - adds new_sys (lower case) to the <ValidFor> list holding source_sys.
It does NOT change parameter values or uprating indices: do those as separate, commented edits.
UNTESTED IN EUROMOD: open the bundle in the EUROMOD UI and save once to validate.
"""
import argparse, re, uuid
from pathlib import Path

GUID = r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}'


def read(p):
    b = Path(p).read_bytes()
    bom = b.startswith(b'\xef\xbb\xbf')
    return b.decode('utf-8-sig'), bom


def write(p, text, bom):
    Path(p).write_bytes((b'\xef\xbb\xbf' if bom else b'') + text.encode('utf-8'))


def nl_of(text):
    return '\r\n' if '\r\n' in text else '\n'


def system_blocks(text):
    """Yield (start, end, name, id) for each <System>...</System> block (with leading indent)."""
    for m in re.finditer(r'[ \t]*<System>.*?</System>[ \t]*\r?\n', text, re.S):
        blk = m.group(0)
        name = re.search(r'<Name>([^<]+)</Name>', blk).group(1)
        sid = re.search(r'<ID>([^<]+)</ID>', blk).group(1)
        yield m.start(), m.end(), name, sid


def rename_outputs(block, src, new):
    """Rename DefOutput `file` values equal to SRC or starting with SRC_ (case-insensitive), and ChangeParam
    Param_NewVal values that target one of those `file` parameters. Returns (block, number renamed)."""
    pat = re.compile(rf'^{re.escape(src)}(?=_|$)', re.I)
    file_ids, n = set(), 0
    def fun(m):
        nonlocal n
        f = m.group(0)
        if not re.search(r'<Name>\s*DefOutput\s*</Name>', f, re.I):
            return f
        def par(pm):
            nonlocal n
            pb = pm.group(0)
            if not re.search(r'<Name>\s*file\s*</Name>', pb, re.I):
                return pb
            file_ids.add(re.search(r'<ID>([^<]+)</ID>', pb).group(1))
            def val(vm):
                nonlocal n
                if pat.match(vm.group(1)):
                    n += 1
                    return f'<Value><![CDATA[{pat.sub(new.lower() if vm.group(1)[:1].islower() else new, vm.group(1))}]]></Value>'
                return vm.group(0)
            return re.sub(r'<Value><!\[CDATA\[(.*?)\]\]></Value>', val, pb, count=1, flags=re.S)
        return re.sub(r'<Parameter>.*?</Parameter>', par, f, flags=re.S)
    block = re.sub(r'<Function>.*?</Function>', fun, block, flags=re.S)
    def cp(m):
        nonlocal n
        f = m.group(0)
        if not re.search(r'<Name>\s*ChangeParam\s*</Name>', f, re.I):
            return f
        pars = re.findall(r'<Parameter>.*?</Parameter>', f, re.S)
        def g(pb, field):
            mm = re.search(rf'<{field}>(.*?)</{field}>', pb, re.S)
            return (mm.group(1) if mm else '').strip()
        targets = {g(pb, 'Group') for pb in pars if g(pb, 'Name').lower() == 'param_id'
                   and re.sub(r'<!\[CDATA\[|\]\]>', '', g(pb, 'Value')).strip() in file_ids}
        def par(pm):
            nonlocal n
            pb = pm.group(0)
            if g(pb, 'Name').lower() != 'param_newval' or g(pb, 'Group') not in targets:
                return pb
            def val(vm):
                nonlocal n
                if pat.match(vm.group(1)):
                    n += 1
                    return f'<Value><![CDATA[{pat.sub(new.lower() if vm.group(1)[:1].islower() else new, vm.group(1))}]]></Value>'
                return vm.group(0)
            return re.sub(r'<Value><!\[CDATA\[(.*?)\]\]></Value>', val, pb, count=1, flags=re.S)
        return re.sub(r'<Parameter>.*?</Parameter>', par, f, flags=re.S)
    block = re.sub(r'<Function>.*?</Function>', cp, block, flags=re.S)
    return block, n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('bundle'); ap.add_argument('cc'); ap.add_argument('src'); ap.add_argument('new')
    ap.add_argument('--comment', default='')
    ap.add_argument('--cf', choices=['new', 'join'], default='new')
    a = ap.parse_args()
    cc = a.cc.upper()
    ym = re.search(r'_(\d{4})(?:_|$)', a.new)
    if not ym:
        raise SystemExit(f'no 4-digit year after the country code in {a.new}')
    year = ym.group(1)
    xml_p = Path(a.bundle, 'XMLParam', 'Countries', cc, f'{cc}.xml')
    dc_p = Path(a.bundle, 'XMLParam', 'Countries', cc, f'{cc}_dataconfig.xml')
    er_p = Path(a.bundle, 'XMLParam', 'Config', 'ExchangeRatesConfig.xml')

    text, bom = read(xml_p)
    nl = nl_of(text)
    blocks = list(system_blocks(text))
    if any(n == a.new for _, _, n, _ in blocks):
        raise SystemExit(f'{a.new} already exists in {xml_p}')
    src = next((b for b in blocks if b[2] == a.src), None)
    if src is None:
        raise SystemExit(f'{a.src} not found')
    s0, s1, _, src_id = src
    blk = text[s0:s1]

    # map every GUID defined as an <ID> inside the block to a fresh one
    ids = re.findall(rf'<ID>({GUID})</ID>', blk)
    mapping = {old: str(uuid.uuid4()) for old in ids}
    new_blk = re.sub(GUID, lambda m: mapping.get(m.group(0), m.group(0)), blk)

    # system-level fields (the first occurrence of each tag is the system's own)
    max_order = max(int(re.search(r'<Order>(\d+)</Order>', text[b0:b1]).group(1)) for b0, b1, _, _ in blocks)
    head_end = new_blk.index('<Policy>') if '<Policy>' in new_blk else len(new_blk)
    head, rest = new_blk[:head_end], new_blk[head_end:]
    head = re.sub(r'<Name>[^<]*</Name>', f'<Name>{a.new}</Name>', head, count=1)
    if re.search(r'<Year>[^<]*</Year>|<Year\s*/>', head):
        head = re.sub(r'<Year>[^<]*</Year>|<Year\s*/>', f'<Year>{year}</Year>', head, count=1)
    else:  # older systems may lack <Year>: add it after <Order>
        head = re.sub(r'([ \t]*)(<Order>[^<]*</Order>)(\r?\n)', lambda m: f'{m.group(1)}{m.group(2)}{m.group(3)}{m.group(1)}<Year>{year}</Year>{m.group(3)}', head, count=1)
    head = re.sub(r'<Order>[^<]*</Order>', f'<Order>{max_order + 1}</Order>', head, count=1)
    if a.comment:
        head = re.sub(r'<Comment>.*?</Comment>|<Comment\s*/>', f'<Comment><![CDATA[{a.comment}]]></Comment>', head, count=1, flags=re.S)
    rest, n_out = rename_outputs(rest, a.src, a.new)
    new_blk = head + rest

    last_end = blocks[-1][1]
    text = text[:last_end] + new_blk + text[last_end:]

    # extensions: duplicate Extension_Policy / Extension_Function entries of the source system
    def dup_ext(tag, idtag, text):
        out = []
        for m in re.finditer(rf'[ \t]*<{tag}>.*?</{tag}>[ \t]*\r?\n', text, re.S):
            e = m.group(0)
            ref = re.search(rf'<{idtag}>({GUID})</{idtag}>', e).group(1)
            if ref in mapping:
                out.append((m.end(), e.replace(ref, mapping[ref])))
        for pos, e in reversed(out):
            text = text[:pos] + e + text[pos:]
        return text, len(out)
    text, n_ep = dup_ext('Extension_Policy', 'PolicyID', text)
    text, n_ef = dup_ext('Extension_Function', 'FunctionID', text)
    text, n_epar = dup_ext('Extension_Parameter', 'ParameterID', text)

    # conditional formats
    n_cf = 0
    if a.cf == 'new':
        cfs = list(re.finditer(r'[ \t]*<ConditionalFormat>.*?</ConditionalFormat>[ \t]*\r?\n', text, re.S))
        if cfs:
            tmpl = next((m for m in cfs if f'<SystemName>{a.src}</SystemName>' in m.group(0)), cfs[-1]).group(0)
            old_id = re.search(r'<ID>([^<]+)</ID>', tmpl).group(1)
            new_id = str(uuid.uuid4())
            e = tmpl.replace(old_id, new_id)
            e = re.sub(r'<BaseSystemName>[^<]*</BaseSystemName>|<BaseSystemName\s*/>', f'<BaseSystemName>{a.src}</BaseSystemName>', e, count=1)
            e = re.sub(r'([ \t]*)<ConditionalFormat_Systems>.*?</ConditionalFormat_Systems>[ \t]*\r?\n', '', e, flags=re.S)
            ind = re.match(r'[ \t]*', tmpl).group(0) + '  '
            e = e.replace(f'{ind[:-2]}</ConditionalFormat>',
                          f'{ind}<ConditionalFormat_Systems>{nl}{ind}  <ConditionalFormatID>{new_id}</ConditionalFormatID>{nl}'
                          f'{ind}  <SystemName>{a.new}</SystemName>{nl}{ind}</ConditionalFormat_Systems>{nl}{ind[:-2]}</ConditionalFormat>', 1)
            text = text[:cfs[-1].end()] + e + text[cfs[-1].end():]
            n_cf = 1
    def cf_add(m):
        nonlocal n_cf
        e = m.group(0)
        if f'<SystemName>{a.src}</SystemName>' in e:
            n_cf += 1
            fid = re.search(r'<ConditionalFormatID>([^<]+)</ConditionalFormatID>', e).group(1)
            ind = re.match(r'[ \t]*', e).group(0)
            e += (f'{ind}<ConditionalFormat_Systems>{nl}{ind}  <ConditionalFormatID>{fid}</ConditionalFormatID>{nl}'
                  f'{ind}  <SystemName>{a.new}</SystemName>{nl}{ind}</ConditionalFormat_Systems>{nl}')
        return e
    if a.cf == 'join':
        text = re.sub(r'[ \t]*<ConditionalFormat_Systems>.*?</ConditionalFormat_Systems>[ \t]*\r?\n', cf_add, text, flags=re.S)
    write(xml_p, text, bom)

    # dataconfig
    dtext, dbom = read(dc_p)
    new_sid = mapping[src_id]
    n_db = 0
    def db_add(m):
        nonlocal n_db
        e = m.group(0)
        if f'<SystemName>{a.src}</SystemName>' not in e:
            return e
        n_db += 1
        return e + e.replace(src_id, new_sid).replace(f'<SystemName>{a.src}</SystemName>', f'<SystemName>{a.new}</SystemName>')
    dtext = re.sub(r'[ \t]*<DBSystemConfig>.*?</DBSystemConfig>[ \t]*\r?\n', db_add, dtext, flags=re.S)
    write(dc_p, dtext, dbom)

    # exchange rates
    n_er = 0
    if er_p.exists():
        etext, ebom = read(er_p)
        def er_add(m):
            nonlocal n_er
            items = [x.strip() for x in m.group(1).split(',')]
            if a.src.lower() in items and a.new.lower() not in items:
                n_er += 1
                return f'<ValidFor>{a.new.lower()}, {m.group(1)}</ValidFor>'
            return m.group(0)
        etext = re.sub(r'<ValidFor>([^<]*)</ValidFor>', er_add, etext)
        write(er_p, etext, ebom)

    print(f'{a.new}: cloned from {a.src} with {len(mapping)} new IDs; system Order {max_order + 1}; '
          f'{n_ep} Extension_Policy + {n_ef} Extension_Function + {n_epar} Extension_Parameter entries; '
          f'{n_out} output names; {n_cf} conditional formats ({a.cf}); '
          f'{n_db} dataset bindings; {n_er} exchange-rate entries.')


if __name__ == '__main__':
    main()
