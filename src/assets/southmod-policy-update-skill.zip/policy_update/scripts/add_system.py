#!/usr/bin/env python3
"""Add a new policy system to a SOUTHMOD country model by cloning an existing one.

Works on the text of the legacy XML (keeps BOM, CRLF line ends and formatting), so the
diff against the original shows only the added blocks.

Usage:
  python3 $SKILL/scripts/add_system.py <bundle_dir> <CC> <SOURCE_SYS> <NEW_SYS> [--comment TEXT]

What it does (all in <bundle_dir>/XMLParam/...):
  Countries/<CC>/<CC>.xml
    - copies the <System> block of SOURCE_SYS, gives every element in it a new GUID
      (system, policies, functions, parameters; internal references remapped), sets
      Name/Year/Order/Comment, and inserts it after the last <System>.
    - duplicates each <Extension_Policy>/<Extension_Function> entry pointing to a policy or
      function of SOURCE_SYS, so extensions cover the new system.
    - renames DefOutput files (<SOURCE_SYS>_std, _std_hh) to the new system name.
    - adds NEW_SYS to each <ConditionalFormat_Systems> list that contains SOURCE_SYS.
  Countries/<CC>/<CC>_dataconfig.xml
    - for every <DataBase> with a <DBSystemConfig> for SOURCE_SYS, adds one for NEW_SYS
      (same BestMatch and extension switches).
  Config/ExchangeRatesConfig.xml
    - adds new_sys (lower case) to the <ValidFor> list holding source_sys.
It does NOT change parameter values or uprating indices: do those as separate, commented edits.
UNTESTED IN EUROMOD: open the bundle in the EUROMOD UI and save once to validate.
"""
import argparse, re, uuid
from pathlib import Path

GUID = r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}'


def read(p):
    b = Path(p).read_bytes()
    bom = b.startswith(b'\xef\xbb\xbf')
    return b.decode('utf-8-sig'), bom


def write(p, text, bom):
    Path(p).write_bytes((b'\xef\xbb\xbf' if bom else b'') + text.encode('utf-8'))


def nl_of(text):
    return '\r\n' if '\r\n' in text else '\n'


def system_blocks(text):
    """Yield (start, end, name, id) for each <System>...</System> block (with leading indent)."""
    for m in re.finditer(r'[ \t]*<System>.*?</System>[ \t]*\r?\n', text, re.S):
        blk = m.group(0)
        name = re.search(r'<Name>([^<]+)</Name>', blk).group(1)
        sid = re.search(r'<ID>([^<]+)</ID>', blk).group(1)
        yield m.start(), m.end(), name, sid


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('bundle'); ap.add_argument('cc'); ap.add_argument('src'); ap.add_argument('new')
    ap.add_argument('--comment', default='')
    a = ap.parse_args()
    cc = a.cc.upper()
    year = re.search(r'(\d{4})$', a.new).group(1)
    xml_p = Path(a.bundle, 'XMLParam', 'Countries', cc, f'{cc}.xml')
    dc_p = Path(a.bundle, 'XMLParam', 'Countries', cc, f'{cc}_dataconfig.xml')
    er_p = Path(a.bundle, 'XMLParam', 'Config', 'ExchangeRatesConfig.xml')

    text, bom = read(xml_p)
    nl = nl_of(text)
    blocks = list(system_blocks(text))
    if any(n == a.new for _, _, n, _ in blocks):
        raise SystemExit(f'{a.new} already exists in {xml_p}')
    src = next((b for b in blocks if b[2] == a.src), None)
    if src is None:
        raise SystemExit(f'{a.src} not found')
    s0, s1, _, src_id = src
    blk = text[s0:s1]

    # map every GUID defined as an <ID> inside the block to a fresh one
    ids = re.findall(rf'<ID>({GUID})</ID>', blk)
    mapping = {old: str(uuid.uuid4()) for old in ids}
    new_blk = re.sub(GUID, lambda m: mapping.get(m.group(0), m.group(0)), blk)

    # system-level fields (the first occurrence of each tag is the system's own)
    max_order = max(int(re.search(r'<Order>(\d+)</Order>', text[b0:b1]).group(1)) for b0, b1, _, _ in blocks)
    head_end = new_blk.index('<Policy>') if '<Policy>' in new_blk else len(new_blk)
    head, rest = new_blk[:head_end], new_blk[head_end:]
    head = re.sub(r'<Name>[^<]*</Name>', f'<Name>{a.new}</Name>', head, count=1)
    head = re.sub(r'<Year>[^<]*</Year>', f'<Year>{year}</Year>', head, count=1)
    head = re.sub(r'<Order>[^<]*</Order>', f'<Order>{max_order + 1}</Order>', head, count=1)
    if a.comment:
        head = re.sub(r'<Comment>.*?</Comment>|<Comment\s*/>', f'<Comment><![CDATA[{a.comment}]]></Comment>', head, count=1, flags=re.S)
    # output file names (DefOutput 'file' parameters such as <SRC>_std, <SRC>_std_hh)
    rest = re.sub(rf'<!\[CDATA\[{a.src}(_std\w*)\]\]>', lambda m: f'<![CDATA[{a.new}{m.group(1)}]]>', rest, flags=re.I)
    new_blk = head + rest

    last_end = blocks[-1][1]
    text = text[:last_end] + new_blk + text[last_end:]

    # extensions: duplicate Extension_Policy / Extension_Function entries of the source system
    def dup_ext(tag, idtag, text):
        out = []
        for m in re.finditer(rf'[ \t]*<{tag}>.*?</{tag}>[ \t]*\r?\n', text, re.S):
            e = m.group(0)
            ref = re.search(rf'<{idtag}>({GUID})</{idtag}>', e).group(1)
            if ref in mapping:
                out.append((m.end(), e.replace(ref, mapping[ref])))
        for pos, e in reversed(out):
            text = text[:pos] + e + text[pos:]
        return text, len(out)
    text, n_ep = dup_ext('Extension_Policy', 'PolicyID', text)
    text, n_ef = dup_ext('Extension_Function', 'FunctionID', text)

    # conditional formats: add the new system wherever the source system is listed
    n_cf = 0
    def cf_add(m):
        nonlocal n_cf
        e = m.group(0)
        if f'<SystemName>{a.src}</SystemName>' in e:
            n_cf += 1
            fid = re.search(r'<ConditionalFormatID>([^<]+)</ConditionalFormatID>', e).group(1)
            ind = re.match(r'[ \t]*', e).group(0)
            e += (f'{ind}<ConditionalFormat_Systems>{nl}{ind}  <ConditionalFormatID>{fid}</ConditionalFormatID>{nl}'
                  f'{ind}  <SystemName>{a.new}</SystemName>{nl}{ind}</ConditionalFormat_Systems>{nl}')
        return e
    text = re.sub(r'[ \t]*<ConditionalFormat_Systems>.*?</ConditionalFormat_Systems>[ \t]*\r?\n', cf_add, text, flags=re.S)
    write(xml_p, text, bom)

    # dataconfig
    dtext, dbom = read(dc_p)
    new_sid = mapping[src_id]
    n_db = 0
    def db_add(m):
        nonlocal n_db
        e = m.group(0)
        if f'<SystemName>{a.src}</SystemName>' not in e:
            return e
        n_db += 1
        return e + e.replace(src_id, new_sid).replace(f'<SystemName>{a.src}</SystemName>', f'<SystemName>{a.new}</SystemName>')
    dtext = re.sub(r'[ \t]*<DBSystemConfig>.*?</DBSystemConfig>[ \t]*\r?\n', db_add, dtext, flags=re.S)
    write(dc_p, dtext, dbom)

    # exchange rates
    n_er = 0
    if er_p.exists():
        etext, ebom = read(er_p)
        def er_add(m):
            nonlocal n_er
            items = [x.strip() for x in m.group(1).split(',')]
            if a.src.lower() in items and a.new.lower() not in items:
                n_er += 1
                return f'<ValidFor>{a.new.lower()}, {m.group(1)}</ValidFor>'
            return m.group(0)
        etext = re.sub(r'<ValidFor>([^<]*)</ValidFor>', er_add, etext)
        write(er_p, etext, ebom)

    print(f'{a.new}: cloned from {a.src} with {len(mapping)} new IDs; system Order {max_order + 1}; '
          f'{n_ep} Extension_Policy + {n_ef} Extension_Function entries; {n_cf} conditional formats; '
          f'{n_db} dataset bindings; {n_er} exchange-rate entries.')


if __name__ == '__main__':
    main()
