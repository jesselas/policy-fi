#!/usr/bin/env python3
"""Extract every policy/function/parameter cell of a SOUTHMOD country XML into a long CSV.

Usage: python3 $SKILL/scripts/extract_params.py <CC>.xml out.csv
Columns: system, pol_no, policy, pol_switch, fun_no, function, fun_switch, fun_comment,
         par_no, parameter, group, value, par_comment  (numbering = GUI order, as spine.py)
"""
import csv, sys
import xml.etree.ElementTree as ET

def loc(t): return t.rsplit('}', 1)[-1]
def ch(e, n):
    for c in e:
        if loc(c.tag) == n: return c
def tx(e, n):
    c = ch(e, n); return (c.text or '').strip() if c is not None else ''
def ok(e):
    try: return float(tx(e, 'Order') or 0)
    except ValueError: return 0.0

root = ET.parse(sys.argv[1]).getroot()
w = csv.writer(open(sys.argv[2], 'w', newline='', encoding='utf-8'))
w.writerow(['system','pol_no','policy','pol_switch','pol_comment','fun_no','function','fun_switch','fun_comment','par_no','parameter','group','value','par_comment'])
for s in [e for e in root.iter() if loc(e.tag) == 'System']:
    pols = sorted([p for p in s if loc(p.tag) == 'Policy'], key=ok)
    for n, p in enumerate(pols, 1):
        funs = sorted([f for f in p if loc(f.tag) == 'Function'], key=ok)
        for m, f in enumerate(funs, 1):
            pars = sorted([x for x in f if loc(x.tag) == 'Parameter'], key=ok)
            for k, x in enumerate(pars, 1):
                w.writerow([tx(s,'Name'), n, tx(p,'Name'), tx(p,'Switch'), tx(p,'Comment'), f'{n}.{m}', tx(f,'Name'), tx(f,'Switch'), tx(f,'Comment'), k, tx(x,'Name'), tx(x,'Group'), tx(x,'Value'), tx(x,'Comment')])
