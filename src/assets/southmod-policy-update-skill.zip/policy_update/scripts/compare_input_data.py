#!/usr/bin/env python3
"""Compare a rebuilt input dataset with its target, by person ID: schema, order, IDs and every column.

Tolerances are explicit, per variable, in the variable's own units and stored precision. Nothing gets a
tolerance from its name prefix: IDs, counts, classifications and flags are exact unless you say otherwise.
  --tol VAR=X [VAR=X ...]   absolute tolerance for named variables (e.g. xhh=0.01)
  --tol-file FILE           CSV with columns variable,tolerance (e.g. monetary variables at export precision)
  --id idperson             person identifier
Missing values match only missing values. Text columns compare exactly.

usage: python3 $SKILL/scripts/compare_input_data.py TARGET REBUILT --out DIR/name [--tol ...] [--tol-file ...]
Writes name.csv (per variable) and name.json (summary).
exit codes: 0 identical within the given tolerances; 1 differences; 2 invalid IDs or tolerance spec.
"""
import argparse, json, sys
from pathlib import Path
import pandas as pd


def read(path):
    if str(path).endswith('.dta'):
        return pd.read_stata(path, convert_categoricals=False)
    return pd.read_csv(path, sep='\t', low_memory=False)


def compare(target, rebuilt, tol, idcol='idperson'):
    for name, frame in [('target', target), ('rebuilt', rebuilt)]:
        if idcol not in frame or frame[idcol].isna().any() or frame[idcol].duplicated().any():
            raise ValueError(f'{name}: missing, incomplete or nonunique {idcol}')
    unknown = sorted(set(tol) - set(target.columns))
    if unknown:
        raise ValueError(f'tolerances given for variables not in target: {unknown}')
    meta = dict(target_rows=len(target), rebuilt_rows=len(rebuilt),
                columns_same_order=list(target) == list(rebuilt),
                missing_columns=sorted(set(target) - set(rebuilt)),
                extra_columns=sorted(set(rebuilt) - set(target)),
                missing_ids=len(set(target[idcol]) - set(rebuilt[idcol])),
                extra_ids=len(set(rebuilt[idcol]) - set(target[idcol])),
                same_row_order=len(target) == len(rebuilt) and (target[idcol].values == rebuilt[idcol].values).all(),
                tolerances=tol)
    a, b = target.set_index(idcol), rebuilt.set_index(idcol)
    ids = a.index.intersection(b.index)
    a, b = a.loc[ids], b.loc[ids]
    rows = []
    for col in a.columns.intersection(b.columns, sort=False):
        x, z = a[col], b[col]
        t = float(tol.get(col, 0))
        if pd.api.types.is_numeric_dtype(x) and pd.api.types.is_numeric_dtype(z):
            delta = (x.astype(float) - z.astype(float)).abs()
            mismatch = (x.isna() != z.isna()) | (delta > t)
            maximum = float(delta.max()) if delta.notna().any() else 0
        else:
            mismatch = ~((x.astype(str) == z.astype(str)) | (x.isna() & z.isna()))
            maximum = None
        rows.append(dict(variable=col, tolerance=t, differing=int(mismatch.sum()), max_abs_difference=maximum,
                         target_missing=int(x.isna().sum()), rebuilt_missing=int(z.isna().sum())))
    table = pd.DataFrame(rows)
    meta['changed_columns'] = int((table.differing > 0).sum()) if len(table) else 0
    meta['pass'] = bool(meta['columns_same_order'] and not meta['missing_columns'] and not meta['extra_columns']
                        and not meta['missing_ids'] and not meta['extra_ids'] and not meta['changed_columns'])
    return meta, table


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('target'); p.add_argument('rebuilt'); p.add_argument('--out', required=True)
    p.add_argument('--tol', nargs='*', default=[]); p.add_argument('--tol-file'); p.add_argument('--id', default='idperson')
    a = p.parse_args(argv)
    try:
        tol = {}
        if a.tol_file:
            f = pd.read_csv(a.tol_file)
            tol.update(dict(zip(f.variable.astype(str), f.tolerance.astype(float))))
        for s in a.tol:
            k, v = s.split('=', 1); tol[k] = float(v)
        if any(v < 0 for v in tol.values()):
            raise ValueError('negative tolerance')
        meta, table = compare(read(a.target), read(a.rebuilt), tol, a.id)
    except ValueError as e:
        print('INVALID:', e, file=sys.stderr); return 2
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    table.to_csv(out.with_suffix('.csv'), index=False)
    out.with_suffix('.json').write_text(json.dumps(meta, indent=2, default=bool) + '\n')
    print(json.dumps(meta, default=bool))
    if len(table):
        print(table.loc[table.differing > 0, ['variable', 'tolerance', 'differing', 'max_abs_difference']].to_string(index=False))
    return 0 if meta['pass'] else 1


if __name__ == '__main__':
    sys.exit(main())
