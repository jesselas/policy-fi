#!/usr/bin/env python3
"""Compare input datasets by idperson: schema/order, IDs and per-column changes.

Money prefixes b/k/p/t/x/y use absolute tolerance 0.01; all other columns are exact.
Use --money to override that classification with an explicit comma-separated list.
Missing values match only missing values. Exit 1 means differences, 2 invalid IDs.
"""
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd


def read(path):
    if str(path).endswith('.dta'):
        return pd.read_stata(path, convert_categoricals=False)
    return pd.read_csv(path, sep='\t', low_memory=False)


def compare(target, rebuilt, money=None):
    for name, frame in [('target', target), ('rebuilt', rebuilt)]:
        if 'idperson' not in frame or frame.idperson.isna().any() or frame.idperson.duplicated().any():
            raise ValueError(f'{name}: missing/nonunique idperson')
    meta = dict(target_rows=len(target), rebuilt_rows=len(rebuilt),
                columns_same_order=list(target)==list(rebuilt),
                missing_columns=sorted(set(target)-set(rebuilt)),
                extra_columns=sorted(set(rebuilt)-set(target)),
                missing_ids=len(set(target.idperson)-set(rebuilt.idperson)),
                extra_ids=len(set(rebuilt.idperson)-set(target.idperson)))
    a, b = target.set_index('idperson'), rebuilt.set_index('idperson')
    ids = a.index.intersection(b.index)
    a, b = a.loc[ids], b.loc[ids]
    rows=[]
    for col in a.columns.intersection(b.columns,sort=False):
        x,z=a[col],b[col]
        tolerance = .01 if (col in money if money is not None else col[0] in 'bkptxy') else 0
        if pd.api.types.is_numeric_dtype(x) and pd.api.types.is_numeric_dtype(z):
            delta=(x.astype(float)-z.astype(float)).abs()
            mismatch=(x.isna()!=z.isna()) | (delta>tolerance)
            maximum=float(delta.max()) if delta.notna().any() else 0
        else:
            mismatch=~((x==z)|(x.isna() & z.isna()))
            maximum=None
        rows.append(dict(variable=col,tolerance=tolerance,differing=int(mismatch.sum()),max_abs_difference=maximum,
                         target_missing=int(x.isna().sum()),rebuilt_missing=int(z.isna().sum())))
    table=pd.DataFrame(rows)
    meta['changed_columns']=int((table.differing>0).sum())
    meta['pass']=bool(meta['columns_same_order'] and not meta['missing_ids'] and not meta['extra_ids'] and not meta['changed_columns'])
    return meta,table


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('target');p.add_argument('rebuilt');p.add_argument('--out',required=True);p.add_argument('--money')
    a=p.parse_args()
    meta,table=compare(read(a.target),read(a.rebuilt),None if a.money is None else set(a.money.split(',')))
    out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
    table.to_csv(out.with_suffix('.csv'),index=False)
    out.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(json.dumps(meta));print(table.loc[table.differing>0,['variable','differing','max_abs_difference']].to_string(index=False))
    raise SystemExit(0 if meta['pass'] else 1)

if __name__=='__main__':main()
