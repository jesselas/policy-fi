#!/usr/bin/env python3
"""Post-fiscal poverty lines from a EUROMOD output (generic SOUTHMOD method).

Method (as in the SOUTHMOD Stata steps): collapse the output to households (sum ils_taxco, ils_benco,
ils_con; ses summed if it varies within the household, else taken once; first of spl and the group
variable), equivalise consumption ils_con/ses and NET indirect taxes (ils_taxco - ils_benco)/ses, and
subtract from the line the UNWEIGHTED mean equivalised net indirect tax of households whose equivalised
consumption lies within +/- band (default 2.5%) of the line. Indirect benefits (ils_benco, e.g. fuel
subsidies) enter with a minus sign because post-fiscal income is ils_dispy - ils_taxco + ils_benco.

Per system, nominal: run it on each system's output. The line is taken from the output variable
(--line-var, default spl = the system's CPI-uprated line); scale a second line with --ratio (e.g. extreme
line = spl * extreme/basic). If the model uprates the post-fiscal constant by a CPI factor, divide the
result by that factor before writing it back (better: make the model use it nominally, per system).

usage:
  python3 $SKILL/scripts/pf_povlines.py OUTPUT.txt[.gz] [--line-var spl] [--group drgn1] [--band 0.025]
          [--ratio 1.0] [--compare 1234.5 ...]
Prints the post-fiscal line (per group if --group) and the number of households in the band. Use
--compare with the model's current constants (same order as the groups) to see the change in per cent.
A system is final when a rerun leaves every line unchanged (fixed point).
"""
import argparse
import pandas as pd

ap = argparse.ArgumentParser(); ap.add_argument('output')
ap.add_argument('--line-var', default='spl'); ap.add_argument('--group'); ap.add_argument('--band', type=float, default=0.025)
ap.add_argument('--ratio', type=float, default=1.0); ap.add_argument('--compare', type=float, nargs='*')
a = ap.parse_args()
use = {'idhh', 'idperson', 'ils_taxco', 'ils_benco', 'ils_con', 'ses', a.line_var} | ({a.group} if a.group else set())
d = pd.read_csv(a.output, sep='\t', low_memory=False, usecols=lambda c: c in use)
if 'ils_benco' not in d: d['ils_benco'] = 0.0
ses_varies = d.groupby('idhh').ses.nunique().max() > 1
agg = dict(tax=('ils_taxco', 'sum'), ben=('ils_benco', 'sum'), con=('ils_con', 'sum'),
           ses=('ses', 'sum' if ses_varies else 'first'), line=(a.line_var, 'first'))
if a.group: agg['grp'] = (a.group, 'first')
h = d.groupby('idhh').agg(**agg)
h['line'] = h.line * a.ratio
h['eqc'] = h.con / h.ses; h['eqt'] = (h.tax - h.ben) / h.ses
groups = sorted(h.grp.unique()) if a.group else [None]
print(f'ses {"summed (varies within households)" if ses_varies else "taken once per household"}')
for n, g in enumerate(groups):
    s = h if g is None else h[h.grp == g]
    line = s.line.iloc[0]
    band = s[(s.eqc >= line * (1 - a.band)) & (s.eqc <= line * (1 + a.band))]
    pf = line - band.eqt.mean()
    msg = f'group {g}: ' if g is not None else ''
    cmp = ''
    if a.compare and n < len(a.compare):
        cmp = f'  model {a.compare[n]:.4f} -> {pf:.4f} ({(pf / a.compare[n] - 1) * 100:+.3f}%)'
    print(f'{msg}line {line:.4f} -> post-fiscal {pf:.4f} (households in band: {len(band)}){cmp}')
