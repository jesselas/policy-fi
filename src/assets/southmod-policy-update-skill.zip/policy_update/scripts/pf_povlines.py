#!/usr/bin/env python3
"""Post-fiscal poverty lines from a EUROMOD output (the usual SOUTHMOD method; conventions are explicit).

Method: collapse the output to households (sum ils_taxco, ils_benco and ils_con over members; household
scale and line per --ses-agg / first member), equivalise consumption ils_con/ses and NET indirect taxes
(ils_taxco - ils_benco)/ses, and subtract from the line the mean equivalised net indirect tax of households
whose equivalised consumption lies within +/- band of the line. Indirect benefits (ils_benco, e.g. fuel
subsidies) enter with a minus sign because post-fiscal income is ils_dispy - ils_taxco + ils_benco.
Run it per system (nominal lines). A system is final when a rerun leaves every stored line unchanged.

Conventions differ between models: verify each in the model and its report, then pass it explicitly.
  --ses-agg sum|household   REQUIRED. How the household equivalence scale is stored in the output:
                            sum = per-person contributions that add up to the household scale;
                            household = the household total repeated on every member (checked: must be
                            constant within households). The data cannot tell these apart reliably.
  --line-var spl            line variable in the output (must be constant within each household and group)
  --group VAR               lines per group (e.g. region, urban/rural); constant within households
  --ratio r                 scale the line (e.g. extreme = basic * extreme/basic ratio)
  --band 0.025              half-width of the band, as a share of the line
  --mean unweighted|weighted   mean over band households (default unweighted; weighted uses --weight)
  --weight dwt              household weight (first member) for --mean weighted
  --no-benco                allow an output without ils_benco (treated as 0; stated in the output)
  --compare V [V ...]       the model's stored constants: plain numbers in the printed group order, or
                            GROUP=VALUE pairs; must cover every group exactly
  --precision N             decimals stored in the model (default: the decimals of the --compare values)
  --min-hh 1                fail if a band holds fewer households
  --csv FILE                write the results

usage:
  python3 $SKILL/scripts/pf_povlines.py OUTPUT.txt[.gz] --ses-agg sum [--group drgn1] --compare 1234.56 ...

exit codes: 0 computed (and, with --compare, every line a fixed point at the stored precision);
1 computed but at least one line moved; 2 invalid input or empty/too small band (no result written).
"""
import argparse, math, sys
import numpy as np
import pandas as pd


class Invalid(Exception):
    pass


def ndec(tok):
    tok = tok.strip()
    return len(tok.split('.', 1)[1]) if '.' in tok and 'e' not in tok.lower() else 0


def households(d, a):
    for v in ['idhh', 'ils_taxco', 'ils_con', 'ses', a.line_var] + ([a.group] if a.group else []) + \
             (['ils_benco'] if not a.no_benco else []) + ([a.weight] if a.mean == 'weighted' else []):
        if v not in d:
            raise Invalid(f'missing column {v}' + (' (use --no-benco if the model has no indirect benefits)'
                                                  if v == 'ils_benco' else ''))
    if 'ils_benco' not in d:
        d['ils_benco'] = 0.0
    num = ['ils_taxco', 'ils_benco', 'ils_con', 'ses', a.line_var] + ([a.weight] if a.mean == 'weighted' else [])
    for v in num:
        x = pd.to_numeric(d[v], errors='coerce')
        bad = ~np.isfinite(x)
        if bad.any():
            raise Invalid(f'{int(bad.sum())} missing or nonfinite values in {v}')
        d[v] = x
    if d.idhh.isna().any():
        raise Invalid('missing idhh')
    g = d.groupby('idhh', sort=True)
    for v in [a.line_var] + ([a.group] if a.group else []):
        k = g[v].nunique(dropna=False)
        if (k > 1).any():
            raise Invalid(f'{v} varies within {int((k > 1).sum())} households (e.g. idhh {k[k > 1].index[0]})')
    if a.ses_agg == 'household':
        k = g.ses.nunique()
        if (k > 1).any():
            raise Invalid(f'--ses-agg household, but ses varies within {int((k > 1).sum())} households: '
                          'check the model; per-person contributions need --ses-agg sum')
    agg = dict(tax=('ils_taxco', 'sum'), ben=('ils_benco', 'sum'), con=('ils_con', 'sum'),
               ses=('ses', 'sum' if a.ses_agg == 'sum' else 'first'), line=(a.line_var, 'first'))
    if a.group:
        agg['grp'] = (a.group, 'first')
    if a.mean == 'weighted':
        agg['w'] = (a.weight, 'first')
    h = g.agg(**agg)
    if not (h.ses > 0).all():
        raise Invalid(f'{int((h.ses <= 0).sum())} households with equivalence scale <= 0')
    if not a.group and h.line.nunique() > 1:
        raise Invalid(f'{a.line_var} takes {h.line.nunique()} values across households: pass --group')
    if a.group:
        k = h.groupby('grp').line.nunique()
        if (k > 1).any():
            raise Invalid(f'{a.line_var} varies within group(s) {list(k[k > 1].index)}: wrong --group?')
    h['line'] = h.line * a.ratio
    h['eqc'] = h.con / h.ses
    h['eqt'] = (h.tax - h.ben) / h.ses
    if not a.group:
        h['grp'] = 'all'
    return h


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('output'); ap.add_argument('--ses-agg', choices=['sum', 'household'], required=True)
    ap.add_argument('--line-var', default='spl'); ap.add_argument('--group')
    ap.add_argument('--band', type=float, default=0.025); ap.add_argument('--ratio', type=float, default=1.0)
    ap.add_argument('--mean', choices=['unweighted', 'weighted'], default='unweighted')
    ap.add_argument('--weight', default='dwt'); ap.add_argument('--no-benco', action='store_true')
    ap.add_argument('--compare', nargs='+'); ap.add_argument('--precision', type=int)
    ap.add_argument('--min-hh', type=int, default=1); ap.add_argument('--csv')
    a = ap.parse_args(argv)
    try:
        if not (0 < a.band < 1) or not (a.ratio > 0) or a.min_hh < 1:
            raise Invalid('--band must be in (0, 1), --ratio > 0, --min-hh >= 1')
        use = {'idhh', 'ils_taxco', 'ils_benco', 'ils_con', 'ses', a.line_var, a.weight} | ({a.group} if a.group else set())
        d = pd.read_csv(a.output, sep='\t', low_memory=False, usecols=lambda c: c in use,
                        dtype={a.group: str} if a.group else None)
        h = households(d, a)
        groups = sorted(h.grp.unique(), key=str)
        comp = {}
        if a.compare:
            if all('=' in c for c in a.compare):
                for c in a.compare:
                    k, v = c.split('=', 1); comp[k] = v
            elif any('=' in c for c in a.compare):
                raise Invalid('--compare: use either plain values or GROUP=VALUE pairs, not both')
            else:
                if len(a.compare) != len(groups):
                    raise Invalid(f'--compare has {len(a.compare)} values for {len(groups)} groups {groups}')
                comp = dict(zip(map(str, groups), a.compare))
            if set(comp) != set(map(str, groups)):
                raise Invalid(f'--compare groups {sorted(comp)} do not match output groups {groups}')
            for v in comp.values():
                if not math.isfinite(float(v)):
                    raise Invalid(f'--compare value {v!r} is not a finite number')
        print(f'conventions: ses {a.ses_agg}; line {a.line_var} x {a.ratio:g}; band +/-{a.band:g}; '
              f'{a.mean} mean{" (" + a.weight + ")" if a.mean == "weighted" else ""}; '
              f'net indirect tax = ils_taxco - {"0 (no ils_benco)" if a.no_benco and "ils_benco" not in d else "ils_benco"}')
        res, moved = [], False
        for g in groups:
            s = h[h.grp == g]
            line = float(s.line.iloc[0])
            band = s[(s.eqc >= line * (1 - a.band)) & (s.eqc <= line * (1 + a.band))]
            if len(band) < a.min_hh:
                near = (s.eqc / line - 1).abs().nsmallest(3).round(4).tolist()
                raise Invalid(f'group {g}: {len(band)} households in band (minimum {a.min_hh}); '
                              f'nearest relative distances {near}')
            mean = (np.average(band.eqt, weights=band.w) if a.mean == 'weighted' else band.eqt.mean())
            pf = line - mean
            r = dict(group=g, line=line, households_in_band=len(band), post_fiscal=pf)
            msg = f'group {g}: line {line:.6f} -> post-fiscal {pf:.6f} (households in band {len(band)})'
            if comp:
                tok = comp[str(g)]
                p = a.precision if a.precision is not None else ndec(tok)
                stored, new = round(float(tok), p), round(pf, p)
                fixed = stored == new
                moved |= not fixed
                r.update(model=float(tok), precision=p, new_rounded=new, fixed_point=fixed)
                msg += (f'  model {tok} -> {new:.{p}f} at {p} decimals '
                        f'({(pf / float(tok) - 1) * 100:+.4f}%) {"FIXED POINT" if fixed else "MOVED"}')
            print(msg)
            res.append(r)
        if a.csv:
            pd.DataFrame(res).to_csv(a.csv, index=False)
        return 1 if moved else 0
    except Invalid as e:
        print('INVALID:', e, file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
