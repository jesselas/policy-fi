#!/usr/bin/env python3
"""Repair paragraphs whose reject-all view differs from the previous report (garbled or lost original).

Typical causes: an earlier pass overwrote a paragraph without keeping the original as w:del (reject view
empty), or deleted its own earlier insertions as w:del (they reappear as "original" text on reject).
Each affected paragraph is rebuilt as a word-level tracked diff between the previous report's text and
the draft's current accepted text, keeping per-character formatting (equal/inserted words take the
draft's run formatting, deleted words the original's). The accepted text is unchanged (asserted), and
the reject view equals the previous report (asserted). Paragraphs with fields, footnote references,
hyperlinks or drawings are skipped and listed: fix those by hand.

usage: python3 $SKILL/scripts/fix_reject_view.py PREVIOUS.docx DRAFT.docx [--dry-run]
Caution: if the previous report itself still holds tracked changes, compare report_qa.py output first;
a paragraph that differs only because of the previous report's own revisions needs no repair.
"""
import sys, os, zipfile, difflib, re, copy, itertools
from lxml import etree
sys.path.insert(0, os.path.dirname(__file__))
import docx_track as dt
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
SPECIAL = ('footnoteReference', 'fldChar', 'instrText', 'hyperlink', 'drawing', 'fldSimple')

def inside(e, p, tag):
    a = e.getparent()
    while a is not None and a is not p:
        if a.tag == W + tag: return True
        a = a.getparent()
    return False
def ptext(p, mode):
    out = []
    for t in p.iter(W + 't', W + 'delText'):
        if mode == 'reject' and inside(t, p, 'ins'): continue
        if mode == 'accept' and (t.tag == W + 'delText' or inside(t, p, 'del')): continue
        out.append(t.text or '')
    return ''.join(out)
def p_inserted(p):
    if p.find(W + 'pPr/' + W + 'rPr/' + W + 'ins') is not None: return True
    a = p.getparent()
    while a is not None:
        if a.tag == W + 'tr' and a.find(W + 'trPr/' + W + 'ins') is not None: return True
        if a.tag == W + 'tc' and a.find(W + 'tcPr/' + W + 'cellIns') is not None: return True
        a = a.getparent()
    return False
def chars(p, accept):
    out = []
    for r in p.iter(W + 'r'):
        if accept and inside(r, p, 'del'): continue
        rp = r.find(W + 'rPr')
        for t in r.findall(W + 't'): out += [(ch, rp) for ch in (t.text or '')]
    return out
def runs(seq, kind):
    out = []
    for _, grp in itertools.groupby(seq, key=lambda x: id(x[1])):
        g = list(grp); r = etree.Element(W + 'r')
        if g[0][1] is not None:
            rc = copy.deepcopy(g[0][1])
            for b in rc.findall(W + 'ins') + rc.findall(W + 'del') + rc.findall(W + 'rPrChange'): rc.remove(b)
            r.append(rc)
        t = etree.SubElement(r, W + ('delText' if kind == 'del' else 't')); t.text = ''.join(c for c, _ in g)
        t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve'); out.append(r)
    return out
def rebuild(op, p):
    a, b = chars(op, False), chars(p, True)
    toks = lambda s: re.findall(r'\s+|[^\s]+', s)
    ta, tb = toks(''.join(c for c, _ in a)), toks(''.join(c for c, _ in b))
    oa = [0]; [oa.append(oa[-1] + len(x)) for x in ta]; ob = [0]; [ob.append(ob[-1] + len(x)) for x in tb]
    new = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, ta, tb, autojunk=False).get_opcodes():
        if tag == 'equal': new += runs(b[ob[j1]:ob[j2]], 'eq')
        if tag in ('delete', 'replace'):
            dl = dt._mark('w:del'); [dl.append(r) for r in runs(a[oa[i1]:oa[i2]], 'del')]; new.append(dl)
        if tag in ('insert', 'replace'):
            ins = dt._mark('w:ins'); [ins.append(r) for r in runs(b[ob[j1]:ob[j2]], 'ins')]; new.append(ins)
    for ch in list(p):
        if ch.tag != W + 'pPr': p.remove(ch)
    for e in new: p.append(e)

prev, draft = sys.argv[1], sys.argv[2]; dry = '--dry-run' in sys.argv
zo, zd = zipfile.ZipFile(prev), zipfile.ZipFile(draft)
ro, rd = etree.fromstring(zo.read('word/document.xml')), etree.fromstring(zd.read('word/document.xml'))
mx = max([int(m) for n in zd.namelist() if n.endswith('.xml') for m in re.findall(rb'w:id="(\d+)"', zd.read(n))] + [0])
dt._ids = itertools.count(mx + 1)
ao = list(ro.iter(W + 'p')); a = [ptext(p, 'reject') for p in ao]
pb = [p for p in rd.iter(W + 'p') if not p_inserted(p)]; b = [ptext(p, 'reject') for p in pb]
done = skipped = 0
for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
    if tag == 'equal': continue
    if tag != 'replace' or i2 - i1 != j2 - j1:
        print(f'structural difference ({tag} orig {i1}:{i2}, draft {j1}:{j2}): fix by hand'); skipped += 1; continue
    for k in range(i2 - i1):
        op, p = ao[i1 + k], pb[j1 + k]
        if any(e.tag.split('}')[-1] in SPECIAL for e in p.iter()):
            print('skipped (special content):', a[i1 + k][:80]); skipped += 1; continue
        print('rebuild:', a[i1 + k][:80])
        if dry: continue
        before = ptext(p, 'accept'); rebuild(op, p)
        assert ptext(p, 'accept') == before and ptext(p, 'reject') == a[i1 + k]
        done += 1
if not dry and done:
    xml = etree.tostring(rd, xml_declaration=True, encoding='UTF-8', standalone=True)
    tmp = draft + '.tmp'
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as z2:
        for it in zd.infolist(): z2.writestr(it, xml if it.filename == 'word/document.xml' else zd.read(it.filename))
    zd.close(); os.replace(tmp, draft)
print(f'rebuilt {done}, skipped {skipped}')
