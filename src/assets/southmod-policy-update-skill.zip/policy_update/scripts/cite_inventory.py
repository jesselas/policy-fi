#!/usr/bin/env python3
"""Inventory the laws and URLs cited in the previous country report and in the model's comments.

Seeds the policy research (02): every instrument the report or the model cites is a candidate for an
"amended since?" check, and every cited URL is checked for link rot before the report goes out (05).

usage: python3 $SKILL/scripts/cite_inventory.py <file> [<file> ...] [--out inventory.csv] [--check-links]
  <file>: the previous report (.docx or .pdf), the model XML (<CC>.xml: <Comment> texts only), or any
          .txt/.md (e.g. downloaded laws).
  --check-links: request each URL (HEAD, then GET) and record the HTTP status; a dead link can be
          repaired with an archived copy (scripts/wayback.py) or the new official location.

Output columns: kind (law|url), item (normalised), count, files, first context, status (with
--check-links). Patterns cover English, Spanish, Portuguese, French and Vietnamese legal citations
(acts, finance acts, legal instruments, decrees, laws, circulars, gazette notices). They over-collect
on purpose: review the list, merge variants, and add the model's own citation styles with --pattern REGEX
(repeatable).
"""
import csv
import html
import re
import subprocess
import sys
import urllib.request
import zipfile
from collections import OrderedDict
from pathlib import Path

LAW_PATTERNS = [
    # English
    r"\b(?:Finance|Income Tax|Value Added Tax|VAT|Excise(?: Duty)?|Customs|Social Security|Pensions?|Revenue|Tax(?:ation)?|Appropriation|Budget)\s+(?:\(Amendment\)\s+)?Act,?\s*(?:No\.?\s*\d+\s*(?:of\s*)?)?(?:\d{4})?",
    r"\bAct\s+No\.?\s*\d+(?:/\d+)?(?:\s+of\s+\d{4})?",
    r"\b(?:Act|Law)\s+\d{3,4}\b",                         # e.g. "Act 896" (numbered acts)
    r"\b(?:Legislative Instrument|L\.\s?I\.)\s*\d+",
    r"\b(?:Statutory Instrument|S\.\s?I\.)\s*(?:No\.?\s*)?\d+(?:\s+of\s+\d{4})?",
    r"\b(?:Government Notice|G\.\s?N\.)\s*(?:No\.?\s*)?\d+(?:\s+of\s+\d{4})?",
    r"\b(?:Ministerial|Presidential)\s+(?:Order|Decree)\s+(?:No\.?\s*)?[\w/.-]+",
    r"\bProclamation\s+No\.?\s*[\d/]+",
    r"\b(?:Gazette|Official Journal)\s+(?:No\.?\s*)?[\w/.-]*\d[\w/.-]*",
    # Spanish
    r"\bLey\s+(?:Orgánica\s+|Org[aá]nica\s+)?(?:de\s+[A-ZÁÉÍÓÚ][\wáéíóúñ ]{3,60}?\s+)?(?:N[°ºo]\.?\s*)?\d+(?:[-/]\d+)?",
    r"\bDecreto\s+(?:Supremo|Ejecutivo|Legislativo|de Urgencia)?\s*(?:N[°ºo]\.?\s*)?[\d][\w/.-]*",
    r"\bResoluci[oó]n\s+(?:de\s+Superintendencia\s+|Ministerial\s+)?(?:N[°ºo]\.?\s*)?[\w/.-]*\d[\w/.-]*",
    r"\bRegistro Oficial\s+(?:Suplemento\s+)?(?:N[°ºo]\.?\s*)?\d+",
    # Portuguese
    r"\bLei\s+n\.?\s*[ºo°]?\s*\d+(?:/\d+)?",
    r"\bDecreto(?:-Lei)?\s+n\.?\s*[ºo°]?\s*\d+(?:/\d+)?",
    r"\bDiploma Ministerial\s+n\.?\s*[ºo°]?\s*\d+(?:/\d+)?",
    # French
    r"\b(?:Loi|Décret|Arr[êe]t[ée]|Ordonnance)\s+n\s*[°o]\s*[\d][\w/.-]*",
    r"\bLoi de finances(?: rectificative)?\s+(?:pour\s+)?\d{4}",
    # Vietnamese
    r"\bLuật\s+(?:số\s+)?\d+/\d{4}/QH\d+",
    r"\bLuật\s+[A-ZĐ][\wÀ-ỹ ]{3,60}?\s+(?:số\s+)?\d+/\d{4}/QH\d+",
    r"\b(?:Nghị định|Thông tư|Quyết định|Nghị quyết)\s+(?:số\s+)?\d+/\d{4}/[\w-]+",
    r"\b\d+/\d{4}/(?:NĐ-CP|TT-BTC|QĐ-TTg|QH\d+|NQ-CP|UBTVQH\d+)",
]
URL = re.compile(r"https?://[^\s<>\"')\]]+", re.I)


def text_of(path):
    p = Path(path)
    suf = p.suffix.lower()
    if suf == '.pdf':
        try:
            return subprocess.run(['pdftotext', '-layout', str(p), '-'], capture_output=True, text=True, check=True).stdout
        except Exception:
            from pypdf import PdfReader
            r = PdfReader(str(p))
            links = [a.get_object().get('/A', {}).get('/URI', '') for pg in r.pages for a in (pg.get('/Annots') or [])]
            return '\n'.join((pg.extract_text() or '') for pg in r.pages) + '\n' + '\n'.join(map(str, links))
    if suf in ('.docx', '.docm'):
        z = zipfile.ZipFile(p)
        parts = [n for n in z.namelist() if re.match(r'word/(document|footnotes|endnotes|header\d*|footer\d*)\.xml$', n)]
        out = []
        for n in parts:
            x = z.read(n).decode('utf-8', 'replace')
            x = re.sub(r'<w:tab/>', ' ', x)
            x = re.sub(r'</w:p>', '\n', x)
            out.append(html.unescape(re.sub(r'<[^>]+>', '', x)))
        for n in z.namelist():                      # hyperlink targets (text links hide their URL)
            if n.endswith('.rels'):
                out += [html.unescape(u) for u in re.findall(r'Target="(https?://[^"]+)"', z.read(n).decode('utf-8', 'replace'))]
        return '\n'.join(out)
    raw = p.read_bytes().decode('utf-8-sig', 'replace')
    if suf == '.xml':
        return '\n'.join(html.unescape(c) for c in re.findall(r'<Comment><!\[CDATA\[(.*?)\]\]></Comment>', raw, re.S))
    return raw


def status(url):
    for method in ('HEAD', 'GET'):
        try:
            req = urllib.request.Request(url, method=method, headers={'User-Agent': 'Mozilla/5.0 (link check)'})
            with urllib.request.urlopen(req, timeout=30) as r:
                return str(r.status)
        except urllib.error.HTTPError as e:
            if method == 'GET' or e.code not in (403, 405, 501):
                return str(e.code)
        except Exception as e:
            if method == 'GET':
                return f'error: {type(e).__name__}'
    return ''


def main():
    args, out, extra = [], 'cite_inventory.csv', []
    it = iter(sys.argv[1:])
    for a in it:
        if a == '--out':
            out = next(it)
        elif a == '--pattern':
            extra.append(next(it))
        elif not a.startswith('--'):
            args.append(a)
    if not args:
        print(__doc__); return 2
    pats = [re.compile(x, re.I) for x in LAW_PATTERNS + extra]
    found = OrderedDict()
    for f in args:
        try:
            t = text_of(f)
        except Exception as ex:
            print(f'cannot read {f}: {ex}'); return 2
        t = re.sub(r'[ \t  ]+', ' ', t)
        hits = []
        for pat in pats:
            hits += [('law', m) for m in pat.finditer(t)]
        hits += [('url', m) for m in URL.finditer(t)]
        for kind, m in hits:
            item = m.group(0).strip().rstrip('.,;:')
            if kind == 'url':
                item = html.unescape(item)
            key = (kind, re.sub(r'\s+', ' ', item).lower())
            ctx = t[max(0, m.start() - 80):m.end() + 80].replace('\n', ' ')
            e = found.setdefault(key, {'kind': kind, 'item': re.sub(r'\s+', ' ', item), 'count': 0,
                                       'files': [], 'context': ctx, 'status': ''})
            e['count'] += 1
            if Path(f).name not in e['files']:
                e['files'].append(Path(f).name)
    if '--check-links' in sys.argv:
        for e in found.values():
            if e['kind'] == 'url':
                e['status'] = status(e['item'])
    with open(out, 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['kind', 'item', 'count', 'files', 'context', 'status'])
        for e in found.values():
            w.writerow([e['kind'], e['item'], e['count'], '; '.join(e['files']), e['context'], e['status']])
    laws = sum(1 for e in found.values() if e['kind'] == 'law')
    urls = sum(1 for e in found.values() if e['kind'] == 'url')
    dead = [e for e in found.values() if e['kind'] == 'url' and e['status'] and not e['status'].startswith(('2', '3'))]
    print(f'{laws} distinct legal citations, {urls} URLs -> {out}')
    for e in dead:
        print(f"  link {e['status']}: {e['item']}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
