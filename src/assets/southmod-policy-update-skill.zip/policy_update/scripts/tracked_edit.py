#!/usr/bin/env python3
"""Tracked-change editing of a country report (python-docx), safe for repeated update passes.

Import it from a short Python script:
    import sys; sys.path.insert(0, '<skill>/scripts'); import tracked_edit as T
    d = T.open_doc('CR ... DRAFT tracked.docx')          # sets revision ids above every existing w:id
    T.edit(d, anchor, old, new, section, reason)           # replace text in the paragraph containing `anchor`
    T.set_cell(d, table_key, row_label, year, old, new, section, reason, section_row='RWAMOD')
    T.new_paragraph_after(d, anchor, text, section, reason)
    d.save(path); T.write_log('work/CR_edit_log_<CC>.md', 'date: what')

edit() handles three cases:
  - the old text lies wholly inside earlier insertions by the same author (AUTHOR): it is changed in place,
    so the reviewer sees one clean insertion, not an insertion with a deletion inside it;
  - the old text is original text: each covered run is wrapped in its own w:del at its own position and the
    new text is inserted as one w:ins after the last one;
  - mixed: own-insertion runs are trimmed in place and original runs are deleted as above.
Never delete own earlier insertions as w:del (rejecting all changes would then show them as original text).
Always run report_qa.py afterwards: rejecting all changes must give exactly the previous report.
"""
import sys, os, itertools, re
sys.path.insert(0, os.path.dirname(__file__))
import docx_track as dt
from docx_track import _runs, _rtext
from docx import Document
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph
AUTHOR = dt.AUTHOR
LOG = []

def open_doc(path):
    d = Document(path); mx = 0
    for part in d.part.package.iter_parts():
        el = getattr(part, '_element', None)
        if el is None: continue
        for x in el.iter():
            v = x.get(qn('w:id'))
            if v and v.lstrip('-').isdigit(): mx = max(mx, int(v))
    dt._ids = itertools.count(mx + 1)
    return d

def vis(p): return ''.join(_rtext(r) for r in _runs(p))

def find(d, sub, nth=1):
    hits = [p for p in d.element.body.iter(qn('w:p')) if sub in vis(p)]
    if len(hits) < nth: raise ValueError('not found: ' + sub)
    return hits[nth - 1]

def _own(r, p):
    a = r.getparent()
    while a is not None and a is not p:
        if a.tag == qn('w:ins') and a.get(qn('w:author')) == AUTHOR: return True
        a = a.getparent()
    return False

def _settext(r, text):
    ts = r.findall(qn('w:t')); ts[0].text = text
    ts[0].set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
    for x in ts[1:]: r.remove(x)

def edit(d, anchor, old, new, sec, why):
    p = find(d, anchor); runs = _runs(p); full = ''.join(_rtext(r) for r in runs)
    assert full.count(old) == 1, f'{old!r} occurs {full.count(old)} times'
    s = full.index(old); e = s + len(old); pos = 0; cov = []
    for r in runs:
        t = _rtext(r); r0, r1 = pos, pos + len(t); pos = r1
        if r1 > s and r0 < e: cov.append((r, r0, r1))
    if all(_own(r, p) for r, _, _ in cov):
        first = True
        for r, r0, r1 in cov:
            t = _rtext(r); a = max(s, r0) - r0; b = min(e, r1) - r0
            _settext(r, t[:a] + (new if first else '') + t[b:]); first = False
        mode = 'in place (own insertion)'
    else:
        last = None
        for r, r0, r1 in cov:
            t = _rtext(r); a = max(s, r0) - r0; b = min(e, r1) - r0
            if _own(r, p):
                _settext(r, t[:a] + t[b:]); node = r
            else:
                cur = r
                if a > 0: _, cur = dt._split_run(cur, a)
                if b - a < len(_rtext(cur)): cur, _ = dt._split_run(cur, b - a)
                dl = dt._mark('w:del'); cur.addprevious(dl)
                dl.append(dt._run_like(cur, _rtext(cur), deleted=True)); cur.getparent().remove(cur); node = dl
            while node.getparent() is not p and node.getparent().tag != qn('w:hyperlink'): node = node.getparent()
            last = (node, r)
        if new:
            ins = dt._mark('w:ins'); ins.append(dt._run_like(last[1], new)); last[0].addnext(ins)
        mode = 'tracked'
    LOG.append((sec, old, new, why, mode))

def set_cell(d, table_key, row_label, year, old, new, sec, why, section_row=None, header_row=None):
    """Change one table cell, tracked. table_key: text that identifies the table. Year columns are found
    from the header row (python-docx repeats merged cells, so never use fixed indices). section_row: label of
    the block (e.g. 'Ratios') after which row_label is searched, for tables that repeat row labels."""
    t = [t for t in d.tables if table_key in vis(t._tbl)][0]
    rows = t.rows
    hr = header_row if header_row is not None else next(i for i, r in enumerate(rows) if year in [vis(c._tc).strip() for c in r.cells])
    hdr = [vis(c._tc).strip() for c in rows[hr].cells]
    j = max(i for i, h in enumerate(hdr) if h == year)
    labs = [vis(r.cells[0]._tc).strip() for r in rows]
    start = labs.index(section_row) if section_row else 0
    i = next(k for k in range(start, len(labs)) if labs[k] == row_label)
    c = rows[i].cells[j]; cur = vis(c._tc).strip()
    assert cur == old, f'{row_label} {year}: cell holds {cur!r}, expected {old!r}'
    dt.set_cell_tracked(c, new); LOG.append((sec, f'{row_label} {year}: {old}', new, why, 'tracked cell'))

def new_paragraph_after(d, anchor, text, sec, why):
    p = find(d, anchor); dt.insert_paragraph_after(Paragraph(p, None), text)
    LOG.append((sec, '(new paragraph)', text, why, 'tracked paragraph'))

def write_log(path, title):
    with open(path, 'a', encoding='utf-8') as f:
        f.write(f'\n## {title}\n\n| Section | Old | New | Reason | Mode |\n|---|---|---|---|---|\n')
        for r in LOG: f.write('| ' + ' | '.join(str(x).replace('|', '/') for x in r) + ' |\n')
    LOG.clear()
