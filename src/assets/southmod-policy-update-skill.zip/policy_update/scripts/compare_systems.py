#!/usr/bin/env python3
"""List every cell that differs between two systems of a country XML (GUI row numbers).

Usage: python3 $SKILL/scripts/compare_systems.py <CC>.xml SYS_A SYS_B [out.csv]
Cells are matched on (policy, function number N.M, parameter name, group).
"""
import csv, subprocess, sys, tempfile, os
import pandas as pd
xml, a, b = sys.argv[1:4]
tmp = tempfile.mktemp(suffix='.csv')
subprocess.run([sys.executable, os.path.join(os.path.dirname(__file__), 'extract_params.py'), xml, tmp], check=True)
d = pd.read_csv(tmp, dtype=str).fillna('')
os.remove(tmp)
k = ['policy', 'fun_no', 'function', 'parameter', 'group']
d['dup'] = d.groupby(['system'] + k).cumcount()
k = k + ['dup']
cols = ['pol_switch', 'fun_switch', 'value', 'par_comment']
A = d[d.system == a].set_index(k)[cols]; B = d[d.system == b].set_index(k)[cols]
j = A.join(B, how='outer', lsuffix='_' + a, rsuffix='_' + b).fillna('(missing)')
diff = j[[any(r[c + '_' + a] != r[c + '_' + b] for c in cols) for _, r in j.iterrows()]]
out = sys.argv[4] if len(sys.argv) > 4 else None
if out: diff.reset_index().to_csv(out, index=False)
pd.set_option('display.width', 250, 'display.max_colwidth', 60, 'display.max_rows', 500)
print(f'{len(diff)} differing cells between {a} and {b}')
print(diff.reset_index()[['policy', 'fun_no', 'parameter', 'group', f'value_{a}', f'value_{b}', f'fun_switch_{a}', f'fun_switch_{b}']].to_string(index=False))
