#!/usr/bin/env python3
"""Apply a CSV of edits to a SOUTHMOD legacy country XML, editing the text in place.

Usage: python3 $SKILL/scripts/edit_model.py <bundle_dir> <CC> <edits.csv> [--dry-run]

CSV columns (header required):
  op, system, policy, fun, parameter, group, value, comment
    op = set_value   : set <Value> of parameter `parameter` (and `group`, if given) in function
                       `fun` (GUI number "N.M" or the function's <Comment> text) of `policy`.
         set_switch  : set <Switch> of the policy (fun empty) or the function to `value`.
         set_name    : rename parameter `parameter` to `value` (e.g. an income-list member).
         set_comment : set the <Comment> of the parameter (or of fun/policy if parameter empty).
         add_param   : add a parameter to `fun` by copying the parameter named in `comment`'s
                       prefix "copy:<name>|" (or the last parameter), with name `parameter`,
                       group `group`, value `value`; the remainder of `comment` is its comment.
         copy_function_all : in EVERY system, copy function `fun` of `policy` to the end of the
                       policy (new GUIDs, next Order), with <Comment> `comment`; its switch is
                       `value` (on/off) in the systems listed in `system` (separated by ;) and
                       n/a elsewhere. The new function gets GUI number N.(last+1).
         add_param_all : in EVERY system, add parameter `parameter` (group `group`) to function
                       `fun` of `policy` by copying the parameter named in "copy:<name>|" at the
                       start of `comment` (or the last one); value `value` in the systems listed in
                       `system`, "n/a" elsewhere. Keeps GUI rows aligned across systems.
         uprate      : set year `fun` of uprating index `policy` (its <Reference>, e.g.
                       $f_CPI_Overall) to `value`; `comment` (optional) replaces the index comment.
    comment is APPENDED to the existing <Comment> for set_value/set_switch (prefix " | ").
Row numbers follow <Order> (GUI order), as in the southmod skill's spine.py.
Each edit must match exactly one element; otherwise the script stops and nothing is written.
UNTESTED IN EUROMOD: open the bundle in the EUROMOD UI and save once to validate.
"""
import csv, re, sys, uuid
from pathlib import Path
from lxml import etree

NS = '{http://euromod.com/CountryConfig.xsd}'


def t(e, n):
    c = e.find(NS + n)
    return (c.text or '').strip() if c is not None and c.text else ''


def order(e):
    try: return float(t(e, 'Order') or 0)
    except ValueError: return 0.0


def cdata_escape(v):
    return v.replace(']]>', ']]]]><![CDATA[>')


class Model:
    def __init__(self, path):
        self.path = Path(path)
        raw = self.path.read_bytes()
        self.bom = raw.startswith(b'\xef\xbb\xbf')
        self.text = raw.decode('utf-8-sig')
        self.nl = '\r\n' if '\r\n' in self.text else '\n'
        self.reparse()

    def reparse(self):
        self.root = etree.fromstring(self.text.encode('utf-8'))

    def save(self):
        self.path.write_bytes((b'\xef\xbb\xbf' if self.bom else b'') + self.text.encode('utf-8'))

    LIMITS = {'Parameter': ('</Parameter>',), 'Function': ('<Parameter>', '</Function>'),
              'Policy': ('<Function>', '</Policy>'), 'UpratingIndex': ('</UpratingIndex>',)}

    def id_pos(self, el):
        """Char offset of the element's own <ID>...</ID> (every edited element has a unique GUID)."""
        gid = t(el, 'ID')
        pos = self.text.index(f'<ID>{gid}</ID>')
        if self.text.find(f'<ID>{gid}</ID>', pos + 1) != -1:
            raise SystemExit(f'ID {gid} not unique')
        return pos

    def span(self, el):
        """Char span of a Parameter element (start tag to end tag)."""
        tag = etree.QName(el).localname
        pos = self.id_pos(el)
        start = self.text.rindex(f'<{tag}>', 0, pos)
        end = self.text.index(f'</{tag}>', pos) + len(f'</{tag}>')
        return start, end

    def child_span(self, el, child):
        """Char span of direct child <child> of el (a header field before any nested element)."""
        tag = etree.QName(el).localname
        pos = self.id_pos(el)
        limit = min(x for x in (self.text.find(l, pos) for l in self.LIMITS[tag]) if x != -1)
        m = re.compile(rf'<{child}>.*?</{child}>|<{child}\s*/>', re.S).search(self.text, pos, limit)
        if not m:
            raise SystemExit(f'no <{child}> in {tag} {t(el, "ID")}')
        return m.start(), m.end()

    def system(self, name):
        s = [x for x in self.root.iter(NS + 'System') if t(x, 'Name') == name]
        if len(s) != 1: raise SystemExit(f'system {name}: {len(s)} matches')
        return s[0]

    def policy(self, sysname, pname):
        s = self.system(sysname)
        p = [x for x in s.findall(NS + 'Policy') if t(x, 'Name').lower() == pname.lower()]
        if len(p) != 1: raise SystemExit(f'{sysname}/{pname}: {len(p)} matches')
        return p[0]

    def function(self, pol, fun):
        funs = sorted(pol.findall(NS + 'Function'), key=order)
        if re.fullmatch(r'\d+\.\d+', fun):
            m = int(fun.split('.')[1])
            return funs[m - 1]
        f = [x for x in funs if t(x, 'Comment') == fun]
        if len(f) != 1: raise SystemExit(f'function "{fun}": {len(f)} matches')
        return f[0]

    def param(self, fn, name, group):
        p = [x for x in fn.findall(NS + 'Parameter') if t(x, 'Name').lower() == name.lower()
             and (not group or t(x, 'Group') == group)]
        if len(p) != 1: raise SystemExit(f'parameter {name} #{group}: {len(p)} matches')
        return p[0]

    def replace_child(self, el, child, new_inner, cdata=True):
        """Replace the text of direct child <child> of el."""
        s0, s1 = self.child_span(el, child)
        inner = f'<![CDATA[{cdata_escape(new_inner)}]]>' if cdata else new_inner
        self.text = self.text[:s0] + f'<{child}>{inner}</{child}>' + self.text[s1:]
        self.reparse()


def run(bundle, cc, edits_csv, dry):
    m = Model(Path(bundle, 'XMLParam', 'Countries', cc, f'{cc}.xml'))
    rows = list(csv.DictReader(open(edits_csv, encoding='utf-8-sig')))
    log = []
    for i, r in enumerate(rows, 2):
        r = {k: (v or '').strip() for k, v in r.items()}
        op = r['op']
        if not op or op.startswith('#'):
            continue
        if op in ('copy_function_all', 'add_param_all'):
            targets = [x.strip() for x in r['system'].split(';') if x.strip()]
            allsys = [t(x, 'Name') for x in m.root.iter(NS + 'System')]
            for sname in allsys:
                pol = m.policy(sname, r['policy'])
                fn = m.function(pol, r['fun'])
                if op == 'copy_function_all':
                    funs = sorted(pol.findall(NS + 'Function'), key=order)
                    new_order = int(max(order(x) for x in funs)) + 1
                    f0 = m.text.rindex('<Function>', 0, m.id_pos(fn))
                    f1 = m.text.index('</Function>', m.id_pos(fn)) + len('</Function>')
                    line0 = m.text.rindex('\n', 0, f0) + 1
                    indent = m.text[line0:f0]
                    blk = m.text[f0:f1]
                    new_fid = str(uuid.uuid4())
                    old_fid = t(fn, 'ID')
                    blk = blk.replace(f'<ID>{old_fid}</ID>', f'<ID>{new_fid}</ID>', 1).replace(f'<FunctionID>{old_fid}</FunctionID>', f'<FunctionID>{new_fid}</FunctionID>')
                    blk = re.sub(r'(<Parameter>\s*<ID>)[^<]+(</ID>)', lambda mm: mm.group(1) + str(uuid.uuid4()) + mm.group(2), blk)
                    head_end = blk.index('<Parameter>') if '<Parameter>' in blk else len(blk)
                    head, rest = blk[:head_end], blk[head_end:]
                    head = re.sub(r'<Order>[^<]*</Order>', f'<Order>{new_order}</Order>', head, count=1)
                    head = re.sub(r'<Switch>[^<]*</Switch>', f'<Switch>{r["value"] if sname in targets else "n/a"}</Switch>', head, count=1)
                    head = re.sub(r'<Comment>.*?</Comment>|<Comment\s*/>', f'<Comment><![CDATA[{cdata_escape(r["comment"])}]]></Comment>', head, count=1, flags=re.S)
                    last_f = max(funs, key=lambda x: m.id_pos(x))
                    e1 = m.text.index('</Function>', m.id_pos(last_f)) + len('</Function>')
                    m.text = m.text[:e1] + m.nl + indent + head + rest + m.text[e1:]
                else:
                    src_name, com = None, r['comment']
                    if com.startswith('copy:'):
                        src_name, com = com[5:].split('|', 1)
                    pars = sorted(fn.findall(NS + 'Parameter'), key=order)
                    src = m.param(fn, src_name, '') if src_name else pars[-1]
                    s0, s1 = m.span(src)
                    line0 = m.text.rindex('\n', 0, s0) + 1
                    indent = m.text[line0:s0]
                    blk = m.text[s0:s1]
                    blk = re.sub(r'<ID>[^<]+</ID>', f'<ID>{uuid.uuid4()}</ID>', blk, count=1)
                    blk = re.sub(r'<Name>[^<]*</Name>', f'<Name>{r["parameter"]}</Name>', blk, count=1)
                    v = r['value'] if sname in targets else 'n/a'
                    blk = re.sub(r'<Value>.*?</Value>|<Value\s*/>', f'<Value><![CDATA[{cdata_escape(v)}]]></Value>', blk, count=1, flags=re.S)
                    blk = re.sub(r'<Comment>.*?</Comment>|<Comment\s*/>', f'<Comment><![CDATA[{cdata_escape(com)}]]></Comment>', blk, count=1, flags=re.S)
                    blk = re.sub(r'<Order>[^<]*</Order>', f'<Order>{int(max(order(x) for x in pars)) + 1}</Order>', blk, count=1)
                    blk = re.sub(r'<Group>[^<]*</Group>|<Group\s*/>', f'<Group>{r["group"]}</Group>' if r['group'] else '<Group />', blk, count=1)
                    _, e1 = m.span(max(pars, key=lambda x: m.span(x)[1]))
                    m.text = m.text[:e1] + m.nl + indent + blk + m.text[e1:]
                m.reparse()
            log.append(f'row {i}: {op} {r["policy"]} {r["fun"]} {r["parameter"]} in {len(allsys)} systems (active in {", ".join(targets)})')
            continue
        if op in ('set_value', 'set_switch', 'uprate', 'add_param', 'set_name') and r['value'] == '':
            raise SystemExit(f'row {i}: empty value for {op}')
        if op == 'uprate':
            u = [x for x in m.root.iter(NS + 'UpratingIndex') if t(x, 'Reference') == r['policy']]
            if len(u) != 1: raise SystemExit(f'row {i}: index {r["policy"]}: {len(u)} matches')
            u = u[0]
            yv = dict(p.split('|') for p in t(u, 'YearValues').split('°') if '|' in p)
            old = yv.get(r['fun'], '')
            yv[r['fun']] = r['value']
            new = '°'.join(f'{y}|{yv[y]}' for y in sorted(yv))
            m.replace_child(u, 'YearValues', new, cdata=False)
            if r['comment']:
                m.replace_child(m.root.xpath(f'//*[local-name()="UpratingIndex"][*[local-name()="Reference"]="{r["policy"]}"]')[0], 'Comment', r['comment'])
            log.append(f'row {i}: {r["policy"]} {r["fun"]}: {old or "(none)"} -> {r["value"]}')
            continue
        pol = m.policy(r['system'], r['policy'])
        fn = m.function(pol, r['fun']) if r['fun'] else None
        if op == 'set_switch':
            el = fn if fn is not None else pol
            old = t(el, 'Switch')
            s0, s1 = m.child_span(el, 'Switch')
            m.text = m.text[:s0] + f'<Switch>{r["value"]}</Switch>' + m.text[s1:]
            m.reparse()
            el = m.function(m.policy(r['system'], r['policy']), r['fun']) if r['fun'] else m.policy(r['system'], r['policy'])
            if r['comment']:
                m.replace_child(el, 'Comment', (t(el, 'Comment') + ' | ' if t(el, 'Comment') else '') + r['comment'])
            log.append(f'row {i}: {r["system"]} {r["policy"]} {r["fun"]} switch {old} -> {r["value"]}')
        elif op == 'set_value':
            p = m.param(fn, r['parameter'], r['group'])
            old = t(p, 'Value')
            m.replace_child(p, 'Value', r['value'])
            if r['comment']:
                p = m.param(m.function(m.policy(r['system'], r['policy']), r['fun']), r['parameter'], r['group'])
                m.replace_child(p, 'Comment', (t(p, 'Comment') + ' | ' if t(p, 'Comment') else '') + r['comment'])
            log.append(f'row {i}: {r["system"]} {r["policy"]} {r["fun"]} {r["parameter"]}: {old} -> {r["value"]}')
        elif op == 'set_name':
            p = m.param(fn, r['parameter'], r['group'])
            m.replace_child(p, 'Name', r['value'], cdata=False)
            if r['comment']:
                p = m.param(m.function(m.policy(r['system'], r['policy']), r['fun']), r['value'], r['group'])
                m.replace_child(p, 'Comment', r['comment'])
            log.append(f'row {i}: {r["system"]} {r["policy"]} {r["fun"]} renamed {r["parameter"]} -> {r["value"]}')
        elif op == 'set_comment':
            el = m.param(fn, r['parameter'], r['group']) if r['parameter'] else (fn if fn is not None else pol)
            m.replace_child(el, 'Comment', r['comment'])
            log.append(f'row {i}: comment set')
        elif op == 'add_param':
            src_name, com = None, r['comment']
            if com.startswith('copy:'):
                src_name, com = com[5:].split('|', 1)
            pars = sorted(fn.findall(NS + 'Parameter'), key=order)
            src = m.param(fn, src_name, '') if src_name else pars[-1]
            s0, s1 = m.span(src)
            line0 = m.text.rindex('\n', 0, s0) + 1
            indent = m.text[line0:s0]
            blk = m.text[s0:s1]
            new_id = str(uuid.uuid4())
            blk = re.sub(r'<ID>[^<]+</ID>', f'<ID>{new_id}</ID>', blk, count=1)
            blk = re.sub(r'<Name>[^<]*</Name>', f'<Name>{r["parameter"]}</Name>', blk, count=1)
            blk = re.sub(r'<Value>.*?</Value>|<Value\s*/>', f'<Value><![CDATA[{cdata_escape(r["value"])}]]></Value>', blk, count=1, flags=re.S)
            blk = re.sub(r'<Comment>.*?</Comment>|<Comment\s*/>', f'<Comment><![CDATA[{cdata_escape(com)}]]></Comment>', blk, count=1, flags=re.S)
            blk = re.sub(r'<Order>[^<]*</Order>', f'<Order>{int(max(order(x) for x in pars)) + 1}</Order>', blk, count=1)
            blk = re.sub(r'<Group>[^<]*</Group>|<Group\s*/>', f'<Group>{r["group"]}</Group>' if r['group'] else '<Group />', blk, count=1)
            _, e1 = m.span(max(pars, key=lambda x: m.span(x)[1]))
            m.text = m.text[:e1] + m.nl + indent + blk + m.text[e1:]
            m.reparse()
            log.append(f'row {i}: {r["system"]} {r["policy"]} {r["fun"]}: added {r["parameter"]} = {r["value"]}')
        else:
            raise SystemExit(f'row {i}: unknown op {op}')
    print('\n'.join(log))
    if not dry:
        m.save()
        print(f'written {m.path}')


if __name__ == '__main__':
    a = [x for x in sys.argv[1:] if not x.startswith('--')]
    run(a[0], a[1].upper(), a[2], '--dry-run' in sys.argv)
