#!/usr/bin/env python3
"""Add functions controlled by an extension (e.g. the Full Year Adjustment switch, FYA).

Used from Python (see examples/vn_1jan_fya.py):

    from fya import add_ext_function, ensure_ext_switches
    add_ext_function(model, policy='poa01_vn', ftype='BenCalc', comment='FYA: ...',
                     params=[('Comp_Cond', 'dag>=60', 'condition', '1', 'comment'), ...],
                     values_by_system={'VN_2024': {...override values by (name, group)...}},
                     targets=['VN_2024'], ext_short='FYA')

The function is added to the end of `policy` in EVERY system (so GUI rows stay aligned):
  - in target systems: <Switch>switch</Switch> and an <Extension_Function> entry
    (BaseOff=false), i.e. it runs only when the extension is switched on;
  - in other systems: <Switch>n/a</Switch>, parameter values n/a.
ensure_ext_switches(dataconfig_path, ext_short, value='off') adds a PolicySwitch for the extension
to every DBSystemConfig that lacks one (explicit default).
UNTESTED IN EUROMOD.
"""
import re, uuid
from pathlib import Path

NS = '{http://euromod.com/CountryConfig.xsd}'


def _t(e, n):
    c = e.find(NS + n)
    return (c.text or '').strip() if c is not None and c.text else ''


def _cd(v):
    return '<![CDATA[' + v.replace(']]>', ']]]]><![CDATA[>') + ']]>'


def ext_id(model, short):
    dc = model.path.with_name(model.path.stem + '_dataconfig.xml').read_text(encoding='utf-8-sig')
    m = re.search(rf'<Extension>\s*<ID>([^<]+)</ID>\s*<Name>[^<]*</Name>\s*<ShortName>{short}</ShortName>', dc)
    if not m:
        raise SystemExit(f'extension {short} not found in dataconfig')
    return m.group(1)


def add_ext_function(model, policy, ftype, comment, params, targets, ext_short='FYA',
                     values_by_system=None, switch='switch', base_off=False):
    """params: list of (name, value, valuetype, group, comment). values_by_system: {sys: {(name, group): value}}."""
    nl = model.nl
    eid = ext_id(model, ext_short)
    values_by_system = values_by_system or {}
    new_ext = []
    for sysel in list(model.root.iter(NS + 'System')):
        sname = _t(sysel, 'Name')
        pol = model.policy(sname, policy)
        funs = pol.findall(NS + 'Function')
        order = max(int(float(_t(f, 'Order') or 0)) for f in funs) + 1 if funs else 0
        fid = str(uuid.uuid4())
        on = sname in targets
        ind = ' ' * 8
        lines = [f'{ind}<Function>', f'{ind}  <ID>{fid}</ID>', f'{ind}  <PolicyID>{_t(pol, "ID")}</PolicyID>',
                 f'{ind}  <Name>{ftype}</Name>', f'{ind}  <Comment>{_cd(comment)}</Comment>', f'{ind}  <PrivateComment />',
                 f'{ind}  <Order>{order}</Order>', f'{ind}  <Switch>{switch if on else "n/a"}</Switch>',
                 f'{ind}  <Private>no</Private>', f'{ind}  <Color>-1</Color>']
        for k, (pn, pv, vt, grp, pc) in enumerate(params):
            v = values_by_system.get(sname, {}).get((pn, grp), pv) if on else 'n/a'
            lines += [f'{ind}  <Parameter>', f'{ind}    <ID>{uuid.uuid4()}</ID>', f'{ind}    <FunctionID>{fid}</FunctionID>',
                      f'{ind}    <Name>{pn}</Name>', f'{ind}    <Comment>{_cd(pc)}</Comment>', f'{ind}    <PrivateComment />',
                      f'{ind}    <Value>{_cd(v)}</Value>', f'{ind}    <Order>{k}</Order>', f'{ind}    <ValueType>{vt}</ValueType>',
                      f'{ind}    <Group>{grp}</Group>' if grp else f'{ind}    <Group />', f'{ind}    <Color>-1</Color>',
                      f'{ind}    <Private />', f'{ind}  </Parameter>']
        lines.append(f'{ind}</Function>')
        blk = nl.join(lines)
        if funs:
            last = max(funs, key=lambda x: model.id_pos(x))
            e1 = model.text.index('</Function>', model.id_pos(last)) + len('</Function>')
        else:
            e1 = model.text.index(nl, model.id_pos(pol))  # after the policy's <ID> line (rare)
        model.text = model.text[:e1] + nl + blk + model.text[e1:]
        model.reparse()
        if on:
            new_ext.append(fid)
    if new_ext:
        ent = nl.join(f'  <Extension_Function>{nl}    <ExtensionID>{eid}</ExtensionID>{nl}    <FunctionID>{f}</FunctionID>{nl}'
                      f'    <BaseOff>{"true" if base_off else "false"}</BaseOff>{nl}  </Extension_Function>' for f in new_ext)
        pos = model.text.rfind('</Extension_Function>')
        if pos >= 0:
            pos += len('</Extension_Function>')
        else:  # no extension entries yet: insert before closing root
            pos = model.text.rindex('</CountryConfig>') - 1
        model.text = model.text[:pos] + nl + ent + model.text[pos:]
        model.reparse()
    return len(new_ext)


def ensure_ext_switches(dc_path, ext_short, value='off', force=False):
    p = Path(dc_path)
    raw = p.read_bytes(); bom = raw.startswith(b'\xef\xbb\xbf')
    t = raw.decode('utf-8-sig'); nl = '\r\n' if '\r\n' in t else '\n'
    eid = re.search(rf'<Extension>\s*<ID>([^<]+)</ID>\s*<Name>[^<]*</Name>\s*<ShortName>{ext_short}</ShortName>', t).group(1)
    n_add = n_set = 0
    def fix(m):
        nonlocal n_add, n_set
        b = m.group(0)
        sid = re.search(r'<SystemID>([^<]+)</SystemID>', b).group(1)
        dbid = re.search(r'<DataBaseID>([^<]+)</DataBaseID>', b).group(1)
        if eid in b:
            if force:
                b2 = re.sub(rf'(<SwitchablePolicyID>{eid}</SwitchablePolicyID>.*?<Value><!\[CDATA\[)[^\]]*(\]\]>)',
                            lambda mm: mm.group(1) + value + mm.group(2), b, count=1, flags=re.S)
                n_set += b2 != b
                return b2
            return b
        n_add += 1
        ps = (f'      <PolicySwitch>{nl}        <SwitchablePolicyID>{eid}</SwitchablePolicyID>{nl}        <SystemID>{sid}</SystemID>{nl}'
              f'        <DataBaseID>{dbid}</DataBaseID>{nl}        <Value><![CDATA[{value}]]></Value>{nl}      </PolicySwitch>{nl}')
        return b.replace('    </DBSystemConfig>', ps + '    </DBSystemConfig>')
    t = re.sub(r'[ \t]*<DBSystemConfig>.*?</DBSystemConfig>', fix, t, flags=re.S)
    p.write_bytes((b'\xef\xbb\xbf' if bom else b'') + t.encode('utf-8'))
    return n_add, n_set


# WARNING (2026-09-26 run): elements attached this way did NOT run in EUROMOD 3.8.6 (VN_2025 poa01_vn 20.4,
# VN_2020 bsacv policies). Use FYA constants (DefConst 10.2/10.3) or Extension_Parameter pairs instead.
def attach_existing(model, kind, sysname, policy, fun=None, ext_short='FYA', base_off=False, switch='switch'):
    """Put an existing policy (kind='Policy') or function (kind='Function', fun='N.M') of one system under
    the extension: set its <Switch> to `switch` and add an Extension_Policy/Extension_Function entry."""
    nl = model.nl
    eid = ext_id(model, ext_short)
    pol = model.policy(sysname, policy)
    el = model.function(pol, fun) if kind == 'Function' else pol
    s0, s1 = model.child_span(el, 'Switch')
    model.text = model.text[:s0] + f'<Switch>{switch}</Switch>' + model.text[s1:]
    model.reparse()
    gid = _t(el, 'ID')
    tag = f'Extension_{kind}'
    ent = (f'  <{tag}>{nl}    <ExtensionID>{eid}</ExtensionID>{nl}    <{kind}ID>{gid}</{kind}ID>{nl}'
           f'    <BaseOff>{"true" if base_off else "false"}</BaseOff>{nl}  </{tag}>')
    pos = model.text.rfind(f'</{tag}>')
    if pos < 0:
        pos = model.text.rfind('</Extension_Function>')
    pos = model.text.index('>', pos) + 1 if pos >= 0 else model.text.rindex('</CountryConfig>') - 1
    model.text = model.text[:pos] + nl + ent + model.text[pos:]
    model.reparse()
