# 02 Policy research and the T1 policy-change document

## Scope: what to check for each new system (and back to the previous system's date)

Walk the model's spine, instrument by instrument, from the previous system's time point to the new one:
- **Personal income tax**: bands, rates, thresholds, allowances and deductions, surcharges, non-resident
  schedules, presumptive/turnover regimes, rental and capital income taxes, local taxes (e.g. local service tax).
- **Social insurance**: employee/employer rates, caps, bases, health insurance premiums (flat or banded), new schemes.
- **Benefits**: social assistance amounts, age bands, eligibility, new programmes (with start dates), school
  feeding, social pensions, fuel/electricity subsidies (prices, reference prices), in-kind benefits (usually not
  modelled: say why).
- **Indirect taxes**: VAT rate(s), reduced rates and their item lists, exemptions/zero-rating (energy, food,
  water, electricity, LPG, kerosene, ICT, transport), excise rates and bases (ad valorem on which price, specific
  per unit), new excises, temporary relief (dates).
- **Uprating**: CPI series used by the model (annual average or a reference month, as the model does), official
  weights if the model derives series (e.g. food/non-food), the latest available values (provisional flagged).
- **Poverty lines** used by the model, minimum wages or base salaries if parameters depend on them.
- **Budget speech, finance acts, gazettes** of the period: list every measure, then mark each "modellable",
  "not modellable (reason)" or "not relevant".

## Method

0. **Seed the list** from the inventory: every instrument the previous report or the model cites
   (`cite_inventory.py`, 01) is checked for amendments since the previous time point.
1. **Pass 1 (research log):** search primary sources first: official gazettes, parliament, ministries of finance,
   revenue authorities, social security institutions, statistics offices, regulators (fuel prices). Record per
   item: rule on each system's time point, effective dates, legal reference (instrument, article, page), URL,
   access date, status. Big-4 tax summaries and news only as corroboration or when nothing else exists (label).
2. **Pass 2 (independent verification):** a second pass (a separate agent if available, with the pass-1 log
   hidden or treated as claims) re-finds each item from sources, marks confirmed / conflicting / unverified.
   Resolve conflicts yourself from the stronger source; unresolved items become team questions.
   **Arbitration:** the law decides. If the law says A and another source says B, B is wrong. If no legal text
   is available, record the disagreement neutrally with both values and their sources; never pick a value
   because its source is newer, and never treat agreement between the model and its own country report as
   confirmation (the report is written from the model and inherits its errors).
3. **Issues in previous systems:** check the previous system (t-1) as well as the new one: tabulate each
   changed or audited parameter with its value in the model, in the previous report and in the law, per
   system (a t-1 cross-check table in the research log). Past errors (wrong rate, wrong item on a VAT list,
   rule applied before it existed, caps applied to the wrong base) are corrected in all affected systems and
   listed in T1 section 4 and SM_LOG ("correction"). On every mismatch test:
   - **year shift**: does the model value equal the legal value of the year before or after? (A rule applied
     one system early or late, or a value in the wrong column, is the most common error type.)
   - **units**: period suffixes (`#y`, `#m`, `#d` × 30.5, `#l` × 21.73; southmod `functions_and_syntax.md`
     §4), rates as fractions vs percentages, amounts in thousands, calendar vs working days, the reference
     wage or base a cap applies to;
   - **constant vs literal**: is the constant you are checking actually used (`unused_constants.py`), or does
     the formula hold a typed-in number?
   `scripts/locate_values.py locate <CC>.xml <SYSTEM> <law.pdf> ...` shows where each model value appears in
   the downloaded texts, in their number formats (a locator: read every hit).
4. **Within-year changes:** give exact start dates. Under a 1 January time point, a change from 1 July is in the
   next system's rules and, if the model uses a Full Year Adjustment (FYA) extension, pro-rated in the current
   system (6/12). Transitional provisions matter (e.g. a decree in force in October that pays existing
   recipients from July: use July).
5. **Downloaded sources** go to `_internal/sources/` with an index: title, instrument and article, URL, access
   date, what it supports, **status** (extracted / partial / inaccessible, with the reason: 404, JavaScript-only
   page, login, cookie wall, scanned without text), archive snapshot (timestamp and URL) if used, SHA-256 of the
   saved file, and manual instructions for anything still missing ("open <URL> in a browser and save the PDF to
   `_internal/sources/raw/`"). Never drop a source silently: an inaccessible one stays in the index with what was
   tried. Use the `pdf-loading` skill for PDFs.

## Getting the text of a source

Work down this ladder and record which step produced the text:
1. the official host (gazette, ministry, revenue authority, parliament), preferring the **consolidated or
   point-in-time version** in force on the time point where a legal portal offers one (record its version
   date);
2. the gazette issue PDF itself, or alternative official URLs (print, mobile or `/en/` versions, a direct link
   to the document instead of the page that embeds it);
3. a reader proxy for pages that block scripts (`https://r.jina.ai/<URL>`) or a headless browser (Playwright,
   headless, never the user's own browser);
4. an **archived copy**: `scripts/wayback.py closest <URL> <YYYYMMDD>` (the snapshot nearest the policy time
   point, which also shows what the page said then), `wayback.py fetch` (original bytes, e.g. the PDF),
   `wayback.py list <folder URL>* <from> <to>` (every archived file under a ministry's uploads folder);
5. ask the user, stating exactly what is missing and where it should be.
Do not use tools that impersonate browsers or scrape search engines to get round access controls, and do not
disable certificate checks on legal sources.

Check every fetched text before relying on it: not an error page, a cookie or JavaScript notice, an empty
application shell or a table of contents only; it mentions the instrument and year you need; its language is
as expected. Decode from bytes with the declared character set (never drop undecodable characters silently).
Keep tables as tables (convert HTML tables to Markdown or CSV before flattening text): a rate table flattened
to text loses its row and column labels. A PDF with almost no extractable text per page is a scan: run OCR
with the document's language (e.g. `spa`, `por`, `fra`, `vie`), set the status to "OCR" and verify every
number used against the page image. In Word sources, values can sit in tables nested inside table cells
(python-docx `cell.text` misses them; read `cell.tables`) or inside paragraphs.

**Which source speaks for which year.** A budget speech is a proposal until the finance act or decree passes
(status "budget"); the previous country report covers systems up to the previous release only; the T2 team
answers cover the new year. Record the status with each value and never place a proposal in a "final" cell.

**Discrepancy types** (use them in the research log, T1 §4 and SM_LOG notes): wrong value; wrong year (a value
in the wrong system); missing rule; incomplete description (e.g. a mid-year change without its date); missing
source; formatting (separators, units); structural (the model cannot represent the rule as legislated).
Grade each: **fix** (the model or report is wrong) or **note** (advisory).

Year conventions: state them everywhere. For fiscal-year countries "2026" usually means FY2026/27 with rules on
1 July 2026; for calendar-year countries rules on 1 January (or the model's convention).

## T1 policy-change document (`<CC>/Update_<year>/T1_policy_changes_<CC>.md`)

Readable by the national team. Structure:

```
# <MODEL>: policy changes <previous time point> to <new time point>
- Systems, data, time point, research passes (paths to logs), edit CSVs applied, row numbering note (GUI N.M).
## 1. Changes that can be modelled (implemented)
| # | Instrument | Change (legal basis) | Policy, row | Parameter | <prev system> | <new system> |
Rules checked and found unchanged: (bullets)
## 2. Modellable, not yet implemented (need team input or data)
| # | Instrument | Issue | What is needed | Proposed implementation |
## 3. Changes that cannot be modelled
| Change | Effective | Reason |
## 4. Issues in previous systems
| # | Kind | Issue | Systems | Law / source | Action (Fixed: edit CSV / Team to confirm / Keep, documented) |
## 5. Data needs
## 6. Desk-research answers (date, source file) - added when remaining questions are answered
```

Keep T1 in sync with the model at the end (every implemented row names its edit CSV; "Fixed" only when applied).
