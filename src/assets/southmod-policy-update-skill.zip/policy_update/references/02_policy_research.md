# 02 Policy research and the T1 policy-change document

## Scope: what to check for each new system (and back to the previous system's date)

Walk the model's spine, instrument by instrument, from the previous system's time point to the new one:
- **Personal income tax**: bands, rates, thresholds, allowances and deductions, surcharges, non-resident
  schedules, presumptive/turnover regimes, rental and capital income taxes, local taxes (e.g. local service tax).
- **Social insurance**: employee/employer rates, caps, bases, health insurance premiums (flat or banded), new schemes.
- **Benefits**: social assistance amounts, age bands, eligibility, new programmes (with start dates), school
  feeding, social pensions, fuel/electricity subsidies (prices, reference prices), in-kind benefits (usually not
  modelled: say why).
- **Indirect taxes**: VAT rate(s), reduced rates and their item lists, exemptions/zero-rating (energy, food,
  water, electricity, LPG, kerosene, ICT, transport), excise rates and bases (ad valorem on which price, specific
  per unit), new excises, temporary relief (dates).
- **Uprating**: CPI series used by the model (annual average or a reference month, as the model does), official
  weights if the model derives series (e.g. food/non-food), the latest available values (provisional flagged).
- **Poverty lines** used by the model, minimum wages or base salaries if parameters depend on them.
- **Budget speech, finance acts, gazettes** of the period: list every measure, then mark each "modellable",
  "not modellable (reason)" or "not relevant".

## Method

1. **Pass 1 (research log):** search primary sources first: official gazettes, parliament, ministries of finance,
   revenue authorities, social security institutions, statistics offices, regulators (fuel prices). Record per
   item: rule on each system's time point, effective dates, legal reference (instrument, article, page), URL,
   access date, status. Big-4 tax summaries and news only as corroboration or when nothing else exists (label).
2. **Pass 2 (independent verification):** a second pass (a separate agent if available, with the pass-1 log
   hidden or treated as claims) re-finds each item from sources, marks confirmed / conflicting / unverified.
   Resolve conflicts yourself from the stronger source; unresolved items become team questions.
3. **Issues in previous systems:** while checking, compare the model's past values with the law. Past errors
   (wrong rate, wrong item on a VAT list, rule applied before it existed, caps applied to the wrong base) are
   corrected in all affected systems and listed in T1 section 4 and SM_LOG ("correction").
4. **Within-year changes:** give exact start dates. Under a 1 January time point, a change from 1 July is in the
   next system's rules and, if the model uses a Full Year Adjustment (FYA) extension, pro-rated in the current
   system (6/12). Transitional provisions matter (e.g. a decree in force in October that pays existing
   recipients from July: use July).
5. **Downloaded sources** go to `_internal/sources/` with an index (title, URL, date, what it supports). Use the
   `pdf-loading` skill for PDFs.

Year conventions: state them everywhere. For fiscal-year countries "2026" usually means FY2026/27 with rules on
1 July 2026; for calendar-year countries rules on 1 January (or the model's convention).

## T1 policy-change document (`<CC>/Update_<year>/T1_policy_changes_<CC>.md`)

Readable by the national team. Structure:

```
# <MODEL>: policy changes <previous time point> to <new time point>
- Systems, data, time point, research passes (paths to logs), edit CSVs applied, row numbering note (GUI N.M).
## 1. Changes that can be modelled (implemented)
| # | Instrument | Change (legal basis) | Policy, row | Parameter | <prev system> | <new system> |
Rules checked and found unchanged: (bullets)
## 2. Modellable, not yet implemented (need team input or data)
| # | Instrument | Issue | What is needed | Proposed implementation |
## 3. Changes that cannot be modelled
| Change | Effective | Reason |
## 4. Issues in previous systems
| # | Issue | Systems | Action (Fixed: edit CSV / Team to confirm / Keep, documented) |
## 5. Data needs
## 6. Desk-research answers (date, source file) - added when remaining questions are answered
```

Keep T1 in sync with the model at the end (every implemented row names its edit CSV; "Fixed" only when applied).
