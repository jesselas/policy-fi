# 06 External statistics and validation tables

## External statistics research

For every row of the report's validation tables (Section 4 / Annex), for every year the model covers (at least
the new years and any year whose official figure has since been revised or finalised):
- population (statistics office, WDI), labour force and employment by definition used in the table;
- poverty and inequality (official measure; say whether it matches the model's income/consumption concept);
- benefit programmes: recipients and amounts (ministries, programme agencies, budget execution reports);
- revenues by tax head (revenue authority annual reports, final state budget accounts, OECD Revenue Statistics,
  IMF country reports as estimates), social insurance revenue and contributors (social security institution);
- the definition behind each series (e.g. what a "PIT" aggregate contains; fiscal vs calendar year; households
  vs persons; registered vs active members).

Status labels: final (adopted accounts, published historical), provisional (estimates, partial year), budget
estimate (allocations, targets). Never place a budget figure, partial-year result or derived estimate in a
"final" cell; if used, flag it in the table note. Record everything in
`work/<cc>_external_stats.csv` (table_id, row_id, indicator, unit, year, value, status, source, note, URL).

## Validation code (T6)

Write (or reuse and extend) a script that reads the model outputs and the external-statistics workbook and
produces every validation table cell (simulated, external, ratio) for all years: `T6_<cc>_validation_tables.py`
(and a Stata twin if the team uses Stata). Conventions to settle and document in the table notes:
- weights (`dwt`), annualisation (monthly x 12), units (billions, thousands), rounding as in the report;
- household counts: a household counts as a recipient if any member receives (state the rule);
- which output (POV on/off) feeds which row; base-year vs other years.
Run it after every final run; diff its output against the previous run's output; every changed cell goes into
the report.

## Section 4 text

Explain the comparison: which gaps are expected (under-reporting of formal employment, survey vs administrative
concepts, budget vs outturn), what changed between years and why (policy reforms, data vintage switches, e.g. a
new survey from year X creates a level break). Quote numbers that match the tables exactly and recheck them after
each rerun.

## Team workbook for statistics (T3)

A long `data` sheet (table_id, row_id, indicator, unit, year, value, status, source, note, URL, alternatives) plus
one read-only overview sheet per table, and four green team columns (Confirm / Change / Not sure, correct value,
source, comment). The team fills gaps; new figures found later by desk research go into the team columns with
the prefix "[Desk research <date>, <ID>]" (do not rebuild the workbook once teams or retrieval results filled
columns: edit cells with openpyxl). `examples/build_t3.py` shows a builder.
