# 01 Intake, workspace and inventory

## Files to request (ask once, in one message; proceed with what exists)

Essential:
1. **Previous release bundle** (the SOUTHMOD bundle folder with `XMLParam/` and `Input/`), or at least
   `XMLParam/Countries/<CC>/` (`<CC>.xml`, `<CC>_dataconfig.xml`), `XMLParam/Config/` and the input datasets
   (`Input/<cc>_<year>_a<n>.txt`).
2. **Previous country report** as `.docx` (the published FINAL; a PDF alone does not allow tracked changes).
3. **Target**: which new policy year(s) (e.g. add `<CC>_2025` and `<CC>_2026`), the release/bundle name, the new
   model version number, deadlines.

Strongly wanted:
4. **DRD workbooks** (`DRD_<CC>_<year>_a<n>.xlsm`) of the datasets in use.
5. **Data-preparation do-files** of the recent datasets (and where the raw survey data sit; raw data stay local).
6. **SM_LOG** (`Log/SM_LOG.xlsx` in the bundle) and any update notes, to-do lists, emails from the national team,
   last year's team template.
7. Outputs of the previous release (`Output/*_std.txt`), if available, to diff against.

Ask only what has no sensible default:
- **Policy time point** of the model (read it from the report and system comments first; ask if unclear).
- Whether the user runs **EUROMOD** (you cannot) and **Stata** (you may not), and how outputs come back.
- Whether national-team contacts, co-authors and deadlines should appear in the emails.
- Whether input-data corrections found on the way may be applied in this update or deferred.

## Workspace layout (create at the start; keep it this clean to the end)

```
<Project>/
  CLAUDE.md or README.md            short: layout, conventions, where the plan is
  <CC>/
    SOUTHMOD_<release>_<CC>/        the working model (XMLParam/, Input/, Output/, Log/SM_LOG.xlsx)
    CR <MODEL> v<new> DRAFT tracked.docx     the report being updated (copy of the previous FINAL)
    CR <MODEL> v<old> FINAL.docx             previous report (reference, never edited)
    DRD_<CC>_<year>_a<n>.xlsm               DRDs (sumstats updated in phase 7)
    Data_Prep_Syntax/                        final do-files (no data), README with run order
    Update_<year>/                           team-facing deliverables: T1 (md/pdf), T2, T3, T6 results
  _internal/
    PLAN.md, HANDOVER.md, tools/ (copies of this skill's scripts if the user wants them in the repo)
    <CC>/Update_<year>/work/        research logs, verification logs, edit CSVs (T7_*), edit logs, T6 code
    <CC>/Data_Work/                 edited do-files before they become final, old versions
    reference_bundle/               untouched copy of the previous release (for diffs and audits)
    sources/                        downloaded laws, gazettes, reports (PDFs), with an index
    Misc/                           prompts, email drafts history
  SM_LOG_<release>_entries.csv      the release's SM_LOG rows (mirrors Log/SM_LOG.xlsx)
  Emails_to_national_teams_<year>.txt
```

Keep an untouched copy of the previous release (`_internal/reference_bundle/`) before the first edit, and commit
it (in git: large `.txt` datasets as `.txt.gz`, GitHub rejects files over 100 MB). Everything the user will not
open goes under `_internal/`.

## PLAN.md (write before any edit; keep it current)

```
# PLAN: <MODEL> <year> policy update
Established facts (from the files): systems, datasets and their system ranges, time point, versions.
Deliverables and locations (table).
Steps with status markers [ ] [~] [x] [B] (blocked, reason).
Progress log (dated, newest first).
Findings (issues in previous systems, to verify).
Questions for the user (open ones only; mark RESOLVED with the answer).
```

## Inventory (phase 1)

Do this before any research, so the research targets the model's actual instruments:
- `spine.py` (southmod skill) for the latest system: every policy, function and switch in GUI order.
- `scripts/extract_params.py <CC>.xml params.csv`: one long CSV of all cells; pivot constants by system.
- Datasets and bindings: `<CC>_dataconfig.xml` (which dataset each system uses; extensions and their defaults).
- VAT lists (DefIl functions of `tva_<cc>`), excise functions and constants (`tex_<cc>`), per system:
  `examples/coicop_table.py` and `examples/inventory.py` show how to tabulate them.
- Uprating indices (`UpratingIndex` years and values; which items use which index), `$HICP`,
  `ExchangeRatesConfig.xml` entries for each system.
- The time point: system comments, the report's Section 2 ("rules as of ..."), extension names (FYA etc.).
- Previous report: sections, tables (numbers and years), reference style, author line, version strings.
Write the inventory into `_internal/<CC>/Update_<year>/work/` and the facts into PLAN.md.
