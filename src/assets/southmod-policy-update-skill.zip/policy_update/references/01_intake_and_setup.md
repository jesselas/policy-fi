# 01 Intake, workspace and inventory

## Files to request (ask once, in one message; proceed with what exists)

Essential:
1. **Previous release bundle** (the SOUTHMOD bundle folder with `XMLParam/` and `Input/`), or at least
   `XMLParam/Countries/<CC>/` (`<CC>.xml`, `<CC>_dataconfig.xml`), `XMLParam/Config/` and the input datasets
   (`Input/<cc>_<year>_a<n>.txt`).
2. **Previous country report** as `.docx` (the published FINAL; a PDF alone does not allow tracked changes).
3. **Target**: which new policy year(s) (e.g. add `<CC>_2025` and `<CC>_2026`), the release/bundle name, the new
   model version number, deadlines.

Strongly wanted:
4. **DRD workbooks** (`DRD_<CC>_<year>_a<n>.xlsm`) of the datasets in use.
5. **Data-preparation do-files** of the recent datasets (and where the raw survey data sit; raw data stay local).
6. **SM_LOG** (`Log/SM_LOG.xlsx` in the bundle) and any update notes, to-do lists, emails from the national team,
   last year's team template.
7. Outputs of the previous release (`Output/*_std.txt`), if available, to diff against.

Ask only what has no sensible default:
- **Scope**: the whole update, or one part (report only, SM_LOG only, one system). Do only what is asked; a
  report-only task does not become a model update.
- **Policy time point** of the model (read it from the report and system comments first; ask if unclear).
- **Execution**: who runs EUROMOD and Stata (or R), and how outputs and run logs come back. Inspect what is
  installed rather than assume.
- **Revision author** for the report (`<author>`: a name or institution) and names for the SM_LOG.
- Whether national-team contacts, co-authors and deadlines should appear in the emails.
- Whether input-data corrections found on the way may be applied now or deferred, and the sharing scope of raw
  data (survey licence).
Record every answer in PLAN.md as a decision; do not ask again unless new evidence contradicts it.

## Workspace layout (create at the start; keep it this clean to the end)

```
<project_root>/
  README.txt                         short: layout, conventions, where the plan is
  <CC>/                              what the team and users see
    SOUTHMOD_<release>_<CC>/         the working model (XMLParam/, Input/, Output/, Log/SM_LOG.xlsx)
    DRD_<CC>_<year>_a<n>.xlsm        DRDs
    Data_Prep_Syntax/                final preparation code (no data), README.txt with run order
    Raw_data/  Auxiliary_data/       inputs of the preparation code (not in git; licence permitting)
    Update_<year>/                   team deliverables: tracked report, T1 (PDF), T2, T3, T6 results
  _internal/                         everything else
    PLAN.md, README.txt (folder guide), planning/ (handovers, history)
    <CC>/Update_<year>/              research logs, edit CSVs (T7_*), edit logs, T6 code, working files
    <CC>/Previous_release/           previous FINAL report, previous DRDs
    bundles/                         untouched copy of the previous release (for diffs and audits)
    previous_syntax/                 old do-files and drafts
    data/                            compressed inputs and accepted outputs with hashes
    sources/                         downloaded laws, gazettes, reports, with an index
    tools/                           internal scripts
  Emails_to_national_teams_<year>.txt
```

Keep an untouched copy of the previous release before the first edit. In git, store large datasets
compressed (hosting services reject large files). Everything the user will not open goes under `_internal/`.

## PLAN.md (write before any edit; keep it current)

```
# PLAN: <MODEL> <year> policy update
Established facts (from the files): systems, datasets and their system ranges, time point, versions.
Deliverables and locations (table).
Steps with status markers [ ] [~] [x] [B] (blocked, reason).
Progress log (dated, newest first).
Findings (issues in previous systems, to verify).
Questions for the user (open ones only; mark RESOLVED with the answer).
```

## Inventory (phase 1)

Do this before any research, so the research targets the model's actual instruments:
- `spine.py` (southmod skill) for the latest system: every policy, function and switch in GUI order.
- `scripts/extract_params.py <CC>.xml params.csv`: one long CSV of all cells; pivot constants by system.
- Datasets and bindings: `<CC>_dataconfig.xml` (which dataset each system uses; extensions and their defaults).
- VAT lists (DefIl functions of `tva_<cc>`), excise functions and constants (`tex_<cc>`), per system:
  `examples/coicop_table.py` and `examples/inventory.py` show how to tabulate them.
- Uprating indices (`UpratingIndex` years and values; which items use which index), `$HICP`,
  `ExchangeRatesConfig.xml` entries for each system.
- The time point: system comments, the report's Section 2 ("rules as of ..."), extension names (FYA etc.).
- Previous report: sections, tables (numbers and years), reference style, author line, version strings.
Write the inventory into the internal work folder and the facts into PLAN.md.
