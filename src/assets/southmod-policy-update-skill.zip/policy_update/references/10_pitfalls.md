# 10 Pitfalls (lessons from real updates; the examples come from specific models)

Model
- **Partial extension bindings do not run.** Rows bound to an extension only in the newest systems never ran,
  silently (no warning; a total tax equalled the sum of its components). Bind whole rows; verify in output.
  What decides is the **first `<System>` in the file** (EUROMOD's EM3 copy takes row bindings from it), which is
  not always the earliest year.
- **Cloning lost parameter bindings.** An earlier clone script copied policy and function bindings but not
  `Extension_Parameter` entries, so parameter-level FYA values in the new system were unbound.
  `add_system.py` now copies all three; `ext_binding_check.py` checks parameters too.
- **Output names not renamed.** A clone kept `<CC>_<old year>_hh_std` because only `_std` names were renamed;
  outputs of two systems then overwrite each other. Check every DefOutput `file` of a new system.
- **Whole-file XML rewrites.** Parsing and re-serialising the model (lxml or similar) drops the BOM, CRLF and
  CDATA: the diff becomes the whole file and review is impossible. Edit text in place (edit_model.py).
- **Edits overwritten by the GUI.** A model open in EUROMOD (`*_in_use.txt`) is saved from its working copy
  (`Temp/astmp_<CC>.xml`), replacing script edits made meanwhile.
- **"Contiguous Order" is a myth.** Released models have gaps in `<Order>`; renumbering rows to "fix" them
  changes nothing but the diff.
- **Elig without effect.** A new `Elig` did nothing because the benefit function lacked `Who_Must_Be_Elig`
  (default `nobody`).
- **Benefit on one person.** A household-unit function stores its result on the head and sets everyone else to
  0 (`Output_Var`); a later `Output_Var` on the same variable wiped an earlier component.
- **Constant updated, literal used.** A DefConst was updated but the formula held a typed-in number (or another
  constant); `unused_constants.py` finds such cases.
- **Query codings.** `IsMarried` (`dms=2`), `IsDisabled` (`ddi>0`) and similar queries assume particular codes;
  a data revision that recoded the variable changed results silently. Check codings when data change.
- **A regex across XML elements** once changed 12 unrelated parameters (a non-greedy `.*?` spanning elements).
  Anchor on `<ID>` or parse; diff every cell after each edit.
- **Row numbers shift** when policies/functions are deleted or added; an old CSV's "31.2" became "28.2". Re-print
  the spine; never reuse old row numbers.
- **Duplicate list definitions**: a VAT list and its "formal outlets only" twin both define the same `il_`; an
  edit to one was missed in the other. Edit both; test against output which one the formula uses.
- **VAT counted twice**: an item on the VAT list and also taxed by the excise policy's "VAT on excise items".
- **Stale comments** after value changes ("7.5%", "3/12", "team to confirm"): search all comments for old values.
  Comments copied into every system must be true in every system.
- **Hand-written XML on one line**: `<Extension>`/`<PolicySwitch>` elements added by a script without whitespace
  between children reached `EM3Translation` with name, system and value empty. Write one child per line and
  check the translation after EUROMOD regenerates it.
- **Caps applied to the wrong base** (a per-litre legal cap applied to total household spending).
- **Rules applied before they existed** (a 2026 schedule in the 2024 system); check effective dates per system.
- **Year shifts**: in one verification, five of thirteen errors were a value from the adjacent year in the wrong
  system column. Test every mismatch against the law of year ±1.
- **The report agreed with the model and both were wrong**: the report had been written from the model.
  Verify against the law, not the report.
- **Period conversions**: a daily (`#d`, × 30.5) or labour-day (`#l`, × 21.73) amount compared with a monthly
  legal figure looked wrong; convert with the engine's factors first.
- **Tax unit**: a benefit on a household tax unit paid at most one person per household; use the individual unit
  when the rule is individual.

Data
- **Recall-period bug**: a 30-day module divided by 12 made daily items 12 times too small, and so their VAT and
  excise. Check monthly means of large items for plausibility.
- **Stripping lists out of line with the model** (an exempt item stripped of VAT; a taxed item not stripped; a
  removed excise still stripped).
- **Nondeterministic allocation**: unstable sorts with ties moved businesses between households across runs.
  The model's random draws (`RandSeed`, `rand`) behave the same way when an input is reordered.
- **Prefix-based tolerances**: a count variable whose name started like a monetary prefix inherited a money
  tolerance and hid a difference. Set tolerances per variable.
- **Same name, new content**: an input kept its file name after its content changed. Refer to snapshots by hash.
- **Overwritten or deleted run inputs**: an input used by accepted runs gets a new version before it is
  regenerated, never an overwrite; gzip superseded files and verify the decompressed SHA-256 before deleting.
- **Stata `local L : list A - B`** takes macro names: `list A - xhh` with a literal word removes nothing, silently
  (an exclusion that never worked). Put the words in a macro (`local drop xhh`, `list A - drop`) and `assert`.
- **Wrong weighting unit**: a statistics office report said "households" while its published rates were
  person-weighted. Recompute both before calling a discrepancy.

Runs and numbers
- **Checks that pass on partial data**: an older yds check reported success with unmatched people, and an
  older post-fiscal script printed `nan` for an empty band. Treat any check without explicit population and
  validity tests as unverified.
- **Post-fiscal lines drift** after any indirect-tax change; iterate to a fixed point, per system.
- **Base-year yds** must be refreshed after income-list corrections in base-year systems.
- **Rounded or derived figures presented as reported** (a tax total = last year x growth rate): label as derived.
- **Hard-coded numbers in build scripts**: a paper builder kept a superseded figure after a rerun.
- **Rounded output**: `DefOutput` `nDecimals` 2 rounded `ses`, moving a base-year poverty rate computed from the
  output (27.42 vs 27.37 per cent) and the post-fiscal fixed points. Use more decimals (04).

Report
- **Garbled reject view**: earlier passes overwrote paragraphs (original lost) or deleted their own insertions as
  deletions (they reappear as original text on reject). Use `tracked_edit.py`; run `report_qa.py` after each pass.
- **Copied paragraphs with only the mark tracked**: rejecting merges the untracked copy into the next paragraph
  and duplicates text. An older QA script removed such paragraphs whole and missed it.
- **Endnotes, headers and footers** change too: QA must cover every story part.
- **Merged table cells** repeat in python-docx `row.cells`: locate columns by header year, rows by label.
- **The previous FINAL may still contain tracked changes**; choose the baseline explicitly (05).
- **Numbers in text** that quote table cells go stale after reruns: search for old values after each T6.
- **Year columns copied with the old header** or old values: `locate_values.py tables` catches parameter cells
  that are not the model's value for that year.
- **Nested tables**: values inside a table within a table cell are invisible to `cell.text`; read `cell.tables`.
- **Dead reference links** in the report: check them (`cite_inventory.py --check-links`) and replace with the
  current official URL or an archived copy.

Process
- **Ambiguous user answers** ("keep 2026") cost a rerun: confirm in one line when an answer could mean two things.
- **Editing a model folder during a run** makes the runs fail. Ask whether EUROMOD is running before touching
  `XMLParam`, configs or `EM3Translation`.
- **Stale run requests**: an old request file said earlier results "remain valid" after a later input change.
- **Do not rebuild team workbooks** once they hold answers or research notes; edit cells.
- **Blank team cells read as agreement**: they mean "not reviewed". Ask for an explicit Confirm.
- **Wayback's oldest snapshot**: an archive lookup without a date returned a capture years before the policy
  year. Ask for the capture closest to the time point (`wayback.py closest`).
- **Silent fetch failures**: error pages, cookie walls and empty JavaScript shells saved as "the law". Check every
  fetched text (02) and keep failed sources in the index with what was tried.
- **Connector runs on the wrong engine**: the Python package falls back to its bundled engine when the installed
  EUROMOD is older than it requires; check `using_bundled_fallback`.
- **Temp folders refill** when EUROMOD is reopened; check right before packaging.
- **Shared model without `XMLParam/Temp/`**: the folder is usually empty, so git and some zip tools leave it out;
  keep it (empty) in every package and check the zip listing.
- **Hidden absolute paths** in shipped Office files (image descriptions, workbook `absPath`).
- **Split big edits into small commits**; push often.
