# 10 Pitfalls (lessons from real updates; the examples come from specific models)

Model
- **Partial extension bindings do not run.** Rows bound to an extension only in the newest systems never ran,
  silently (no warning; a total tax equalled the sum of its components). Bind whole rows; verify in output.
- **A regex across XML elements** once changed 12 unrelated parameters (a non-greedy `.*?` spanning elements).
  Anchor on `<ID>` or parse; diff every cell after each edit.
- **Row numbers shift** when policies/functions are deleted or added; an old CSV's "31.2" became "28.2". Re-print
  the spine; never reuse old row numbers.
- **Duplicate list definitions**: a VAT list and its "formal outlets only" twin both define the same `il_`; an
  edit to one was missed in the other. Edit both; test against output which one the formula uses.
- **VAT counted twice**: an item on the VAT list and also taxed by the excise policy's "VAT on excise items".
- **Stale comments** after value changes ("7.5%", "3/12", "team to confirm"): search all comments for old values.
  Comments copied into every system must be true in every system.
- **Caps applied to the wrong base** (a per-litre legal cap applied to total household spending).
- **Rules applied before they existed** (a 2026 schedule in the 2024 system); check effective dates per system.
- **Tax unit**: a benefit on a household tax unit paid at most one person per household; use the individual unit
  when the rule is individual.

Data
- **Recall-period bug**: a 30-day module divided by 12 made daily items 12 times too small, and so their VAT and
  excise. Check monthly means of large items for plausibility.
- **Stripping lists out of line with the model** (an exempt item stripped of VAT; a taxed item not stripped; a
  removed excise still stripped).
- **Nondeterministic allocation**: unstable sorts with ties moved businesses between households across runs.
- **Prefix-based tolerances**: a count variable whose name started like a monetary prefix inherited a money
  tolerance and hid a difference. Set tolerances per variable.
- **Same name, new content**: an input kept its file name after its content changed. Refer to snapshots by hash.

Runs and numbers
- **Checks that pass on partial data**: an older yds check reported success with unmatched people, and an
  older post-fiscal script printed `nan` for an empty band. Treat any check without explicit population and
  validity tests as unverified.
- **Post-fiscal lines drift** after any indirect-tax change; iterate to a fixed point, per system.
- **Base-year yds** must be refreshed after income-list corrections in base-year systems.
- **Rounded or derived figures presented as reported** (a tax total = last year x growth rate): label as derived.
- **Hard-coded numbers in build scripts**: a paper builder kept a superseded figure after a rerun.

Report
- **Garbled reject view**: earlier passes overwrote paragraphs (original lost) or deleted their own insertions as
  deletions (they reappear as original text on reject). Use `tracked_edit.py`; run `report_qa.py` after each pass.
- **Copied paragraphs with only the mark tracked**: rejecting merges the untracked copy into the next paragraph
  and duplicates text. An older QA script removed such paragraphs whole and missed it.
- **Endnotes, headers and footers** change too: QA must cover every story part.
- **Merged table cells** repeat in python-docx `row.cells`: locate columns by header year, rows by label.
- **The previous FINAL may still contain tracked changes**; choose the baseline explicitly (05).
- **Numbers in text** that quote table cells go stale after reruns: search for old values after each T6.

Process
- **Ambiguous user answers** ("keep 2026") cost a rerun: confirm in one line when an answer could mean two things.
- **Stale run requests**: an old request file said earlier results "remain valid" after a later input change.
- **Do not rebuild team workbooks** once they hold answers or research notes; edit cells.
- **Temp folders refill** when EUROMOD is reopened; check right before packaging.
- **Hidden absolute paths** in shipped Office files (image descriptions, workbook `absPath`).
- **Split big edits into small commits**; push often.
