# 10 Pitfalls (lessons from the 2026 VNMOD / RWAMOD / UGAMOD update)

Model
- **Partial extension bindings do not run.** FYA rows bound only in the two newest systems never ran, silently
  (no warning; the total excise equalled the sum of its components). Bind whole rows; verify effects in output.
- **A regex across XML elements** once changed 12 unrelated parameters (a non-greedy `.*?` spanning elements).
  Anchor on `<ID>` or parse; diff every cell after each edit.
- **Row numbers shift** when policies/functions are deleted or added; an old CSV's "31.2" became "28.2". Re-print
  the spine; never reuse old row numbers.
- **Duplicate list definitions**: a VAT list and its "formal outlets only" twin both define `il_exp_vat01`; an edit
  to one was missed in the other. Edit both; check which one the tax formula actually uses (test against output).
- **VAT counted twice**: an item on the VAT list and also taxed by the excise policy's "VAT on excise items" function.
- **Stale comments** after value changes ("7.5%", "3/12", "team to confirm"): search all comments for old values.
- **Caps applied to the wrong base** (a per-litre legal cap applied to total household spending).
- **Rules applied before they existed** (a 2026 schedule in the 2024 system); check effective dates per system.
- **Tax unit**: a benefit on a household tax unit paid at most one person per household; use the individual unit
  when the rule is individual.

Data
- **Recall-period bug**: a 30-day expenditure module divided by 12 made petrol, soap and other daily items 12 times
  too small, and so their VAT and excise. Check monthly means of large items for plausibility.
- **Stripping lists out of line with the model** (LPG stripped of VAT although exempt; electricity not stripped
  although taxed; a removed excise still stripped).
- **First-run variables** merged from an old model run: document them as fixed dependencies or regenerate.

Runs and numbers
- **Post-fiscal lines drift** after any indirect-tax change; iterate to a fixed point, per system.
- **Base-year yds** must be refreshed after income-list corrections in base-year systems (e.g. a reported benefit
  that had been excluded from income).
- **Rounded or derived figures presented as reported** (a tax total = last year x growth rate): label as derived.

Report
- **Garbled reject view**: earlier passes overwrote paragraphs (original lost) or deleted their own insertions as
  deletions (they reappear as original text on reject). Use `tracked_edit.py`; run `report_qa.py` after every pass.
- **Merged table cells** repeat in python-docx `row.cells`: locate columns by header year, rows by label.
- **The previous FINAL may still contain tracked changes**; compare reject views, not raw text.
- **Citations in the reference list**: every new citation needs an entry; keep the report's style.
- **Numbers in text** that quote table cells go stale after reruns: search the text for old values after each T6.

Process
- **Ambiguous user answers** ("keep 2026") cost a rerun: confirm in one line when an answer could mean two things.
- **Do not rebuild team workbooks** once they hold answers or research notes; edit cells.
- **Split big edits into small commits**; push often (cloud sessions end).
- **Never drive the user's own browser**; headless tools only (if any browser work is needed).
