# 07 Input data, data-preparation code and DRDs

Ask the user before changing input data; offer the alternative of documenting and deferring to the next data
update. Any data change triggers reruns of every system on that dataset, the yds check, post-fiscal lines, T6,
report numbers, DRD, SM_LOG ("input data" entries).

## Typical corrections

- **VAT/excise stripping**: inputs are usually net of VAT and excise, stripped item by item in the preparation
  code. The stripping list must follow the rules of the dataset year and the model's own tax formulas, or the
  model double-counts or misses tax. Verify the gross/net identity for each item against the model formula.
  Specific duties stay per physical unit after any price adjustment.
- **Total and formal components** (a formal-purchase extension): create formal-expenditure variables only for
  inputs whose systems use the extension; validate each total/formal pair and never add both into expenditure
  aggregates.
- **Recall periods**: daily, 30-day and 12-month modules need the right conversion. If the recall period is
  uncertain, read labels and questionnaires and compare weighted means with plausible values. Record an
  approved assumption as an assumption; stop and report if evidence contradicts it.
- **Reported vs simulated variables** in income lists; first-run variables merged from an earlier model run
  (document them as fixed dependencies or regenerate them).
- **yds** is always the last step (`yds = ils_dispyki` from the final model's base-year output, 04).

## Reproduction from raw data

1. Inventory the chain: raw and auxiliary sources, every do-file (or script) in run order, intermediate files,
   the final export. Record which inputs are fixed historical extracts, calibration weights or earlier model
   outputs.
2. Check that each correction survives later merges, keep/drop statements and the export.
3. Check deterministic allocation wherever sorting or ties can move businesses, incomes or household
   assignments (stable sorts, explicit seeds; rerun with a changed sort order when the risk exists).
4. Compare the rebuilt dataset with the target:
   `python3 $SKILL/scripts/compare_input_data.py <target> <rebuilt> --out <dir>/<name> --tol-file <tolerances.csv>`.
   Tolerances are per variable, in its units and stored precision (monetary variables at export precision).
   IDs, counts, classifications and flags are exact. Every difference is an approved change or a bug.
5. Classify each input:
   - **raw reproduction verified**;
   - **reproduced with documented fixed dependencies** (list them);
   - **limited refresh only** (e.g. yds), raw reproduction unverified.
   A successful refresh, or reuse of an existing input, is not proof of raw reproduction.

## Dataset versions and provenance

- A substantively changed released input gets a new version (`a<n>` to `a<n+1>`). Apply it everywhere at once:
  file names, preparation code, dataconfig bindings, DRD name, report, logs.
- Increment at publication boundaries, not for every intermediate edit. A byte-identical rename (verified by
  hash) is not a data change and needs no new simulation.
- Keep an old-to-new version map with input hashes. Preserve original run logs and the file names recorded at
  execution; do not rewrite history to the new names.
- If the user decides to keep a name despite changed content, record the hash of each snapshot and refer to
  snapshots by hash.

## Do-files: versioning and the shared package

- Final do-files keep the names the master file calls. Old versions get a dated suffix (e.g.
  `_Before<date>update`) and move to the internal archive. Each changed do-file gets a dated header (what
  changed, why, which model change it matches) and a comment at each changed line.
- The shared preparation package (`<CC>/Data_Prep_Syntax/`) has one obvious entry point, one clearly marked
  root-path setting, relative paths, a `version` statement and logs. Raw and auxiliary inputs sit in sibling
  folders (`<CC>/Raw_data`, `<CC>/Auxiliary_data`) with an exact dependency manifest; generated work goes to a
  separate folder. A plain-text README gives the run order, the required files, the outputs, the manual
  EUROMOD steps (yds, post-fiscal constants) and what to review before installing a rebuilt input.
- Teams that use Stata get Stata validation code; keep internal Python checks out of the shared package.
- The package must run without the internal workspace (09: public package checks).
- Raw data follow the survey licence and the sharing scope the user authorised; never commit them to git.

## DRD workbooks (`DRD_<CC>_<year>_a<n>.xlsm`)

- Update summary statistics for every variable whose values changed (as the sheet defines them, with the
  dataset's weight) and the derivation text of every variable whose derivation changed.
- Add a dated entry to the DRD's history or log sheet (configured author, dataset version, variables or
  derivations changed), following the sheet's column conventions.
- Edit only the needed cells. `.xlsm`: `openpyxl.load_workbook(path, keep_vba=True)` after a backup. If the
  workbook does not round-trip safely (styles lost, invalid style definitions, formulas dropped), edit the
  sheet XML inside the package directly, when authorised.
- Verify afterwards against the backup: macros (`vbaProject.bin`), formulas, style definitions (new styles only
  where needed), untouched sheets and other package parts. Look at the changed cells. If anything would be
  lost, stop and tell the user.
- Renamed dataset: rename the DRD too and update the dataconfig and report.
