# 07 Input data, data-preparation code and DRDs

## When input data must change

Model corrections often expose data-preparation inconsistencies. Typical cases:
- **VAT/excise stripping**: SOUTHMOD input expenditures are usually net of VAT and excise (the data prep strips
  them item by item from reported spending, and stores imputed `tvaiv`/`texiv`). When the model's VAT status or
  excise of an item changes (e.g. an item found exempt, or standard-rated), the stripping list in the data prep
  must match the rules of the dataset year, or the model double-counts or misses tax.
- **Recall periods**: expenditure modules with different recall periods (daily, 30 days, 12 months) must be
  annualised/monthly-ised correctly (a 30-day module divided by 12 understates the items 12 times).
- **Excise bases** (ad valorem on the tax-inclusive price) and specific rates per unit (quantities).
- **Reported vs simulated variables** in income lists; first-run variables merged from an earlier model run.
- **yds**: always the last step (`yds = ils_dispyki` from the final model's base-year output).
Any data change triggers: reruns of every system on that dataset, yds check/refresh, post-fiscal lines, T6,
report numbers, DRD sumstats, SM_LOG ("input data" entries). Ask the user before changing data; offer the
alternative of documenting and deferring to the next data update.

## Do-files: versioning and reproduction

- Final do-files keep their original names and are the ones the master/run-all file calls. The old version gets
  the suffix `_Before<date>update` and moves under `_internal/`. Each changed do-file gets a dated header block
  (what changed, why, which model change it matches) and a comment at each changed line.
- One root path global per model; relative paths; a `version` statement; logs.
- Reproduce: run the chain (the user or an agent with Stata), then compare the rebuilt dataset with the target by
  idperson: `python3 $SKILL/scripts/compare_input_data.py <target> <rebuilt>` (rows, column order, per-column
  differences with a money tolerance). Every difference is either an approved change or a bug.
- A data-free, tracked copy of the final syntax per model (`<CC>/Data_Prep_Syntax/` with a README: run order, raw
  files needed, outputs, where yds and post-fiscal steps need EUROMOD) is what gets shared with teams.
- Raw survey data never go into git or shared folders.

## DRD workbooks (`DRD_<CC>_<year>_a<n>.xlsm`)

- Update the **sumstats** sheet for every variable whose values changed (mean, weighted mean, share non-zero, min,
  max, as the sheet defines; compute from the new dataset with the dataset's weight). Edit only those cells.
- If a variable's derivation changed, update its derivation text in the variable sheets (e.g. "30-day recall,
  monthly value" instead of "divided by 12"; "VAT stripped at 18%").
- `.xlsm`: open with `openpyxl.load_workbook(path, keep_vba=True)`, back up first, change only the needed cells,
  and verify afterwards that other sheets, macros (`vbaProject.bin`) and formatting are intact (compare with the
  backup, e.g. unzip both and diff the XML of untouched sheets). If anything would be lost, stop and tell the user.
- Rename the DRD if the dataset version changes (`a<n>` -> `a<n+1>`), and update the dataconfig and report.
