# 09 SM_LOG, audit and the final package

## SM_LOG

The model's change log lives in the bundle: `Log/SM_LOG.xlsx`, sheet `Log`, columns
`Date | Name | Version | File | Policy | System | Element | Change | Additional notes`. Append rows after the last
row of the release (copy the previous row's cell styles). Keep a CSV mirror (`SM_LOG_<release>_entries.csv`) and,
if several bundle copies exist, keep them identical.

Style: date (`2026-09-27`), the user's name, release (`A5.0`), country code, policy name(s), systems as years
(`2024-2026`, `2026`, `all`), element (row and parameter, e.g. `9.7 $bsf_amnt1`, `DefIl x04510`,
`Extension_Function (FYA) for tva_vn 24.7`), a short lowercase change, and a note: `correction` or the legal
reference or the tool used. One entry per logical change; systems added get one entry each ("added <SYS>, cloned
from <SYS>, run on <dataset>"); data changes use policy `input data` and name the dataset and variables. Revert
entries are deleted if a change is undone the same day (keep the log readable).

## Audit before finishing

`python3 $SKILL/scripts/audit_vs_previous.py <reference_bundle>/<CC>.xml <working>/<CC>.xml SM_LOG_entries.csv`
lists, per policy, every value, name, switch, added/removed parameter/function/policy and uprating change against
the previous release, and flags policies without an SM_LOG entry. Also compare `Config/*.xml` (VarConfig,
HICPConfig, ExchangeRatesConfig) and `<CC>_dataconfig.xml` with the previous release. Every difference needs an
entry (or is covered by a "system added" or an "all systems" entry).

## Final organisation (what the user should see)

```
<CC>/
  SOUTHMOD_<release>_<CC>/                  final model (runs; Output/ not committed as .txt)
  CR <MODEL> v<new> DRAFT tracked.docx       report with all changes tracked (QA clean)
  DRD_<CC>_*.xlsm                            DRDs with updated sumstats
  Data_Prep_Syntax/                          final do-files, README
  Update_<year>/                             T1, T2, T3 (team), T6 results
Emails_to_national_teams_<year>.txt
SM_LOG_<release>_entries.csv
_internal/                                   everything else (plan, handover, logs, research, edit CSVs, tools,
                                             old do-files, reference bundle, sources)
```

## Handover document (`_internal/HANDOVER_<date>.md`)

What the project is; layout; current state (verified checks with dates: yds, pf lines, T6 = report tables, T2 =
model, SM_LOG audit, report QA); conventions and rules followed; how to run and check; open items (team replies,
data updates, deferred corrections) with where each lands. A new session should be able to continue from it alone.

## Definition of done

- Every new system runs; every base-year yds check passes; every post-fiscal line is a fixed point.
- `ext_binding_check.py` clean (or only rows with deliberate partial bindings, documented).
- `audit_vs_previous.py`: every change logged.
- T1 = model; T2 cells = model; T6 output = report tables; report QA "IDENTICAL after reject".
- Emails drafted with only the questions the team can answer better; remaining-question answers applied.
- Data-prep code reproduces the final input datasets (or the gap is documented) and DRD sumstats match them.
- Workspace organised as above; handover written; everything committed and pushed.
