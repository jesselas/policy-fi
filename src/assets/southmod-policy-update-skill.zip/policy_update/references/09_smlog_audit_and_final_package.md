# 09 SM_LOG, audit and the final package

## SM_LOG

The model's change log is `Log/SM_LOG.xlsx` in the model folder, sheet `Log`, columns
`Date | Name | Version | File | Policy | System | Element | Change | Additional notes`. Append rows after the
last row (copy the previous row's cell styles).

Style: date (`2026-09-27`), `<author>`, release (`A5.0`), country code, policy name(s), systems as years
(`2024-2026`, `2026`, `all`), element (row and parameter, e.g. `9.7 $bsf_amnt1`, `DefIl x04510`,
`Extension_Function (FYA) for tva_<cc> 24.7`), a short lowercase change, and a note: `correction`, the legal
reference, or a one-line reason. One entry per logical change, covering every system it touches (a policy added
as `n/a` in earlier systems is logged for all of them). New variables in `VarConfig.xml` get entries too.
Systems added get one entry each ("added <SYS>, cloned from <SYS>, run on <dataset>"); data changes use policy
`input data` and name the dataset version and variables. Delete a same-day revert rather than logging both.

The log is public: explain the change and cite legislation where useful. Never refer readers to private
scripts, edit CSVs or internal notes. A CSV mirror of the entries is an internal working file.

Decide with the user whether the shipped log is cumulative (all history) or current-release-only. For
current-release-only logs, archive the earlier history internally before replacing it. A single-country
package contains only that country's entries.

## Audit before finishing

`python3 $SKILL/scripts/audit_vs_previous.py <reference_bundle>/<CC>.xml <working>/<CC>.xml SM_LOG_entries.csv`
lists, per policy, every value, name, switch, added/removed parameter/function/policy and uprating change
against the previous release, and flags policies without an SM_LOG entry. Also compare `Config/*.xml`
(VarConfig, HICPConfig, ExchangeRatesConfig) and `<CC>_dataconfig.xml` with the previous release. Every
difference needs an entry (or is covered by a "system added" or an "all systems" entry).

## Public packages (model, preparation code, team materials)

What is shipped must work and make sense without the private workspace:
- Scan code, configuration, model comments, READMEs and shared documents for internal paths, absolute paths
  (`/Users/`, `C:\Users\`), links to private repositories, symlinks, and references to material the recipient
  cannot see ("validated project", "internal notes"). Office files hide paths too: image descriptions in
  `word/document.xml`, `absPath` in `xl/workbook.xml`, external links in `.rels` files. Unzip and grep them.
- Labels and comments describe the model, not its development history: a variable built from synthetic or
  unavailable data must not be labelled as validated.
- Formats: plain-text READMEs; PDF, Word or Excel for review material; Markdown only for internal plans.
- Clear generated contents of public `Output/` and `Temp/` folders for a sharing package, after the accepted
  outputs and logs are archived with hashes (04). Never delete files of an active run or evidence still
  needed. Opening EUROMOD writes new files into `XMLParam/Temp`: check again right before packaging.
- Respect survey licences and the sharing scope the user authorised.

## Internal workspace

Keep a short current plan and an internal folder guide (what each folder is for). Group material by purpose:
plans and handovers, sources, reference bundles, country research, previous syntax, compressed data, tools,
verification records. Archive old reports, obsolete syntax, old bundles and research scripts there. When
moving files, keep a path map and check that internal tools still run.

## Handover document (internal)

What the project is; layout; current state (verified checks with dates: yds, pf lines, T6 = report tables,
T2 = model, SM_LOG audit, report QA, input status per dataset); decisions taken; how to run and check; open
items (team replies, data updates, deferred corrections) with where each lands. A new session should be able
to continue from it alone.

## Definition of done

- Every new system runs; every base-year yds check passes; every post-fiscal line is a fixed point; every
  accepted run has provenance (04).
- `ext_binding_check.py` clean (or only deliberate partial bindings, documented).
- `audit_vs_previous.py`: every change logged.
- T1 = model; T2 cells = model; T6 output = report tables; `report_qa.py` passes and the changed pages were
  inspected.
- Emails drafted with only the questions the team can answer better.
- Each input classified (07: verified / fixed dependencies / limited refresh); DRD sumstats, derivations and
  history match the input.
- Public packages scanned (above); internal workspace organised; handover written; everything committed.
