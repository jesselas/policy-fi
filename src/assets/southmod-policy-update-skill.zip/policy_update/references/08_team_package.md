# 08 National-team package, remaining questions and applying answers

## What the team gets (per country)

1. **T2 parameter workbook** `<CC>/Update_<year>/T2_<MODEL>_<year>_parameters_for_team.xlsx`: sheets README,
   Parameters (model rows: grey current values by system, blue proposed new values with basis/source, green team
   columns: Confirm / Change / Not sure, correct value, source, comment), COICOP_VAT_excise (every expenditure item
   with average spending, share, VAT status and excise by system; sorted so large items come first), CPI
   (uprating series), Earlier systems (proposed corrections), New or missing (changes we missed), Questions.
   Build it once (`examples/build_t2.py`, styling in `scripts/team_workbook.py`); afterwards edit cells by hand
   with openpyxl so answers and research notes are not lost. Keep every cell equal to the model at the end.
   A model change that teams must review (a new instrument, a changed data treatment) also gets its rows or
   questions in T2.
2. **T3 external statistics workbook** (06).
3. **T1 policy-change document** (PDF) for information.
4. For data work, only if needed: metadata-export code the team can run on raw data that cannot be shared.

## Before asking a team anything

Answer what you can locally first: raw data, variable and value labels, questionnaires, preparation code, DRDs,
previous reports. Distinguish a variable the model lacks from information the survey lacks; finding
quantities in the data does not show that their units or legal tax categories can be mapped reliably.
Ask teams for data lookups or metadata exports only for information that is genuinely inaccessible locally.

Each remaining question states the current choice, the remaining uncertainty and the confirmation sought:
"The model applies X from 2025 (source). We could not confirm Y. Please confirm X or give the correct value."

## Email draft (`Emails_to_national_teams_<year>.txt`; the user sends)

Brief and centred on the attachments. Ask mainly for confirmation or correction of the implemented policies,
retained approximations and proposed scope:

```
To / Subject / Attachments (paths)
Dear colleagues,
We have updated <MODEL> with the <year> policy system (rules on <time point>) [and new data ...].
Please review the attachments and confirm or correct:
1. Policy rules (T2): answers from our research are filled in; reply only where you disagree. Open points:
   (short bullets, each with current choice, uncertainty and the confirmation sought).
2. Corrections to earlier systems: (bullets).
3. External statistics (T3): what we most need (bullets, with the institution).
4. Data (if any): what is needed, and why.
Please reply by <date>.
```
Keep research histories and implementation details internal. Keep an internal note under each draft: what
was settled by desk research, what to look up in parallel. Attachments use familiar formats (PDF, Word, Excel,
plain-text README) unless the recipients ask otherwise.

## Remaining-questions prompt for an online research AI

When questions remain after two research passes, write one prompt (IDs per country, e.g. V1-V13, R1-R8) that a
browsing AI can answer: rules (primary sources first, exact quotes with translation, document/article/page/URL,
status final/provisional/budget, "Not found" with what was tried, year conventions), then one line per question
with what we already have. Store it in `_internal/Misc/`.

## Applying the answers (per ID)

1. Judge the source (primary > secondary; label unverified).
2. Apply where it belongs: model (edit CSV, SM_LOG), T1 (sections 1-4 and a "Desk-research answers" section),
   T2 (team columns with "[Desk research <date>, <ID>] ...", proposal cells aligned with the model), T3 team
   columns, report (tracked, with new references), emails (remove or shorten the question; keep what the team
   knows better).
3. List what needs rerunning; after the runs follow 04.
4. Summarise per ID: changed / confirmed (no change) / still open (and asked of whom).
