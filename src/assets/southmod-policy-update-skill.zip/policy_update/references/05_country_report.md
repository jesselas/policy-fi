# 05 Country report update (Word, tracked changes)

Copy the previous FINAL to `CR <MODEL> v<new> DRAFT tracked.docx` and edit only the copy, only with tracked
changes (python-docx via `scripts/tracked_edit.py`). The revision author is `<author>`, the name or institution
agreed with the user (`open_doc(path, author=...)` or `REPORT_AUTHOR`). Log every edit in an internal edit log
(`CR_edit_log_<CC>.md`: section, old, new, reason/source).

## Content rules

- **The report stands on its own**: describe the current model and policies only. No "previous version",
  "was corrected", "we changed the method", "v3.5 had". Version, years and author line are updated plainly.
- UN English, the report's own reference style (copy the format of an existing entry of the same type), no
  semicolons or em dashes in new prose, minimal hyphens, "per cent", thousands separators as in the report.
- Every new fact has a citation that is in the reference list (add entries in alphabetical position).
- Use the `econ-writing` skill for prose passes if available.

## Section by section (all need online research)

**Front matter:** title (model version, years covered), author line and year, citation line, acknowledgements
(institution names change: check the partner institute's current official English name), abstract, version
and bundle name, JEL/keywords if present.

**Section 1 (country background and policy context):** economic growth, inflation, employment, poverty and
inequality with the latest official figures (statistics office, central bank, World Bank; mark provisional
values); redraw or update figures if the report has charts with data (update chart data or note what to redraw);
the tax and benefit system overview with every reform since the last report (laws, dates, rates), new
programmes, programmes ended; each policy table (e.g. PIT schedule, VAT rates, excise table) gets the new year
column and footnotes with the legal source.

**Section 2 (modelling of policies):** the time point and how within-year changes are handled (extension
switches), the order of simulation (spine), each policy's modelling description updated for new parameters,
new instruments, corrections (describe the current rule, not the correction), what is not simulated and why,
tables of parameters by year (add the new years), switches table (policies on/off/n/a by system).

**Section 3 (data):** datasets and which systems use them, survey descriptions (sample size, response rate,
reference period: from the statistics office's report), any changes to input-data preparation (describe the
current method), uprating (series and sources), the DRD reference.

**Section 4 and Annex (validation):** tables comparing simulated with external statistics for every year
(population, labour market, poverty/inequality, benefits recipients and amounts, tax and contribution revenues);
fill the new year columns from the validation code (06); ratios; notes (sources, definitions, provisional
figures); text that explains the main gaps and changes (quote numbers that match the tables exactly).

## Mechanics (tracked_edit.py)

```python
import sys; sys.path.insert(0, '<skill>/scripts'); import tracked_edit as T
d = T.open_doc(path, author='<author>')                # revision ids above every existing w:id
T.edit(d, 'unique anchor text in the paragraph', 'old text', 'new text', '2.4 PIT', 'Law 109/2025 Art. 7')
T.set_cell(d, 'text that identifies the table', 'VAT', '2026', '161,835', '155,641', 'Annex A3', 'T6 rerun',
           section_row='Simulated revenues (billion VND)')
T.new_paragraph_after(d, 'anchor', 'New paragraph text.', '1.3', 'source')
d.save(path); T.write_log(log_path, '2026-09-27: what this pass did')
```
- Text inside the same author's earlier insertions is edited in place (one clean insertion for the reviewer); original
  text is deleted and inserted as tracked; mixed spans are handled run by run.
- Tables: python-docx repeats merged cells in `row.cells`; find year columns from the header row (never fixed
  indices) and rows by label after the block label when labels repeat (official / simulated / ratios).
- New references: `new_paragraph_after` the entry that precedes it alphabetically.

## QA after every pass

`python3 $SKILL/scripts/report_qa.py "<previous FINAL>.docx" "<DRAFT>.docx" [--author <author>]`

- **Rule:** rejecting the update's revisions gives the agreed previous report, in every story part (body,
  footnotes, endnotes, headers, footers), with the same tables, rows, cells, figures (by image content), note
  references, sections and hyperlinks. Added or removed parts fail.
- **Baseline:** by default all revisions are rejected in both files (right when the previous FINAL still holds
  revisions that were carried over unchanged). With `--author`, only that author's revisions are rejected and
  the previous report's own revisions count as accepted; use it when those were agreed.
- **Paragraph marks:** a paragraph whose mark is tracked as inserted merges with the next paragraph on reject.
  A copied paragraph with an inserted mark but untracked text therefore duplicates text in the reject view:
  track the copied text as inserted too.
- No duplicate revision ids; style warnings reviewed.
- The check covers text and structure only. Formatting revisions and changed style parts are listed as
  warnings; the paragraphs changed by the update are listed so that their pages can be inspected. Render the
  draft (`--render out.pdf` if LibreOffice is installed) or ask the user to check those pages in Word.

A paragraph whose reject view is garbled (an earlier pass overwrote text or deleted its own insertion) can be
repaired with `python3 $SKILL/scripts/fix_reject_view.py "<previous>.docx" "<DRAFT>.docx"` (asserts that the
accepted text is unchanged; it skips paragraphs with fields, note references, hyperlinks or drawings, and does
not repair inserted-mark merges). If the previous FINAL holds its own revisions, compare with both baselines
before repairing.

## Numbers produced by code

If a paper or report is assembled by a script, numbers written into that script go stale like any other text.
Read numbers from the current result files, or search the script for the old values after every rerun.
