# 05 Country report update (Word, tracked changes)

Copy the previous FINAL to `CR <MODEL> v<new> DRAFT tracked.docx` and edit only the copy, only with tracked
changes (python-docx via `scripts/tracked_edit.py`). Author: "UNU-WIDER" unless agreed otherwise. Log every edit
in `_internal/<CC>/Update_<year>/work/CR_edit_log_<CC>.md` (section, old, new, reason/source).

## Content rules

- **The report stands on its own**: describe the current model and policies only. No "previous version",
  "was corrected", "we changed the method", "v3.5 had". Version, years and author line are updated plainly.
- UN English, the report's own reference style (copy the format of an existing entry of the same type), no
  semicolons or em dashes in new prose, minimal hyphens, "per cent", thousands separators as in the report.
- Every new fact has a citation that is in the reference list (add entries in alphabetical position).
- Use the `econ-writing` skill for prose passes if available.

## Section by section (all need online research)

**Front matter:** title (model version, years covered), author line and year, citation line, acknowledgements
(institution names change: check the partner institute's current official English name), abstract, version
and bundle name, JEL/keywords if present.

**Section 1 (country background and policy context):** economic growth, inflation, employment, poverty and
inequality with the latest official figures (statistics office, central bank, World Bank; mark provisional
values); redraw or update figures if the report has charts with data (update chart data or note what to redraw);
the tax and benefit system overview with every reform since the last report (laws, dates, rates), new
programmes, programmes ended; each policy table (e.g. PIT schedule, VAT rates, excise table) gets the new year
column and footnotes with the legal source.

**Section 2 (modelling of policies):** the time point and how within-year changes are handled (extension
switches), the order of simulation (spine), each policy's modelling description updated for new parameters,
new instruments, corrections (describe the current rule, not the correction), what is not simulated and why,
tables of parameters by year (add the new years), switches table (policies on/off/n/a by system).

**Section 3 (data):** datasets and which systems use them, survey descriptions (sample size, response rate,
reference period: from the statistics office's report), any changes to input-data preparation (describe the
current method), uprating (series and sources), the DRD reference.

**Section 4 and Annex (validation):** tables comparing simulated with external statistics for every year
(population, labour market, poverty/inequality, benefits recipients and amounts, tax and contribution revenues);
fill the new year columns from the validation code (06); ratios; notes (sources, definitions, provisional
figures); text that explains the main gaps and changes (quote numbers that match the tables exactly).

## Mechanics (tracked_edit.py)

```python
import sys; sys.path.insert(0, '<skill>/scripts'); import tracked_edit as T
d = T.open_doc(path)                                   # revision ids above every existing w:id
T.edit(d, 'unique anchor text in the paragraph', 'old text', 'new text', '2.4 PIT', 'Law 109/2025 Art. 7')
T.set_cell(d, 'text that identifies the table', 'VAT', '2026', '161,835', '155,641', 'Annex A3', 'T6 rerun',
           section_row='Simulated revenues (billion VND)')
T.new_paragraph_after(d, 'anchor', 'New paragraph text.', '1.3', 'source')
d.save(path); T.write_log(log_path, '2026-09-27: what this pass did')
```
- Text inside earlier UNU-WIDER insertions is edited in place (one clean insertion for the reviewer); original
  text is deleted and inserted as tracked; mixed spans are handled run by run.
- Tables: python-docx repeats merged cells in `row.cells`; find year columns from the header row (never fixed
  indices) and rows by label after the block label when labels repeat (official / simulated / ratios).
- New references: `new_paragraph_after` the entry that precedes it alphabetically.

## QA after every pass

`python3 $SKILL/scripts/report_qa.py "<previous FINAL>.docx" "<DRAFT>.docx"`:
- "IDENTICAL after reject" for document and footnotes (rejecting all changes gives the previous report);
- no duplicate revision ids;
- style warnings reviewed.
If a paragraph fails (reject view garbled or empty: an earlier pass overwrote text or deleted its own insertion),
repair it with `python3 $SKILL/scripts/fix_reject_view.py "<previous>.docx" "<DRAFT>.docx"` (asserts that the
accepted text is unchanged). If the previous FINAL itself still holds tracked changes, compare before repairing:
differences caused by its own revisions need no repair. Render once (LibreOffice
`soffice --headless --convert-to pdf`, if installed) or ask the user to open it in Word.
