# 04 Runs, output checks, base-year yds and post-fiscal poverty lines

## Before requesting runs

Finish every authorised model and data correction that the next batch depends on, so one batch does the work.
Check what can run where: EUROMOD is usually run by the user (GUI or command line); ask or inspect rather
than assume what the assistant can execute (EUROMOD, Stata, R).
Never edit a model folder (`XMLParam`, `VarConfig`, dataconfig, `EM3Translation`) while the user is running
EUROMOD from it: the runs fail. After edits, delete `EM3Translation/` (with EUROMOD closed) and ask the user
to close and reopen the project before the next batch.

## The run request

Write a compact table into the run-request file (e.g. `RUN_IN_EUROMOD.txt` next to the models, dated) and the
chat. One row per run:

| Model folder | System | Input dataset | Scenario / switches | Purpose |
|---|---|---|---|---|
| `SOUTHMOD_<release>_<CC>` | `<CC>_2026` | `<cc>_2024_a3` | FORoff (default) | new system |
| `SOUTHMOD_<release>_<CC>` | `<CC>_2026` | `<cc>_2024_a3` | FORon | formal-purchase variant |

- Separate rows for each setting of the same system, with explicit labels (POVoff/POVon, FORoff/FORon).
- Request only switches that the system exposes and that apply to it (check the dataconfig).
- Say where outputs and run logs should go and how they will be named.
  EUROMOD names outputs after the `DefOutput` `file` parameter and replaces `_std` with the switch state when
  an extension is set in the run dialog (`<CC>_2024_FORon`); see the southmod skill, `running_and_analysis.md` §2.
- Keep the request file current: when a batch is accepted, mark it done so an old request never reads as
  pending or still valid.

## Accepting finished runs (provenance)

A run is accepted only when its provenance is established:
- the run log exists and reports success, the system, the input dataset and every extension switch;
- the model files and the input used are the intended ones: compare hashes of the XML and input with the
  versions prepared for the batch (timestamps alone are not evidence);
- the output is complete (expected rows, columns, no partial write) and not a stale file from an earlier batch;
- an output without an explicit switch suffix proves nothing about its settings: resolve the scenario from the
  log. Never substitute a same-named output from another snapshot.
Record per run: log path, input hash, model hash, scenario, output hash.
The EUROMOD 3.8 `*_SOUTHMOD_Log.txt` lists each run's extension states (1/0/-1), output file and MD5
(`Output-Hash`): match every output against it.

## After every accepted batch

1. **Aggregates:** `python3 $SKILL/scripts/diff_outputs.py OLD NEW --vars <instrument vars>` per rerun system.
   Explain every movement (the edited instrument and second-round effects: contributions on net bases,
   means-tested benefits, consumption adjustment, post-fiscal income). An expected change that does not appear
   means the edit did not run (matrix cells, switches, extension bindings).
2. **Base-year consistency** for every base-year system (system year = dataset year):
   `python3 $SKILL/scripts/replace_yds.py --check <input> <base-year output>`. Exit 0 pass, 1 differences
   beyond tolerance, 2 invalid (IDs, populations, values). The default tolerance is the export precision of
   `ils_dispyki`; pass `--tol` in dataset units if the model or data warrant another. The `xhh`/`ils_con`
   difference is information only unless you have read the model's `ils_con` definition and pass
   `--con-check --tol-con`. Refresh (`--replace`, with `--also` for every copy of the input) only when the
   check fails, then rerun that system and check again. Indirect-tax-only changes leave yds unchanged.
   Precision matters both ways: the output must carry enough decimals (`DefOutput` `nDecimals`), and any
   export of the refreshed `yds` must keep them (a Stata `%20.10g` export lost 4-decimal precision;
   `%21.14g` kept it). Fixed points and poverty rates from a 2-decimal output can differ from Stata.
3. **Post-fiscal poverty lines:** `python3 $SKILL/scripts/pf_povlines.py <output> --ses-agg sum|household
   [--group <var>] [--ratio r] --compare <stored constants>`. Read the model and report first and pass the
   conventions explicitly (how `ses` is stored, grouping, weighting, which output feeds which line, whether the
   model uprates the constant). The script fails on empty bands, inconsistent line or group assignments,
   invalid scales and incomplete comparisons, and reports FIXED POINT or MOVED at the stored precision (exit 1
   if any line moved). A moved line goes into the model (edit CSV) and needs another run. Constants that the
   model uprates by a CPI factor are divided by that factor before being written back.
4. **Further runs** only where needed (a moved line, a refreshed yds). Do not promise convergence in a fixed
   number of rounds: stop when every base-year check passes and every line is a fixed point.
5. **Validation tables:** rerun the T6 code (06) and diff against the previous T6 output. Every changed cell goes
   into the report (tracked), and so does any sentence that quotes it.
6. **Archive**: keep hashes and compressed copies of the accepted outputs and logs with the commit that produced
   them; clear public `Output/` and `Temp/` folders only after that (09).

## Decisions the user makes, you advise

When a result depends on a judgement, state the evidence, recommend, and implement the recommendation unless
the user decides otherwise. Decisions already given stay in force; ask again only if new evidence contradicts
them or a new choice falls outside them. If an answer could mean two things, ask a one-line question before
anything is rerun.
