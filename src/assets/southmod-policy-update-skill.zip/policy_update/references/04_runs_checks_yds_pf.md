# 04 Runs, output checks, base-year yds and post-fiscal poverty lines

## Asking the user to run EUROMOD

Batch changes so each round of runs is useful. Write the request into `_internal/RUN_IN_EUROMOD.md` (a dated
section) and the chat:
- which project folder, which systems, which datasets, default extension settings or which switches (e.g.
  "POV off and on"), output renaming if batch mode names files differently (e.g. `_POVoff` -> `_std`);
- where to put the outputs (e.g. gzip copies in `_internal/reference_bundle/Output/` for git).
Ask for the run log too (the `*_SOUTHMOD_Log.txt` in the output folder): check status, extension flags, warnings.

## After every run

1. **Aggregates:** `python3 $SKILL/scripts/diff_outputs.py OLD NEW --vars <instrument vars>` for each rerun
   system. Explain every movement: the edited instrument and the second-round effects (contributions on
   net bases, means-tested benefits, consumption adjustment `xhh_s`, post-fiscal income). An expected change that
   does not appear means the edit did not run (check matrix cells, switches, extension bindings).
2. **Base-year consistency (Essential):** for every base-year system (system year = dataset year):
   `python3 $SKILL/scripts/replace_yds.py --check <input dataset> <base-year output>`. Pass: max
   |yds - ils_dispyki| < 1 and max |xhh - ils_con| < 1. If it fails (a model or data change moved disposable
   income in a base year): `--replace` (input .txt.gz and every copy with `--also`), rerun that system, check
   again. Indirect taxes do not enter `ils_dispy`, so VAT/excise-only changes leave yds unchanged (check anyway).
3. **Post-fiscal poverty lines:** the line minus the unweighted mean equivalised **net** indirect tax
   `(ils_taxco - ils_benco)/ses` of households with equivalised `ils_con` within ±2.5% of the line, per system,
   nominal. `python3 $SKILL/scripts/pf_povlines.py <output> [--group <region var>] [--ratio r] --compare <model
   constants>`. Some models need the POV-on output for upper lines. Recompute after any change to indirect taxes,
   indirect benefits (fuel subsidies) or base-year data. If a line moves, write it into the model (edit CSV) and
   rerun: a system is final when a rerun leaves every line unchanged (**fixed point**). Constants that the model
   uprates by a CPI factor must be divided by that factor before being written back (better: make the model use
   the per-system nominal constant without uprating, and record the change).
4. **Validation tables:** rerun the T6 code (06) and diff against the previous T6 output. Every changed cell
   goes into the report (tracked) and any sentence that quotes it.
5. **Save outputs** (gzip) with the commit that produced them; keep the output that matches the final model.

## The loop

model/data change -> run -> aggregates explained -> yds check (base years) -> pf lines -> (if moved) edit + run ->
fixed point -> T6 -> report numbers. Plan runs so this converges in two rounds.

## Decisions the user makes, you advise

When a result depends on a judgement (e.g. from which year a new rate applies with no documented start), state the
evidence (e.g. budget allocation vs simulated cost), recommend, and implement the recommendation unless the user
decides otherwise. If the user's answer is ambiguous, ask a one-line question before rerunning.
