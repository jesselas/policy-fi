# Architecture and conventions — universal EUROMOD/SOUTHMOD knowledge

This file carries the parts of SOUTHMOD/EUROMOD that are **genuinely identical across all 14 country models** (and DEVMOD): the software architecture, the function set, the naming taxonomy, the modelling conventions, and the configuration-file schema. None of it is country-specific. For anything that *varies* per country — parameter values, which programmes exist, which extensions ship, dataset vintages, year ranges — do **not** rely on this file: read the live model, following `exploration_playbook.md`.

Verified against the full 14-country `SOUTHMOD_A4.0` bundle at build time. Where a claim is *near*-universal with known exceptions, the exception is named so you do not assert it blindly.

---

## 1. What SOUTHMOD is

SOUTHMOD is the UNU-WIDER / SASPRI / LSE-III family of tax-benefit microsimulation models for Global South countries. Every model runs inside the **EUROMOD** software platform — the same free engine (developed by the JRC) that hosts the EU-country tax-benefit models. A model takes a household micro-dataset, applies a country's tax and benefit rules for a given policy year, and outputs household- and individual-level incomes you can analyse for poverty, inequality, and the distributional effect of reforms.

The 14 production models and their codes:

| Model | Country | `cc` / `CC` |
|---|---|---|
| BOLMOD | Bolivia | `bo` / `BO` |
| COLMOD | Colombia | `co` / `CO` |
| ECUAMOD | Ecuador | `ec` / `EC` |
| EGYMOD | Egypt | `eg` / `EG` |
| ETMOD | Ethiopia | `et` / `ET` |
| GHAMOD | Ghana | `gh` / `GH` |
| MOZMOD | Mozambique | `mz` / `MZ` |
| PERUMOD | Peru | `pe` / `PE` |
| RWAMOD | Rwanda | `rw` / `RW` |
| TAZMOD | Mainland Tanzania | `tz` / `TZ` |
| UGAMOD | Uganda | `ug` / `UG` |
| VNMOD | Viet Nam | `vn` / `VN` |
| MicroZAMOD | Zambia | `zm` / `ZM` |
| ZANMOD | Zanzibar | `zn` / `ZN` |

DEVMOD is the SOUTHMOD training model used in the online course. The official distribution is **one multi-country project** (`SOUTHMOD_A4.0`) containing all models under a shared `XMLParam/` tree; any model runs without being opened first.

---

## 2. The hierarchy: System → Policy → Function → Parameter

A model is built from four nested element types, all stored in the country XML (`XMLParam/Countries/<CC>/<CC>.xml`):

- **`<System>`** — one *policy system* per policy year (e.g. `GH_2013` … `GH_2025`, `RW_2017` … `RW_2025`). The set of years is country-specific — discover it; do not assume a range. A system binds to an input dataset (in `<CC>_dataconfig.xml`) and owns its own complete copy of the policy spine.
- **`<Policy>`** — a tax, benefit, contribution, or definitional block (e.g. `tin_<cc>` income tax, `tva_<cc>` VAT, `uprate_<cc>` uprating). Each policy carries `<Type>` (`def`/`tax`/`ben`/`sic`), an `<Order>` (spine position), a `<Switch>` (the cell state for that system), and usually a `<Comment>`.
- **`<Function>`** — a calculation step inside a policy. The function *type* (its `<Name>`, e.g. `ArithOp`, `BenCalc`, `DefIl`) is one of the EUROMOD function set in §3. Each function has its own `<Order>` and `<Switch>`.
- **`<Parameter>`** — a named slot inside a function: `<Name>`, `<Value>` (often `<![CDATA[…]]>`), `<Comment>`, `<Order>`, `<ValueType>`.

The country XML is **one giant flat document**: every system contains a full clone of every policy, so element counts run to hundreds of thousands of lines and a name like `<Name>uprate_gh</Name>` appears once per system. Never cite a single line number as "the" location; locate the occurrence inside the system block you mean (match `<SystemID>` → `<System><Name>`).

### The matrix mental model

The single most important idea: **the model is a matrix, not a flat program.** In the EUROMOD GUI you see exactly this:

- **Rows** = the policy → function → parameter spine.
- **Columns** = the systems (`<CC>_<year>`).
- **Cells** = for policy/function rows, a `<Switch>` state (`on` / `off` / `n/a`); for parameter rows, a `<Value>`.

So "what does X do in `<CC>_2024`?" is a question about the **cell** in row X, column `<CC>_2024` — not the row in isolation. The same row can be `on` in one system, `n/a` in another, and hold a different value in a third. A policy whose XML you can read may be `<Switch>n/a</Switch>` in the system the user cares about — meaning it does not execute, and the behaviour comes from elsewhere (often a `DefIl` that folds reported survey data straight into an income list). Always read the cell. (Mechanics and grep recipes: `exploration_playbook.md`.)

---

## 3. The EUROMOD function set

A small set of function types does everything. The exact set used in any one model is discoverable by grepping `<Name>…</Name>` inside `<Function>` blocks; the union below is universal across the bundle (verified: every country uses the core ten; `Allocate` and `SetDefault` appear in some; `DefIL`/`DefTU` are case variants of `DefIl`/`DefTu`, and the parser is case-tolerant).

| Function | Category | One-line purpose |
|---|---|---|
| `ArithOp` | policy / calculation | Arithmetic or Boolean assignment to an output variable. The workhorse — `ils_*` definitions, tax/benefit branches, accumulators. |
| `BenCalc` | policy / calculation | Generic benefit calculator: combines eligibility-style conditions with arithmetic via grouped `Comp_Cond` / `Comp_perTU` / `Comp_perElig` parameters. Used for benefits and for structural non-schedule tax simulation. |
| `SchedCalc` | policy / calculation | Tax-schedule calculator — band-by-band rate application (e.g. progressive income tax). |
| `Elig` | policy / calculation | Eligibility test producing a 0/1 result consumed by a later `BenCalc`. |
| `DefIl` (`DefIL`) | system / definition | Define income list: add one component variable to a named `ils_*`/`il_*` list with a signed `+`/`−` (or scaler). The atomic building block of every income list. |
| `DefConst` | system / definition | Define a `$`-prefixed constant (band thresholds, poverty-line values, rates). Usually grouped in a `constdef_<cc>` policy — but not always (see §5). |
| `DefVar` | system / definition | Declare/initialise a model-internal variable (intermediate `i_*` scratch, running totals). |
| `DefTu` (`DefTU`) | system / definition | Define a tax unit — the grouping over which monetary outputs aggregate. |
| `Uprate` | system / definition | Apply an `<UpratingIndex>` (e.g. a `$f_CPI_*` factor) to monetary input variables. Runs first, in `uprate_<cc>`. |
| `DefOutput` | system / definition | Emit a per-system output `.txt` file. One per `output_std_<cc>` clone. |

Other types exist in the EUROMOD engine (`Allocate`, `SetDefault`, `UpdateTU`, `Min`, `Max`, `Loop`, `Store`/`Restore`, `ChangeParam`, `IlArithOp`, AddOn functions, etc.) and a given model may use a few of them — grep before claiming a model does or does not use one.

**Operators and idioms** (in `<Value>` text): arithmetic `+ - * /`, comparison and Boolean conditions, period suffixes on monetary amounts (`#m` monthly, `#y` yearly, etc.), `$name` for constants, `$f_*` for uprating factors. Function-interaction modes within a policy: *Condition* (one function tests, the next acts on the result), *Input* (one feeds another), *Addition* (each adds a component), *Replacement* (a later function overrides — rare).

---

## 4. Variable naming taxonomy

SOUTHMOD variable names are systematic. Decompose, don't guess — then confirm against the `<Comment>` and `VarConfig.xml`.

**Class-1 prefix** (first character; `id` is a two-character exception):

| Prefix | Type | Notes |
|---|---|---|
| `a*` | Asset | Often unused in a given model. |
| `b*` | Benefit | Input passthrough + simulated `_s` counterparts. |
| `d*` | Demographic | Includes the survey weight `dwt`. |
| `id` | Identifier | `idhh`, `idperson`, `idpartner`, `idmother`, `idfather`; `idorig*` for survey re-merge. |
| `i_*` | Intermediate / scratch | Convention: omit from output (some models keep a few for debugging). |
| `k*` | In-kind income | Folded into `ils_benki`. |
| `l*` | Labour-market | `les`, `loc`, `lcs`, … |
| `p*` | Pension **and** COICOP price | Same letter, two meanings — context disambiguates. |
| `q*` | Quantity (COICOP excise inputs) | **Not** uprated. |
| `s*` | System | `ses`, `ses00/01/02`, `spl`, `splpf`. `ses` is non-monetary. |
| `t*` | Tax / social contribution | `tin`, `tva`, `tex*`, `tsc*`. |
| `x*` | Expenditure | 7-digit COICOP, plus 9-character `x00…` formal-outlet variants. |
| `y*` | Market income | `yem`, `yse`, `yag`, … all gross, monthly. |

**Class-2 refiner** (next one–two characters, context-dependent): `ag` age/agriculture, `ch` child, `co` indirect-tax/benefit consumption variant, `di` disability, `em` employment, `fo` formality, `gn` gender, `hh` household, `ms` marital status, `of` oil/fuel, `sa` social assistance, `sc` social contribution, `se` self-employment, `su` survivor, `un` unemployment, `wt` weight, etc.

**Suffixes and special forms:**

| Form | Meaning |
|---|---|
| `_s` | Simulated — the output of a model function (as opposed to a reported input). |
| `_yn` | Take-up / receipt flag (0/1). |
| `_pf` | Post-fiscal: base income + indirect-tax-side benefits − indirect taxes. |
| `01`, `02`, … | Sub-category or country-specific variant. |
| `_<cc>` | Country suffix on **policy** names (lowercase ISO Alpha-2): `tin_rw`, `tva_gh`, `output_std_et`. |
| `$<name>` | A constant defined by `DefConst`. |
| `$f_*` | An uprating-factor name. |
| `il_*` | Country-specific income list. |
| `ils_*` | Standard income list (used by the Statistics Presenter and the review pipeline). |
| `tu_*` | Tax unit. |

> **On `=cc=` / `=sys=`.** Some EUROMOD documentation describes runtime placeholders `=cc=` (country acronym) and `=sys=` (system name). **These do not appear as literal strings in the shipped SOUTHMOD XML** (verified: zero occurrences). Treat them as a documentation/Help-file convention for *describing* names, not as tokens you will find or should write in a model file.

---

## 5. The policy spine

Every model's spine opens and closes the same way, then carries country-specific tax/benefit/contribution policies in between. The GUI shows policies sorted by `<Order>` ascending (the `<Order>` integer itself is arbitrary per country — sort by it, don't assume `uprate` is literally `Order 1`).

**Universal prefix** (present in every model — verified across all 14):
`uprate_<cc>` (sorts first) → `neg_<cc>` → `ilsdef_<cc>` → `ildef_stats_<cc>` → `ildef_exp_<cc>` → `tudef_<cc>` → `constdef_<cc>` → `spl_<cc>` → `ses_<cc>` …

**Universal close** (verified across all 14):
… → `xhhadj_<cc>` → `output_std_<cc>` → `output_std_hh_<cc>` (the household-level output is usually `off`).

> **Casing varies — grep case-insensitively.** Policy names are mostly lowercase but some models capitalise (e.g. GHAMOD's constants policy is `ConstDef_gh`, not `constdef_gh`). A case-sensitive grep will falsely report a universal policy as "missing". Always `grep -i` when checking for a spine policy, and preserve the as-found casing in citations.

**Near-universal definitional policies — confirm by reading:**
- `ildef_<cc>` (model-specific income lists) — present in every model **except UGAMOD** (which keeps only `ildef_stats_ug`/`ildef_exp_ug`). The companions `ildef_stats_<cc>` and `ildef_exp_<cc>` *are* universal (all 14).
- `lma_<cc>` — the COVID-19 "transitions and shocks" definitional policy (moves a share of workers into unemployment and adjusts consumption for 2020/2021 systems). **Only about half the models ship it** (verified present in ET, GH, MZ, RW, TZ, VN, ZM; absent in BO, CO, EC, EG, PE, UG, ZN). It is the documented exception to the "no macro effects" rule; don't assume it exists.

Note also that `DefConst` constants are not always grouped in the `constdef_<cc>` policy — a model may define some constants inside other policies. When chasing a specific `$`-constant, grep the constant name directly rather than only scanning `constdef_<cc>`.

**Middle** (country-specific, in roughly this band): social insurance contributions and direct taxes (`tsc*_<cc>`, `tin_<cc>`, …) → benefits (`bsa_<cc>`, `bch_<cc>`, …) → indirect side (fuel subsidy `bof_<cc>` → VAT `tva_<cc>` → excises `tex*_<cc>`).

Policy `<Comment>`s begin with a **type tag**: `DEF:`, `TAX:`, `BEN:`, or `SIC:`. Reading these tags down the spine is the fastest way to map a model.

---

## 6. Modelling conventions

The SOUTHMOD Modelling Conventions label rules **Essential** (must hold) or **Desirable** (recommended). Pass the label through when you cite a rule.

**Core vocabulary (Essential):**
- **Policy year / policy system** — the tax/benefit rules *as of 30 June or 1 July* of that year, not a calendar-year average. One `<System>` per policy year.
- **Income/expenditure reference period** — the period the survey income/expenditure data refer to.
- **Data collection period** — when the survey was fielded (may differ from the reference period).
- **Base-year simulation** — policy year matches the data's income reference year; simulated aggregates should match official statistics closely (without distorting calibrations).
- **Target-year simulation** — policy year ≠ data year (data uprated forward); aggregate match with official statistics is *not* expected.
- **Baseline simulation** — the "best" pairing of recent rules with recent suitable data, used as the comparison point for reforms.

These distinctions resolve many "why don't my numbers match the tax authority?" puzzles — usually because it was a target-year run.

**Identifiers:** `idhh` (household), `idperson` (typically `idhh × 100 + person index`), plus partner/parent links and `idorig*` for re-merging to the source survey.

**Uprating:** monetary input variables are scaled to the policy year by `Uprate` functions in `uprate_<cc>`, each applying a named `<UpratingIndex>` (`$f_*`). Quantity (`q*`) variables are **not** uprated. Consortium-shared CPI series live in `HICPConfig.xml` and are snapshotted into per-model `<UpratingIndex>` blocks.

**Income lists.** Two families:
- `ils_*` — **standard** lists the engine, the Statistics Presenter, and the review pipeline expect. Most-used:

  | List | Concept |
  |---|---|
  | `ils_origy` | Original (market) income before tax/benefit intervention. |
  | `ils_earns` | Earnings only. |
  | `ils_ben` / `ils_benmt` / `ils_bennt` | Benefits: all / means-tested / non-means-tested. |
  | `ils_benki` | In-kind benefits. |
  | `ils_benco` | Indirect-tax-side benefits (subsidies). |
  | `ils_tax` | Direct taxes. |
  | `ils_taxco` | Indirect taxes (VAT + excise). |
  | `ils_sicee` / `ils_sicse` / `ils_sicer` | SICs: employee / self-employed / employer. |
  | `ils_dispy` | Disposable income = `ils_origy` + `ils_ben` − `ils_tax` − employee/self-employed SICs. |
  | `ils_dispyx` | Disposable income incl. home-produced. |
  | `ils_dispy_pf` / `ils_dispyx_pf` | Post-fiscal: base + `ils_benco` − `ils_taxco`. |
  | `ils_con` / `ils_con_pf` | Consumption / post-fiscal consumption. |

- `il_*` — **country-specific** lists a model defines for its own needs (e.g. a country's VAT-base list). Names vary; the convention the User Manual gives for a VAT base is `ils_exp_vat` (`01`/`02` for two tiers), but individual models deviate — read the model.

Income-list entries are built by `DefIl` rows that mark a component `+` (include), `−` (subtract), or `n/a` (excluded in this system). VAT-base lists conventionally use only `+` / `n/a` (standard-rated vs exempt/zero-rated), never `−`.

**Tax units.** Defined by `DefTu` in `tudef_<cc>`. Two are universal: `tu_individual_<cc>` and `tu_household_<cc>`. Some models add `tu_family_<cc>`, `tu_partners_<cc>`, or `tu_couple_<cc>`. Monetary variables in a formula are **summed over the tax unit**; non-monetary variables are per-individual in conditions but taken from the unit *head* elsewhere (head = richest member; ties broken by oldest, then lowest `idperson`). This rule is the usual cause of "my benefit is N× too large" bugs.

**Equivalence scales.** The output dataset carries an `ses` column (the equivalence scale the run used) plus alternatives `ses01` (per-capita) and `ses02` (square-root). By **default** `ses` is the model's national scale from `ses_<cc>`. *Caveat (this is the default convention, not a hard rule):* most models ship an **optional override** inside `ses_<cc>` (off by default) that overwrites `ses` with `ses01`/`ses02` at the model level — if that was on, the `ses` column is no longer the national scale. And analysts are free to equivalise by any scale post hoc in their own code; `ses01`/`ses02` are stored precisely for that. So the honest rule is "use the `ses` column from output, weighted by `dwt`" — explain why that is usually the national scale and when it isn't, rather than asserting `ses01`/`ses02` can never drive poverty/Gini.

**Reported vs simulated convention.** The modern SOUTHMOD convention is that a benefit whose eligibility you cannot properly simulate flows **survey → input data → income list directly** (via a `DefIl`), *without* a pseudo-simulating `BenCalc`. Older systems often still run the `BenCalc` pattern (read a take-up flag and reported amount, copy to a `_s` variable, fold `_s` into the list). The same matrix row can therefore flip semantics across system columns — the reported variable carries the substance in recent systems, the `_s` variant in older ones. Always check which column the user means.

**Extensions** are standardised on/off toggles declared in `<CC>_dataconfig.xml` (`<Extension>` with a `<ShortName>`), bound to policies/functions in the country XML, and defaulted per (system, dataset). **Which extensions a model ships varies a lot** — verified across the bundle: `POV` is common but **not universal** (e.g. GHAMOD ships only `FYA`; UGAMOD ships `DWT`/`FOR`), and you will also see `BRO`, `TCA`, `FYA`, `FOR`, `MOD`, `TOT`, `PSCH`, `UPS`, and others. The standardised consortium set referenced in documentation is `BRO`/`TCA`/`FYA`/`POV`/`INF`, but never assume a model's shipped set — read its dataconfig. Extensions are for *persistent, shipped* toggles; one-off study reforms use a system clone instead (see `running_and_analysis.md`).

---

## 7. Configuration XMLs (schema only)

These live under `XMLParam/Config/` (shared across the bundle) and `XMLParam/Countries/<CC>/` (per model). Schema is universal; counts/values are not — read them.

| File | Location | What it holds |
|---|---|---|
| `VarConfig.xml` | `XMLParam/Config/` | The variable dictionary — one `<Variable>` per name, with a `<Comment>` description. The GUI's Variable Manager. Bundle-wide. |
| `HICPConfig.xml` | `XMLParam/Config/` | Consortium-shared CPI/HICP uprating series by country and year. |
| `ExchangeRatesConfig.xml` | `XMLParam/Config/` | PPP / exchange-rate conversion factors. |
| `PROJECTSETTINGS.xml` | `XMLParam/Config/` | Project-level settings. |
| `SwitchablePolicyConfig.xml` | `XMLParam/Config/` | Bundle-level switchable-policy registry. |
| `EuromodVersion.txt` | `XMLParam/Config/` | Platform/version stamp. |
| `<CC>.xml` | `XMLParam/Countries/<CC>/` | The model: systems, policies, functions, parameters, uprating indices. |
| `<CC>_dataconfig.xml` | `XMLParam/Countries/<CC>/` | Binds datasets (`<DataBase>`) to systems (`<DBSystemConfig>` / `<SystemName>`), and declares `<Extension>`s. The fastest place to list a model's systems and extensions. |

**Legacy vs EM3.** The bundle ships each model twice: the editable legacy monolithic XML under `XMLParam/`, and a relational mirror under `EM3Translation/XMLParam/`. **EM3 is read-only** — the GUI regenerates it from legacy on save (gated by `up2Date_*` MD5 sentinels). All edits go through the legacy XML. EM3 drops some legacy-only fields (`<ValueType>`, `<Group>`, `<Color>`, `<ConditionalFormat>`, policy `<Type>`, `<PrivateComment>`). When asked "where does X live", answer for legacy; mention EM3 only if relevant.
