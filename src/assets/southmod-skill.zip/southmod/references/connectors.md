# Running SOUTHMOD models from code: the Python and Stata connectors

The EUROMOD engine can be driven from Python (`euromod` package) or Stata (EUROMOD connector) instead of the
GUI. Both work with SOUTHMOD bundles: point them at the bundle folder that contains `XMLParam/`. Use them for
batch runs, sensitivity grids, debugging and fixed-point loops. Results that will be reported still need the
provenance described in §5.

What carries over from the GUI: the same model files, systems, datasets, extension defaults and engine. What
differs: nothing is written to disk unless you ask for it, there is no run log by default, and some options exist
only here (overriding constants, custom output, breakpoints).

---

## 1. Requirements and platform

- **EUROMOD installed** on the same machine. The `euromod` Python package needs a minimum engine version
  (0.4.x needs EUROMOD 3.8.8 or later). It looks for the engine in the environment variable `EUROMOD_PATH`, then
  in the default installation folder (`C:\Program Files\EUROMOD\EUROMOD` for recent versions). **If the engine
  it finds is older or unreadable, it silently falls back to an engine bundled with the package and only warns.**
  Check after import: `euromod.software_version`, `euromod.required_software_version`,
  `euromod.using_bundled_fallback` (must be `False` if the run should match GUI results).
- **Platforms.** The Python package is published for Windows and Linux x86_64 (with .NET); there is no macOS
  build. On a Mac, run it (and the GUI) in a Windows virtual machine. The Stata connector is a Windows plugin
  (`StataPlugin.plugin` in the EUROMOD installation); for a non-standard installation set
  `global EUROMOD_PATH "<install>\Executable/"` in Stata before any connector command. Note that `EUROMOD_PATH`
  is an environment variable for Python but a Stata global for Stata.
- **Loading a model writes to the model folder.** Both connectors translate the legacy XML into
  `EM3Translation/` when they load a country. Do not load a model from code while the GUI has it open, and do
  not edit `XMLParam/` while a connector session holds it (`architecture_and_conventions.md` §7).

## 2. Python (`euromod` package)

```python
from euromod import Model
import euromod
print(euromod.__version__, euromod.software_version, euromod.using_bundled_fallback)

mod = Model(r"<bundle>")                      # folder containing XMLParam/
cty = mod["RW"]                               # country by code
sys_ = cty["RW_2024"]                         # system by name
print([d.name for d in sys_.datasets], sys_.bestmatch_datasets)
data = cty.load_data("rw_2024_a1")            # reads Input/rw_2024_a1.txt (name must match the file exactly)
sim = sys_.run(data, "rw_2024_a1")
out = sim.outputs["rw_2024_std"]              # pandas DataFrame
```

- **`sim.outputs` is keyed by output file name** (list them with `sim.output_filenames`). A system can have several `DefOutput`s (an individual and a
  household file, a top-incomes file): select by name, never by position. Names follow the `DefOutput` `File`
  parameter (case as written there).
- All columns come back as numbers (float64); string columns are dropped silently.
- **A failed run raises an exception.** `sim.errors` (or the printed messages) holds only the **warnings** of a
  successful run: read them, they include "not initialised" and "unused footnote" warnings.
- `run()` changes the working directory to the engine folder during the run and back to the directory current
  at import.

**Run options** (keyword arguments of `run`):

| Option | Use |
|---|---|
| `constantsToOverwrite={("$name", "<group>"): "value"}` | Override a constant or uprating factor for this run. Values are strings; `""` as group means ungrouped. Uprating factors are keyed by year: `("$f_CPI_Overall", "2025")`. |
| `switches=[("FOR", True)]` | Set an extension on or off, deviating from the (system, dataset) default. |
| `requested_vars=[...]`, `requested_incomelists=[...]`, `suppress_other_output=True` | Return a small custom output (`custom_output`) and optionally skip the model's own `DefOutput`s: fast loops. |
| `breakfun_id="<function GUID>"` | Stop after that function and return every variable at that point (debugging). |
| `nowarnings=True` | Suppress warning messages (avoid when checking a model). |
| `outputpath="<folder>"` | Also write the output files to disk (useful for provenance and for comparing with GUI runs). |

Discovering what can be overridden or switched (0.4.x):
- `euromod.introspect.system_constant_params(sys_)`: every `$`-parameter that `constantsToOverwrite` accepts,
  with its groups;
- `sys_.get_default_extensions("rw_2024_a1")`: extension defaults for a dataset;
  `cty.get_switch_value(ext_name=..., dataset_name=..., sys_name=...)`: the configured switches (omits `n/a`,
  raises `KeyError` for unknown names);
- `euromod.introspect.income_list_components(sys_, "ils_dispy", dataset=..., extensions=[("FOR", True)])`: the
  effective members of an income list after extensions and redefinitions, a useful cross-check of a grep-based
  trace (`exploration_playbook.md` Step 6);
- `cty.upratefactors`: uprating indices with their values by year.

**Navigating the model in Python.** Systems and datasets are keyed by name, but **policies, functions and
parameters are keyed by GUID**: `sys_.policies["tin_rw"]` raises `KeyError`. Use
`sys_.policies.find("name", "^tin_rw$")`. The pattern is a regular expression and is not anchored (hence `^...$`);
matching is always case-insensitive. The package's own row ordering takes policy order from one system and
function order from another, so it can disagree with the GUI when orders differ across systems: for "row N.M"
always use `spine.py`.

**In-memory changes are temporary.** Setting `PolicyInSystem.switch = "off"` or a parameter value on the
Python objects affects later runs of that `Model` object only. After editing the legacy XML, create a new
`Model(...)`: an existing object keeps the model it read.

## 3. Stata (EUROMOD connector)

```stata
euromod run, model("<bundle>") system(RW_2024) country(RW) dataset(rw_2024_a1) ///
    repository("<bundle>/Input") replace
```

- `country()` is the model's two-letter code (`RW`, `GH`, ...). Use `dataset()` or `bestmatch`.
- `repository()` reads `<dataset>.txt` from that folder (and overwrites data in memory); without it, the data in
  memory are the input. `if` passes a subset: never split households.
- `extensions(FOR=on, POV=off)`; `constants("name(group) = 'value' ...")` **without** the `$` (the group or year is
  required for uprating factors); `prefix(sim1_)` to keep several scenarios side by side and merge on
  `idperson`; `outputdataset()` to pick one of several outputs; `outputpath()` to also write the output to disk.
- Custom output: `il_output("ils_dispy, ils_tax")`, `vars_output("bsa_s, yem")`,
  `extrainfo_output("'tu_household_rw':'IsDependentChild,HeadID'")`, `suppress_output`.
- Debugging: `breakfun_id(<GUID>)`, `sequentialoutput` (run the spine sequentially).
- After a run: `$EM_outputs`, `$EM_vars` (true names; Stata truncates variable names to 32 characters),
  `r(errorMessages)`. Wrap runs in `capture noisily` and test `_rc`; `$n_euromod_errors` is not set reliably.
- `euromod getinfo, model() country()` returns aligned lists `$EM_all_systems`, `$EM_all_datasets`,
  `$EM_isBestMatch` (and best-match lists): loop over them to run every system on its datasets.
- **The connector caches the model.** After editing the XML (or saving in the GUI), run
  `euromod_reload, model("<bundle>")`. `euromod setinfo` changes a parameter in memory only.
- **The engine does not check extension names.** An unknown short name in `extensions()` is ignored with only a
  console message, and the run "succeeds" without the scenario you asked for. Check names against the
  dataconfig. (The Python package rejects unknown names.)

## 4. SOUTHMOD specifics

- **Extensions are local to each model** (POV, FOR, FYA, BRO, ... declared in `<CC>_dataconfig.xml`). There are
  no bundle-level extensions in SOUTHMOD. An extension's short name can coincide with one used elsewhere with a
  different meaning: read the model's `<Extension><Name>`.
- **Currency conversion.** The connectors' `euro` option converts with `ExchangeRatesConfig.xml`, which in
  SOUTHMOD holds current-year GDP PPP conversion factors. The result is in current GDP-PPP international dollars,
  not euros and not the 2021 PPP used for World Bank poverty lines. Do not use it for international poverty
  lines (`running_and_analysis.md` §4).
- **Add-ons and EU tools** (marginal tax rate and similar add-ons, Policy Effects, Macro validation, the
  hypothetical household tool) are not set up for SOUTHMOD models. Do not offer them.
- Dataset IDs must match the file name exactly, including case, on Linux.

## 5. Script-only reforms and provenance

A connector run can change constants, switches or policy switches **without editing the model**
("script-only reform"). That is fast for sensitivity grids and fixed points, and it leaves no trace in the
model, the GUI or a log. Rules:
- Record for every run that feeds a reported number: package or connector version, `software_version`,
  `using_bundled_fallback`, the bundle path, hashes of `<CC>.xml`, `<CC>_dataconfig.xml` and the input file, the
  system, dataset, switches and overridden constants, and a hash of each output saved.
- A result that will be published or shared needs a persistent form: a system clone with the changed values
  (`running_and_analysis.md` §5, pattern A), rerun from the GUI or with `outputpath()`.
- Output from memory and output written by `DefOutput` can differ in rounding: `nDecimals` applies to written
  files. Before comparing an in-memory result with a file output (or using it in a fixed-point loop that will be
  checked against files), compare one run both ways.
