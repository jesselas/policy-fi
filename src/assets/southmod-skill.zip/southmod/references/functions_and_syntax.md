# Functions and formula syntax: how the engine evaluates a model

This file explains what the EUROMOD engine does with a function's parameters: where results are stored, how
values are aggregated over assessment units, the defaults that apply when a parameter is absent, the formula
language, and the behaviour of each function type. It is engine knowledge, shared by every SOUTHMOD model. For
what a particular model contains, read the model (`exploration_playbook.md`). When a parameter's exact behaviour
matters and this file does not settle it, read the EUROMOD help that ships with the software
(`Help\EUROMODHelp.chm` in the installation folder; 7-Zip extracts it to HTML pages such as `EM_FC_BenCalc.htm`).
Do not improvise semantics.

Usage notes in brackets ("used in most models", "seen in GHAMOD") describe the 14-model bundle at the time of
writing. They show what you are likely to meet; always grep the model in front of you.

Contents: 1 assessment units and where results go · 2 common parameters and their defaults · 3 formulas and
conditions · 4 periods and monetary status · 5 footnotes · 6 queries · 7 identifiers · 8 the functions one by
one · 9 rarely used functions.

---

## 1. Assessment units and where results go

Every policy function has a `TAX_UNIT` parameter naming a tax unit defined in `tudef_<cc>` (`DefTu`). The unit
controls both how operands are read and where the result is written.

**How operands are read** (the assessment-unit rule):

| Operand | In a condition (`Elig_Cond`, `Comp_Cond`, ...) | Elsewhere (formulas, amounts, bases) |
|---|---|---|
| Monetary variable or income list | Sum over the unit | Sum over the unit |
| Non-monetary variable (age, flags, codes) | Each person's own value | The head's value |
| Query | As the query defines it (individual or unit level) | As the query defines it |
| `$`-constant | The head's value (constants must be equal for everyone) | The head's value |
| Simulated `sin*`/`stm*` scratch variables | Monetary: summed | Monetary: summed |

Example with a three-person household unit where `yem` is 2,000, 1,500 and 0: `yem` in a formula is 3,500 for
the unit; `dag>=18` in a condition is tested person by person; `dag` in a formula is the head's age.

Whether a variable is monetary comes from `VarConfig.xml` (`<Monetary>1</Monetary>`) or, for a model-defined
variable, from `DefVar`'s `Var_Monetary` (default **yes**, see §8). This rule is the usual cause of "the
benefit is N times too large": a household-level formula sums every member's income.

**Where the result goes:**
- The result is assigned to the **head** of the assessment unit.
- With `Output_Var`, every other member of the unit gets **0**, and so does everyone in a unit that is not
  eligible. The variable is overwritten for everyone.
- With `Output_Add_Var`, the result is added to the head's existing value; other members and non-eligible units
  keep what they had (a VOID value becomes 0).
- `Result_Var` (optional) receives a copy of the result and is always overwritten like `Output_Var`. Typical use:
  a component (`tsceehl_s`) kept separately while the total (`tscee_s`) accumulates with `Output_Add_Var`.
- Exceptions: `Elig` writes its 0/1 result **per person**; `Allocate` redistributes amounts within the unit.

Consequences:
- A benefit computed on a household unit sits on one row (the head's). Analyse it at household level, or sum
  over `idhh`, before reading it per person.
- A later function with `Output_Var` on the same variable wipes what earlier functions wrote (the "replacement"
  interaction). If two functions should both contribute, the later one needs `Output_Add_Var`.

**The head of a unit** is the member with the highest head-defining income, among members satisfying
`ExtHeadCond` (default: not a dependent child); ties go to the older person, then the lower `idperson`. The
income list is the unit's `HeadDefInc` if set, otherwise the system's `<HeadDefInc>` (in the `<System>` header;
SOUTHMOD models typically use a dedicated list such as `ils_head`; EUROMOD's own default is `ils_origy`).

**VOID and "use of not initialised variable".** Every simulated variable starts as VOID (internally a tiny
number, not 0). Reading a VOID variable anywhere except output triggers the "not initialised" warning. A
variable stays VOID when the function producing it is `off`, `n/a`, extension-controlled and switched off, or
skipped by a false `Run_Cond`, and when a simulated component of an income list is computed after the list is
used. Fixes: compute the variable in every system where a reader runs; or give it a default with `SetDefault`
(§8); or, for output only, let `DefOutput` replace VOID (`Replace_Void_By`, default 0, with a warning that
`Suppress_Void_Message` silences).

---

## 2. Common parameters and their defaults

Every policy function (`ArithOp`, `BenCalc`, `SchedCalc`, `Elig`, `Allocate`, `Min`, `Max`, ...) accepts these.
Definitional functions (`DefIl`, `DefTu`, `DefConst`, `Uprate`, ...) do not.

| Parameter | Meaning | Default |
|---|---|---|
| `TAX_UNIT` | Assessment unit (§1) | required |
| `Output_Var` / `Output_Add_Var` | Overwrite / accumulate (§1). Exactly one is required; they are mutually exclusive. `Elig` has no `Output_Add_Var`. | required |
| `Result_Var` | Extra copy of the result, always overwritten | none |
| `Who_Must_Be_Elig` | Which members must have the eligibility variable = 1 for the unit to be eligible: `one` (`one_member`), `one_adult`, `all` (`all_members`, `taxunit`), `all_adults`, `nobody` | **`nobody`** |
| `Elig_Var` | The eligibility variable that `Who_Must_Be_Elig` tests | `sel_s` |
| `LowLim`, `UpLim` | Floor and ceiling on the result | none |
| `Threshold` | A result below it becomes 0 (or `LowLim`, if set) | none |
| `LimPriority` | Which limit wins when `UpLim` < `LowLim` (`upper`/`lower`) | upper, with a warning |
| `Round_to`, `Round_Up`, `Round_Down` | Round the result to a step (1, 0.1, 10, ...) | none |
| `Run_Cond` | Run the function only if a global condition holds (§3) | always runs |
| `Switch` | The matrix cell: `on`, `off`, `n/a`, `toggle`, or `switch` (extension-controlled) | |

**`Who_Must_Be_Elig` defaults to `nobody`.** A function without it runs for every unit and ignores any `Elig`
result. An `Elig` therefore has an effect only if the function that should use it sets `Who_Must_Be_Elig` (and
`Elig_Var`, if the `Elig` wrote somewhere other than `sel_s`). Writing `n/a` for `Who_Must_Be_Elig` is the same
as `nobody`. "Adult" in `one_adult`/`all_adults` means "not a dependent child of that tax unit".
(`Who_Must_Be_Elig` is set in most models' ArithOp, BenCalc and SchedCalc functions.)

**Limits** apply to the function's final result. `999999999999.99` is the engine's "infinity". Limits on single
operands are footnotes (`#_LowLim`, `#_UpLim`, §5); BenCalc adds per-component limits (`Comp_LowLim`,
`Comp_UpLim`, used in every model). Rounding parameters are not used in SOUTHMOD models but can implement
statutory rounding in a reform; the order of rounding and limits is not documented precisely, so check a case by
hand.

**Switch states.**
- `on`: runs. `off`: does not run (its outputs stay VOID unless something else writes them).
- `n/a`: does not run, and tells the GUI the row does not apply to this system (used when copying and comparing
  systems). In a run it behaves like `off`.
- `toggle`: initially off, but its parameters are read and checked, so something else can switch it on. In SOUTHMOD
  models every `toggle` cell is bound to an extension with `BaseOff=false` (an older way of marking an
  extension-only row, seen in ECUAMOD, ETMOD and GHAMOD): treat it like `switch`, running only when that
  extension is on (`spine.py` shows the binding), and confirm in the output. A `toggle` cell with no extension
  binding runs only if a `ChangeParam`/`ChangeSwitch` switches it on.
- `switch`: controlled by an extension; the run's extension setting decides (architecture §6).

---

## 3. Formulas and conditions

Formulas (`Formula`, `Comp_perTU`, amounts) and conditions (`Elig_Cond`, `Comp_Cond`, `Condition`, `Run_Cond`)
share one expression language. A condition is a formula read as false when 0 and true otherwise.

**Operands:** numbers (with period suffixes, §4), variables, income lists, `$`-constants, queries (§6),
`amount#n` placeholders (§5), and `rand` (a uniform random number on [0,1], seeded by `RandSeed`, §8).

**Operators**, from highest to lowest precedence:
1. numbers and `%` (`yem*3%` is `yem*0.03`)
2. parentheses and the inline functions below
3. `<min>`, `<max>`, `<abs>`, `!` (not)
4. `^` (power)
5. `*`, `/`, `\` (remainder)
6. `+`, `-`
7. `<`, `>`, `<=`, `>=`, `=`, `!=`
8. `&` (and)
9. `|` (or)

So `&` binds tighter than `|`: `a & b | c` means `(a & b) | c`. Use parentheses whenever a condition mixes them.

**Inline functions** (preferred in current EUROMOD): `min(a,b)`, `max(a,b)`, `abs(x)`, `if(cond,a,b)` (also a
clean way to avoid division by zero), `round(x[,n])`, `floor(x)`, `ceiling(x)`, `ln`, `log`, `log10`, `exp`,
`sqrt`, `power(x,y)`. The older infix forms `a<min>b`, `a<max>b`, `<abs>(x)` still work (several models use
`<max>`); prefer the inline forms in new edits.

**Curly braces** group terms in conditions in SOUTHMOD models (`{lfo=1}`, `{xhh_ind<spl} & {drgn0=1}`). Read them
as grouping; their exact semantics are not documented in this skill, so do not build new logic that depends on
anything beyond grouping.

**`Run_Cond`** (function level) must be a **global** condition, the same for everyone in the run: unconditioned
constants, `GetSystemYear`, `GetDataIncomeYear`, `IsUsedDatabase#n` (with `#_DataBasename`). It cannot use
variables or conditioned constants. Example: `Run_Cond = IsUsedDatabase#1` runs a function only on a given
dataset (seen in GHAMOD and MOZMOD). For per-person or per-unit conditions use an `Elig` with
`Who_Must_Be_Elig`. If the condition is false, the function's outputs stay VOID (§1).

---

## 4. Periods and monetary status

The engine works in **monthly** amounts. Amounts carry a period suffix and are converted on reading:

| Suffix | Period | Monthly equivalent |
|---|---|---|
| `#m` | month | × 1 |
| `#y` | year | ÷ 12 |
| `#q` | quarter | ÷ 3 |
| `#w` | week | × 4.34 |
| `#d` | day | × 30.5 |
| `#l` | labour day (5-day week) | × 21.73 |
| `#s` | labour day (6-day week) | × 26.07 |
| `#c` | capital (no conversion) | × 1 |

A trailing `r` (`#mr`, `#yr`) marks a **rate**, which is non-monetary. Output is monthly. Before comparing a
model value with the law or the Country Report, convert with these factors: `0.3#l` is 6.52 a month, not 0.3 or
6.6. (`#d` and `#l` appear in some models, e.g. ETMOD, GHAMOD, MOZMOD.)

**Monetary status** decides whether an operand is summed over the unit (§1):
- data and simulated variables: `<Monetary>` in `VarConfig.xml`;
- `DefVar` variables: `Var_Monetary` (default **yes**). A flag or count defined by `DefVar` without
  `Var_Monetary = no` is summed over the tax unit, a classic multi-person bug;
- an amount ending in `#?r` is non-monetary.

---

## 5. Footnotes

A footnote attaches extra settings to one operand. Write `operand#n` in the formula or condition, and add
footnote parameters with the same number `n` (in the XML, `<Group>n</Group>`). Any integer works; one footnote
can serve several operands.

| Footnote | Effect |
|---|---|
| `#_Level` | Evaluate the operand on another tax unit. In **formulas** only a containing (larger) unit is allowed; otherwise there is a warning and the level is ignored. In **conditions** any unit works, because conditions are evaluated per person. |
| `#_Amount` | Value of an `amount#n` placeholder: keeps per-system numbers out of the formula text (`Amount#1*$minwage`) |
| `#_LowLim`, `#_UpLim` | Limits on that operand only |
| `#_Type` | Force the operand to be read as a variable, income list or query |
| `#_AgeMin`, `#_AgeMax`, `#_N`, `#_M`, `#_Val`, `#_Unique`, `#_Adults_Only`, `#_Income`, `#_Info`, `#_DataBasename` | Arguments of queries (§6) |

A footnote parameter whose number appears in no operand produces an "unused footnote" warning. Use `#_Level`
only when a condition genuinely aggregates over another unit (architecture §6).

---

## 6. Queries

Queries are built-in operands that return information about a person or unit. Grep the model for the ones it
uses. Several are **hard-wired to specific variable codings**. They were designed for one coding of these
variables; check the model's input coding (VarConfig label, DRD, data-preparation code) before trusting them:

| Query | Hard-wired definition | Check |
|---|---|---|
| `IsMarried` | `dms = 2` | Is 2 "married" in this model's `dms`? (used heavily in SOUTHMOD tax units) |
| `IsCohabiting` | `idpartner > 0 & dms != 2` | same |
| `IsInEducation` | `dec > 0 & les = 6` | `dec` and `les` codes |
| `IsDisabled` | `ddi > 0` (falls back to `ddilv` with a warning; with neither, "not disabled" with a warning) | `ddi` coding |
| `IsCivilServant` | `lcs = 1` | `lcs` coding |
| `IsBlueColl` | `loc` in {6,7,8,9,0} | ISCO one-digit coding of `loc` |

Others, by group:
- **Unit composition:** `nDepChildrenInTu` (`#_AgeMin`/`#_AgeMax` restrict ages; `nDepChInTu` is an alias),
  `nAdultsInTu`, `nPersInUnit`, `nDepParentsInTu`; `IsDepChild`, `IsOwnDepChild`, `IsLoneParent`, `IsPartner`,
  `IsHeadOfTu` (alias `IsHead`), `IsDepParent`. `IsParent` ignores the tax unit and has no age limit.
- **Ranking:** `IsNtoMchild` (`#_N`, `#_M`: the N-th to M-th child by age; ties go to the lower `idperson`),
  `HasMaxValInTu`/`HasMinValInTu` (`#_Val` names the variable, `#_Unique` breaks ties, `#_Adults_Only`).
- **Relatives:** `GetPartnerIncome`, `GetPartnerInfo`, `GetMotherIncome`, `GetFatherIncome`,
  `GetParentsIncome`, `GetOwnChildrenIncome`, `GetCoupleIncome`. They follow the `idpartner`/`idmother`/
  `idfather` links, not the tax unit, and return 0 when the relative is absent.
- **Run context (global, usable in `Run_Cond`):** `GetSystemYear` (four digits parsed from the system name, -1 if
  none), `GetDataIncomeYear`, `IsUsedDatabase#n` (`#_DataBasename`, wildcards `*` and `?`),
  `IsDataVariable#n`.

---

## 7. Identifiers

Each policy, function and parameter has a GUID (`<ID>`), and the GUID differs per system: the same row in
`<CC>_2024` and `<CC>_2025` has different IDs. `ChangeParam` refers to a parameter by its GUID (`Param_Id`).
The GUI also offers symbolic identifiers (`tin_<cc>_#3.7`), but they shift when rows are reordered; inside a
country model use GUIDs. Copy an identifier in the GUI by right-clicking the row.

Runtime placeholders `=cc=`, `=sys=`, `=sysyear=`, `=data=`, `=datayear=` and `=datacoicop=` are replaced when a
model runs (in `DefOutput`/`DefInput` file names and in add-on parameters). SOUTHMOD country XMLs write names out
in full and do not use them.

---

## 8. The functions one by one

### ArithOp
`Formula` is its only own parameter; everything else is §2. The workhorse for assignments, intermediate
amounts and income-list-based taxes.

### Elig
Writes 0/1 **per person** to `Output_Var` (default `sel_s`): 1 only if the person meets the personal parts of
`Elig_Cond` **and** the unit meets the unit-level parts. Example: `nDepChildrenInTu>2 & dag<10` sets 1 only for
the children under 10 in units with more than two dependent children. `Result_Var` gives an extra copy; there
are no limit parameters. A later function uses the result only through `Who_Must_Be_Elig` and `Elig_Var` (§2).
Moving one operand to another unit with `#_Level` is common.

### BenCalc
Result = sum of components. Each component is a group (`#n`) of:
- `Comp_Cond`: who qualifies for the component;
- `Comp_perTU`: amount added **once per unit** if at least one member meets `Comp_Cond`; or
- `Comp_perElig`: amount added **once per qualifying member** (mutually exclusive with `Comp_perTU` in a group);
- `Comp_LowLim`/`Comp_UpLim`: limits on that component.

`Base` defines a base amount that formulas can use as `$Base`. A **taper** (means test) is available:
result − max(`Withdraw_Base` − `Withdraw_Start`, 0) × `Withdraw_Rate`; with `Withdraw_End` instead of a rate the
rate is result / (`Withdraw_End` − `Withdraw_Start`) (ignored if a rate is also given). Any withdraw parameter
floors the result at 0. SOUTHMOD models do not use the taper today, but it is the natural tool for a means-tested
reform.

Typical SOUTHMOD uses: benefits with age bands or roles (head, partner, child), structural taxes, and the older
"pseudo-simulation" pattern that copies a reported amount into an `_s` variable for recipients
(architecture §6, reported vs simulated).

### SchedCalc
Applies a schedule to `Base`. Bands are defined by `Band_UpLim` (or `Band_LowLim`; mix them only with care). The
first band starts at 0 and the last runs to infinity by default. Each band has `Band_Rate` or `Band_Amount` (a
fixed amount added once the base reaches the band; one or the other per band, mixing them across bands warns).
Options:
- `Simple_Prog = yes` (also `Do_Average_Rates`): the rate of the band the base falls in applies to the whole base;
- `Quotient = q`: divide the base by q, apply the schedule, multiply the result by q (income splitting);
- `BaseThreshold`: a base below it gives 0; `Round_Base` rounds the base first.

Check figure for verifying an encoding against a legislated schedule: base 60,000 with 0 % to 5,000, 25 % to
50,000 and 50 % above gives 16,250; with `Quotient` 2, 12,500; with `Simple_Prog`, 30,000.
(SchedCalc is the PIT core in 13 of the 14 models.)

### Min and Max
Repeated `Val` parameters; the result is their minimum (needs at least one) or maximum (at least two).
`Positive_Only` (Min only) ignores values ≤ 0 and returns 0 if none is positive. Inline `min()`/`max()` in an
ArithOp does the same and is simpler. (Seen in COLMOD.)

### Allocate
Pools the `Share` variable over the unit and redistributes it: equally among members by default, among those
meeting `Share_Between` (e.g. `!{IsDepChild}`), or in proportion to `Share_Prop`. Settings:
- `Share_All_IfNoElig` (default yes): if nobody meets `Share_Between`, share among all members; with `no`, the
  output is 0, and if `Share` and `Output_Var` are the same variable the amount disappears;
- `Share_Equ_IfZero` (default no): if every `Share_Prop` value is 0 the run errors; `yes` shares equally;
- `Ignore_Neg_Prop`; `Who_Must_Be_Elig` does not apply.
Typical use: moving a household benefit from the head (§1) to the recipient or the mother.
(Seen in BOLMOD, COLMOD, ETMOD, GHAMOD.)

### DefVar
Declares a model variable and initialises it with a **constant** only (there is no tax unit; fill it with an
ArithOp). `Var_Monetary` defaults to yes (§4). `Var_Dataset` and `Var_SystemYear` restrict the definition to
datasets or years (wildcards such as `20??`).

### DefConst
Defines `$`-constants. A constant may be **conditional**: one unconditioned default plus groups, each with a
`Condition`. When several conditions match, the **highest group number wins**; with no default and no match the
value is 0, with a warning. Conditioned constants cannot be used in `Run_Cond`. `Const_Dataset` and
`Const_SystemYear` restrict a definition. A constant may be redefined later (e.g. by ArithOp) but must stay equal
for everyone. Constants are not always in `constdef_<cc>`; grep the name. (Conditional constants appear in a few
models, e.g. region-specific poverty lines.)

### DefIl
Builds an income list from components, each with a factor: `+`, `-`, or a number (`+0.5`, `-2`). A component can
be another list, which must already be defined. `RegExp_Def` with `RegExp_Factor` adds every variable matching a
pattern (e.g. `x[0-9]+` for all expenditure items). `Warn_If_NonMonetary` (default yes) flags non-monetary
members. A simulated component must be computed before the list is used, or it is VOID (§1).

### DefTu and UpdateTU
`DefTu` defines a tax unit:
- `Type`: `HH` (household), `IND` (individual), `SUBGROUP` (built from the conditions below);
- `Members`: combine `Partner`, `OwnDepChild`, `LooseDepChild`, `OwnChild`, `DepParent`, `DepRelative` with `&`;
  the head is always included;
- conditions `DepChildCond`, `PartnerCond`, `LoneParentCond`, `DepParentCond`, `OwnChildCond`, `ExtHeadCond` and
  others, evaluated in a fixed order (dependent children first, then the head, then partners and the rest).
  `HeadDefInc` chooses the head (default: the system's `<HeadDefInc>`, §1);
- the keyword **`Default`** inside a condition stands for that condition's default, so `Default & !...` narrows
  it (seen in GHAMOD); overriding a condition without `Default` replaces it;
- prefixes `head:` and `partner:` read the head's or partner's value of a variable;
- flags: `NoChildIfHead`, `NoChildIfPartner`, `AssignDepChOfDependents`, `AssignPartnerOfDependents`,
  `MultiplePartners` (warn/ignore/allow), `StopIfNoHeadFound` (default no). (`AssignDepChOfDependents` and
  `NoChildIfHead` are common in SOUTHMOD, where households are large and multigenerational.)

**Membership is fixed when the unit is first used.** It is not re-evaluated when incomes that define it change
later in the spine (e.g. a child whose new benefit income ends dependency). Use `UpdateTU` (`Name` or
`Update_All`) after the change, or `IsStatic = no` on the unit, when that matters.
In a SUBGROUP unit's own conditions, write `#_Level` explicitly, because the unit is not complete while it is
being built.

### Uprate
Scales monetary input variables to the policy year:
- `Dataset` binds an Uprate function to one or more datasets (wildcards); models keep one function per dataset
  vintage and switch them per system;
- one parameter per variable, with a factor (`$f_*` from an `<UpratingIndex>`, a number, or a named factor);
- `Def_Factor` covers monetary variables without their own factor; `WarnIfNoFactor` and `WarnIfNonMonetary`
  control warnings;
- `Factor_Condition`: factors apply only to records meeting a condition, and **several matching conditions
  multiply**; conditioning on a variable that the same function uprates compounds the factor (use a copy of
  the original). (Seen in ETMOD.)
- `AggVar_Name`/`AggVar_Part`/`AggVar_Tolerance`: rebuild an aggregate as the sum of its uprated parts;
- `RegExp_Def`/`RegExp_Factor`/`RegExp_Condition`: uprate groups of variables by pattern (e.g. by COICOP
  division); cannot be combined with `AggVar_*`;
- `DBYearVar`: per-record income year in multi-year datasets.
Quantity (`q*`) variables are not uprated (architecture §6).

### DefOutput
Writes the output file:
- `File` (the file name; with the run dialog's extension settings it becomes `<name>_<EXT>on/off`,
  `running_and_analysis.md` §2);
- `Var`, `VarGroup` (wildcards), `IL` (list totals), `ILGroup`, `DefIL` (list components);
- `UnitInfo_Id`/`UnitInfo_TU`: columns such as `<tu>_HeadID`, `_IsPartner`, `_IsDepChild`, `_IsLoneParent`;
- `nDecimals` (default 2): rounds every column, `ses` included (`running_and_analysis.md` §4);
- `Replace_Void_By`, `Suppress_Void_Message` (§1); `MultiplyMonetaryBy` (e.g. a currency conversion);
- `AutoRenameWhenCopying` (default yes): the GUI renames the file when a system is copied;
- several `File` parameters in one function are allowed only for different extension settings; the last
  applicable one wins, with a warning.
`TAX_UNIT` decides the rows: a household unit writes one row per household, with monetary variables summed and
non-monetary ones taken from the head. A variable that is not in `VarConfig.xml` in a `*_std` file gives a
"non-standard variable" warning.

### SetDefault
Supplies values for variables **missing from the dataset**, per `Dataset` (wildcards); a default may reference
another variable. With the dataset option `UseCommonDefault` off, a variable missing from the data is an error
unless SetDefault covers it; with it on, it is set to 0. SetDefault takes precedence. Some models use it to give
downstream readers a value for switched-off policies, which avoids "not initialised" warnings. When present,
`SetDefault_<cc>` is the first policy in the spine. (The function appears in ECUAMOD, VNMOD and MicroZAMOD;
GHAMOD has the policy without functions.)

### RandSeed
Sets the seed (`Seed`, default 1) for `rand`. A random draw is reproducible only with the **same seed and the
same records in the same order**. If a revised input file adds, drops or reorders people, every random
allocation (take-up, targeting) reshuffles, and results change although no policy did. The same seed in every
system gives the same person the same draw in baseline and reform, which keeps reform comparisons clean.
(Used in 12 of the 14 models.)

### ChangeParam and ChangeSwitch
`ChangeParam` changes another parameter's value (`Param_Id`, a GUID, with `Param_NewVal`) when the model is
**read**, so its position in the spine does not matter; `Dataset` and `SystemYear` restrict it. It cannot change
values during the run. `ChangeSwitch` (`PolFun`, `SwitchNewVal`, optional `Run_Cond`) changes a policy's or
function's switch, including `toggle` cells. ECUAMOD uses ChangeParam to rename its output file when its
minimum-wage variant runs.

---

## 9. Rarely used functions

Not used in SOUTHMOD models at the time of writing; recognise them if you meet them:
- `InitVars`: initialise or overwrite variables at a point in the spine.
- `DefInput`: read an external table (merge on a key, or look up a value by row × column).
- `Loop`, `UnitLoop`, `Store`, `Restore`: repeat part of the spine, keep and restore variable values.
- `Totals`: weighted sums, means, quantiles and counts over the population, the same value for everyone
  (calibration to an administrative total).
- `IlVarOp`, `IlArithOp`: operations on every variable of an income list (e.g. per-item VAT across matching
  expenditure lists).
- `DropUnit`/`KeepUnit`: drop or keep units by condition (debugging on a subsample).
- `Scale`, `CumulativeSum`, `AddHHMembers`, `CallProgramme`: specialised.
- `Break`: stops the run after a function and writes every variable and income list at that point (optionally
  tax-unit information). A development tool for debugging a reform; remove it before shipping.
