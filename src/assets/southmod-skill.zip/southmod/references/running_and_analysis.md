# Running models and analysing results — universal procedure

Procedural knowledge that applies to every SOUTHMOD model: how to obtain and install the software, how to run a model and read its logs, how to use the Statistics Presenter, how to compute the standard distributional statistics from an output dataset, and how to author a reform. None of this is country-specific. For the *contents* of a specific model, follow `exploration_playbook.md`.

---

## 1. Getting, installing, and getting help

- **Models, data, DRDs, Country Reports** — request access via UNU-WIDER: <https://www.wider.unu.edu/about/accessing-southmod-models>. You accept the **SOUTHMOD Adhesion Agreement** (non-commercial research use), state which input datasets you need, and receive a download link on approval. The skill ships **no model data** — users bring their own licensed bundle.
- **Input-data caveat** — some models ship only **Stata do-files that generate the input data** from a survey the user must obtain separately (the underlying microdata are not redistributable); others ship ready-made input datasets. So a missing `<cc>_<year>_a<n>.txt` may be by design — check whether the model ships data or only the do-file, and point the user to the data source named in the Country Report / DRD.
- **Software** — EUROMOD is a separate **free** download from the JRC: <https://euromod-web.jrc.ec.europa.eu/download-euromod> (open source, EUPL-1.2; Stata/Python/R connectors). SOUTHMOD users need only the software, not the EU model. **Windows is the only documented platform for the GUI** — don't improvise Mac/Linux GUI instructions; suggest a Windows VM. The Python package also runs on Linux x86_64; running models from Python or Stata is covered in `connectors.md`.
- **Tools that do not apply to SOUTHMOD.** The EUROMOD add-ons (e.g. marginal tax rates), Policy Effects, Macro validation and the hypothetical household tool are not set up for SOUTHMOD models; do not offer them.
- **The official bundle is one multi-country project** — opening it shows a Countries tab with all flags and a **Run SOUTHMOD** button; any model runs without being opened first.
- **Training** — the free **SOUTHMOD Online Course** (modules + exercises on **DEVMOD**, certificate): <https://www.wider.unu.edu/about/southmod-online-course>.
- **Help desk** — **southmod@wider.unu.edu**.

---

## 2. Running a model (the Run SOUTHMOD dialog)

1. Open the EUROMOD GUI → File → Open Project → the bundle folder containing `XMLParam/`. (It reopens automatically next launch.)
2. Countries tab → **Run SOUTHMOD**. In the Main tab, tick the system rows you want (`<CC>_<year>`); the Dataset dropdown defaults to "(Best Match)".
3. Check the **Output path** — *the folder must already exist or the run errors.*
4. View/Filter/Add-Ons tab: pick extensions per system — `on` / `off` / `all` (`all` outputs both switch states in one run); optionally restrict to households between two `idhh` values (debugging) or the first N households.
5. Run → outputs land as `<cc>_<year>_std.txt` in the output folder, plus provenance/log files (below). Keep the progress window open — closing it aborts the run.
   - **Output names** come from the `file` parameter of `DefOutput` in `output_std_<cc>` (case as written there, e.g. `RW_2024_std`, not always lower case). When an extension is switched in the run dialog, EUROMOD 3.8 writes `<file without _std>_<EXT>on/off` instead (seen: `RW_2024_FORon`, `RW_2024_top_m1_REWoff`; the other extensions, at their default `off`, added no suffix; a system where the extension is `n/a` kept `_std`). Names with two switches set are unverified: read the log, never infer the scenario from the name.

**Logs and provenance** (in the output folder):
- `yyyymmddhhmm_errlog.txt` — warnings/errors from the run.
- `yyyymmddhhmm_EMHeader.txt` — the answer to "which version/dataset produced this output?": system, dataset, software/UI/executable versions, timestamps, currency, exchange rate. (`XMLParam/Config/EuromodVersion.txt` is a bundle label, not the software version.)
- `<yyyymmddhhmmss>_<guid>_SOUTHMOD_Log.txt` (Run SOUTHMOD, EUROMOD 3.8): one row per run with system, dataset, each extension state (`1` on, `0` off, `-1` n/a), output file and its MD5 (`Output-Hash`). Check outputs against these hashes.

**Debugging "my benefit is N× too large":** almost always the assessment-unit rule — monetary variables/income lists in a formula are **summed over the `TAX_UNIT`**; non-monetary variables are per-individual in conditions but taken from the unit **head** elsewhere (head = richest member; ties → oldest → lowest `idperson`). Check the function's `TAX_UNIT` parameter. The mirror image, "paid to only one person per household" or "zero for everyone but the head", is the result-storage rule: the result goes to the head, and `Output_Var` sets other members to 0 (`functions_and_syntax.md` §1).

**Other debugging tools:**
- "Use of not initialised variable": the variable is VOID because its producer is `off`/`n/a`/`toggle`, extension-controlled and off, skipped by `Run_Cond`, or runs later in the spine (`functions_and_syntax.md` §1).
- "Unused footnote": a `#_...` footnote whose number appears in no operand.
- An `Elig` that seems to have no effect: the consuming function lacks `Who_Must_Be_Elig` (default `nobody`).
- Restrict the run to a household range in the run dialog; or stop after a given function and inspect every variable: a temporary `Break` function, or `breakfun_id` in a connector run (`connectors.md`).
- Results that moved although no policy changed: random draws (`RandSeed`) reshuffle when the input file's records change or are reordered.

---

## 3. Statistics Presenter (built-in distributional reporting)

Applications → EUROMOD Statistics. Two SOUTHMOD templates:
- **Default** — one system.
- **Baseline/Reform** — one baseline + up to four reforms; deciles and poverty status are **fixed to the baseline**; gainers/losers reported at >1% / >5% income change. Designed for exactly the clone-pair workflow in §5.

**Hard rule: compared outputs must come from the same input dataset.** Distribution basis: consumption or income, each optionally net of indirect taxes/benefits (the post-fiscal `_pf` concepts); consumption-based is the usual choice for African models. The Presenter needs the `ildef_stats_<cc>` lists plus `ils_tax`/`ils_pen`, and the input variables `xhh`, `dhh`, `xivot`. **Never amend `ils_dispyx`/`ils_con` (or their `_pf` forms) directly — edit their component lists** so the Presenter's identities still hold.

When adding a simulated policy, route its output into the right income lists: a benefit into exactly one of `ils_pen`/`ils_benmt`/`ils_bennt` **and** one type list (`ils_bch`/`ils_bsa`/`ils_bsu`/`ils_bdi`/`ils_bun`/`ils_bag`/`ils_pen`); a direct tax → `ils_tax`; an indirect subsidy → `ils_benco`; an indirect tax → `ils_taxco`; a SIC → `ils_sicee`/`ils_sicse`/`ils_sicer`. Never store both a reported and a simulated version of the same amount.

---

## 4. Computing the standard statistics from an output dataset

The standard output `<cc>_<year>_std.txt` is tab-delimited, individual-level, with `ils_*` income lists, weights, and equivalence-scale columns. This works **even with no XML present** (state that caveat — you can analyse results but not explain how each column was produced).

Canonical recipe (Stata idiom; the same logic transfers to R/Python):
1. **Income concept** — equivalised disposable income from `ils_dispy` (or `ils_dispyx` incl. home production; the `_pf` post-fiscal variants if you want indirect taxes/benefits netted).
2. **Equivalise** by the `ses` column from the output dataset. By default `ses` is the model's national scale; `ses01` (per-capita) and `ses02` (square-root) are stored alongside for post-hoc use. *This is the default convention, not an absolute rule:* if the model was run with the on-model `ses` override on, the `ses` column is whichever scale that override selected — and analysts may equivalise by any scale in their own code. So: use the `ses` column, weighted by `dwt`; if poverty/Gini numbers look off, ask which scale the run used.
   - **How `ses` is stored differs between models.** Read the model's `ses_<cc>` policy (and the review code) before computing: in some models every member carries the household's scale value (use it once per household: equivalised income = household income / `ses` of any member), in others `ses` is a per-person weight whose household **sum** is the scale (sum `ses` over `idhh` first). Getting this wrong scales every equivalised income by the household size. The `policy_update` skill's `pf_povlines.py --ses-agg sum|household` makes the choice explicit.
   - **Output precision:** `DefOutput`'s `nDecimals` (`2` in the A4.0 RWAMOD, UGAMOD and VNMOD) rounds every output column, `ses` included, so poverty rates and post-fiscal lines computed from the output can differ from the same calculation in Stata on unrounded data (RWAMOD 2024: 27.42 vs 27.37 per cent until `nDecimals` 4). Raise `nDecimals` in the output policy when exact comparisons or fixed points matter.
3. **Weight** by `[aw=dwt]` (the survey weight).
4. **Floor negatives** at 0 before poverty/inequality measures.
5. **Poverty line** — `spl` is **monthly** (× 12 for an annual comparison); `splpf` is its post-fiscal counterpart.
6. **Measures** — poverty headcount and gap against `spl`; Gini on the equivalised, weighted distribution (e.g. `povdeco` / `sgini` in Stata, or equivalent canonical commands).
   - All person-level: every person counts with weight `dwt` and their household's equivalised income. A household-weighted headcount is a different statistic; say which one you report.
   - FGT measures with line z and income y: headcount FGT0 = weighted share with y < z; poverty gap FGT1 = weighted mean of max(0, z − y)/z; severity FGT2 = weighted mean of (max(0, z − y)/z)².
   - S80/S20 and decile shares: ratios of **weighted sums** (Σ w·y in the top quintile / Σ w·y in the bottom quintile). In Stata compute sums with `[iw=dwt]` or as `r(mean)*r(sum_w)` from `summarize [aw=dwt]`; do not rely on `tabstat ..., stat(sum)` with `[aw]` within `if` subsets.
   - Reform comparisons: keep the poverty line (and decile cut-offs) fixed at the baseline, as the Statistics Presenter's Baseline/Reform template does, unless the question is about a relative line.
   - Standard errors: if the input carries survey design variables (PSU, strata), use them (`svyset psu [pw=dwt], strata(strata)`); weights alone understate the uncertainty. An estimated (relative) poverty line adds further variance.

**International poverty lines.** SOUTHMOD's `spl` lines are national. For World Bank comparisons use the 2021 PPP lines of **US$3.00, US$4.20 and US$8.30 per person per day**. They are per capita (not equivalised): divide household income or consumption by household size (`ses01` where the model stores a per-capita scale) and count people. Convert to a monthly line in local currency for policy year t:

  line_LCU,month = 3.00 × 365 / 12 × PPP2021 × CPI_t / CPI_2021

with PPP2021 the 2021 **private consumption** PPP conversion factor (LCU per international dollar, World Bank ICP/WDI) and CPI the national consumer price index. Check the model's currency unit (some models hold amounts in thousands of the national currency). Do **not** use the bundle's `ExchangeRatesConfig.xml` or a connector's `euro` option: they hold current-year **GDP** PPP factors. State that the result approximates, but does not reproduce, the World Bank's own estimates, which use the survey's welfare aggregate.

**Base- vs target-year expectations:** for a base-year run (policy year = data year) expect a close match to official statistics; for a target-year run (uprated data) do **not** expect aggregate match — uprating assumptions carry the data forward.

**The review pipeline** (shipped as `.do`/`.py` review code) is the canonical validation: an input-checks step validates the input data, an output-checks step enforces the income-list identities and presence checks, and a baseline-statistics step produces poverty headcount / gap / Gini and a summary workbook. If the review code is present, run it rather than reinventing the checks.

---

## 5. Authoring a reform — clarify the pattern first

There are two patterns; they serve different purposes. **Ask which the user wants before walking through mechanics**, and **first confirm the parameter they want to change actually exists** (Step 5 of the playbook) — many reforms aren't a one-line value edit.

**Pattern A — one-off study reform → clone the system** (the right answer for the large majority of reform questions: a research paper, a sensitivity analysis):
1. In the GUI, select the baseline system column (e.g. `<CC>_2024`) → **Copy/Paste-System** → name it e.g. `<CC>_2024_reform`. A new column appears, inheriting every cell value from the source — **including its dataset binding and extension switches**. No new `<DBSystemConfig>` block is needed unless you want a *different* dataset.
2. Edit only the cells that change — typically one or a few `<Parameter><Value>` entries (e.g. a VAT rate constant in `constdef_<cc>`).
3. Save → run baseline and reform side by side.
4. Compare on the two output files in Stata/R/Python, or with the Statistics Presenter's Baseline/Reform template.

**Pattern B — persistent, shipped, user-toggleable variant → add an Extension** (only when the change should ship as an on/off switch users flip across model versions, like the model's existing extensions):
1. In `<CC>_dataconfig.xml`, add an `<Extension>` block (new GUID, 3-letter `<ShortName>`, colour).
2. In `<CC>.xml`, add `<Extension_Policy>`/`<Extension_Function>` rows binding the new ExtensionID to the policies/functions it gates (`<BaseOff>true</BaseOff>` switches the baseline policy off when the extension is on). A binding covers the **whole row in every system**: bind new, dedicated rows (`n/a` in systems where the variant does not apply), never one year's cell of a row that runs normally in other years (that binding is ignored and the element does not run). For year-specific values use `<Extension_Parameter>` pairs or paired `DefConst` rows (see `architecture_and_conventions.md` §6).
3. Per `<DBSystemConfig>` row, add a `<PolicySwitch>` defaulting the extension `on`/`off`/`n/a` per (system, dataset).
   - **Reading or changing a default:** in `<CC>_dataconfig.xml` each `<DBSystemConfig>` (one system × dataset pair) has one `<PolicySwitch>` per extension (`SwitchablePolicyID` = the `<Extension>` ID, `<Value>` `on`/`off`/`n/a`). Change it in the GUI or in the legacy XML, never while EUROMOD has the model open. The EM3 copy regenerates on the next open because its `up2Date_<CC>_DataConfig` MD5 no longer matches (deleting `EM3Translation/` also works); then check the translated `EXTENSION_SWITCHs` rows have the system and value filled. Seen once: hand-added `<Extension>`/`<PolicySwitch>` elements written on one line (no whitespace between children) translated with `Name`, `Look`, `SystemID` and `Value` empty (cause not confirmed); write new elements one child per line, like the existing ones.
4. Save → the EM3 mirror and `up2Date_*` sentinels refresh.
5. Validate by running each affected system with the extension on vs off and diffing the output.

**Pattern C — script-only reform from Python or Stata** (no model edit): override constants or switch policies and extensions at run time (`connectors.md`). Good for sensitivity grids and quick checks. Nothing is stored in the model and no GUI log is written, so record the provenance yourself (`connectors.md` §5) and turn any result you will report into a Pattern A clone.

**Overriding values inside the model: `ChangeParam`.** A policy holding `ChangeParam` functions changes other parameters' values when the model is read (by GUID, optionally only for some datasets or years), and `ChangeSwitch` switches rows on or off. This is how a model can carry a variant without a second system (one model uses it to rename its output when a minimum-wage variant runs). Use it only where a model already follows this pattern; clones and extensions are easier to read.

**Decision rule:** "Will users need to flip this on/off as part of standard analysis going forward?" → Extension. "Is this a self-contained variant I want to compare against baseline once?" → System clone. Most user-facing reform questions want the clone path; don't default to an Extension.

**Adding a new policy year** is the same as a system clone with a new `<Name>` (`<CC>_<nextyear>`), then updating the year's constants, uprating factors, and (if the dataset changes) a `<DBSystemConfig>` binding.

---

## 5b. Measuring a reform's fiscal effect — sum *all* aggregates, not just the instrument you changed

When you compare a reform to its baseline, **the change in the parameter you edited is not the full fiscal effect.** A reform to one instrument propagates through the model, and other tax, contribution, and benefit aggregates can move in the same run — partly offsetting (or amplifying) the headline change. Reporting only the edited instrument's change (e.g. "the PIT cut costs ΔPIT") systematically misstates the cost to government. **Always diff the complete set of fiscal aggregates between the two output files**, confirm which ones moved, and report the **net** effect.

The aggregates to difference (survey-weighted, `[aw=dwt]`; annualise monthly figures × 12):
- **Direct taxes** — `ils_tax` (and the specific `t*_s` instrument you changed, e.g. `tin_s`).
- **Social insurance contributions** — `ils_sicee` (employee), `ils_sicse` (self-employed) and `ils_sicer` (employer). Aggregate lists (`ils_sic`, `ils_sicdy`) differ between models in whether employer contributions are included: read their definitions in `ilsdef_<cc>` before using one, and report employer contributions separately.
- **Benefits** — `ils_ben` (and `ils_benmt`/`ils_bennt`/`ils_pen` for the breakdown).
- **Indirect taxes and subsidies** — `ils_taxco` (VAT + excise) and `ils_benco` (indirect-side subsidies).

Net fiscal cost ≈ Δ(direct taxes + contributions + indirect taxes) − Δ(benefits + subsidies). Lead with the instrument's mechanical change, then state the net once the second-round movements are in.

**Why other aggregates move — common in-model interactions to check for:**
- **Contributions levied on a base that depends on the changed instrument.** If a social/health-insurance contribution is charged on *net-of-income-tax* income, or its premium is **banded by income**, then cutting income tax raises net income and pushes contributions *up* — a partial revenue rebound. (A worked case: an employee health-insurance contribution set as a percent of net salary plus income-banded premiums rose by a small amount when a PIT cut raised net salaries, offsetting a fraction of the PIT loss.)
- **Means-tested benefits assessed on disposable income.** If a simulated benefit's eligibility or amount depends on a means test over disposable income, a reform that moves disposable income can change benefit entitlement and therefore spending. (Where benefits are read from the input data rather than simulated — the modern reported-straight-into-`ils_*` convention — they will *not* move; confirm which convention the system uses by checking the matrix cell.)
- **Indirect taxes/subsidies via a consumption response.** If the model feeds a disposable-income change into simulated consumption, then `ils_taxco`/`ils_benco` can move with it; if consumption is taken straight from expenditure data, they will not. Check rather than assume.

**Operational rule:** never assert "this is the full revenue cost" from the single instrument alone. Difference every `ils_*` fiscal aggregate, note the ones that changed (even small ones), and explain the interaction that drove each — or confirm explicitly that the others were unchanged. The same caution applies to the welfare side: a reform's effect on poverty/inequality flows through whichever income or consumption concept actually moved, which may not be the one you edited.

---

## 5c. Decomposing a result by instrument (Shapley)

"How much of the poverty (or Gini) reduction comes from each tax and benefit?" depends on the order in which instruments are added. The Shapley value averages over all orders and is order-independent. Two variants:

- **Accounting decomposition (one run).** Take the components from one output: e.g. original income, `ils_ben` (or each benefit type list), direct taxes `ils_tax`, employee and self-employed contributions, and, for post-fiscal concepts, `ils_benco` and `ils_taxco`. Build income for every subset S of components with the same household aggregation and equivalence scale as the total, and compute the indicator v(S) against a **fixed** line. It ignores interactions inside the model (a contribution levied on net-of-tax income, a means test on disposable income).
- **Simulation decomposition (2ⁿ runs).** Switch the instruments' policies off in every combination (connector runs, `connectors.md`) and compute v(S) from each run. It captures in-model interactions (cf. behavioural rule 15) at the cost of 2ⁿ runs; keep n small (group instruments).

Shapley contribution of component k among n:
φ_k = Σ over S ⊆ N∖{k} of |S|! (n − |S| − 1)! / n! × [v(S ∪ {k}) − v(S)].

```python
from itertools import combinations
from math import factorial
def shapley(components, v):           # v: frozenset of components -> indicator value
    n = len(components); phi = {}
    for k in components:
        others = [c for c in components if c != k]
        phi[k] = sum(factorial(len(S)) * factorial(n - len(S) - 1) / factorial(n)
                     * (v(frozenset(S) | {k}) - v(frozenset(S)))
                     for r in range(n) for S in combinations(others, r))
    return phi
# check: sum(phi.values()) == v(frozenset(components)) - v(frozenset())
```

Always verify that the contributions add up to the total change. For consumption-based welfare, say which components are removed from `ils_con` and how; this is a methodological choice, not a fixed convention.

---

## 6. Validating a system against the Country Report

1. Find the relevant Country Report table (e.g. the PIT schedule, VAT rates, benefit amounts).
2. Cross-check the XML constants (`$`-values in `constdef_<cc>`, read per system) against the report's legislated values. Convert period suffixes first (`#y` ÷ 12, `#d` × 30.5, `#l` × 21.73; `functions_and_syntax.md` §4), and for schedules use the SchedCalc check figure in `functions_and_syntax.md` §8. Agreement with the Country Report is not proof that a value is right: reports are written from the model, so check legislated values against the law where it matters (`exploration_playbook.md` Step 8).
3. Run the system; compute equivalised disposable income (`[aw=dwt]`, equivalised by `ses`).
4. Run the shipped review code (input checks → output checks → baseline statistics).
5. Compare to the report's published tables — expect a close match for a base-year run; accept calibration differences for a target-year run.
