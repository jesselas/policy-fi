# Exploration playbook — understand ANY SOUTHMOD model by reading its files

This is the core method of the skill. SOUTHMOD models share one architecture (`architecture_and_conventions.md`) but every model's *contents* — its systems, programmes, parameter values, datasets, extensions — are specific and change over time. So the rule is: **explore, then answer.** Never recite a country's specifics from memory. At the start of any model-specific task, find what material is actually open, read it, and ground every claim in `file:line` from that material.

All grep recipes below were run against the real `SOUTHMOD_A4.0` bundle and are known-good. They are written with placeholders `<CC>` (uppercase code, e.g. `GH`) and `<cc>` (lowercase, e.g. `gh`) and a bundle root `<B>`. Substitute before running. Always `grep -i` for policy/variable names — casing varies between models.

---

## Step 0 — Discover what's open and route by artifact (the entry point)

This step delivers the skill's primary promise: whenever the user has a folder open with the SOUTHMOD bundle **or any SOUTHMOD-related material**, you can understand and analyse it from what is actually there. Material rarely arrives complete — a user may have only an output dataset, only one country XML, only a Country Report. Detect what is present, route to the right path, and **state plainly what you cannot determine without the missing pieces.**

First, scan the open folder(s):

```bash
# What kind of SOUTHMOD material is here?
find <B> -maxdepth 4 \( \
  -iname '*.xml' -o -iname '*_std.txt' -o -iname '*_a[0-9].txt' \
  -o -iname 'DRD_*.xls*' -o -iname '*.do' -o -iname '*.py' -o -iname 'CR-*.pdf' \
\) 2>/dev/null | head -50
# Bundle present? these two paths are the signature of a full project:
ls <B>/XMLParam/Countries/ 2>/dev/null        # country folders => bundle
ls <B>/XMLParam/Config/VarConfig.xml 2>/dev/null
```

Then route by what you find. Each artifact answers different questions:

| Artifact (pattern) | What it lets you answer | What it canNOT tell you alone |
|---|---|---|
| **Full bundle** (`XMLParam/Countries/<CC>/<CC>.xml` + `Config/`) | Everything structural: systems, spine, policies, parameters, uprating, extensions, the variable dictionary. | Actual simulated results — those need a run / output dataset. |
| **Lone country XML** (`<CC>.xml`) | Model structure, policy logic, parameter values per system, the matrix cells. | Variable descriptions live in `VarConfig.xml`; results need output; dataset provenance needs dataconfig/Country Report. |
| **`<CC>_dataconfig.xml`** | The list of systems, which dataset each binds to, which extensions ship and their defaults. | The policy logic itself (that's in `<CC>.xml`). |
| **`VarConfig.xml`** | The variable dictionary — every variable name and its `<Comment>` label. | Which policies use a variable (that's in `<CC>.xml`). |
| **Output dataset** (`<cc>_<year>_std.txt`, tab-delimited) | Full distributional analysis: incomes, taxes, benefits, `ils_*` lists, weights — **even with no XML present**. Poverty, inequality, decile tables. | *How* each column was produced (need `<CC>.xml`); which scale `ses` used if an override was on (need the run header / dataconfig). |
| **Input dataset** (`<cc>_<year>_a<n>.txt`) | The pre-simulation survey variables fed to the model; column inventory. | Anything simulated (`_s` variables) — that requires a run. |
| **DRD workbook** (`DRD_<CC>_*.xls[mx]`) | Data Requirement Document: variable inventory, definitions, provenance, survey→model mapping. | The live model logic (read `<CC>.xml`). |
| **Review code** (`.do` / `.py`, e.g. `*_input_checks.do`, `*_output_checks.do`, `*_baseline_statistics.do`) | The canonical input/output validation checks, income-list identities, and how baseline poverty/Gini are computed. | Whether a specific model passes — run it on the model's output. |
| **Country Report** (`CR-<MODEL>-*.pdf`) | Legal basis of each instrument, validation targets, programme descriptions, PIT/VAT schedules as legislated, data sources. | The exact XML encoding (cross-check against `<CC>.xml`). |

**Degrade gracefully.** Examples of honest, useful partial answers:
- *Only an output `*_std.txt`* → do the full distributional analysis (deciles, poverty, Gini, weighted by `dwt`, equivalised by `ses`), and say: "I'm reading results only; I can't tell you *how* `tin_s` was computed or confirm which equivalence scale `ses` holds without the XML / run header."
- *Only a `<CC>.xml`* → explain structure and parameter values, but say you can't produce distributional numbers without a run, and that variable labels are richer in `VarConfig.xml`.
- *Only a Country Report PDF* → explain the legal/programme content and validation targets, and say the exact encoding (`$`-constants, switches, spine position) must be confirmed against `<CC>.xml`.

If **nothing relevant** is in the open folder, ask the user for the path to their bundle or file rather than answering from memory.

Finally, identify the model and its systems:

```bash
# Which country?  (folder name, or the _<cc> suffix on policy names)
ls <B>/XMLParam/Countries/
# Available systems for this model (fastest source = dataconfig):
grep -oE "<SystemName>[A-Za-z0-9_]+</SystemName>" <B>/XMLParam/Countries/<CC>/<CC>_dataconfig.xml \
  | sed -E 's#</?SystemName>##g' | sort -u
# (or infer from the country XML)
grep -oE "<Name><CC>_[0-9]{4}</Name>" <B>/XMLParam/Countries/<CC>/<CC>.xml | sort -u
```

The set of years is country-specific (e.g. GHAMOD runs `GH_2013`…`GH_2025`). Do not assume a range.

---

## Step 1 — Orient: read the spine

Get a one-screen map of the model by reading the policy `<Comment>` type tags in order. Each policy comment opens with `DEF:` / `TAX:` / `BEN:` / `SIC:`:

```bash
grep -oE "<Comment><!\[CDATA\[(DEF|TAX|BEN|SIC):[^]]*\]\]>" <B>/XMLParam/Countries/<CC>/<CC>.xml \
  | sed -E 's#<Comment><!\[CDATA\[##; s#\]\]>##' | head -40
```

This prints the spine for the first system (the list repeats once per system — that repetition *is* the matrix). It tells you, in plain language, what instruments the model contains.

> **Illustrative only (GHAMOD).** Running the recipe above on `GH.xml` yields, in order: `DEF: Set Default`, `DEF: UPRATING FACTORS`, `DEF: Constants`, `DEF: ASSESSMENT UNITS`, `TAX: Employer social contributions`, `TAX: Employee social contributions`, `BEN: LEAP transfer programme`, `TAX: Capital income tax`, `TAX: Labour income tax`, … — i.e. you can read off that GHAMOD has the LEAP cash transfer, capital and labour income taxes, presumptive tax, excises, VAT, a school-feeding in-kind benefit, etc., without opening the GUI. **This is GHAMOD's content; every other model differs — always run the recipe on the model in front of you.**

To get the GUI's spine ordering, sort policies by `<Order>` ascending within a system (the `<Order>` integer is arbitrary per country, so sort — don't assume `uprate` is literally `Order 1`).

---

## Step 2 — Resolve "row N.M"

Users address the spine as "row N.M" (the EUROMOD GUI's display):
- **N** = the Nth `<Policy>` in the system's spine, counted by `<Order>` ascending.
- **M** = the Mth `<Function>` within that policy (document/`<Order>` order, numbered 1, 2, 3…).

To resolve: pick the system (default = most recent), list its policies by `<Order>`, take the Nth, read its `<Comment>`, then take the Mth function, read its `<Comment>` and parameters. If the GUI's display filters (hidden/switched-off rows) make the count ambiguous, ask the user for the policy or function *name* and grep for it rather than guessing.

---

## Step 3 — Read the `<Comment>` before improvising meaning

Almost every policy, function, and parameter carries inline documentation:

```bash
grep -n -A2 "<Name><ENTITY></Name>" <B>/XMLParam/Countries/<CC>/<CC>.xml | head
# the <Comment><![CDATA[...]]></Comment> sits right after <Name>
```

The structure is consistent:
```xml
<Policy>
  <Name>uprate_gh</Name>
  <Type>def</Type>
  <Comment><![CDATA[DEF: UPRATING FACTORS]]></Comment>
  <Order>15</Order>
  <Switch>on</Switch>
  <Function> … <Parameter> … </Parameter> </Function>
</Policy>
```

A parameter looks like:
```xml
<Parameter>
  <Name>ils_dispy</Name>
  <Comment><![CDATA[Disposable income]]></Comment>
  <Value><![CDATA[+]]></Value>
  <Order>2</Order>
</Parameter>
```

Read the `<Comment>` first; it is the most direct "what does this do" source. For a variable's description, also check `VarConfig.xml`.

---

## Step 4 — Check the matrix cell for the user's system

A row's behaviour is per-column. Each `<System>` holds its own clone of every policy, each with its own `<Switch>` and parameter `<Value>`s.

```bash
# every clone of a policy across systems, with the line numbers:
grep -n "<Name><cc>_policy</Name>" <B>/XMLParam/Countries/<CC>/<CC>.xml
# for the clone inside the system you want, read its <Switch> (a few lines below <Name>)
```

To bind an occurrence to its system: each `<Policy>` carries a `<SystemID>` matching a `<System>`'s `<ID>` / `<Name>`. Read the `<Switch>` for the occurrence in the right system:
- `on` → runs;
- `off` → present but disabled;
- `n/a` → not applicable to this system — it does **not** execute. Explain what runs instead. The common pattern: a benefit policy is `n/a` in recent systems because the reported amount is folded straight into an income list by a `DefIl` in `ilsdef_<cc>` (the reported-vs-simulated convention — see `architecture_and_conventions.md` §6). For parameter rows, report the `<Value>` for the user's system specifically, not the first match in document order.

> **Illustrative only (RWAMOD).** In RWAMOD, the RDRP benefit policy `bml_rw` is `on` (a `BenCalc` pseudo-simulation) in the older systems but `n/a` in the recent systems, where the reported `bml` instead flows into `ils_bennt` directly via a `DefIl` in `ilsdef_rw`. So "what does `bml_rw` do?" has *two* answers depending on the system column. **Confirm the actual switches in the model in front of you before describing this — the convention shift happens benefit-by-benefit and year-by-year, and differs across models.**

---

## Step 5 — Find constants and parameters; sanity-check before proposing reforms

`$`-constants (band thresholds, rates, poverty lines) are defined by `DefConst`, usually in `constdef_<cc>` — but not always (some models put constants in other policies, and the policy may be capitalised, e.g. `ConstDef_gh`). Grep the constant name directly:

```bash
grep -niE "<Name>\$?<constant_name></Name>" <B>/XMLParam/Countries/<CC>/<CC>.xml
grep -niE "<Name>(constdef)_<cc></Name>" <B>/XMLParam/Countries/<CC>/<CC>.xml   # find the constants policy
```

**Before walking through any reform mechanics, confirm the thing the user wants to change actually exists as an editable parameter.** Many natural-sounding reforms ("double the VAT registration threshold") do not map to a single `<Value>` edit because the underlying construct isn't modelled as a constant — they would need new eligibility/structural logic. Surface that gap instead of miming a parameter walkthrough that can't exist.

---

## Step 6 — Trace income lists, uprating, and variables

**Income lists** — find every `DefIl` row that builds a list:
```bash
grep -n "<Name>ils_dispy</Name>" <B>/XMLParam/Countries/<CC>/<CC>.xml   # then read the <Value> (+/−/n/a)
```
The components and signs of `ils_dispy`/`ils_dispyx`/etc. are assembled from many `DefIl` rows; never amend `ils_dispyx`/`ils_con` (or `_pf`) directly — edit their component lists.

**Uprating** — which factor scales a monetary variable:
```bash
# inside an Uprate function, the parameter whose <Name> is the variable has <Value>=$f_*
grep -n -A2 "<Name><variable></Name>" <B>/XMLParam/Countries/<CC>/<CC>.xml   # look for the $f_* in <Value>
```
The factor's year→value series lives in a sibling `<UpratingIndex>`; consortium-shared series come from `HICPConfig.xml`. Quantity (`q*`) variables are not uprated.

**Variables** — the dictionary and the taxonomy:
```bash
grep -n -A2 "<Name><variable></Name>" <B>/XMLParam/Config/VarConfig.xml   # the <Comment> is the description
```
Decompose the name by the taxonomy (`architecture_and_conventions.md` §4), then confirm against the `<Comment>`.

---

## Step 7 — Watch for data-vintage shifts

When a model spans a survey change, the same COICOP `x*`/`q*` expenditure code can be **reassigned** between vintages, and parallel functions (one per classification) are switched per system. Do not infer an expenditure variable's meaning from its code alone — confirm via the per-system `<Comment>` inside the relevant `Uprate`/`DefIl` function for the system the user means. A code that is the bread/petrol/diesel code in one classification may be something else, or `n/a`, in another.

---

## Step 8 — Verify, cite, surface unknowns

- Cite `file:line` from the **actual** model you read (e.g. `GH.xml:7936`), never from memory or another country.
- If a needed artifact is absent, say what you can't determine and offer to read it if the user provides it.
- If the model genuinely doesn't contain something, say so — don't invent values, uprating factors, income-list members, or parameters.
- Distinguish a SOUTHMOD *convention* (which generalises) from a *country specific* fact (which must be read).

---

## Appendix — portable grep recipe card (verified against the bundle)

```bash
B=/path/to/SOUTHMOD_bundle          # folder containing XMLParam/
CC=GH ; cc=gh                       # the model

# list systems
grep -oE "<SystemName>[A-Za-z0-9_]+</SystemName>" $B/XMLParam/Countries/$CC/${CC}_dataconfig.xml \
  | sed -E 's#</?SystemName>##g' | sort -u

# list shipped extensions
grep -oE "<ShortName>[A-Z]+</ShortName>" $B/XMLParam/Countries/$CC/${CC}_dataconfig.xml \
  | sed -E 's#</?ShortName>##g' | sort -u

# spine map (policy type tags in order)
grep -oE "<Comment><!\[CDATA\[(DEF|TAX|BEN|SIC):[^]]*\]\]>" $B/XMLParam/Countries/$CC/$CC.xml \
  | sed -E 's#<Comment><!\[CDATA\[##; s#\]\]>##' | head -40

# which function types this model uses
grep -oE "<Name>(ArithOp|BenCalc|DefIl|DefIL|DefConst|DefVar|DefTu|DefTU|Elig|Uprate|DefOutput|SchedCalc|Allocate|SetDefault)</Name>" \
  $B/XMLParam/Countries/$CC/$CC.xml | sort | uniq -c

# find a policy / variable (case-insensitive!) and read its comment + switches
grep -niE "<Name>tin_$cc</Name>" $B/XMLParam/Countries/$CC/$CC.xml

# tax units in use
grep -oiE "tu_[a-z]+_$cc" $B/XMLParam/Countries/$CC/$CC.xml | sort | uniq -c

# variable description from the dictionary
grep -n -A2 "<Name>yem</Name>" $B/XMLParam/Config/VarConfig.xml
```
