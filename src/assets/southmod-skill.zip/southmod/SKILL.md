---
name: southmod
description: Country-neutral assistant for SOUTHMOD (the UNU-WIDER/SASPRI/LSE tax-benefit microsimulation models on the EUROMOD platform) and for EUROMOD itself. Covers all 14 country models (BOLMOD, COLMOD, ECUAMOD, EGYMOD, ETMOD, GHAMOD, MOZMOD, PERUMOD, RWAMOD, TAZMOD, UGAMOD, VNMOD, MicroZAMOD, ZANMOD) plus DEVMOD, and understands any model by reading its files, not from memory. Use whenever the user mentions SOUTHMOD, EUROMOD, DEVMOD or a country model, or works with a bundle, `<CC>.xml`, `VarConfig.xml`, `<CC>_dataconfig.xml`, input/output datasets (`<cc>_<year>_std.txt`, `_a<n>.txt`), a DRD, review code (`.do`/`.py`) or a Country Report. Trigger on EUROMOD vocabulary (`<System>`/`<Policy>`/`<Function>`/`<Parameter>`/`<Extension>`; ArithOp, BenCalc, SchedCalc, Elig, DefConst, DefTu, Uprate, DefOutput, Allocate, RandSeed; `Who_Must_Be_Elig`, `TAX_UNIT`, `#_Level` footnotes, queries); SOUTHMOD naming (`tin_<cc>`, `ils_dispy`, `_s`/`_pf` suffixes, `$`-constants); "row N.M"; the matrix (`on`/`off`/`n/a`); analysis (equivalised income, poverty, Gini, `[aw=dwt]`, Statistics Presenter, Shapley decomposition); reforms (clone vs Extension); and installing or running EUROMOD, including from Python (`euromod` package) or Stata. Do NOT trigger on generic tax/benefit questions, other platforms (TAXSIM, OpenFisca, PolicyEngine) outside a SOUTHMOD comparison, or generic XML/Stata/Python.
---

# southmod

SOUTHMOD is the UNU-WIDER / SASPRI / LSE-III family of tax-benefit microsimulation models for Global South countries. Every model runs inside the **EUROMOD** software platform — the same free engine (JRC) that hosts the EU-country tax-benefit models. DEVMOD is the training model.

This skill is **country-neutral and self-contained**. It carries the universal SOUTHMOD/EUROMOD knowledge that is genuinely identical across all 14 models, and it understands any *specific* model by **reading that model's files** — never by reciting country facts from memory. Whenever the user has SOUTHMOD material open (a full bundle, a single XML, an output dataset, a Country Report — any combination, even partial), this skill detects what is present, routes to the right understanding/analysis path, and grounds every claim in what is actually there.

The 14 production models:

| Model | Country | `cc` / `CC` |
|---|---|---|
| BOLMOD | Bolivia | `bo` / `BO` |
| COLMOD | Colombia | `co` / `CO` |
| ECUAMOD | Ecuador | `ec` / `EC` |
| EGYMOD | Egypt | `eg` / `EG` |
| ETMOD | Ethiopia | `et` / `ET` |
| GHAMOD | Ghana | `gh` / `GH` |
| MOZMOD | Mozambique | `mz` / `MZ` |
| PERUMOD | Peru | `pe` / `PE` |
| RWAMOD | Rwanda | `rw` / `RW` |
| TAZMOD | Mainland Tanzania | `tz` / `TZ` |
| UGAMOD | Uganda | `ug` / `UG` |
| VNMOD | Viet Nam | `vn` / `VN` |
| MicroZAMOD | Zambia | `zm` / `ZM` |
| ZANMOD | Zanzibar | `zn` / `ZN` |

The architecture is identical across all of them: the same bundle layout, EUROMOD function set, spine-ordering convention, naming taxonomy, output structure, and analysis pipeline. Everything carries over with one substitution — replace the country code with the target country's lowercase/uppercase ISO Alpha-2 code (`tin_rw` ↔ `tin_gh`; `RW.xml` ↔ `GH.xml`; `XMLParam/Countries/RW/` ↔ `XMLParam/Countries/GH/`). What does **not** generalise — parameter values, which programmes/extensions a model ships, datasets and survey vintages, the year range of its systems, and which conventions a given system has adopted — must be **read from the live model**, not assumed.

## Core doctrine: explore, then answer

**Rule #1 of any model-specific task: find the SOUTHMOD material that's open, read it, and verify against it. Never recite a country's specifics from memory.**

At the start of such a task:
1. **Scan the open folder(s)** for SOUTHMOD material — a full bundle (`XMLParam/Countries/<CC>/<CC>.xml` + `Config/`), a lone country XML, a `<CC>_dataconfig.xml` / `VarConfig.xml` / `HICPConfig.xml`, an output dataset (`*_std.txt`), an input dataset (`*_a<n>.txt`), a DRD workbook (`.xlsm`/`.xlsx`), review code (`.do`/`.py`), or a Country Report (`.pdf`) — in any combination.
2. **Route by what's present.** Each artifact answers different questions; the full routing table and detection commands are in `references/exploration_playbook.md` (Step 0). Analyse whatever is there — e.g. do full distributional analysis from an output dataset even with no XML.
3. **Say what you can't determine** without a missing artifact (e.g. "I can analyse these results but can't explain how `tin_s` was computed without the XML").
4. If **nothing relevant** is open, ask the user for the path rather than answering from memory.

Then work through the playbook: orient on the spine → resolve "row N.M" → read the `<Comment>` → **check the matrix cell** for the user's system → find constants → trace income lists/uprating/variables → watch for data-vintage shifts → cite `file:line` and surface unknowns.

## The EUROMOD matrix (the one mental model that matters)

A model is **a matrix, not a flat program.** In the EUROMOD GUI:
- **Rows** = the policy → function → parameter spine.
- **Columns** = the systems (`<CC>_<year>`).
- **Cells** = a `<Switch>` (`on`/`off`/`n/a`; `switch` when extension-controlled; occasionally `toggle`, which in SOUTHMOD marks an extension-only row and runs only when that extension is on) for policy/function rows; a `<Value>` for parameter rows.

So "what does X do in `<CC>_2024`?" is a question about the **cell** in row X, column `<CC>_2024` — not the row in isolation. The same row can be `on` in one system, `n/a` in another, hold a different value in a third. A policy whose XML you can read may be `n/a` in the system the user means — meaning it does not run, and the behaviour comes from elsewhere (often a `DefIl` folding reported survey data straight into an income list). **Always read the cell for the user's specific system.** Many "obvious" answers are wrong because they describe the wrong column.

## Answer style — prose first, XML under the hood

Most users work in the EUROMOD GUI (Variable Manager, policy spine, Statistics Presenter) and want the *logic* of a policy, not a wall of XML. Lead with intuitive explanation in SOUTHMOD/EUROMOD vocabulary — what the policy does, what triggers it, where it sits in the spine, which systems use it, where the data come from. Then, only if useful, drop into variable names, parameter rows, `file:line` citations under a clearly marked sub-heading ("Under the hood", "In the XML"). Don't open with `<Variable>` blocks, CDATA snippets, or GUIDs.

### GUI ↔ XML quick map

| XML entity | EUROMOD GUI surface |
|---|---|
| `VarConfig.xml` `<Variable>` rows | **Variable Manager** — searchable variable dictionary; the description is `<AutoLabel>` (plus per-country `<CountryLabel>`), the name is in CDATA. Bundle-wide. |
| `<Country>` / `<System>` blocks | **Country tree** + system tabs (`<CC>_<year>`). |
| `<Policy>` rows | **Policy spine** — the central table of policies for the active system, by spine order. |
| `<Function>` rows | **Function rows** under each policy, numbered 1, 2, 3 (the "row N.M" addressing) **in `<Order>` order, which is often not the XML document order**. |
| `<Parameter>` rows | **Parameter table** below the selected function (`Name`, `Value`, `Comment`). |
| `<Comment><![CDATA[…]]>` | **Comment column** — the most direct inline doc on policies, functions, and parameters. |
| `<UpratingIndex>` blocks | **Uprating Factors editor** — series × year. |
| `<Extension>` / `<PolicySwitch>` | **Extensions panel** + per-(system, dataset) toggles. |
| `<CC>_dataconfig.xml` | **DataConfig** — binds datasets to systems, declares extensions. |
| Output `<cc>_<year>_std.txt` | **Statistics Presenter** (built-in distributional tables) or post-hoc Stata/R/Python. |
| `EM3Translation/…` copy | **Not exposed** — generated from the legacy XML (refreshed when its MD5 sentinel no longer matches), read by the engine; never edit it. |

When unsure whether to lead with XML or GUI: would the user open a 400,000-line file in Notepad++, or click a GUI panel? Lead with the panel.

## Behavioural rules

1. **Verify by reading; cite `file:line` from the actual model.** Never quote a line number from memory or from another country. Locate the occurrence inside the system block you mean.
2. **Check the matrix cell** for the user's system before describing any policy/function behaviour. If `n/a`/`off`, say it doesn't run and explain what runs instead.
3. **Read the `<Comment>` first** — almost every policy/function/parameter carries inline documentation; grep for the entity and read its comment before improvising meaning. For variable labels, also check `VarConfig.xml` (grep the CDATA form: `<Name><![CDATA[yem]]></Name>`). For what a function's parameters do, use `references/functions_and_syntax.md`, never guess.
4. **Number policies, functions and parameters by `<Order>`, never by position in the XML.** The GUI sorts every level (policies in the spine, functions inside a policy, parameters inside a function) by the `<Order>` element. Document order is frequently different — functions added in later model versions sit at the end of the `<Policy>` block in the XML but carry a small `<Order>` and are displayed near the top. Counting elements as they appear in the file (or as `grep` prints them) therefore gives wrong numbers: "function 5" ends up being the GUI's function 3, "the 5th income list" is actually the 13th, and training material or instructions built on such numbers send the user to the wrong row. Before writing *any* "row N.M", "function k", "the third BenCalc" or "the Nth income list", run `python3 scripts/spine.py <CC>.xml <SYSTEM> [<policy>]` (in this skill's folder) and take the numbers from its output. If the GUI's display filters could still make the count ambiguous, name the policy/function instead of numbering it.
5. **Grep case-insensitively** for policy/variable names — casing varies between models (e.g. a constants policy may be `ConstDef_gh`, not `constdef_gh`). Preserve as-found casing in citations.
6. **Distinguish convention from country-specific.** SOUTHMOD Modelling Conventions are labelled Essential/Desirable — pass the label through. Flag anything country-specific as something to read from the model, not assert.
7. **Reform = clarify the pattern.** A one-off study reform → clone the system (the usual case); a persistent shipped on/off toggle → add an Extension; a quick sensitivity check from Python/Stata → override constants or switches at run time (record provenance; clone before reporting). Ask which; don't default to an Extension. Mechanics in `references/running_and_analysis.md` §5.
8. **Sanity-check a parameter exists before proposing a reform.** Many natural reforms ("double the VAT registration threshold") aren't a single `<Value>` edit because the construct isn't modelled. Grep for it first; surface the gap.
9. **Don't invent** uprating factors, income-list members, parameter values, datasets, or programmes — discover them. If absent, say so.
10. **Equivalisation default, stated honestly:** use the `ses` column from output, weighted by `[aw=dwt]`; `ses` is the national scale by default but a model may override it (off-by-default) to `ses01`/`ses02`, and analysts can use any scale post hoc. Explain why these usually coincide and when they don't; never claim `ses01`/`ses02` can't drive poverty/Gini.
11. **Legacy vs EM3:** edits go through the legacy `XMLParam/` XML; `EM3Translation/` is generated and **read-only**. Never script-edit `XMLParam/` while EUROMOD has the model open (`XMLParam/Temp/*_in_use.txt`): a later GUI save overwrites the edit.
12. **Watch data-vintage shifts:** the same COICOP `x*`/`q*` code can be reassigned across survey vintages; confirm meaning via the per-system `<Comment>`, never from the code alone.
13. **Surface unknowns instead of fabricating.** If a needed artifact is absent, say what you can't determine and offer to read it if provided.
14. **A reform's fiscal effect ≠ the instrument you changed.** When comparing a reform to baseline, never report only the edited instrument's change (e.g. "the PIT cut costs ΔPIT") as the cost to government. Other aggregates move in the same run through in-model interactions — contributions levied on net-of-tax or income-banded bases, means-tested benefits assessed on disposable income, indirect taxes via a consumption response. Difference *every* fiscal aggregate (`ils_tax`, `ils_sic`, `ils_ben`, `ils_taxco`, `ils_benco`) between the two output files, report the **net**, and explain each second-round movement (or confirm the others were unchanged). Same caution for poverty/inequality — it flows through whichever concept actually moved. Procedure in `references/running_and_analysis.md` §5b.
15. **UN English, minimal hyphens** — "income tax policy" not "income-tax policy"; keep canonical SOUTHMOD spelling ("equivalised", "uprating", "modelling", "post-fiscal").
16. **Extensions bind whole rows across all systems.** Never bind a single system's cell of an existing policy/function row to an extension (e.g. FYA only in one year): EUROMOD ignores it and the element does not run. Give the year-specific variant its own row (`switch` where it applies, `n/a` elsewhere) and bind that row in **every** system, including the `n/a` cells and above all the **first `<System>` in the file** (EM3 takes row identity and bindings from that system, which is not necessarily the earliest year): a row bound only in some systems is ignored silently, with no log warning. Or use `<Extension_Parameter>` pairs (also bound in every system) or paired `DefConst` rows. After the run, verify in the output that the row had its effect. Details in `references/architecture_and_conventions.md` §6.
17. **Model-editing hygiene.** One simulated variable per corresponding policy (don't produce a new instrument inside another instrument's policy or reuse its row in later columns). Row comments must hold for every system column. Use `#_Level` footnotes only when a condition aggregates over another unit. Any variable read downstream must be computed in every system where the reader runs. After an edit, check the run log for "not initialised" and "unused footnote" warnings.
18. **Base-year consistency: `yds` = `ils_dispyki`.** In every base-year system (system year = dataset year), the input `yds` must equal the simulated `ils_dispyki` from that system's default output, person by person, so that `ils_con` = `xhh` in the base year. It is the last data-prep step (e.g. RWAMOD Stage 9: `drop yds`, `rename ils_dispyki yds`) and must be redone after any model change that moves disposable income in a base-year system, followed by a rerun. Check it before calling a model final: same people in input and output, and max |`yds` − `ils_dispyki`| within the export precision (e.g. the `policy_update` skill's `scripts/replace_yds.py --check`, which fails on unmatched or duplicate IDs). Read the model's `ils_con` definition before treating `ils_con` = `xhh` as a test.
19. **Post-fiscal poverty lines are net of indirect benefits too.** A post-fiscal line (`splpf`, e.g. `$povline_indir`, `$pline_*_pf`) is the line minus the unweighted mean equivalised **net** indirect tax, `(ils_taxco - ils_benco)/ses`, of households with equivalised `ils_con` within ±2.5% of the line (the usual SOUTHMOD convention: read the model's own grouping, weighting and equivalence-scale storage before recomputing), because post-fiscal income is `ils_dispy - ils_taxco + ils_benco`. Recompute it per system (indirect taxes and subsidies change by year) and after any change to indirect taxes, indirect benefits (e.g. fuel subsidies) or base-year data. Constants uprated in the model by a CPI factor must be divided by that factor before being written back.

20. **Results land on the head of the assessment unit.** A function's result is stored on the head of its `TAX_UNIT`; with `Output_Var` every other member (and every non-eligible unit) is set to 0, and a later `Output_Var` on the same variable wipes earlier values (`Output_Add_Var` accumulates). A household-level benefit therefore sits on one row per household. Elig (per person) and Allocate (redistributes) are the exceptions. `functions_and_syntax.md` §1.
21. **An `Elig` result is used only through `Who_Must_Be_Elig`.** Its default is `nobody`: a function without it runs for every unit and ignores the eligibility variable. Check this before explaining who receives a benefit.
22. **Convert period suffixes before comparing values.** The engine works monthly: `#y` ÷ 12, `#q` ÷ 3, `#w` × 4.34, `#d` × 30.5, `#l` × 21.73, `#s` × 26.07; `#…r` marks a non-monetary rate. Compare with the law or the Country Report only after converting. `DefVar` variables are monetary (summed over the tax unit) unless `Var_Monetary = no`.
23. **Random draws need stable input.** Models with `RandSeed` allocate some outcomes randomly; the same seed reproduces them only for the same records in the same order. When results move after an input revision with no policy change, check this before anything else.
24. **Policy time point is model-specific.** Most models describe rules on 30 June/1 July of the policy year; some use 1 January (e.g. VNMOD). Read it from the Country Report and system comments, never assume.

## Bundled script

`scripts/spine.py` prints a system's spine exactly as the GUI numbers it (policies `N`, functions `N.M` and, for one policy, parameters `N.M.K`, all sorted by `<Order>`, with switches and comments). Rows bound to an extension are marked `{EXT:<name>, base off|ext only}`; the system list marks the first `<System>` in the file; `--grep PATTERN` finds rows by name, value or comment. It needs only the Python standard library. Run it before quoting any row/function/parameter number; it also gives a quick one-screen orientation of any model.

```bash
python3 ~/.claude/skills/southmod/scripts/spine.py <B>/XMLParam/Countries/<CC>/<CC>.xml               # systems
python3 ~/.claude/skills/southmod/scripts/spine.py <B>/XMLParam/Countries/<CC>/<CC>.xml <CC>_2025     # numbered spine
python3 ~/.claude/skills/southmod/scripts/spine.py <B>/XMLParam/Countries/<CC>/<CC>.xml <CC>_2025 tin_<cc>   # one policy with parameters
python3 ~/.claude/skills/southmod/scripts/spine.py <B>/XMLParam/Countries/<CC>/<CC>.xml <CC>_2025 --grep 'minwage'   # search rows
```

## Reference router

For the full annual policy update of a model (research, new systems, reruns, yds, post-fiscal lines, country report in tracked changes, input data and DRDs, SM_LOG, team package), use the companion **`policy_update`** skill together with this one.


Five reference files carry the detail. Load the one you need:

- **`references/architecture_and_conventions.md`** — universal "what it is": the System→Policy→Function→Parameter hierarchy, the EUROMOD function set, the variable naming taxonomy, the policy spine (with verified universal/near-universal/conditional policies), the modelling conventions (income lists, tax units, uprating, equivalence scales, reported-vs-simulated, extensions), and the configuration-XML schema. Load for "what is X / how is the model structured / what does this convention mean".
- **`references/exploration_playbook.md`** — the core "how to understand ANY model": Step 0 artifact discovery & routing (the entry point), then orient → row N.M → comments → matrix cell → constants → income lists/uprating/variables → vintage shifts → cite. Includes a verified, copy-pasteable grep recipe card. Load for any model-specific task.
- **`references/functions_and_syntax.md`** — how the engine evaluates a model: assessment units and where results are stored, VOID values, common parameters and their defaults (`Who_Must_Be_Elig`, limits, `Run_Cond`, switch states), formula syntax and operator precedence, period suffixes, footnotes, queries (with hard-wired variable codings to check), identifiers, and each function (BenCalc, SchedCalc, DefTu, Uprate, DefOutput, Allocate, RandSeed, ChangeParam, ...). Load whenever explaining, checking or writing a function's parameters.
- **`references/running_and_analysis.md`** — universal procedure: getting/installing/running EUROMOD, logs, debugging, the Statistics Presenter, computing equivalised income / poverty (national and international lines) / Gini from an output dataset, authoring a reform (clone, Extension, script-only), fiscal effects, and Shapley decomposition by instrument. Load for "how do I run / analyse / reform / install".
- **`references/connectors.md`** — running models from Python (`euromod` package) or Stata (EUROMOD connector): versions and platforms, run options (constant overrides, extension switches, custom output, breakpoints), pitfalls, and provenance for script-only runs. Load for any request to run or loop over a model from code.

## File-path templates (relative to the bundle root containing `XMLParam/`)

Substitute `<CC>`/`<cc>`; never hardcode an absolute path or a line count (these vary by model and by extract).

- Country model (legacy, editable): `XMLParam/Countries/<CC>/<CC>.xml`
- Country model (EM3, read-only): `EM3Translation/XMLParam/Countries/<CC>/<CC>.xml`
- DataConfig (systems + datasets + extensions): `XMLParam/Countries/<CC>/<CC>_dataconfig.xml`
- Variable dictionary: `XMLParam/Config/VarConfig.xml`
- Shared uprating series: `XMLParam/Config/HICPConfig.xml`
- Exchange rates: `XMLParam/Config/ExchangeRatesConfig.xml`
- Bundle label (not the software version): `XMLParam/Config/EuromodVersion.txt`; software version that last saved the project: `<UIVERSION>` in `XMLParam/Temp/EMConfig*.xml`
- GUI working copies and lock files (present while a model is open): `XMLParam/Temp/astmp_<CC>.xml`, `*_in_use.txt`
- Input data: `Input/<cc>_<year>_a<n>.txt`  ·  Output: `Output/<cc>_<year>_std.txt`
- Country Report / DRD / review code / docs: ship alongside the bundle under model-specific or shared `docs`/`review` folders — discover by globbing (`CR-*.pdf`, `DRD_<CC>_*.xls*`, `*_checks.do`).

## Final reminder

This skill's job is to **understand the model in front of the user by reading it**, then explain it in modeller's language with citations — not to recite memorised country facts. If the open material doesn't show it and you can't read it, say so and offer to look once the file is provided. Surface open questions rather than glossing them.
