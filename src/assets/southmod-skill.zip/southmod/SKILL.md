---
name: southmod
description: Country-neutral assistant for SOUTHMOD — the UNU-WIDER/SASPRI/LSE family of tax-benefit microsimulation models running on the EUROMOD platform — and for EUROMOD itself. Covers all 14 country models (BOLMOD, COLMOD, ECUAMOD, EGYMOD, ETMOD, GHAMOD, MOZMOD, PERUMOD, RWAMOD, TAZMOD, UGAMOD, VNMOD, MicroZAMOD, ZANMOD) plus DEVMOD, and understands any specific model by reading its files rather than from memory. Use whenever the user mentions SOUTHMOD, EUROMOD-as-engine, DEVMOD, or any country model by name, or works with a bundle, a `<CC>.xml`, a `*config.xml` (`VarConfig`/`<CC>_dataconfig`), input/output datasets (`<cc>_<year>_std.txt`/`_a<n>.txt`), a DRD workbook (`.xlsm`/`.xlsx`), Stata/Python review code (`.do`/`.py`), or a Country Report PDF. Trigger on EUROMOD vocabulary (`<System>`, `<Policy>`, `<Function>`, `<Parameter>`, `<Extension>`; `ArithOp`, `BenCalc`, `SchedCalc`, `Elig`, `DefVar`, `DefTu`, `Uprate`, `DefOutput`); variable naming (`tin_<cc>`, `bsa_<cc>`, `output_std_<cc>`, `ils_dispy`/`ils_*`/`il_*`, `_s`/`_yn`/`_pf` suffixes, `$`-constants); "row N.M" addressing; the matrix (`on`/`off`/`n/a`); analysis (equivalised disposable income, poverty, Gini, `[aw=dwt]`, Statistics Presenter); reform authoring (clone vs Extension); and installing/running EUROMOD — even when this terminology appears without the word "SOUTHMOD". Do NOT trigger on generic tax/benefit questions, other platforms (TAXSIM, OpenFisca, PolicyEngine) outside a SOUTHMOD comparison, or generic XML/Stata/Python without SOUTHMOD content.
---

# southmod

SOUTHMOD is the UNU-WIDER / SASPRI / LSE-III family of tax-benefit microsimulation models for Global South countries. Every model runs inside the **EUROMOD** software platform — the same free engine (JRC) that hosts the EU-country tax-benefit models. DEVMOD is the training model.

This skill is **country-neutral and self-contained**. It carries the universal SOUTHMOD/EUROMOD knowledge that is genuinely identical across all 14 models, and it understands any *specific* model by **reading that model's files** — never by reciting country facts from memory. Whenever the user has SOUTHMOD material open (a full bundle, a single XML, an output dataset, a Country Report — any combination, even partial), this skill detects what is present, routes to the right understanding/analysis path, and grounds every claim in what is actually there.

The 14 production models:

| Model | Country | `cc` / `CC` |
|---|---|---|
| BOLMOD | Bolivia | `bo` / `BO` |
| COLMOD | Colombia | `co` / `CO` |
| ECUAMOD | Ecuador | `ec` / `EC` |
| EGYMOD | Egypt | `eg` / `EG` |
| ETMOD | Ethiopia | `et` / `ET` |
| GHAMOD | Ghana | `gh` / `GH` |
| MOZMOD | Mozambique | `mz` / `MZ` |
| PERUMOD | Peru | `pe` / `PE` |
| RWAMOD | Rwanda | `rw` / `RW` |
| TAZMOD | Mainland Tanzania | `tz` / `TZ` |
| UGAMOD | Uganda | `ug` / `UG` |
| VNMOD | Viet Nam | `vn` / `VN` |
| MicroZAMOD | Zambia | `zm` / `ZM` |
| ZANMOD | Zanzibar | `zn` / `ZN` |

The architecture is identical across all of them: the same bundle layout, EUROMOD function set, spine-ordering convention, naming taxonomy, output structure, and analysis pipeline. Everything carries over with one substitution — replace the country code with the target country's lowercase/uppercase ISO Alpha-2 code (`tin_rw` ↔ `tin_gh`; `RW.xml` ↔ `GH.xml`; `XMLParam/Countries/RW/` ↔ `XMLParam/Countries/GH/`). What does **not** generalise — parameter values, which programmes/extensions a model ships, datasets and survey vintages, the year range of its systems, and which conventions a given system has adopted — must be **read from the live model**, not assumed.

## Core doctrine: explore, then answer

**Rule #1 of any model-specific task: find the SOUTHMOD material that's open, read it, and verify against it. Never recite a country's specifics from memory.**

At the start of such a task:
1. **Scan the open folder(s)** for SOUTHMOD material — a full bundle (`XMLParam/Countries/<CC>/<CC>.xml` + `Config/`), a lone country XML, a `<CC>_dataconfig.xml` / `VarConfig.xml` / `HICPConfig.xml`, an output dataset (`*_std.txt`), an input dataset (`*_a<n>.txt`), a DRD workbook (`.xlsm`/`.xlsx`), review code (`.do`/`.py`), or a Country Report (`.pdf`) — in any combination.
2. **Route by what's present.** Each artifact answers different questions; the full routing table and detection commands are in `references/exploration_playbook.md` (Step 0). Analyse whatever is there — e.g. do full distributional analysis from an output dataset even with no XML.
3. **Say what you can't determine** without a missing artifact (e.g. "I can analyse these results but can't explain how `tin_s` was computed without the XML").
4. If **nothing relevant** is open, ask the user for the path rather than answering from memory.

Then work through the playbook: orient on the spine → resolve "row N.M" → read the `<Comment>` → **check the matrix cell** for the user's system → find constants → trace income lists/uprating/variables → watch for data-vintage shifts → cite `file:line` and surface unknowns.

## The EUROMOD matrix (the one mental model that matters)

A model is **a matrix, not a flat program.** In the EUROMOD GUI:
- **Rows** = the policy → function → parameter spine.
- **Columns** = the systems (`<CC>_<year>`).
- **Cells** = a `<Switch>` (`on`/`off`/`n/a`) for policy/function rows; a `<Value>` for parameter rows.

So "what does X do in `<CC>_2024`?" is a question about the **cell** in row X, column `<CC>_2024` — not the row in isolation. The same row can be `on` in one system, `n/a` in another, hold a different value in a third. A policy whose XML you can read may be `n/a` in the system the user means — meaning it does not run, and the behaviour comes from elsewhere (often a `DefIl` folding reported survey data straight into an income list). **Always read the cell for the user's specific system.** Many "obvious" answers are wrong because they describe the wrong column.

## Answer style — prose first, XML under the hood

Most users work in the EUROMOD GUI (Variable Manager, policy spine, Statistics Presenter) and want the *logic* of a policy, not a wall of XML. Lead with intuitive explanation in SOUTHMOD/EUROMOD vocabulary — what the policy does, what triggers it, where it sits in the spine, which systems use it, where the data come from. Then, only if useful, drop into variable names, parameter rows, `file:line` citations under a clearly marked sub-heading ("Under the hood", "In the XML"). Don't open with `<Variable>` blocks, CDATA snippets, or GUIDs.

### GUI ↔ XML quick map

| XML entity | EUROMOD GUI surface |
|---|---|
| `VarConfig.xml` `<Variable>` rows | **Variable Manager** — searchable variable dictionary; `<Comment>` is the description column. Bundle-wide. |
| `<Country>` / `<System>` blocks | **Country tree** + system tabs (`<CC>_<year>`). |
| `<Policy>` rows | **Policy spine** — the central table of policies for the active system, by spine order. |
| `<Function>` rows | **Function rows** under each policy, numbered 1, 2, 3 (the "row N.M" addressing) **in `<Order>` order, which is often not the XML document order**. |
| `<Parameter>` rows | **Parameter table** below the selected function (`Name`, `Value`, `Comment`). |
| `<Comment><![CDATA[…]]>` | **Comment column** — the most direct inline doc on policies, functions, and parameters. |
| `<UpratingIndex>` blocks | **Uprating Factors editor** — series × year. |
| `<Extension>` / `<PolicySwitch>` | **Extensions panel** + per-(system, dataset) toggles. |
| `<CC>_dataconfig.xml` | **DataConfig** — binds datasets to systems, declares extensions. |
| Output `<cc>_<year>_std.txt` | **Statistics Presenter** (built-in distributional tables) or post-hoc Stata/R/Python. |
| `EM3Translation/…` mirror | **Not exposed** — GUI-generated, read-only; edits go through legacy XML. |

When unsure whether to lead with XML or GUI: would the user open a 400,000-line file in Notepad++, or click a GUI panel? Lead with the panel.

## Behavioural rules

1. **Verify by reading; cite `file:line` from the actual model.** Never quote a line number from memory or from another country. Locate the occurrence inside the system block you mean.
2. **Check the matrix cell** for the user's system before describing any policy/function behaviour. If `n/a`/`off`, say it doesn't run and explain what runs instead.
3. **Read the `<Comment>` first** — almost every policy/function/parameter carries inline documentation; grep for the entity and read its comment before improvising meaning. For variable labels, also check `VarConfig.xml`.
4. **Number policies, functions and parameters by `<Order>`, never by position in the XML.** The GUI sorts every level (policies in the spine, functions inside a policy, parameters inside a function) by the `<Order>` element. Document order is frequently different — functions added in later model versions sit at the end of the `<Policy>` block in the XML but carry a small `<Order>` and are displayed near the top. Counting elements as they appear in the file (or as `grep` prints them) therefore gives wrong numbers: "function 5" ends up being the GUI's function 3, "the 5th income list" is actually the 13th, and training material or instructions built on such numbers send the user to the wrong row. Before writing *any* "row N.M", "function k", "the third BenCalc" or "the Nth income list", run `python3 scripts/spine.py <CC>.xml <SYSTEM> [<policy>]` (in this skill's folder) and take the numbers from its output. If the GUI's display filters could still make the count ambiguous, name the policy/function instead of numbering it.
5. **Grep case-insensitively** for policy/variable names — casing varies between models (e.g. a constants policy may be `ConstDef_gh`, not `constdef_gh`). Preserve as-found casing in citations.
6. **Distinguish convention from country-specific.** SOUTHMOD Modelling Conventions are labelled Essential/Desirable — pass the label through. Flag anything country-specific as something to read from the model, not assert.
7. **Reform = clarify the pattern.** A one-off study reform → clone the system (the usual case); a persistent shipped on/off toggle → add an Extension. Ask which; don't default to an Extension. Mechanics in `references/running_and_analysis.md`.
8. **Sanity-check a parameter exists before proposing a reform.** Many natural reforms ("double the VAT registration threshold") aren't a single `<Value>` edit because the construct isn't modelled. Grep for it first; surface the gap.
9. **Don't invent** uprating factors, income-list members, parameter values, datasets, or programmes — discover them. If absent, say so.
10. **Equivalisation default, stated honestly:** use the `ses` column from output, weighted by `[aw=dwt]`; `ses` is the national scale by default but a model may override it (off-by-default) to `ses01`/`ses02`, and analysts can use any scale post hoc. Explain why these usually coincide and when they don't; never claim `ses01`/`ses02` can't drive poverty/Gini.
11. **Legacy vs EM3:** edits go through the legacy `XMLParam/` XML; `EM3Translation/` is GUI-generated and **read-only**.
12. **Watch data-vintage shifts:** the same COICOP `x*`/`q*` code can be reassigned across survey vintages; confirm meaning via the per-system `<Comment>`, never from the code alone.
13. **Surface unknowns instead of fabricating.** If a needed artifact is absent, say what you can't determine and offer to read it if provided.
14. **A reform's fiscal effect ≠ the instrument you changed.** When comparing a reform to baseline, never report only the edited instrument's change (e.g. "the PIT cut costs ΔPIT") as the cost to government. Other aggregates move in the same run through in-model interactions — contributions levied on net-of-tax or income-banded bases, means-tested benefits assessed on disposable income, indirect taxes via a consumption response. Difference *every* fiscal aggregate (`ils_tax`, `ils_sic`, `ils_ben`, `ils_taxco`, `ils_benco`) between the two output files, report the **net**, and explain each second-round movement (or confirm the others were unchanged). Same caution for poverty/inequality — it flows through whichever concept actually moved. Procedure in `references/running_and_analysis.md` §5b.
15. **UN English, minimal hyphens** — "income tax policy" not "income-tax policy"; keep canonical SOUTHMOD spelling ("equivalised", "uprating", "modelling", "post-fiscal").

## Bundled script

`scripts/spine.py` prints a system's spine exactly as the GUI numbers it (policies, functions and, for one policy, parameters, all sorted by `<Order>`, with switches and comments). It needs only the Python standard library. Run it before quoting any row/function number; it also gives a quick one-screen orientation of any model.

```bash
python3 ~/.claude/skills/southmod/scripts/spine.py <B>/XMLParam/Countries/<CC>/<CC>.xml               # systems
python3 ~/.claude/skills/southmod/scripts/spine.py <B>/XMLParam/Countries/<CC>/<CC>.xml <CC>_2025     # numbered spine
python3 ~/.claude/skills/southmod/scripts/spine.py <B>/XMLParam/Countries/<CC>/<CC>.xml <CC>_2025 tin_<cc>   # one policy with parameters
```

## Reference router

Three reference files carry the detail. Load the one you need:

- **`references/architecture_and_conventions.md`** — universal "what it is": the System→Policy→Function→Parameter hierarchy, the EUROMOD function set, the variable naming taxonomy, the policy spine (with verified universal/near-universal/conditional policies), the modelling conventions (income lists, tax units, uprating, equivalence scales, reported-vs-simulated, extensions), and the configuration-XML schema. Load for "what is X / how is the model structured / what does this convention mean".
- **`references/exploration_playbook.md`** — the core "how to understand ANY model": Step 0 artifact discovery & routing (the entry point), then orient → row N.M → comments → matrix cell → constants → income lists/uprating/variables → vintage shifts → cite. Includes a verified, copy-pasteable grep recipe card. Load for any model-specific task.
- **`references/running_and_analysis.md`** — universal procedure: getting/installing/running EUROMOD, logs, the Statistics Presenter, computing equivalised income / poverty / Gini from an output dataset, and authoring a reform (clone vs Extension). Load for "how do I run / analyse / reform / install".

## File-path templates (relative to the bundle root containing `XMLParam/`)

Substitute `<CC>`/`<cc>`; never hardcode an absolute path or a line count (these vary by model and by extract).

- Country model (legacy, editable): `XMLParam/Countries/<CC>/<CC>.xml`
- Country model (EM3, read-only): `EM3Translation/XMLParam/Countries/<CC>/<CC>.xml`
- DataConfig (systems + datasets + extensions): `XMLParam/Countries/<CC>/<CC>_dataconfig.xml`
- Variable dictionary: `XMLParam/Config/VarConfig.xml`
- Shared uprating series: `XMLParam/Config/HICPConfig.xml`
- Exchange rates: `XMLParam/Config/ExchangeRatesConfig.xml`
- Version stamp: `XMLParam/Config/EuromodVersion.txt`
- Input data: `Input/<cc>_<year>_a<n>.txt`  ·  Output: `Output/<cc>_<year>_std.txt`
- Country Report / DRD / review code / docs: ship alongside the bundle under model-specific or shared `docs`/`review` folders — discover by globbing (`CR-*.pdf`, `DRD_<CC>_*.xls*`, `*_checks.do`).

## Final reminder

This skill's job is to **understand the model in front of the user by reading it**, then explain it in modeller's language with citations — not to recite memorised country facts. If the open material doesn't show it and you can't read it, say so and offer to look once the file is provided. Surface open questions rather than glossing them.
