"""Synthetic tests for model_qa.py and em_cli.py (offline parts). Run: python3 -m pytest -q tests/"""
import csv
import json
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent / 'scripts'
sys.path.insert(0, str(HERE))
import em_cli  # noqa: E402

GID = iter(range(10 ** 6))


def gid():
    return f'00000000-0000-0000-0000-{next(GID):012d}'


def par(name, value, group='', comment=''):
    return (f'<Parameter><ID>{gid()}</ID><Name>{name}</Name><Comment><![CDATA[{comment}]]></Comment>'
            f'<Value><![CDATA[{value}]]></Value><Order>{next(GID)}</Order><Group>{group}</Group></Parameter>')


def fun(name, pars, switch='on', comment=''):
    return (f'<Function><ID>{gid()}</ID><Name>{name}</Name><Comment><![CDATA[{comment}]]></Comment>'
            f'<Order>{next(GID)}</Order><Switch>{switch}</Switch>{"".join(pars)}</Function>')


def system(name, consts, bands, formula='yem*12'):
    pols = [
        f'<Policy><ID>{gid()}</ID><Name>constdef_tt</Name><Order>1</Order><Switch>on</Switch>'
        + fun('DefConst', [par(k, v) for k, v in consts]) + '</Policy>',
        f'<Policy><ID>{gid()}</ID><Name>tin_tt</Name><Order>2</Order><Switch>on</Switch>'
        + fun('ArithOp', [par('Formula', formula)])
        + fun('SchedCalc', [par('Base', 'yem')] + [par(n, v, g) for n, v, g in bands]) + '</Policy>']
    return f'<System><ID>{gid()}</ID><Name>{name}</Name><Order>1</Order>{"".join(pols)}</System>'


GOOD = [('Band_UpLim', '2820000#y', '1'), ('Band_Rate', '0', '1'),
        ('Band_UpLim', '4020000#y', '2'), ('Band_Rate', '0.1', '2'),
        ('Band_UpLim', '4920000#y', '3'), ('Band_Rate', '0.2', '3'),
        ('Band_Rate', '0.3', '4')]


def model(systems):
    return ('﻿<CountryConfig xmlns="http://euromod.com/CountryConfig.xsd"><Country><Name>TT</Name>'
            + ''.join(systems) + '</Country></CountryConfig>')


def run_qa(tmp, systems, *extra):
    x = Path(tmp) / 'TT.xml'
    x.write_text(model(systems), encoding='utf-8')
    out = Path(tmp) / 'f.csv'
    r = subprocess.run([sys.executable, str(HERE / 'model_qa.py'), str(x), '--csv', str(out), *extra],
                       capture_output=True, text=True)
    return r.returncode, list(csv.DictReader(open(out)))


def has(rows, sev, check, text):
    return any(r['severity'] == sev and r['check'] == check and text in r['message'] for r in rows)


def test_clean_model_passes():
    with tempfile.TemporaryDirectory() as t:
        rc, rows = run_qa(t, [system('TT_2023', [('$a', '100#m')], GOOD),
                              system('TT_2024', [('$a', '100#m')], GOOD)])
        assert rc == 0
        assert not [r for r in rows if r['severity'] in ('error', 'check')]


def test_band_errors():
    bad = [('Band_UpLim', '2820000#y', '1'), ('Band_Rate', '0', '1'),
           ('Band_LowLim', '2900000#y', '2'),                                  # gap after band 1
           ('Band_UpLim', '2000000#y', '2'), ('Band_Rate', '2', '2'),          # falling limit, rate > 1
           ('Band_UpLim', '4920000#y', '3'),                                   # no rate for band 3
           ('Band_Rate', '0.1', '5')]                                          # group 4 missing
    with tempfile.TemporaryDirectory() as t:
        rc, rows = run_qa(t, [system('TT_2024', [], bad)])
        assert rc == 1
        for text in ('gap between band 1', 'rate 2 is outside', 'not above band 1', 'band 3 has no rate',
                     'band groups are [1, 2, 3, 5]'):
            assert has(rows, 'error', 'bands', text), text


def test_period_checks():
    mixed = GOOD[:2] + [('Band_UpLim', '3350000#y', '2'), ('Band_Rate', '0.1', '2')] + GOOD[4:]
    with tempfile.TemporaryDirectory() as t:
        rc, rows = run_qa(t, [system('TT_2023', [('$a', '100#m'), ('$b', '2350000#y')], GOOD),
                              system('TT_2024', [('$a', '100#y'), ('$b', '2820000#y')], mixed, formula='yem*10')])
        assert has(rows, 'error', 'period', 'suffix changed')                  # 100#m -> 100#y
        assert has(rows, 'check', 'period', 'is x12/10')                       # 2350000 -> 2820000
        assert has(rows, 'check', 'period', 'formula * 10')
        assert has(rows, 'check', 'period', 'is 10 x 335,000')                 # one limit 10 x monthly


def test_changes_documented_and_reversal():
    with tempfile.TemporaryDirectory() as t:
        docs = Path(t) / 'smlog.txt'
        docs.write_text('2024: $a raised to 120 per month (Finance Act 2024)\n')
        rc, rows = run_qa(t, [system('TT_2023', [('$a', '100#m'), ('$c', '5')], GOOD),
                              system('TT_2024', [('$a', '120#m'), ('$c', '6')], GOOD),
                              system('TT_2025', [('$a', '120#m'), ('$c', '5')], GOOD),
                              system('TT_2025_reform', [('$a', '200#m'), ('$c', '5')], GOOD)],
                          '--docs', str(docs))
        assert has(rows, 'info', 'changes', 'documented: docs')               # $a explained by the log
        assert has(rows, 'check', 'changes', '5 -> 6; no comment')             # $c not explained
        assert has(rows, 'check', 'changes', 'changes for one year only')      # $c 5 -> 6 -> 5
        assert any(r['check'] == 'reform' and '200#m' in r['message'] for r in rows)


def test_em_cli_patch_constants_and_log():
    with tempfile.TemporaryDirectory() as t:
        x = Path(t) / 'TT.xml'
        x.write_text(model([system('TT_2024', [('$a', '100#m'), ('$b', '5')], GOOD)]), encoding='utf-8')
        rec = em_cli.patch_constants(x, {'TT_2024'}, [('$a', None, '150#m')])
        assert rec[0]['old'] == '100#m' and rec[0]['new'] == '150#m'
        raw = x.read_bytes()
        assert raw.startswith(b'\xef\xbb\xbf') and b'<![CDATA[150#m]]>' in raw and b'<![CDATA[5]]>' in raw
        d = Path(t) / 'job'
        d.mkdir()
        (d / 'tt_2024_std.txt').write_text('idperson\tils_dispy\n1\t10\n')
        md5 = em_cli.sha256(d / 'tt_2024_std.txt', 'md5')
        (d / 'x_EUROMOD_Log.txt').write_text(
            'Software-Version: 3.8.9\nRun-Id\tStatus\tSystem\tDatabase\tPOV\tOutput-File\tOutput-Hash\n'
            f'r1\tfinished\tTT_2024\ttt_2024_a1\t1\ttt_2024_std.txt\t{md5}\n')
        (d / 'launch_receipt.txt').write_text('label=x\ninput_sha256=abc\n')
        job = dict(label='x', mode='manual', system='TT_2024', dataset='tt_2024_a1', switches={'POV': 'on'},
                   constants=[], model_sha256='', dataconfig_sha256='', input_sha256='abc',
                   expected_engine='3.8.9', dir=str(d))
        assert em_cli.verify(job)['ok']
        job['switches'] = {'POV': 'off'}
        assert not em_cli.verify(job)['ok']
        job['switches'] = {'POV': 'on'}
        (d / 'tt_2024_std.txt').write_text('changed')
        p = em_cli.verify(job)
        assert not p['ok'] and any('MD5' in q for q in p['problems'])
        assert json.loads((d / 'provenance.json').read_text())['ok'] is False
