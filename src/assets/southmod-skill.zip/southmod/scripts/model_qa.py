#!/usr/bin/env python3
"""Quality checks of a SOUTHMOD/EUROMOD country XML before review: period conversions, tax bands, and
changes between systems that nothing documents.

usage:
  model_qa.py <CC>.xml [--docs FILE ...] [--systems REGEX] [--pair SYS_A SYS_B ...] [--no-variants]
                       [--csv findings.csv] [--md report.md]

Checks (numbering by <Order>, as the GUI and spine.py number rows):
  period   - a formula multiplies or divides by a hand-typed period factor (10, 11, 13, 14 flagged;
             12, 52, 365, 4.33 ... reported as hand-coded conversions)
           - an annual amount (#y) that is round only when divided by 10, 11, 13 or 14, not by 12
           - an amount that changes between systems by a period factor (x12, x10, x1.2, /12 ...)
           - a period suffix changed (#m <-> #y) while the number stayed the same
  bands    - every active SchedCalc: band groups numbered 1..n, a rate or amount for each band, limits
             increasing, no gap or overlap between Band_UpLim(n) and Band_LowLim(n+1), one period suffix
             for all limits, rates in [0, 1], rates that fall in a higher band
  changes  - consecutive base years (<CC>_2023 -> <CC>_2024): each changed value or switch is
             'documented' when a comment on the row, function or policy changed or names the new year,
             or when a --docs file (SM_LOG .xlsx/.csv, report or thesis .docx/.txt/.md/.tex/.pdf) has a
             line naming the row (constant, parameter or policy) together with the new year or new value
           - a value that changes and changes back the next year (A -> B -> A)
           - variants (<CC>_2024_reform vs <CC>_2024, the longest existing prefix) are listed as reform
             cells, not judged; their bands and period factors are still checked
Severity: error (almost surely wrong), check (look at it), info (listed for the reviewer).
Exit codes: 0 no errors, 1 at least one error, 2 invalid input. Standard library only.
"""
import argparse
import csv
import io
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from collections import defaultdict
from pathlib import Path

PERIOD_TO_MONTH = {'y': 1 / 12, 'm': 1.0, 'q': 1 / 3, 'w': 4.34, 'd': 30.5, 'l': 21.73, 's': 26.07}
AMOUNT = re.compile(r'^\s*(-?(?:\d+(?:\.\d+)?|\.\d+))\s*(?:#([ymqwdls]))?\s*$', re.I)
PCT = re.compile(r'^\s*(-?\d+(?:\.\d+)?)\s*%\s*$')
GUID = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.I)
SUSPECT_FACTORS = {'10', '11', '13', '14'}
CONVERSION_FACTORS = {'12', '52', '26', '4.33', '4.34', '4.345', '30', '30.5', '30.4', '360', '365', '366', '21.73'}
FACTOR_RE = re.compile(r'([*/])\s*(\d+(?:\.\d+)?)(?![\d.#%])')
RATIO_NAMES = [(12, 'x12'), (1 / 12, '/12'), (10, 'x10'), (0.1, '/10'), (1.2, 'x12/10'), (10 / 12, 'x10/12'),
               (52 / 12, 'x52/12'), (12 / 52, 'x12/52'), (100, 'x100'), (0.01, '/100')]


def loc(t):
    return t.rsplit('}', 1)[-1]


def kids(e, n):
    return [c for c in e if loc(c.tag) == n]


def tx(e, n):
    c = kids(e, n)
    return (c[0].text or '').strip() if c else ''


def order(e):
    try:
        return float(tx(e, 'Order') or 0)
    except ValueError:
        return 0.0


def read_model(xml):
    """{system: [row dict]} with GUI numbering; rows keyed like policy_update compare_systems."""
    root = ET.parse(xml).getroot()
    systems = {}
    for s in [e for e in root.iter() if loc(e.tag) == 'System']:
        rows, seen = [], defaultdict(int)
        for n, p in enumerate(sorted(kids(s, 'Policy'), key=order), 1):
            for m, f in enumerate(sorted(kids(p, 'Function'), key=order), 1):
                pars = sorted(kids(f, 'Parameter'), key=order)
                base = dict(system=tx(s, 'Name'), pol_no=n, policy=tx(p, 'Name'), pol_switch=tx(p, 'Switch'),
                            pol_comment=tx(p, 'Comment'), fun_no=f'{n}.{m}', function=tx(f, 'Name'),
                            fun_switch=tx(f, 'Switch'), fun_comment=tx(f, 'Comment'))
                rows.append(dict(base, par_no='', parameter='', group='', value='', par_comment='', dup=0,
                                 kind='function'))
                for k, x in enumerate(pars, 1):
                    key = (base['policy'], base['fun_no'], tx(x, 'Name'), tx(x, 'Group'))
                    rows.append(dict(base, par_no=f'{n}.{m}.{k}', parameter=tx(x, 'Name'), group=tx(x, 'Group'),
                                     value=tx(x, 'Value'), par_comment=tx(x, 'Comment'), dup=seen[key],
                                     kind='parameter'))
                    seen[key] += 1
        systems[tx(s, 'Name')] = rows
    return systems


def key(r):
    return (r['policy'], r['fun_no'], r['function'], r['parameter'], r['group'], r['dup'])


def active(r):
    return r['pol_switch'].lower() not in ('n/a', 'off') and r['fun_switch'].lower() not in ('n/a', 'off')


def amount(v):
    """(number, suffix) for a plain amount like 2820001#y, else None."""
    m = AMOUNT.match(v or '')
    return (float(m.group(1)), (m.group(2) or '').lower()) if m else None


def monthly(a):
    num, suf = a
    return num * PERIOD_TO_MONTH[suf] if suf else num


def trailing_zeros(x):
    if x <= 0 or abs(x - round(x)) > 1e-9:
        return -1
    n, z = int(round(x)), 0
    while n and n % 10 == 0:
        n //= 10
        z += 1
    return z


def where(r):
    p = r['par_no'] or r['fun_no']
    name = f"{r['parameter']}" + (f"[{r['group']}]" if r['group'] else '')
    return f"{r['policy']} {p} {r['function']}" + (f' {name}' if name else '')


class Findings:
    def __init__(self):
        self.items = []
        self.seen = {}

    def add(self, sev, check, system, r, msg, value=''):
        # Same finding on the same row in several systems: one entry, systems listed.
        k = (sev, check, where(r) if r else '', msg)
        if k in self.seen:
            self.seen[k]['systems'].append(system)
            return
        item = dict(severity=sev, check=check, systems=[system], where=where(r) if r else '', message=msg,
                    value=value)
        self.seen[k] = item
        self.items.append(item)


# ---------------------------------------------------------------- period checks

def check_periods(systems, F):
    for sysname, rows in systems.items():
        for r in rows:
            if r['kind'] != 'parameter' or not active(r) or not r['value'] or r['value'].lower() == 'n/a':
                continue
            v = r['value']
            if amount(v) is None and re.search(r'[A-Za-z$]', v):
                for op, num in FACTOR_RE.findall(v):
                    if num in SUSPECT_FACTORS:
                        F.add('check', 'period', sysname, r,
                              f'formula {op} {num}: a month-to-year factor other than 12? (use #y/#m suffixes)', v)
                    elif num in CONVERSION_FACTORS:
                        F.add('info', 'period', sysname, r,
                              f'hand-coded period conversion {op} {num}; a #y/#m suffix is safer', v)
            a = amount(v)
            if a and a[1] == 'y' and a[0] >= 10000:
                # A round annual amount always divides cleanly by 10, so x10 is caught by the band and
                # between-system checks; here only factors that make the number rounder than itself.
                x = a[0] - 1 if trailing_zeros(a[0] - 1) > trailing_zeros(a[0]) else a[0]
                for k in (11, 13, 14):
                    if trailing_zeros(x / k) > max(trailing_zeros(x), trailing_zeros(x / 12)):
                        F.add('check', 'period', sysname, r,
                              f'annual amount is {k} x {x / k:,.0f} (not a round 12 x monthly): '
                              f'monthly value multiplied by {k}?', v)
                        break


def monthly_round(x):
    m = x / 12
    return abs(m - round(m)) < 1e-9 and trailing_zeros(m) >= 2


def check_band_periods(sysname, seq, F):
    """Limits of one schedule: most are 12 x a round monthly amount, a few are not -> mixed conversions."""
    ys = [(g, a, r) for g, a, r in seq if a[1] == 'y' and a[0] >= 10000]
    adj = [(g, a[0] - 1 if trailing_zeros(a[0] - 1) > trailing_zeros(a[0]) else a[0], r) for g, a, r in ys]
    good = [t for t in adj if monthly_round(t[1])]
    bad = [t for t in adj if not monthly_round(t[1])]
    if len(good) >= 2 and bad and len(bad) < len(good):
        for g, x, r in bad:
            alt = [k for k in (10, 11, 13, 14) if trailing_zeros(x / k) >= 2]
            hint = f'; it is {alt[0]} x {x / alt[0]:,.0f}' if alt else ''
            F.add('check', 'period', sysname, r,
                  f'band {g} limit {r["value"]} is not 12 x a round monthly amount, unlike the other '
                  f'{len(good)} limits{hint}', r['value'])


# ---------------------------------------------------------------- band checks

def const_table(rows):
    vals = defaultdict(list)
    for r in rows:
        if r['kind'] == 'parameter' and r['function'].lower() == 'defconst' and r['parameter'].startswith('$'):
            vals[r['parameter']].append(r['value'])
    return {k: v[0] for k, v in vals.items() if len(set(v)) == 1}


def resolve(v, consts):
    v = (v or '').strip()
    if v in consts:
        v = consts[v]
    a = amount(v)
    if a:
        return a
    m = PCT.match(v)
    return (float(m.group(1)) / 100, '') if m else None


def check_bands(systems, F):
    for sysname, rows in systems.items():
        consts = const_table(rows)
        funs = defaultdict(list)
        for r in rows:
            if r['kind'] == 'parameter' and r['function'].lower() == 'schedcalc' and active(r):
                funs[(r['policy'], r['fun_no'])].append(r)
        for (pol, fno), pars in funs.items():
            band = defaultdict(dict)
            for r in pars:
                if r['parameter'].lower().startswith('band_') and r['value'].lower() not in ('', 'n/a'):
                    try:
                        g = int(r['group'])
                    except ValueError:
                        continue
                    band[g][r['parameter'].lower()] = r
            if not band:
                continue
            ref = pars[0]
            groups = sorted(band)
            if groups != list(range(1, len(groups) + 1)):
                F.add('error', 'bands', sysname, ref, f'band groups are {groups}, not 1..{len(groups)}')
            for g in groups:
                if not ({'band_rate', 'band_amount'} & set(band[g])):
                    F.add('error', 'bands', sysname, band[g][next(iter(band[g]))], f'band {g} has no rate or amount')
            rates = []
            for g in groups:
                r = band[g].get('band_rate')
                if not r:
                    continue
                a = resolve(r['value'], consts)
                if a is None:
                    continue
                rates.append((g, a[0], r))
                if a[0] < 0 or a[0] > 1:
                    F.add('error', 'bands', sysname, r, f'band {g} rate {r["value"]} is outside [0, 1]', r['value'])
            for (g0, x0, _), (g1, x1, r1) in zip(rates, rates[1:]):
                if 0 <= x1 < x0 <= 1:
                    F.add('check', 'bands', sysname, r1, f'rate falls from {x0:g} (band {g0}) to {x1:g} (band {g1})',
                          r1['value'])
            for lim in ('band_uplim', 'band_lowlim'):
                seq = [(g, resolve(band[g][lim]['value'], consts), band[g][lim]) for g in groups if lim in band[g]]
                seq = [(g, a, r) for g, a, r in seq if a]
                check_band_periods(sysname, seq, F)
                sufs = {a[1] or '(none)' for _, a, _ in seq}
                if len(sufs) > 1:
                    F.add('check', 'bands', sysname, seq[0][2],
                          f'{lim} values mix period suffixes {sorted(sufs)} within one schedule')
                for (g0, a0, _), (g1, a1, r1) in zip(seq, seq[1:]):
                    if monthly(a1) <= monthly(a0):
                        F.add('error', 'bands', sysname, r1,
                              f'{lim} of band {g1} ({r1["value"]}) is not above band {g0}', r1['value'])
            for g in groups[:-1]:
                up, low = band[g].get('band_uplim'), band.get(g + 1, {}).get('band_lowlim')
                if not (up and low):
                    continue
                a, b = resolve(up['value'], consts), resolve(low['value'], consts)
                if not (a and b):
                    continue
                if a[1] == b[1]:
                    d = b[0] - a[0]
                    ok = abs(d) < 1e-9 or abs(d - 1) < 1e-9 or abs(d - 0.01) < 1e-9
                else:
                    d = monthly(b) - monthly(a)
                    ok = abs(d) <= 1
                if not ok:
                    kind = 'gap' if d > 0 else 'overlap'
                    F.add('error', 'bands', sysname, low,
                          f'{kind} between band {g} upper limit {up["value"]} and band {g + 1} lower limit {low["value"]}',
                          low['value'])


# ---------------------------------------------------------------- changes between systems

def pairs_for(names, explicit, variants):
    out = [(a, b, 'pair') for a, b in explicit]
    years = {}
    for n in names:
        m = re.match(r'^([A-Za-z]+)_(\d{4})$', n)
        if m:
            years[int(m.group(2))] = n
    ys = sorted(years)
    out += [(years[a], years[b], 'year') for a, b in zip(ys, ys[1:])]
    if variants:
        nameset = set(names)
        for n in names:
            parts = n.split('_')
            for i in range(len(parts) - 1, 1, -1):
                parent = '_'.join(parts[:i])
                if parent in nameset:
                    out.append((parent, n, 'variant'))
                    break
    return out


def doc_lines(files):
    lines = []
    for f in files:
        p = Path(f)
        suf = p.suffix.lower()
        try:
            if suf == '.docx':
                xml = zipfile.ZipFile(p).read('word/document.xml').decode('utf-8', 'replace')
                for para in re.split(r'</w:p>', xml):
                    t = ''.join(re.findall(r'<w:t[^>]*>([^<]*)</w:t>', para))
                    if t.strip():
                        lines.append(t)
            elif suf in ('.xlsx', '.xlsm'):
                z = zipfile.ZipFile(p)
                shared = []
                if 'xl/sharedStrings.xml' in z.namelist():
                    sx = z.read('xl/sharedStrings.xml').decode('utf-8', 'replace')
                    shared = [''.join(re.findall(r'<t[^>]*>([^<]*)</t>', si)) for si in re.findall(r'<si>(.*?)</si>', sx, re.S)]
                for name in [n for n in z.namelist() if re.match(r'xl/worksheets/sheet\d+\.xml', n)]:
                    sx = z.read(name).decode('utf-8', 'replace')
                    for row in re.findall(r'<row[^>]*>(.*?)</row>', sx, re.S):
                        cells = []
                        for attrs, body in re.findall(r'<c([^>]*)>(.*?)</c>', row, re.S):
                            v = re.search(r'<v>([^<]*)</v>', body)
                            t = re.findall(r'<t[^>]*>([^<]*)</t>', body)
                            if 't="s"' in attrs and v:
                                cells.append(shared[int(v.group(1))])
                            elif t:
                                cells.append(''.join(t))
                            elif v:
                                cells.append(v.group(1))
                        if cells:
                            lines.append(' | '.join(cells))
            elif suf == '.pdf':
                r = subprocess.run(['pdftotext', '-layout', str(p), '-'], capture_output=True, text=True)
                if r.returncode != 0:
                    sys.exit(f'error: cannot read {p} (install poppler pdftotext, or pass a .txt)')
                lines += r.stdout.splitlines()
            else:
                lines += p.read_text(encoding='utf-8', errors='replace').splitlines()
        except (OSError, zipfile.BadZipFile, KeyError) as e:
            sys.exit(f'error: cannot read {p}: {e}')
    return [l.lower() for l in lines]


def year_of(name):
    m = re.search(r'(\d{4})', name)
    return m.group(1) if m else None


def number_forms(v):
    a = amount(v)
    if not a:
        return []
    n = a[0]
    forms = {v.lower(), f'{n:g}'}
    if n == int(n):
        i = int(n)
        forms |= {str(i), f'{i:,}', f'{i:,}'.replace(',', ' '), f'{i:,}'.replace(',', '.')}
    else:
        forms |= {f'{n * 100:g}%', f'{n * 100:g} %', f'{n * 100:g} per cent', f'{n * 100:g} percent'}
    return [f for f in forms if len(f) >= 3 or '%' in f]


def norm(v):
    v = re.sub(r'\s+', '', v or '').lower()
    a = amount(v)
    return f'{a[0]:g}#{a[1]}' if a else v


def short(v, n=70):
    return v if len(v) <= n else v[:n - 3] + '...'


def change_text(old, new, n=70):
    """old -> new, or for long values only the part that differs."""
    if len(old) <= n and len(new) <= n:
        return f'{old} -> {new}'
    i = 0
    while i < min(len(old), len(new)) and old[i] == new[i]:
        i += 1
    j = 0
    while j < min(len(old), len(new)) - i and old[-1 - j] == new[-1 - j]:
        j += 1
    a, b = old[i:len(old) - j], new[i:len(new) - j]
    ctx = old[max(0, i - 25):i]
    return f'...{ctx}[{short(a, 60) or "(nothing)"} -> {short(b, 60) or "(nothing)"}]... (long value, {len(old)} -> {len(new)} chars)'


def documented(old, new, newsys, docs):
    for c in ('par_comment', 'fun_comment', 'pol_comment'):
        if old[c] != new[c]:
            return f'{c.split("_")[0]} comment changed'
    y = year_of(newsys)
    if y:
        pat = re.compile(rf'(?<!\d){y}(?!\d)|(?<!\d){int(y) - 1}[/-]{y[2:]}(?!\d)')
        for c in ('par_comment', 'fun_comment'):
            if pat.search(new[c]):
                return f'{c.split("_")[0]} comment names {y}'
    if not docs:
        return ''
    const = new['parameter'] if new['parameter'].startswith('$') else ''
    const = const or (new['value'] if re.fullmatch(r'\$\w+', new['value']) else '')
    values = number_forms(new['value'])
    for line in docs:
        covers = bool(y) and (re.search(rf'(?<!\d){y}(?!\d)', line) or re.search(r'\ball\b', line) or any(
            int(p) <= int(y) <= int(q) for p, q in re.findall(r'(?<!\d)((?:19|20)\d\d)\s*[-–]\s*((?:19|20)\d\d)(?!\d)', line)))
        if const:
            # A constant must be named itself; the policy alone (often a shared constants policy) is not enough.
            if const.lower() in line and (covers or any(v in line for v in values)):
                return 'docs: ' + line[:80]
        elif new['policy'].lower() in line and covers:
            return 'docs: ' + line[:80]
    return ''


def check_changes(systems, pair_list, docs, F):
    reform = []
    index = {s: {key(r): r for r in rows} for s, rows in systems.items()}
    for a, b, kind in pair_list:
        A, B = index[a], index[b]
        for k in sorted(set(A) | set(B), key=lambda k: (k[0], [int(x) for x in k[1].split('.')], k[3], k[4], k[5])):
            ra, rb = A.get(k), B.get(k)
            r = rb or ra
            if ra is None or rb is None:
                if kind == 'variant':
                    reform.append(dict(base=a, system=b, where=where(r), old='(absent)' if ra is None else short(ra['value']),
                                       new='(absent)' if rb is None else short(rb['value'])))
                else:
                    F.add('check', 'changes', b, r, f'row {"added" if ra is None else "removed"} relative to {a}')
                continue
            if r['function'].lower() == 'defoutput' and r['parameter'].lower() == 'file':
                continue
            if GUID.match(ra['value']) and GUID.match(rb['value']):
                continue
            fields = [f for f in ('value', 'fun_switch', 'pol_switch') if norm(ra[f]) != norm(rb[f])]
            if r['kind'] == 'parameter':
                fields = [f for f in fields if f == 'value']
                # A function that starts, stops or is off is reported once, on its function row.
                if not (active(ra) and active(rb)):
                    continue
            elif fields == ['pol_switch'] and r['fun_no'].split('.')[1] != '1':
                continue
            if not fields:
                continue
            old = ' / '.join(ra[f] for f in fields)
            new = ' / '.join(rb[f] for f in fields)
            if kind == 'variant':
                reform.append(dict(base=a, system=b, where=where(r), old=short(old), new=short(new)))
                continue
            x, y = amount(ra['value']), amount(rb['value'])
            if 'value' in fields and x and y:
                if x[0] == y[0] and x[1] != y[1]:
                    F.add('error', 'period', b, rb, f'suffix changed {ra["value"]} -> {rb["value"]} with the same number '
                          f'(amount changes x{monthly(y) / monthly(x):g})', rb['value'])
                elif monthly(x) and x[1] == y[1] and x[1]:
                    # Growth of ~20% is ordinary uprating, so x12/10 counts only between round amounts
                    # (statutory figures) or when the ratio is exact.
                    ratio = monthly(y) / monthly(x)
                    round_pair = min(trailing_zeros(x[0]), trailing_zeros(y[0])) >= 2
                    for target, label in RATIO_NAMES:
                        tol = 0.001 if round_pair else 1e-6
                        if abs(ratio / target - 1) < tol:
                            F.add('check', 'period', b, rb, f'{a} -> {b}: {ra["value"]} -> {rb["value"]} is {label}',
                                  rb['value'])
                            break
            why = documented(ra, rb, b, docs)
            if why:
                F.add('info', 'changes', b, rb, f'{a} -> {b}: {change_text(old, new)} (documented: {why})', short(new))
            else:
                F.add('check', 'changes', b, rb, f'{a} -> {b}: {change_text(old, new)}; no comment or document explains it',
                      short(new))
    years = [(a, b) for a, b, kind in pair_list if kind == 'year']
    for (a, b), (b2, c) in zip(years, years[1:]):
        if b != b2:
            continue
        for k, rb in index[b].items():
            ra, rc = index[a].get(k), index[c].get(k)
            if ra and rc and rb['kind'] == 'parameter' and norm(ra['value']) == norm(rc['value']) != norm(rb['value']) \
                    and active(ra) and active(rb) and active(rc) and not GUID.match(rb['value']):
                if rb['function'].lower() == 'defoutput':
                    continue
                F.add('check', 'changes', b, rb, f'{short(ra["value"])} ({a}) -> {short(rb["value"])} ({b}) -> {short(rc["value"])} ({c}): '
                      'changes for one year only; typo or temporary measure?', rb['value'])
    return reform


# ---------------------------------------------------------------- report

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('xml')
    ap.add_argument('--docs', nargs='+', default=[])
    ap.add_argument('--systems', help='regex: check only systems whose name matches')
    ap.add_argument('--pair', nargs=2, action='append', default=[], metavar=('SYS_A', 'SYS_B'))
    ap.add_argument('--no-variants', action='store_true')
    ap.add_argument('--csv')
    ap.add_argument('--md')
    a = ap.parse_args()
    try:
        systems = read_model(a.xml)
    except (OSError, ET.ParseError) as e:
        print(f'error: cannot read {a.xml}: {e}', file=sys.stderr)
        sys.exit(2)
    if a.systems:
        systems = {k: v for k, v in systems.items() if re.search(a.systems, k)}
    for s in [s for p in a.pair for s in p]:
        if s not in systems:
            print(f'error: system {s} not in the model (or filtered out)', file=sys.stderr)
            sys.exit(2)
    docs = doc_lines(a.docs)
    F = Findings()
    check_periods(systems, F)
    check_bands(systems, F)
    pl = pairs_for(list(systems), a.pair, not a.no_variants)
    reform = check_changes(systems, pl, docs, F)

    rank = {'error': 0, 'check': 1, 'info': 2}
    items = sorted(F.items, key=lambda i: (rank[i['severity']], i['check'], i['where']))
    if a.csv:
        with open(a.csv, 'w', newline='', encoding='utf-8') as f:
            w = csv.writer(f)
            w.writerow(['severity', 'check', 'systems', 'where', 'message', 'value'])
            for i in items:
                w.writerow([i['severity'], i['check'], ' '.join(i['systems']), i['where'], i['message'], i['value']])
            for r in reform:
                w.writerow(['info', 'reform', r['system'], r['where'], f"{r['base']} -> {r['system']}: {r['old']} -> {r['new']}",
                            r['new']])
    out = io.StringIO()
    n = defaultdict(int)
    for i in items:
        n[(i['severity'], i['check'])] += 1
    out.write(f'# Model QA: {Path(a.xml).name}\n\n{len(systems)} systems; pairs compared: '
              f'{sum(k == "year" for *_, k in pl)} base-year, {sum(k == "variant" for *_, k in pl)} variant, '
              f'{sum(k == "pair" for *_, k in pl)} explicit; docs: {len(a.docs)} file(s), {len(docs)} lines.\n\n')
    out.write('| severity | period | bands | changes |\n|---|---|---|---|\n')
    for sev in ('error', 'check', 'info'):
        out.write(f'| {sev} | ' + ' | '.join(str(n[(sev, c)]) for c in ('period', 'bands', 'changes')) + ' |\n')
    for sev in ('error', 'check'):
        sel = [i for i in items if i['severity'] == sev]
        if not sel:
            continue
        out.write(f'\n## {sev.capitalize()}s\n')
        for chk in ('period', 'bands', 'changes'):
            part = [i for i in sel if i['check'] == chk]
            if not part:
                continue
            out.write(f'\n### {chk} ({len(part)})\n\n')
            if chk == 'changes' and len(part) > 40:
                per = defaultdict(int)
                for i in part:
                    per[i['where'].split(' ')[0]] += 1
                out.write('By policy: ' + ', '.join(f'{k} {v}' for k, v in sorted(per.items(), key=lambda t: -t[1])) + '\n\n')
            limit = 40 if chk == 'changes' else 200
            for i in part[:limit]:
                sy = ', '.join(i['systems'][:4]) + (f' (+{len(i["systems"]) - 4})' if len(i['systems']) > 4 else '')
                out.write(f"- {i['where']} [{sy}]: {i['message']}\n")
            if len(part) > limit:
                out.write(f'- ... {len(part) - limit} more in the CSV (--csv)\n')
    if reform:
        out.write('\n## Reform cells (variant vs parent)\n\n')
        by = defaultdict(list)
        for r in reform:
            by[(r['base'], r['system'])].append(r)
        for (b, s), rs in by.items():
            out.write(f'- {s} vs {b}: {len(rs)} cell(s)' + (': ' + '; '.join(f"{r['where']} {r['old']} -> {r['new']}"
                                                                    for r in rs[:6]) if rs else '')
                      + (' ...' if len(rs) > 6 else '') + '\n')
    text = out.getvalue()
    if a.md:
        Path(a.md).write_text(text, encoding='utf-8')
    print(text)
    sys.exit(1 if n[('error', 'period')] + n[('error', 'bands')] + n[('error', 'changes')] else 0)


if __name__ == '__main__':
    main()
