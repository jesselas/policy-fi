#!/usr/bin/env python3
"""Print a SOUTHMOD/EUROMOD spine exactly as the GUI numbers it.

The GUI sorts policies, functions and parameters by their <Order> element. The XML
document order is frequently different (functions added later are appended at the
end of a <Policy> but given a small <Order>), so NEVER count elements in document
order. Use this script whenever a question involves "row N.M", "function k",
"the third BenCalc", "the 5th income list" and the like.

Usage:
  python3 spine.py <CC>.xml                      # list systems (file order; the first one matters for EM3)
  python3 spine.py <CC>.xml <SYSTEM>             # spine: N. policy [switch]  N.M function [switch]  comment
  python3 spine.py <CC>.xml <SYSTEM> <policy>    # one policy with every function and its parameters (N.M.K)
  python3 spine.py <CC>.xml <SYSTEM> <policy> --all   # same, including parameters of n/a functions
  python3 spine.py <CC>.xml <SYSTEM> --grep PATTERN   # only rows whose name, value or comment match (regex,
                                                      # case-insensitive), searching parameters too

Rows bound to an extension are marked {EXT:<short name>, base off|ext only}: "base off" (BaseOff=true)
means the row is switched off when the extension is on; "ext only" (BaseOff=false) means it runs only
when the extension is on. Short names are read from <CC>_dataconfig.xml next to the model, if present.
"""
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


def local(tag):
    return tag.rsplit('}', 1)[-1]


def child(el, name):
    for c in el:
        if local(c.tag) == name:
            return c
    return None


def text(el, name):
    c = child(el, name)
    return (c.text or '').strip() if c is not None else ''


def order_key(el):
    try:
        return float(text(el, 'Order') or 0)
    except ValueError:
        return 0.0


def bindings(root, xml_path):
    """{element ID: 'EXT, base off|ext only'} for Extension_Policy/Function/Parameter entries."""
    names = {}
    dc = Path(xml_path).with_name(Path(xml_path).stem + '_dataconfig.xml')
    if dc.exists():
        for ext in ET.parse(dc).getroot().iter():
            if local(ext.tag) == 'Extension':
                names[text(ext, 'ID')] = text(ext, 'ShortName')
    out = {}
    for e in root:
        tag = local(e.tag)
        if tag.startswith('Extension_'):
            idtag = tag.split('_', 1)[1] + 'ID'
            eid = text(e, 'ExtensionID')
            kind = 'base off' if text(e, 'BaseOff').lower() == 'true' else 'ext only'
            out.setdefault(text(e, idtag), []).append(f'{names.get(eid, eid[:8])}, {kind}')
    return {k: ' {EXT:' + '; '.join(v) + '}' for k, v in out.items()}


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    pattern = None
    if '--grep' in sys.argv:
        i = sys.argv.index('--grep')
        if i + 1 >= len(sys.argv):
            print('--grep needs a pattern'); sys.exit(2)
        pattern = re.compile(sys.argv[i + 1], re.I)
        args = [a for a in args if a != sys.argv[i + 1]]
    if not args:
        print(__doc__); sys.exit(1)
    tree = ET.parse(args[0])
    root = tree.getroot()
    systems = [s for s in root.iter() if local(s.tag) == 'System']
    if len(args) == 1:
        for k, s in enumerate(systems):
            print(text(s, 'Name') + ('   <- first system in the file' if k == 0 else ''))
        return
    sysname = args[1]
    system = next((s for s in systems if text(s, 'Name') == sysname), None)
    if system is None:
        print(f'system {sysname} not found; available: ' + ', '.join(text(s, 'Name') for s in systems)); sys.exit(1)
    ext = bindings(root, args[0])
    policies = sorted([p for p in system.iter() if local(p.tag) == 'Policy'], key=order_key)
    want = args[2].lower() if len(args) > 2 else None
    show_na = '--all' in sys.argv

    def hit(*fields):
        return pattern is None or any(pattern.search(f or '') for f in fields)

    for n, pol in enumerate(policies, 1):
        pname = text(pol, 'Name')
        if want and pname.lower() != want:
            continue
        pline = f'{n}. {pname} [{text(pol, "Switch")}]{ext.get(text(pol, "ID"), "")}  {text(pol, "Comment")}'
        lines, matched = [], hit(pname, text(pol, 'Comment'))
        functions = sorted([f for f in pol if local(f.tag) == 'Function'], key=order_key)
        for m, fn in enumerate(functions, 1):
            sw = text(fn, 'Switch')
            fline = f'   {n}.{m}  {text(fn, "Name")} [{sw}]{ext.get(text(fn, "ID"), "")}  {text(fn, "Comment")}'
            fmatch = hit(text(fn, 'Name'), text(fn, 'Comment'))
            plines = []
            params = sorted([p for p in fn if local(p.tag) == 'Parameter'], key=order_key)
            for k, par in enumerate(params, 1):
                grp = text(par, 'Group')
                pl = (f'          {n}.{m}.{k}  {text(par, "Name")}{(" #" + grp) if grp else ""} = {text(par, "Value")}'
                      f'{ext.get(text(par, "ID"), "")}   {text(par, "Comment")}')
                if pattern is not None:
                    if hit(text(par, 'Name'), text(par, 'Value'), text(par, 'Comment')):
                        plines.append(pl)
                elif want and (show_na or sw != 'n/a'):
                    plines.append(pl)
            if pattern is None or fmatch or plines:
                lines.append(fline)
                lines.extend(plines)
        if pattern is None or matched or lines:
            print(pline)
            print('\n'.join(lines)) if lines else None


if __name__ == '__main__':
    main()
