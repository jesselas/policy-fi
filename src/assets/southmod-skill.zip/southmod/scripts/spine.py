#!/usr/bin/env python3
"""Print a SOUTHMOD/EUROMOD spine exactly as the GUI numbers it.

The GUI sorts policies, functions and parameters by their <Order> element. The XML
document order is frequently different (functions added later are appended at the
end of a <Policy> but given a small <Order>), so NEVER count elements in document
order. Use this script whenever a question involves "row N.M", "function k",
"the third BenCalc", "the 5th income list" and the like.

Usage:
  python3 spine.py <CC>.xml                      # list systems
  python3 spine.py <CC>.xml <SYSTEM>             # spine: N. policy [switch]  M. function [switch]  comment
  python3 spine.py <CC>.xml <SYSTEM> <policy>    # one policy with every function and its parameters (GUI order)
  python3 spine.py <CC>.xml <SYSTEM> <policy> --all   # same, including parameters of n/a functions
"""
import sys
import xml.etree.ElementTree as ET


def local(tag):
    return tag.rsplit('}', 1)[-1]


def child(el, name):
    for c in el:
        if local(c.tag) == name:
            return c
    return None


def text(el, name):
    c = child(el, name)
    return (c.text or '').strip() if c is not None else ''


def order_key(el):
    try:
        return float(text(el, 'Order') or 0)
    except ValueError:
        return 0.0


def kids(el, name):
    return sorted([c for c in el.iter() if local(c.tag) == name and c is not el], key=order_key)


def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    tree = ET.parse(sys.argv[1])
    systems = [s for s in tree.getroot().iter() if local(s.tag) == 'System']
    if len(sys.argv) == 2:
        for s in systems:
            print(text(s, 'Name'))
        return
    sysname = sys.argv[2]
    system = next((s for s in systems if text(s, 'Name') == sysname), None)
    if system is None:
        print(f'system {sysname} not found; available: ' + ', '.join(text(s, 'Name') for s in systems)); sys.exit(1)
    policies = sorted([p for p in system.iter() if local(p.tag) == 'Policy'], key=order_key)
    want = sys.argv[3].lower() if len(sys.argv) > 3 else None
    show_na = '--all' in sys.argv
    for n, pol in enumerate(policies, 1):
        pname = text(pol, 'Name')
        if want and pname.lower() != want:
            continue
        print(f'{n}. {pname} [{text(pol, "Switch")}]  {text(pol, "Comment")}')
        functions = sorted([f for f in pol if local(f.tag) == 'Function'], key=order_key)
        for m, fn in enumerate(functions, 1):
            sw = text(fn, 'Switch')
            print(f'   {n}.{m}  {text(fn, "Name")} [{sw}]  {text(fn, "Comment")}')
            if want and (show_na or sw != 'n/a'):
                params = sorted([p for p in fn if local(p.tag) == 'Parameter'], key=order_key)
                for par in params:
                    grp = text(par, 'Group')
                    print(f'          {text(par, "Name")}{(" #" + grp) if grp else ""} = {text(par, "Value")}   {text(par, "Comment")}')


if __name__ == '__main__':
    main()
