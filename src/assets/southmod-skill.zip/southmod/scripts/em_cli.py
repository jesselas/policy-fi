#!/usr/bin/env python3
"""Run SOUTHMOD/EUROMOD systems with the official command-line calculator (EM_ExecutableCaller.exe).

Three execution modes, as in a replication package:
  parallels  Claude on macOS, EUROMOD in a Windows guest reached over SSH. The guest must see the Mac
             folders through a shared folder (Parallels: the home folder as \\\\Mac\\Home).
  windows    Claude and EUROMOD on the same Windows computer.
  manual     Claude prepares self-contained job folders; a person runs RUN_ALL.ps1 (or each job's
             run.ps1) on any Windows computer with EUROMOD, copies the folder back if needed, and
             `import` verifies the results.

usage:
  em_cli.py check  --mode parallels --ssh-host HOST [--engine DIR]
  em_cli.py run    --mode MODE --bundle DIR --system SYS [SYS ...] [options]
  em_cli.py import OUT_DIR                     # after a manual run

run options:
  --dataset NAME         input dataset (default: each system's BestMatch in the dataconfig)
  --switch EXT=on|off    extension switch by short name, repeatable (checked against the dataconfig)
  --const NAME=VALUE     DefConst override, repeatable: '$povline=600000#y' or '$name@GROUP=value'.
                         The calculator has no constant option, so the value is written into a staged
                         copy of the model; the bundle itself is never changed.
  --label TEXT           run label prefix (default: system[_dataset][_switches])
  --out DIR              output folder (default: <bundle>/Output/em_cli/<timestamp>)
  --engine DIR           folder with EM_ExecutableCaller.exe (default: C:/Program Files/EUROMOD/Executable,
                         or env EM_CLI_ENGINE)
  --expected-engine V    refuse a run whose log reports another EUROMOD version (e.g. 3.8.9)
  --ssh-host HOST        parallels: SSH host of the Windows guest (or env EM_CLI_SSH_HOST)
  --ssh-arg ARG          parallels: extra ssh argument, repeatable (e.g. -p 2222)
  --host-share-root DIR  parallels: Mac folder shared with Windows (default: home folder)
  --windows-share-root P parallels: the same folder as Windows sees it (default: //Mac/Home)

Each run writes <out>/<label>/ with the output files, the calculator's *_EUROMOD_Log.txt, stdout/stderr,
run.ps1 and provenance.json (mode, engine version, arguments, SHA-256 of the model XML, dataconfig, input and
outputs, constants, switches). A run counts only when provenance.json says "ok": true: the log must report
status finished for the requested system, dataset and switches, and every output's MD5 must match the log.
Exit codes: 0 all runs ok, 1 a run or its verification failed, 2 setup or input problem,
3 manual jobs are waiting to be run.
"""
import argparse
import base64
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

DEFAULT_ENGINE = os.environ.get('EM_CLI_ENGINE', 'C:/Program Files/EUROMOD/Executable')


def die(msg, code=2):
    print(f'error: {msg}', file=sys.stderr)
    sys.exit(code)


def sha256(p, algo='sha256'):
    h = hashlib.new(algo)
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def loc(t):
    return t.rsplit('}', 1)[-1]


def kids(e, name):
    return [c for c in e if loc(c.tag) == name]


def tx(e, name):
    c = kids(e, name)
    return (c[0].text or '').strip() if c else ''


def ps_quote(s):
    return "'" + str(s).replace("'", "''") + "'"


# ---------------------------------------------------------------- paths

class Paths:
    """Maps a local path to the path the Windows calculator uses."""

    def __init__(self, a):
        self.mode = a.mode
        self.host_root = Path(a.host_share_root).expanduser().resolve()
        self.win_root = a.windows_share_root.rstrip('/\\').replace('/', '\\')

    def win(self, p):
        p = Path(p).resolve()
        if self.mode == 'windows' or os.name == 'nt':
            return str(p)
        try:
            rel = p.relative_to(self.host_root)
        except ValueError:
            die(f'{p} is outside the shared folder {self.host_root}: Windows cannot see it '
                '(set --host-share-root/--windows-share-root, or move the bundle)')
        return self.win_root + '\\' + str(rel).replace('/', '\\')


# ---------------------------------------------------------------- model files

def read_dataconfig(path):
    root = ET.parse(path).getroot()
    dbs = {tx(d, 'ID'): tx(d, 'Name') for d in root.iter() if loc(d.tag) == 'DataBase'}
    best = {}
    for c in root.iter():
        if loc(c.tag) == 'DBSystemConfig' and tx(c, 'BestMatch').lower() == 'yes':
            best.setdefault(tx(c, 'SystemName'), []).append(dbs.get(tx(c, 'DataBaseID'), ''))
    exts = {tx(e, 'ShortName') for e in root.iter() if loc(e.tag) == 'Extension'}
    return best, exts


def global_extensions(bundle):
    f = bundle / 'XMLParam' / 'Config' / 'Extensions.xml'
    if not f.exists():
        return set()
    return {tx(e, 'ShortName') for e in ET.parse(f).getroot().iter() if loc(e.tag) == 'Extension'}


def systems_in(xml):
    return [tx(s, 'Name') for s in ET.parse(xml).getroot().iter() if loc(s.tag) == 'System']


def patch_constants(xml, systems, consts):
    """Write DefConst values into the staged XML. Edits only the <Value> inside each matched <Parameter>."""
    root = ET.parse(xml).getroot()
    targets = []
    for s in [s for s in root.iter() if loc(s.tag) == 'System' and tx(s, 'Name') in systems]:
        for name, group, value in consts:
            hits = []
            for p in kids(s, 'Policy'):
                for f in kids(p, 'Function'):
                    if tx(f, 'Name').lower() != 'defconst':
                        continue
                    for par in kids(f, 'Parameter'):
                        if tx(par, 'Name') == name and (group is None or tx(par, 'Group') == group):
                            hits.append((tx(par, 'ID'), tx(par, 'Value'), tx(p, 'Name')))
            if len(hits) != 1:
                die(f'{name}{"@" + group if group else ""} matches {len(hits)} DefConst parameters in '
                    f'{tx(s, "Name")} (need exactly one; give @GROUP for conditional constants)')
            targets.append((tx(s, 'Name'), name, group, hits[0][0], hits[0][1], value, hits[0][2]))
    raw = Path(xml).read_bytes()
    bom = raw.startswith(b'\xef\xbb\xbf')
    text = raw[3:].decode('utf-8') if bom else raw.decode('utf-8')
    record = []
    for sysname, name, group, pid, old, value, pol in targets:
        i = text.find(f'<ID>{pid}</ID>')
        end = text.find('</Parameter>', i)
        v0 = text.find('<Value>', i, end)
        v1 = text.find('</Value>', v0, end)
        if min(i, end, v0, v1) < 0 or text.count(f'<ID>{pid}</ID>') != 1:
            die(f'could not locate the <Value> of {name} in {sysname}')
        text = text[:v0] + f'<Value><![CDATA[{value}]]>' + text[v1:]
        record.append({'system': sysname, 'policy': pol, 'name': name, 'group': group,
                       'old': old, 'new': value})
    Path(xml).write_bytes((b'\xef\xbb\xbf' if bom else b'') + text.encode('utf-8'))
    return record


def stage(bundle, cc, dest, inputs, copy_inputs):
    """Copy XMLParam/Config and XMLParam/Countries/<CC> (and, for manual jobs, the inputs)."""
    for d in ['XMLParam/Config', f'XMLParam/Countries/{cc}']:
        src = bundle / d
        if not src.is_dir():
            die(f'missing {src}')
        shutil.copytree(src, dest / d, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns('.DS_Store', '*_in_use.txt'))
    (dest / 'XMLParam' / 'Temp').mkdir(parents=True, exist_ok=True)
    data_dir = bundle / 'Input'
    if copy_inputs:
        data_dir = dest / 'Input'
        data_dir.mkdir(exist_ok=True)
        for ds in inputs:
            shutil.copy2(bundle / 'Input' / f'{ds}.txt', data_dir / f'{ds}.txt')
    return data_dir


# ---------------------------------------------------------------- one job

def job_script(job, paths, manual):
    """PowerShell that checks the input hash, launches the calculator and records a receipt."""
    if manual:
        # Paths relative to the job folder, so the whole output folder can be run on another PC.
        head = ["param([string]$Engine = " + ps_quote(job['engine']) + ")",
                "$job = $PSScriptRoot",
                "$staged = Join-Path $PSScriptRoot " + ps_quote('..\\_staged'),
                "if (-not (Test-Path -LiteralPath (Join-Path $Engine 'EM_ExecutableCaller.exe'))) {",
                "  $found = Get-ChildItem 'C:\\Program Files\\EUROMOD','C:\\Program Files (x86)\\EUROMOD' "
                "-Recurse -Filter EM_ExecutableCaller.exe -ErrorAction SilentlyContinue | Select-Object -First 1",
                "  if (-not $found) { throw 'EM_ExecutableCaller.exe not found: run with -Engine <folder>' }",
                "  $Engine = $found.DirectoryName }"]
        em, data, out = '$staged', "(Join-Path $staged 'Input')", '$job'
        inp = "(Join-Path $staged " + ps_quote('Input\\' + job['dataset'] + '.txt') + ")"
    else:
        head = ["$Engine = " + ps_quote(job['engine']),
                "$job = " + ps_quote(paths.win(job['dir']))]
        em = ps_quote(paths.win(job['staged']))
        data = ps_quote(paths.win(job['data_dir']))
        out = '$job'
        inp = ps_quote(paths.win(Path(job['data_dir']) / f"{job['dataset']}.txt"))
    args = ['"-emPath"', '"$(' + em + ')"', '"-sys"', f'"{job["system"]}"', '"-data"', f'"{job["dataset"]}"',
            '"-dataPath"', '"$(' + data + ')"', '"-outPath"', '"$(' + out + ')"', '"-forceSequentialOutput"']
    for k, v in job['switches'].items():
        args += ['"-extSwitch"', f'"{k}={v}"']
    pre = head[:1] if manual else []
    lines = pre + ["$ErrorActionPreference = 'Stop'; $ProgressPreference = 'SilentlyContinue'"] + head[len(pre):] + [
        "$inputFile = " + inp,
        "$h = (Get-FileHash -LiteralPath $inputFile -Algorithm SHA256).Hash.ToLower()",
        "if ($h -ne " + ps_quote(job['input_sha256']) + ") { throw 'Input changed before engine launch' }",
        "@('label=" + job['label'] + "', ('input_sha256=' + $h), ('engine=' + $Engine), "
        "('started=' + (Get-Date -Format o))) | Set-Content -Encoding ASCII -LiteralPath (Join-Path $job 'launch_receipt.txt')",
        "Get-ChildItem -LiteralPath $job -Filter '*_EUROMOD_Log.txt' | Remove-Item",
        '$argText = "' + ' '.join(_ps_arg(a) for a in args) + '"',
        "$p = Start-Process -FilePath (Join-Path $Engine 'EM_ExecutableCaller.exe') -ArgumentList $argText "
        "-RedirectStandardOutput (Join-Path $job 'engine_stdout.txt') "
        "-RedirectStandardError (Join-Path $job 'engine_stderr.txt') -NoNewWindow -Wait -PassThru",
        "exit $p.ExitCode"]
    return '\r\n'.join(lines) + '\r\n'


def _ps_arg(a):
    # a is a double-quoted token; inside the outer PowerShell string the quotes become `".
    inner = a[1:-1]
    return '`"' + inner + '`"'


def read_log(job_dir):
    logs = sorted(Path(job_dir).glob('*_EUROMOD_Log.txt'))
    if len(logs) != 1:
        return None, f'expected one *_EUROMOD_Log.txt, found {len(logs)}'
    lines = logs[0].read_text(encoding='utf-8-sig', errors='replace').splitlines()
    version = [l.split(':', 1)[1].strip() for l in lines if l.startswith('Software-Version:')]
    hdr = [i for i, l in enumerate(lines) if l.startswith('Run-Id\t')]
    if len(version) != 1 or len(hdr) != 1 or hdr[0] + 1 >= len(lines):
        return None, 'calculator log has no version or run record'
    cols = lines[hdr[0]].split('\t')
    vals = lines[hdr[0] + 1].split('\t')
    return {'file': logs[0], 'version': version[0], 'run': dict(zip(cols, vals))}, None


def verify(job):
    d = Path(job['dir'])
    prov = {k: job[k] for k in ('label', 'mode', 'system', 'dataset', 'switches', 'constants',
                                'model_sha256', 'dataconfig_sha256', 'input_sha256')}
    prov['ok'] = False
    problems = []
    log, err = read_log(d)
    if err:
        problems.append(err)
    else:
        run = log['run']
        prov['engine_version'] = log['version']
        prov['log'] = log['file'].name
        prov['log_sha256'] = sha256(log['file'])
        if job.get('expected_engine') and log['version'] != job['expected_engine']:
            problems.append(f"engine {log['version']} != expected {job['expected_engine']}")
        if run.get('Status') != 'finished':
            problems.append(f"status {run.get('Status')!r}")
        if run.get('System') != job['system'] or run.get('Database') != job['dataset']:
            problems.append(f"log ran {run.get('System')}/{run.get('Database')}")
        for k, v in job['switches'].items():
            if run.get(k) != ('1' if v == 'on' else '0'):
                problems.append(f'extension {k} is {run.get(k)!r} in the log, wanted {v}')
        outs, listed = {}, 0
        for col, name in run.items():
            if not col.startswith('Output-File'):
                continue
            listed += 1
            name = name if name.lower().endswith('.txt') else name + '.txt'
            f = d / name
            want = run.get(col.replace('Output-File', 'Output-Hash'), '')
            if not f.exists():
                problems.append(f'output {name} missing')
            elif sha256(f, 'md5') != want.lower():
                problems.append(f'output {name} MD5 differs from the log')
            else:
                outs[name] = sha256(f)
        if not listed:
            problems.append('log lists no output file')
        prov['outputs'] = outs
    receipt = d / 'launch_receipt.txt'
    if receipt.exists():
        r = dict(l.split('=', 1) for l in receipt.read_text().splitlines() if '=' in l)
        prov['engine_directory'] = r.get('engine')
        prov['started'] = r.get('started')
        if r.get('input_sha256', '').lower() != job['input_sha256']:
            problems.append('launch receipt input hash differs')
    else:
        problems.append('no launch receipt (the job did not start)')
    err_file = d / 'engine_stderr.txt'
    warn = [l for l in err_file.read_text(errors='replace').splitlines() if l.strip()] if err_file.exists() else []
    prov['stderr'] = warn[:50]
    if any(l.lower().startswith('error') for l in warn):
        problems.append('calculator wrote errors to stderr')
    prov['problems'] = problems
    prov['ok'] = not problems
    prov['verified'] = datetime.datetime.now().isoformat(timespec='seconds')
    (d / 'provenance.json').write_text(json.dumps(prov, indent=1))
    return prov


# ---------------------------------------------------------------- execution

def run_remote(script, a, paths, cwd_dir):
    enc = base64.b64encode(script.encode('utf-16-le')).decode()
    cmd = ['powershell.exe', '-NoProfile', '-NonInteractive', '-EncodedCommand', enc]
    if a.mode == 'windows':
        if os.name != 'nt':
            die('--mode windows runs only on Windows; on macOS use parallels or manual')
        return subprocess.call(cmd)
    if len(enc) > 30000:
        # Long command lines fail over SSH: run the saved script instead.
        cmd = ['powershell.exe', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
               '-File', paths.win(Path(cwd_dir) / 'run.ps1')]
    return subprocess.call(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', *a.ssh_arg, a.ssh_host,
                            ' '.join(cmd)])


def cmd_check(a):
    if a.mode == 'manual':
        print('manual mode needs no connection: run `run --mode manual` and follow MANUAL_RUN.txt')
        return 0
    script = ("$ProgressPreference = 'SilentlyContinue'; $e = Join-Path " + ps_quote(a.engine) + " 'EM_ExecutableCaller.exe'; "
              "if (Test-Path -LiteralPath $e) { 'calculator found: ' + $e + ' (the EUROMOD version is read from each run log)' } "
              "else { 'calculator NOT FOUND: ' + $e; exit 1 }")
    enc = base64.b64encode(script.encode('utf-16-le')).decode()
    if a.mode == 'windows':
        return subprocess.call(['powershell.exe', '-NoProfile', '-EncodedCommand', enc])
    if not a.ssh_host:
        die('--ssh-host (or EM_CLI_SSH_HOST) is required in parallels mode')
    r = subprocess.call(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', *a.ssh_arg, a.ssh_host,
                         'powershell.exe -NoProfile -NonInteractive -EncodedCommand ' + enc])
    if r == 255:
        print(f'SSH to {a.ssh_host} failed: start the Windows guest and check its OpenSSH server')
    return 0 if r == 0 else 2


def cmd_run(a):
    bundle = Path(a.bundle).expanduser().resolve()
    countries = sorted({s.split('_')[0].upper() for s in a.system})
    if len(countries) != 1:
        die('one country per call')
    cc = countries[0]
    xml = bundle / 'XMLParam' / 'Countries' / cc / f'{cc}.xml'
    dcf = bundle / 'XMLParam' / 'Countries' / cc / f'{cc}_dataconfig.xml'
    for f in (xml, dcf):
        if not f.exists():
            die(f'missing {f}')
    if list((bundle / 'XMLParam' / 'Temp').glob('*_in_use.txt')):
        print('note: EUROMOD has this bundle open; unsaved GUI edits are not in the run', file=sys.stderr)
    known = set(systems_in(xml))
    bad = [s for s in a.system if s not in known]
    if bad:
        die(f'systems not in {xml.name}: {", ".join(bad)}')
    best, exts = read_dataconfig(dcf)
    exts |= global_extensions(bundle)
    switches = {}
    for s in a.switch:
        k, _, v = s.partition('=')
        if v not in ('on', 'off'):
            die(f'--switch {s}: use NAME=on or NAME=off')
        if k not in exts:
            die(f'extension {k} is not declared (known: {", ".join(sorted(exts))})')
        switches[k] = v
    consts = []
    for c in a.const:
        m = re.match(r'^(\$[A-Za-z0-9_]+)(?:@([A-Za-z0-9_]+))?=(.+)$', c)
        if not m:
            die(f"--const {c}: use '$name=value' or '$name@GROUP=value'")
        if re.search(r'[\]<>&]', m.group(3)):
            die(f'--const {c}: value contains a character that cannot go into the XML')
        consts.append((m.group(1), m.group(2), m.group(3)))
    plan = []
    for s in a.system:
        ds = a.dataset or (best.get(s) or [None])[0]
        if not ds or (not a.dataset and len(best.get(s, [])) > 1):
            die(f'{s}: no unique BestMatch dataset in the dataconfig; give --dataset')
        f = bundle / 'Input' / f'{ds}.txt'
        if not f.exists():
            die(f'input {f} not found')
        plan.append((s, ds))

    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    out = Path(a.out).expanduser().resolve() if a.out else bundle / 'Output' / 'em_cli' / stamp
    paths = Paths(a)
    if a.mode == 'parallels':
        if not a.ssh_host:
            die('--ssh-host (or EM_CLI_SSH_HOST) is required in parallels mode')
        paths.win(bundle)
        paths.win(out)
    staged = out / '_staged'
    staged.mkdir(parents=True, exist_ok=True)
    data_dir = stage(bundle, cc, staged, sorted({d for _, d in plan}), copy_inputs=(a.mode == 'manual'))
    sxml = staged / 'XMLParam' / 'Countries' / cc / f'{cc}.xml'
    const_record = patch_constants(sxml, {s for s, _ in plan}, consts) if consts else []
    sw_tag = '_'.join(f'{k}{v}' for k, v in switches.items())
    jobs = []
    for s, ds in plan:
        label = a.label + '_' + s if a.label and len(plan) > 1 else (a.label or s)
        if not a.label:
            label += ('_' + ds if a.dataset else '') + ('_' + sw_tag if sw_tag else '') + ('_const' if consts else '')
        d = out / label
        d.mkdir(parents=True, exist_ok=True)
        job = {'label': label, 'mode': a.mode, 'system': s, 'dataset': ds, 'switches': switches,
               'constants': [r for r in const_record if r['system'] == s], 'engine': a.engine,
               'expected_engine': a.expected_engine, 'dir': str(d), 'staged': str(staged),
               'data_dir': str(data_dir), 'bundle': str(bundle),
               'model_sha256': sha256(sxml), 'dataconfig_sha256': sha256(dcf),
               'input_sha256': sha256(Path(data_dir) / f'{ds}.txt')}
        (d / 'job.json').write_text(json.dumps(job, indent=1))
        (d / 'run.ps1').write_text(job_script(job, paths, a.mode == 'manual'), encoding='utf-8-sig')
        jobs.append(job)

    if a.mode == 'manual':
        lines = ["param([string]$Engine = " + ps_quote(a.engine) + ")"]
        for j in jobs:
            lines.append(f"Write-Host 'Running {j['label']} ...'; "
                         f"try {{ & (Join-Path $PSScriptRoot '{j['label']}\\run.ps1') -Engine $Engine; "
                         f"if ($LASTEXITCODE -ne 0) {{ Write-Warning ('{j['label']} exited with ' + $LASTEXITCODE) }} }} "
                         f"catch {{ Write-Warning ('{j['label']}: ' + $_) }}")
        lines.append("Write-Host 'Done. Tell Claude to import the results.'")
        (out / 'RUN_ALL.ps1').write_text('\r\n'.join(lines) + '\r\n', encoding='utf-8-sig')
        (out / 'MANUAL_RUN.txt').write_text(
            f'{len(jobs)} EUROMOD job(s), prepared {stamp}.\r\n\r\n'
            '1. On a Windows computer with EUROMOD, open this folder (copy it there if needed; keep it whole).\r\n'
            '2. In PowerShell, run:\r\n'
            '     powershell -NoProfile -ExecutionPolicy Bypass -File RUN_ALL.ps1\r\n'
            '   If EUROMOD is not in C:\\Program Files\\EUROMOD, add: -Engine "<folder with EM_ExecutableCaller.exe>"\r\n'
            '3. Leave every file in place, copy the folder back if you moved it, and tell Claude it is done.\r\n'
            f'   Claude then runs: em_cli.py import "{out}"\r\n', encoding='utf-8')
        print(f'{len(jobs)} manual job(s) ready in {out}\nSee {out / "MANUAL_RUN.txt"}; then: em_cli.py import {out}')
        return 3

    results = []
    for j in jobs:
        print(f"[{j['label']}] running {j['system']} on {j['dataset']} ({a.mode}) ...", flush=True)
        t0 = datetime.datetime.now()
        rc = run_remote(job_script(j, paths, False), a, paths, j['dir'])
        prov = verify(j)
        prov['exit_code'] = rc
        prov['seconds'] = round((datetime.datetime.now() - t0).total_seconds(), 1)
        if rc != 0:
            prov['ok'] = False
            prov['problems'].append(f'calculator exit code {rc}')
        Path(j['dir'], 'provenance.json').write_text(json.dumps(prov, indent=1))
        results.append(prov)
        print(f"[{j['label']}] {'ok' if prov['ok'] else 'FAILED: ' + '; '.join(prov['problems'])} "
              f"({prov['seconds']} s, engine {prov.get('engine_version', '?')})", flush=True)
    return finish(out, results)


def finish(out, results):
    (out / 'summary.json').write_text(json.dumps(results, indent=1))
    ok = sum(r['ok'] for r in results)
    print(f'{ok}/{len(results)} run(s) ok; summary {out / "summary.json"}')
    return 0 if ok == len(results) else 1


def cmd_import(a):
    out = Path(a.out_dir).expanduser().resolve()
    jobs = sorted(out.glob('*/job.json'))
    if not jobs:
        die(f'no job folders in {out}')
    results = []
    for jf in jobs:
        job = json.loads(jf.read_text())
        job['dir'] = str(jf.parent)
        prov = verify(job)
        results.append(prov)
        print(f"[{job['label']}] {'ok' if prov['ok'] else 'FAILED: ' + '; '.join(prov['problems'])}")
    return finish(out, results)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    for name in ('check', 'run'):
        p = sub.add_parser(name)
        p.add_argument('--mode', choices=['parallels', 'windows', 'manual'], required=True)
        p.add_argument('--engine', default=DEFAULT_ENGINE)
        p.add_argument('--ssh-host', default=os.environ.get('EM_CLI_SSH_HOST'))
        p.add_argument('--ssh-arg', action='append', default=[])
        p.add_argument('--host-share-root', default=str(Path.home()))
        p.add_argument('--windows-share-root', default='//Mac/Home')
        if name == 'run':
            p.add_argument('--bundle', required=True)
            p.add_argument('--system', nargs='+', required=True)
            p.add_argument('--dataset')
            p.add_argument('--switch', action='append', default=[])
            p.add_argument('--const', action='append', default=[])
            p.add_argument('--label')
            p.add_argument('--out')
            p.add_argument('--expected-engine')
    p = sub.add_parser('import')
    p.add_argument('out_dir')
    a = ap.parse_args()
    sys.exit({'check': cmd_check, 'run': cmd_run, 'import': cmd_import}[a.cmd](a))


if __name__ == '__main__':
    main()
