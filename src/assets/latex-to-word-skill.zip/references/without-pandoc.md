# When Pandoc can’t be installed

`prepare.py`, `pdf_extract.py`, and `check.py` don’t need Pandoc. Only `convert.py` does. Try first `pandoc --version`, `python3 -c "import pypandoc; print(pypandoc.get_pandoc_path())"`, and `pip install pypandoc_binary`.

If none works, run `prepare.py`, then build the file from `work/flat.tex` with python-docx:

```python
import sys; sys.path.insert(0, "scripts")
import docx; from omml import add_inline, add_equation, add_footnote
d = docx.Document("assets/wider_blank.docx")       # WIDER styles, page setup, footnotes part
```

Write a converter script for the paper and run it, rather than typing the text into code. `flat.tex` uses only a few kinds of block:

| In flat.tex | In Word |
|---|---|
| `\section*{1⇥Title}` (also sub-, subsub-) | `heading 1/2/3`, `⇥` becomes a tab |
| paragraph, with `\emph`, `\textbf`, `\textsuperscript`, `\href`, `\footnote` | `Normal`, runs, `add_footnote` |
| `\(...\)`, `$...$` | `add_inline` |
| `\[...\]` with `⟦EQ 3⟧` | `add_equation(d, tex, "3")` |
| `⟦TITLE⟧Table 1⟦:⟧Title` | `Table-title`: “Table 1: Title” |
| `tabular` | a Word table, cells `Table-text`, top, header, and bottom rules, merged cells for `\multicolumn` |
| `tabular` with pictures | a table without rules |
| `Note: …`, `Source: …` | `Table-notes`, `Table-source` |
| `itemize`, `enumerate`, `quote` | list paragraphs, `Quote` |
| entries under References | `Biblio` |

- **Citations** are still `\citet{key}` and so on. Read the .bib file and print names and years as in `wider-style.md` (two authors “and”, three or more “et al.”, a and b for the same author and year), then build the reference list from the cited entries, in alphabetical order. `\href{nopar:}{\citet{…}}` means without brackets, `author:` only names, `year:` only the year, `yearpar:` the year in brackets.
- `omml.py` raises an error for an unknown command. Add it to the tables at the top of the file, or rewrite the equation. Never leave LaTeX as text.
- Build the title page from `work/front.json`: one paragraph per field, with a bold label (see `wider-style.md`), then a page break.

Then run `check.py` as usual.
