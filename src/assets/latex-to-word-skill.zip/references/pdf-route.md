# When there is only a PDF

Rebuild a small LaTeX source from the PDF, then follow the normal steps. Text and numbers come from the PDF’s text layer, not from memory or from reading pictures, wherever the text layer has them.

## 1. Extract

```
python3 scripts/pdf_extract.py paper.pdf -o pdfwork/
```

- `pdfwork/text.txt`: text by page, with headings, captions, possible footnotes, and indented paragraph starts (`[para]`) marked.
- `pdfwork/pages/`: an image of each page. Read equations and table layouts from these.
- `pdfwork/figures/`: each figure cropped at 300 dpi, vector charts included.
- `pdfwork/inventory.json`: what the rebuilt paper must contain.

Look at **every** cropped figure. It must include all panels, axis titles, and the legend, and no caption, note, or body text. Crop again where needed (coordinates in PDF points from the top left; `box` in the inventory gives the current ones):

```
python3 scripts/pdf_extract.py paper.pdf -o pdfwork/ --crop "14:72,90,523,410:figure_3"
```

A figure with a caption but no picture is often on the next page. If the PDF has no text layer, run OCR first (`ocrmypdf`), and tell the user that numbers need checking.

## 2. Write `pdfwork/src/main.tex`

Work page by page. Copy `pdfwork/figures/` to `pdfwork/src/figures/`. Use plain LaTeX only:

```latex
\documentclass{article}
\graphicspath{{figures/}}
\title{...} \author{A. Name \and B. Name}
\begin{document}
\begin{abstract}...\end{abstract}
\section{Introduction}\label{s1}
Text, with citations typed as printed, such as Smith (1993). A footnote.\footnote{...}
\begin{equation}\label{e1} ... \end{equation}
\begin{table}\caption{Title without number}\label{t1}
\begin{tabular}{lcc}\hline ... \\ \hline ... \\ \hline\end{tabular}

Note: ...

Source: ...
\end{table}
\begin{figure}\caption{Title}\label{f1}\includegraphics[width=\textwidth]{figure_1}

Source: ...
\end{figure}
\section*{References}
One entry per paragraph, as printed, with \emph{italics}.
\appendix
\section{Title}
\end{document}
```

- **Join lines** into paragraphs, and join words that were hyphenated at line ends (keep real hyphens). Join paragraphs that run over a page. Drop running heads and page numbers.
- **Place floats** after the paragraph that first mentions them. Join tables that continue over pages.
- **Headings:** drop printed numbers. LaTeX numbers them again in the same order. Check that the result matches the PDF (roman section numbers become 1, 2, 3).
- **References to numbers:** use `\ref` and `\label` for tables, figures, equations, and sections, or type them, but the numbers must agree with the PDF. For an excerpt, start where the PDF starts: `\setcounter{section}{2}`, and the same for `table`, `figure`, and `equation`. If the PDF skips or repeats a number, use `\tag{}` for equations, and report it.
- **Equations:** transcribe each one from the page image, then compare with the text layer, symbol by symbol: indices, hats, bars, primes, signs, limits. Mark one you can’t read as `\textbf{[check equation]}`.
- **Tables:** take the numbers from the text layer and the layout from the page image. Use `\multicolumn` for spanning heads. Count rows and columns.
- **Footnotes:** put each at its mark in the text.
- **Links:** `\href{url}{text}` where the PDF has them.
- Escape `%`, `&`, `$`, `#`, and `_` in text.

For a long paper, write one file per section (`\input{sec1}`) and check each before going on. Don’t summarize or leave “the rest follows” anywhere.

## 3. Convert and check

Run steps 1 to 5 of SKILL.md on `pdfwork/src/main.tex` (with `-o work/`), and `--pdf` set to the original. Here the word and number check is the main safeguard: each missing word or number outside figures is a mistake in the rebuilt text. It can’t see symbols, signs, or which cell a number is in, so compare equations and tables by eye as well. Also compare with `inventory.json`: headings, tables, figures, equation numbers, footnotes. Then read a few pages of the Word file against the PDF, at least one with equations and one with a table.
