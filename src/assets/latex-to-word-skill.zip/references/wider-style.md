# UNU-WIDER working paper style

Summary of the author guidelines and the Word template for UNU-WIDER studies (versions of 2025). The current files are on the “Info for authors” page at wider.unu.edu, and they take precedence. This skill is unofficial. UNU-WIDER makes the cover pages, so don’t create them.

## Format (done by convert.py)

| Element | Word style | Setting |
|---|---|---|
| Page | | A4, 2.54 cm margins, page numbers centred at the bottom |
| Text | Normal | Arial 10, line spacing 1.2, 18 pt after |
| Heading 1 | heading 1 | Arial 18 bold, 24 pt before, 18 pt after, number then tab at 1.5 cm |
| Heading 2 | heading 2 | Arial 16 bold, 24 pt before, 18 pt after |
| Heading 3 | heading 3 | Arial 12 bold, 18 pt before, 0 after, usually no number |
| Table and figure titles | Table-title | Arial 10 bold, left, 12 pt before, 6 pt after |
| Table cells | Table-text | Arial 9, single spacing |
| Notes | Table-notes | Arial 9, 6 pt before and after |
| Source | Table-source | Arial 9, 6 pt before, 18 pt after |
| Equation | Equation | Cambria Math, indented 1 cm, number after a right tab |
| Footnote | footnote text | Arial 9, single spacing, 4 pt after |
| References | Biblio | Arial 9, hanging indent |
| Long quotation | Quote | indented on both sides, no quotation marks |

- Type the numbers of headings, tables, figures, and equations. Don’t use Word’s automatic numbering.
- At most three heading levels. Levels 1 and 2 are numbered 1, 2, 2.1 and so on, also when the LaTeX class printed roman numerals.
- Titles above tables **and** figures: “Table 1: Title”. Under them “Note: …”, then “Source: …”.
- First table column left, the others centred, or right-aligned when they share a number of decimals. Horizontal rules only.
- Footnotes, not endnotes. Equations editable. Tables as tables, not pictures.
- Appendices at the end, each on a new page: Appendix A, B, … with Tables A1, A2, … and Figures A1, ….

## First page

The template lists, each after a bold label: Title, Subtitle, Author(s), Corresponding author and email address, All affiliations (with city and country), Abstract (120–150 words, no abbreviations), Keywords (5–7), JEL codes (at most 4), Acknowledgements.

## Text rules: report, don’t change

Tell the author where the paper departs from these. Change them only if asked.

- British English with -ize. Little capitalization, bold, or italics. Abbreviations explained at first use.
- US$, £, €, or the ISO code before the amount without a space (US$300,000). En dash in ranges (1980–89).
- Every table, figure, and map has a source, also “authors’ calculations based on [data]” or “authors’ illustration”. Every one is mentioned in the text.
- About 10,000–12,000 words, at most 15,000. Long appendices can be separate files.
- In the text: Smith (1993: 37), (Anderson 1991; Jones 1999, 2000), “et al.” from three authors.
- Reference list: Surname, A., B. Surname, and C. Surname (2020). ‘Article title’. *Journal*, 12(3): 45–67. DOI link. Books and reports in italics with Place: Publisher. Working papers ‘Title’. WIDER Working Paper 2020/57. Helsinki: UNU-WIDER. Links that aren’t DOIs: “Available at: … (accessed 1 June 2026)”.
- Everything cited is in the list, and the other way round.

## LaTeX or Word?

The guidelines accept either Word or LaTeX (source files as a .zip, in the WIDER LaTeX template), and LaTeX papers can be copy-edited on Overleaf. So a paper already in the WIDER LaTeX template doesn’t have to become a Word file for submission.
