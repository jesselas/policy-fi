#!/usr/bin/env python3
"""LaTeX equations to native Word equations in plain Python, for machines without Pandoc.

    from omml import omath, add_equation, add_inline, add_footnote
    add_equation(document, r"\\frac{a}{b}=\\sum_{i=1}^{N} x_i", number="3")     # python-docx document
    add_inline(paragraph, r"\\beta_1")

Unknown commands raise ValueError, so that nothing is lost without notice.
"""
import re
from lxml import etree as E
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"; Wn = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
G = dict(alpha="α", beta="β", gamma="γ", delta="δ", epsilon="ϵ", varepsilon="ε", zeta="ζ", eta="η", theta="θ", vartheta="ϑ", iota="ι", kappa="κ", lambda_="λ", mu="μ", nu="ν", xi="ξ", pi="π", rho="ρ", sigma="σ", tau="τ", upsilon="υ", phi="ϕ", varphi="φ", varpi="ϖ", chi="χ", psi="ψ", omega="ω", Gamma="Γ", Delta="Δ", Theta="Θ", Lambda="Λ", Xi="Ξ", Pi="Π", Sigma="Σ", Upsilon="Υ", Phi="Φ", Psi="Ψ", Omega="Ω",
 cdot="·", times="×", div="÷", pm="±", mp="∓", leq="≤", le="≤", geq="≥", ge="≥", neq="≠", ne="≠", approx="≈", equiv="≡", sim="∼", simeq="≃", propto="∝", infty="∞", partial="∂", nabla="∇", forall="∀", exists="∃", in_="∈", notin="∉", subset="⊂", subseteq="⊆", cup="∪", cap="∩", setminus="∖", emptyset="∅", to="→", rightarrow="→", leftarrow="←", Rightarrow="⇒", Leftrightarrow="⇔", iff="⇔", implies="⇒", mapsto="↦", ldots="…", dots="…", cdots="⋯", vdots="⋮", ddots="⋱", mid="∣", vert="|", Vert="‖", perp="⊥", ll="≪", gg="≫", circ="∘", ast="∗", star="⋆", dagger="†", prime="′", ell="ℓ", hbar="ℏ", langle="⟨", rangle="⟩", lfloor="⌊", rfloor="⌋", lceil="⌈", rceil="⌉", lbrace="{", rbrace="}", lvert="|", rvert="|", lVert="‖", rVert="‖", otimes="⊗", oplus="⊕", quad="\u2003", qquad="\u2003\u2003", land="∧", lor="∨", neg="¬", colon=":", top="⊤", bot="⊥", Re="ℜ", Im="ℑ", aleph="ℵ", gets="←", uparrow="↑", downarrow="↓", succ="≻", prec="≺", lnot="¬", coloneqq="≔")
G = {k.rstrip("_"): v for k, v in G.items()}
FN = "sin cos tan log ln exp lim max min sup inf arg det dim Pr gcd argmax argmin limsup liminf".split()
NARY = dict(sum="∑", prod="∏", int="∫", iint="∬", oint="∮", bigcup="⋃", bigcap="⋂")
ACC = dict(hat="\u0302", widehat="\u0302", tilde="\u0303", widetilde="\u0303", bar="\u0305", overline="\u0305", dot="\u0307", ddot="\u0308", vec="\u20d7", check="\u030c")
BB = dict(zip("CHNPQRZ", "ℂℍℕℙℚℝℤ"))
def e(n, *kids, **at):
    x = E.Element("{%s}%s" % (M, n))
    for k, v in at.items(): x.set("{%s}%s" % (M, k), v)
    for k in kids:
        if isinstance(k, list): x.extend(k)
        elif k is not None: x.append(k)
    return x
def run(t, sty=None, nor=False):
    r = e("r")
    if nor: r.append(e("rPr", e("nor")))
    elif sty: r.append(e("rPr", e("sty", val=sty)))
    x = E.SubElement(r, "{%s}t" % M); x.text = t; x.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); return r
TOK = re.compile(r"\\[A-Za-z]+\*?|\\.|\s+|.", re.S)
class P:
    def __init__(s, t): s.t = [x for x in TOK.findall(t)]; s.i = 0
    def peek(s):
        while s.i < len(s.t) and s.t[s.i].isspace(): s.i += 1
        return s.t[s.i] if s.i < len(s.t) else None
    def next(s): x = s.peek(); s.i += 1; return x
    def raw(s):
        """Text of the next {group}, untouched."""
        s.peek(); assert s.t[s.i] == "{", "group expected"; d, out = 0, []
        while True:
            x = s.t[s.i]; s.i += 1
            d += (x == "{") - (x == "}")
            if d == 0: return "".join(out[1:])
            out.append(x)
    def arg(s):
        if s.peek() == "{": s.next(); r = s.seq({"}"}); s.next(); return r
        return s.atom()
    def opt(s):
        if s.peek() != "[": return None
        s.next(); r = s.seq({"]"}); s.next(); return r
    def seq(s, stop):
        out = []
        while s.peek() is not None and s.peek() not in stop:
            a = s.atom(); sub = sup = None
            while s.peek() in ("_", "^", "'"):
                k = s.next()
                if k == "_": sub = s.arg()
                elif k == "'": sup = (sup or []) + [run("′")]
                else: sup = (sup or []) + s.arg()
            if a and a[0].tag.endswith("}nary"):
                n = a[0]; n.find("{%s}sub" % M).extend(sub or []); n.find("{%s}sup" % M).extend(sup or []); pr = n.find("{%s}naryPr" % M)
                if not sub: pr.append(e("subHide", val="1"))
                if not sup: pr.append(e("supHide", val="1"))
                rest = s.seq(stop | {"+", "-", "=", ",", "\\\\", "&"}); n.find("{%s}e" % M).extend(rest); out.append(n); continue
            if a and a[0].get("lim"):
                del a[0].attrib["lim"]
                if sub: a = [e("limLow", e("e", a), e("lim", sub))]; sub = None
            if sub and sup: a = [e("sSubSup", e("e", a), e("sub", sub), e("sup", sup))]
            elif sub: a = [e("sSub", e("e", a), e("sub", sub))]
            elif sup: a = [e("sSup", e("e", a), e("sup", sup))]
            out += a
        return out
    def delim(s):
        x = s.next(); return {"\\{": "{", "\\}": "}", ".": ""}.get(x, G.get(x[1:], x) if x.startswith("\\") else x)
    def rows(s, name):
        rows, cur = [], []
        while True:
            cur.append(s.seq({"&", "\\\\", "\\end"})); x = s.next()
            if x == "&": continue
            rows.append(cur); cur = []
            if x == "\\\\": s.opt() if s.peek() == "[" else None
            if x is None: raise ValueError("unfinished " + name)
            if x == "\\end": s.raw(); return [r for r in rows if any(r)]
            if s.peek() == "\\end": s.next(); s.raw(); return [r for r in rows if any(r)]
    def atom(s):
        x = s.next()
        if x is None: return []
        if x == "{": r = s.seq({"}"}); s.next(); return r
        if not x.startswith("\\"): return [run("−" if x == "-" else "\u00a0" if x == "~" else x)]
        c = x[1:].rstrip("*")
        if c in ("{", "}", "%", "$", "&", "#", "_"): return [run(c)]
        if c in (",", ";", ":", " ", "!", "thinspace", "medspace"): return [] if c == "!" else [run("\u2009")]
        if c in ("displaystyle", "textstyle", "limits", "nolimits", "scriptstyle", "nonumber", "notag", "bigl", "bigr", "Bigl", "Bigr", "big", "Big", "bigg", "Bigg", "biggl", "biggr", "Biggl", "Biggr", "bigm"): return []
        if c in ("label", "tag"): s.raw(); return []
        if c in ("frac", "dfrac", "tfrac"): a, b = s.arg(), s.arg(); return [e("f", e("num", a), e("den", b))]
        if c == "binom": a, b = s.arg(), s.arg(); return [e("d", e("e", e("f", e("fPr", e("type", val="noBar")), e("num", a), e("den", b))))]
        if c == "sqrt": o = s.opt(); a = s.arg(); return [e("rad", e("radPr", None if o else e("degHide", val="1")), e("deg", o or []), e("e", a))]
        if c in NARY: return [e("nary", e("naryPr", e("chr", val=NARY[c]), e("limLoc", val="subSup" if "int" in c else "undOvr")), e("sub"), e("sup"), e("e"))]
        if c in ACC: return [e("acc", e("accPr", e("chr", val=ACC[c])), e("e", s.arg()))]
        if c == "underbrace": a = s.arg(); g = e("groupChr", e("groupChrPr", e("chr", val="⏟"), e("pos", val="bot")), e("e", a)); g.set("lim", "1"); return [g]
        if c in ("text", "textrm", "textnormal", "mbox", "textit", "textbf"): return [run(s.raw(), nor=True)]
        if c in ("mathrm", "operatorname"): t = s.raw(); r = run(re.sub(r"\\[,;]", " ", t), nor=True); r.set("lim", "1") if x.endswith("*") else None; return [r]
        if c in ("mathbf", "boldsymbol", "bm"):
            r = s.arg()
            for t in r:
                for q in t.iter("{%s}r" % M):
                    if q.find("{%s}rPr" % M) is None: q.insert(0, e("rPr", e("sty", val="b" if c == "mathbf" else "bi")))
            return r
        if c == "mathbb": t = s.raw(); return [run("".join(BB.get(k, chr(0x1D538 + ord(k) - 65) if k.isupper() else "𝟙" if k == "1" else k) for k in t))]
        if c in ("mathds", "mathbbm"): return [run("𝟙" if s.raw() == "1" else "𝟙")]
        if c in ("mathcal", "mathscr"): return [e("r", e("rPr", e("scr", val="script"), e("sty", val="p")), *[k for k in run(s.raw())])]
        if c in FN: r = run({"argmax": "arg max", "argmin": "arg min"}.get(c, c), "p"); r.set("lim", "1") if c in ("lim", "max", "min", "sup", "inf", "argmax", "argmin") else None; return [r]
        if c == "left":
            a = s.delim(); r = []; parts = []
            r = s.seq({"\\right"}); s.next(); b = s.delim(); return [e("d", e("dPr", e("begChr", val=a), e("endChr", val=b)), e("e", r))]
        if c == "begin":
            n = s.raw(); base = n.rstrip("*")
            if base in ("array", "alignedat"): s.raw()
            rs = s.rows(n)
            if base in ("aligned", "align", "split", "gathered", "gather", "eqnarray"): return [e("eqArr", *[e("e", [k for cell in r for k in cell]) for r in rs])]
            if base == "cases": return [e("d", e("dPr", e("begChr", val="{"), e("endChr", val="")), e("e", e("eqArr", *[e("e", *[[run("\u2003")] + cell if j else cell for j, cell in enumerate(r)]) for r in rs])))]
            n_ = max(len(r) for r in rs); m = e("m", e("mPr", e("mcs", e("mc", e("mcPr", e("count", val=str(n_)), e("mcJc", val="center"))))), *[e("mr", *[e("e", cell) for cell in r + [[]] * (n_ - len(r))]) for r in rs])
            br = {"pmatrix": "()", "bmatrix": "[]", "vmatrix": "||", "Bmatrix": "{}"}.get(base)
            if br: return [e("d", e("dPr", e("begChr", val=br[0]), e("endChr", val=br[1])), e("e", m))]
            if base in ("matrix", "array", "smallmatrix"): return [m]
            raise ValueError("environment not supported: " + n)
        if c in G: return [run(G[c])]
        raise ValueError("command not supported: " + x)
def omath(tex):
    p = P(tex.strip()); r = p.seq(set())
    for x in r:
        for y in x.iter(): y.attrib.pop("lim", None)
    return e("oMath", r)
def add_inline(paragraph, tex): paragraph._p.append(omath(tex)); return paragraph
def add_equation(document, tex, number=None, style="Equation"):
    p = document.add_paragraph(style=style)
    if number: p._p.append(omath(tex)); p.add_run("\t(%s)" % number)
    else: p._p.append(e("oMathPara", omath(tex)))
    return p
def add_footnote(document, paragraph, text):
    """A real footnote. The document must have a footnotes part (assets/wider_blank.docx has one)."""
    part = next(r.target_part for r in document.part.rels.values() if r.reltype.endswith("/footnotes"))
    root = E.fromstring(part.blob); w = "{%s}" % Wn; i = max([int(x.get(w + "id")) for x in root] + [0]) + 1
    f = E.SubElement(root, w + "footnote"); f.set(w + "id", str(i)); p = E.SubElement(f, w + "p"); E.SubElement(E.SubElement(p, w + "pPr"), w + "pStyle").set(w + "val", "FootnoteText")
    r = E.SubElement(p, w + "r"); E.SubElement(E.SubElement(r, w + "rPr"), w + "rStyle").set(w + "val", "FootnoteReference"); E.SubElement(r, w + "footnoteRef")
    t = E.SubElement(E.SubElement(p, w + "r"), w + "t"); t.text = " " + text; t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    part._blob = E.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
    run_ = paragraph.add_run()._r; E.SubElement(E.SubElement(run_, w + "rPr"), w + "rStyle").set(w + "val", "FootnoteReference"); E.SubElement(run_, w + "footnoteReference").set(w + "id", str(i)); return i
if __name__ == "__main__":
    import sys
    print(E.tostring(omath(sys.argv[1]), pretty_print=True).decode())
