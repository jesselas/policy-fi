#!/usr/bin/env python3
"""Step 2. flat.tex -> paper.docx, with native equations, editable tables and real footnotes.

    python3 convert.py work/ -o paper.docx [--template template.dotx] [--csl style.csl]

Needs Pandoc 3 (`pip install pypandoc_binary` is enough) and lxml. Formats the result in the
UNU-WIDER style. With --template the styles and page setup come from that Word file instead.
"""
import argparse, copy, json, os, re, shutil, subprocess, sys, zipfile
from pathlib import Path
from lxml import etree as E

ap = argparse.ArgumentParser()
ap.add_argument("work"); ap.add_argument("-o", "--out", default="paper.docx"); ap.add_argument("--template"); ap.add_argument("--csl")
ap.add_argument("--no-front", action="store_true", help="do not build the title page from front.json")
A = ap.parse_args()
WK = Path(A.work).resolve(); HERE = Path(__file__).resolve().parent; ASSETS = HERE.parent / "assets"
rep = json.loads((WK / "report.json").read_text(encoding="utf-8")) if (WK / "report.json").exists() else {"bib": []}
def pandoc():
    p = shutil.which("pandoc")
    if p: return p
    try:
        import pypandoc
        return pypandoc.get_pandoc_path()
    except Exception: sys.exit("Pandoc not found. Run: pip install pypandoc_binary. Without network access, see references/without-pandoc.md.")
PD = pandoc()

# ---------- Pandoc: LaTeX -> JSON (citations resolved) ----------
cmd = [PD, str(WK / "flat.tex"), "-f", "latex", "-t", "json", "-o", str(WK / "paper.json")]
if rep.get("bib"):
    cmd += ["--citeproc", "--csl", str(Path(A.csl) if A.csl else ASSETS / "wider.csl"), "-M", "link-citations=false", "-M", "suppress-bibliography=false", "-M", "lang=en-GB"]
    for b in rep["bib"]: cmd += ["--bibliography", b]
r = subprocess.run(cmd, capture_output=True, text=True)
msg = [l for l in r.stderr.splitlines() if l.strip()]
if r.returncode: sys.exit("Pandoc failed:\n" + r.stderr)
J = json.loads((WK / "paper.json").read_text(encoding="utf-8"))
def flat(x):
    if isinstance(x, list): return "".join(flat(y) for y in x)
    if isinstance(x, dict):
        t = x.get("t")
        if t == "Str": return x["c"]
        if t in ("Space", "SoftBreak", "LineBreak"): return " "
        if t in ("Math", "Code"): return x["c"][1]
        if t == "Note": return ""
        return flat(x.get("c", ""))
    return ""
def strs(x, fn):
    """Apply fn to every Str in x, in order."""
    if isinstance(x, list): [strs(y, fn) for y in x]
    elif isinstance(x, dict):
        if x.get("t") == "Str": x["c"] = fn(x["c"])
        elif "c" in x: strs(x["c"], fn)
def unwrap_links(xs):
    out = []
    for x in xs:
        if isinstance(x, dict) and x.get("t") == "Link" and x["c"][2][0].split(":")[0] in ("nopar", "yearpar", "author", "year") and x["c"][2][0].endswith(":"):
            k = x["c"][2][0][:-1]; inner = x["c"][1]; txt = flat(inner)
            m = re.match(r"^\(?(.*?)\s*\(?((?:\d{4}|n\.d\.|forthcoming)[a-z]?(?:[,:].*)?)\)?$", txt, re.S)
            if k == "nopar": strs(inner, lambda s: re.sub(r"^\((?=\d|n\.d)", "", re.sub(r"(?<=[\da-z.])\)$", "", s)) if True else s); out += inner; continue
            s = txt if not m else {"author": m[1], "year": m[2], "yearpar": "(" + m[2] + ")"}[k]
            out.append({"t": "Str", "c": s}); continue
        out.append(x)
    return out
def walk(x):
    if isinstance(x, list):
        if any(isinstance(y, dict) and y.get("t") == "Link" for y in x): x[:] = unwrap_links(x)
        for y in x: walk(y)
    elif isinstance(x, dict):
        if x.get("t") == "Math":
            s = x["c"][1]
            for a, b in [(r"\\begin\{(equation|align|gather|split)\*?\}", ""), (r"\\end\{(equation|align|gather|split)\*?\}", ""), (r"\\(?:nonumber|notag)\b", ""), (r"\\label\{[^}]*\}", ""), (r"\\mathds\b|\\mathbbm\b", r"\\mathbb"), (r"\\bm\b", r"\\boldsymbol"), (r"\\tfrac|\\dfrac", r"\\frac"), (r"\\limits|\\displaystyle|\\textstyle|\\scriptstyle", ""), (r"\\(?:big|Big|bigg|Bigg)[lrm]?(?![A-Za-z])", ""), (r"\\mathrm\{([A-Za-z]{2,})\}", r"\\text{\1}"), (r"\\mathclap|\\mathrlap|\\mathllap", "")]: s = re.sub(a, b, s)
            x["c"][1] = s
        for k in ("c", "blocks"):
            if k in x: walk(x[k])
walk(J)
# take the reference list out of its Div and put it where the source had it
refs = None; blocks = []
for b in J["blocks"]:
    if b["t"] == "Div" and b["c"][0][0] == "refs": refs = [c["c"][1][0] if c["t"] == "Div" else c for c in b["c"][1]]
    elif b["t"] == "Figure":
        for cap in b["c"][1][1]: blocks.append({"t": "Para", "c": cap["c"]})
        for c in b["c"][2]: blocks.append({"t": "Para", "c": c["c"]} if c["t"] == "Plain" else c)
    else: blocks.append(b)
J["blocks"] = []
for b in blocks:
    if b["t"] == "Para" and flat(b).strip() == "⟦REFLIST⟧":
        if refs is None: refs = []
        J["blocks"] += [{"t": "Para", "c": [{"t": "Str", "c": "⟦BIB⟧"}] + r_["c"]} for r_ in refs]
    else: J["blocks"].append(b)
inrefs = False
for b in J["blocks"]:
    if b["t"] == "Header":
        h = flat(b).strip(); inrefs = bool(re.match(r"(?i)(references|bibliography)$", h))
    elif inrefs and b["t"] == "Para" and not flat(b).startswith("⟦BIB⟧"): b["c"].insert(0, {"t": "Str", "c": "⟦BIB⟧"})
(WK / "paper.json").write_text(json.dumps(J, ensure_ascii=False), encoding="utf-8")
raw = WK / "raw.docx"
r = subprocess.run([PD, str(WK / "paper.json"), "-f", "json", "-t", "docx", "-o", str(raw)], capture_output=True, text=True)
msg += [l for l in r.stderr.splitlines() if l.strip()]
if r.returncode: sys.exit("Pandoc failed:\n" + r.stderr)

# ---------- Word formatting ----------
N = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main", "m": "http://schemas.openxmlformats.org/officeDocument/2006/math", "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships", "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing", "a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
def q(n): a, b = n.split(":"); return "{%s}%s" % (N[a], b)
def el(n, **k):
    x = E.Element(q("w:" + n))
    for a, v in k.items(): x.set(q("w:" + a), str(v))
    return x
def xp(e, s): return e.xpath(s, namespaces=N)
def txt(e): return "".join(x.text or "" for x in xp(e, ".//w:t"))
Z = zipfile.ZipFile(raw); P = {n: Z.read(n) for n in Z.namelist()}
D = E.fromstring(P["word/document.xml"]); B = D.find(q("w:body"))
ST = E.fromstring(P["word/styles.xml"])
src = E.fromstring(zipfile.ZipFile(A.template).read("word/styles.xml")) if A.template else E.fromstring((ASSETS / "wider_styles.xml").read_bytes())
have = {s.get(q("w:styleId")): s for s in ST.findall(q("w:style"))}
newids = set()
for s in src.findall(q("w:style")):
    i = s.get(q("w:styleId")); s = copy.deepcopy(s); newids.add(i)
    for n in xp(s, ".//w:numPr"): n.getparent().remove(n)
    if i in have: ST.replace(have[i], s)
    else: ST.append(s)
dd = src.find(q("w:docDefaults"))
if dd is not None:
    o = ST.find(q("w:docDefaults")); ST.replace(o, copy.deepcopy(dd)) if o is not None else ST.insert(0, copy.deepcopy(dd))
linked = {s.get(q("w:styleId")) for s in ST.findall(q("w:style"))}
for l in xp(ST, "//w:link|//w:next|//w:basedOn"):
    if l.get(q("w:val")) not in linked: l.getparent().remove(l)
def has(i): return i in newids
PPR = ["pStyle", "keepNext", "keepLines", "pageBreakBefore", "framePr", "widowControl", "numPr", "suppressLineNumbers", "pBdr", "shd", "tabs", "suppressAutoHyphens", "spacing", "ind", "contextualSpacing", "jc", "outlineLvl", "rPr", "sectPr"]
def pp(p):
    a = p.find(q("w:pPr"))
    if a is None: a = el("pPr"); p.insert(0, a)
    return a
def setp(p, n, **k):
    a = pp(p)
    for x in a.findall(q("w:" + n)): a.remove(x)
    e = el(n, **k); r = PPR.index(n); at = 0
    for j, c in enumerate(a):
        t = E.QName(c).localname
        if t in PPR and PPR.index(t) < r: at = j + 1
    a.insert(at, e); return e
def sty(p, s): setp(p, "pStyle", val=s)
def get(p): x = xp(p, "./w:pPr/w:pStyle/@w:val"); return x[0] if x else "Normal"
def para(t, s="Normal", bold=False):
    p = el("p"); sty(p, s); run(p, t, bold); return p
def run(p, t, bold=False):
    for j, piece in enumerate(t.split("\t")):
        r = el("r")
        if bold: rp = el("rPr"); rp.append(el("b")); r.append(rp)
        if j: r.append(el("tab"))
        x = el("t"); x.text = piece; x.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); r.append(x); p.append(r)
def strip_prefix(p, n):
    for t in xp(p, ".//w:t"):
        if n <= 0: break
        k = len(t.text or ""); cut = min(n, k); t.text = t.text[cut:]; n -= cut; t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
warn = []
# bookmarks from Pandoc headings are not needed; body runs take their look from the style
for x in xp(D, "//w:bookmarkStart|//w:bookmarkEnd"): x.getparent().remove(x)
for p in list(B.iter(q("w:p"))):
    s, t = get(p), txt(p); intable = any(True for _ in p.iterancestors(q("w:tbl")))
    if t.startswith("⟦TITLE⟧"):
        m = re.match(r"⟦TITLE⟧(.*?)⟦:⟧", t); n = m[1]; strip_prefix(p, len(m[0]))
        r = el("r"); x = el("t"); x.text = n + ": "; x.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); r.append(x)
        p.insert(list(p).index(pp(p)) + 1, r); sty(p, "Table-title")
        for b in xp(p, "./w:r/w:rPr/w:b|./w:r/w:rPr/w:bCs"): b.getparent().remove(b)
        continue
    if t.startswith("⟦BIB⟧"): strip_prefix(p, 5); sty(p, "Biblio"); continue
    if intable: sty(p, "Table-text"); [x.getparent().remove(x) for x in xp(p, "./w:pPr/w:spacing|./w:pPr/w:ind")]; continue
    if s.startswith("Heading"):
        ts = xp(p, ".//w:t"); full = txt(p)
        if "⇥" in full:
            for x in ts:
                if x.text and "⇥" in x.text:
                    a, b = x.text.split("⇥", 1); x.text = a; r = x.getparent(); tb = el("tab"); r.append(tb); y = el("t"); y.text = b; y.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); r.append(y)
            if full.startswith("Appendix") and s == "Heading1":
                tabs = setp(p, "tabs"); tabs.append(el("tab", val="clear", pos=851)); tabs.append(el("tab", val="left", pos=2268)); setp(p, "ind", left=2268, hanging=2268)
            if s == "Heading3": tabs = setp(p, "tabs"); tabs.append(el("tab", val="left", pos=851))
        else: setp(p, "ind", left=0, firstLine=0)
        if full.startswith("Appendix") and s == "Heading1" or re.match(r"(?i)references$", full.strip()): setp(p, "pageBreakBefore")
        continue
    # displayed equations: Equation style, number after a right tab
    om = xp(p, "./m:oMathPara")
    if om and not intable:
        num = re.findall(r"⟦EQ (.*?)⟧", t); rest = re.sub(r"⟦EQ .*?⟧", "", t).strip()
        if not rest and len(om) == 1:
            for c in list(p):
                if c.tag != q("w:pPr") and c.tag != q("m:oMathPara"): p.remove(c)
            sty(p, "Equation")
            if num:
                o = om[0]; i = list(p).index(o); p.remove(o)
                for mm in xp(o, "./m:oMath"): p.insert(i, mm); i += 1
                for nary in xp(p, ".//m:nary/m:naryPr"):
                    if nary.find(q("m:limLoc")) is None:
                        l = E.Element(q("m:limLoc")); l.set(q("m:val"), "undOvr"); ch = nary.find(q("m:chr")); nary.insert(0 if ch is None else list(nary).index(ch) + 1, l)
                r = el("r"); r.append(el("tab")); x = el("t"); x.text = "(" + num[0] + ")"; r.append(x); p.append(r)
            continue
        warn.append("displayed equation inside a text paragraph: " + (rest or t)[:60])
        for x in xp(p, ".//w:t"): x.text = re.sub(r"⟦EQ (.*?)⟧", r"(\1)", x.text or "")
    if xp(p, ".//w:drawing"): sty(p, "Normal"); setp(p, "keepNext"); setp(p, "spacing", before=0, after=0, line=240, lineRule="auto"); continue
    low = t.strip().lower()
    if re.match(r"(notes?|source|sources)\s*[:.]", low): sty(p, "Table-source" if low.startswith("source") else "Table-notes"); continue
    if xp(p, "./w:pPr/w:numPr"):
        nx = p.getnext(); more = nx is not None and nx.tag == q("w:p") and xp(nx, "./w:pPr/w:numPr"); sty(p, "Normal"); setp(p, "spacing", before=0, after=120 if more else 360); continue
    if s in ("BlockText",): sty(p, "Quote"); continue
    if s in ("BodyText", "FirstParagraph", "Normal", "Compact", "Bibliography"): sty(p, "Bullets" if xp(p, "./w:pPr/w:numPr") and has("Bullets") and False else "Normal")
# an equation number that Pandoc put in its own paragraph
for p in xp(B, "./w:p"):
    m = re.fullmatch(r"\s*⟦EQ (.*?)⟧\s*", txt(p))
    if m and not xp(p, ".//m:oMath"):
        prev = p.getprevious()
        if prev is not None and get(prev) == "Equation": r = el("r"); r.append(el("tab")); x = el("t"); x.text = "(" + m[1] + ")"; r.append(x); prev.append(r); B.remove(p)
for p in list(xp(B, "./w:p")):
    if get(p) != "Table-notes" or not re.search(r"\bSources?:", txt(p)): continue
    for r in list(p.findall(q("w:r"))):
        t = txt(r)
        if re.match(r"\s*Sources?\b", t) and r.getprevious() is not None and r.getprevious().tag == q("w:r"):
            new = el("p"); sty(new, "Table-source"); nx = r; mv = []
            while nx is not None: mv.append(nx); nx = nx.getnext()
            for x in mv: new.append(x)
            p.addnext(new)
            last = p.findall(q("w:r"))
            if last and xp(last[-1], "./w:br"): p.remove(last[-1])
            break
# text after a table or figure, up to the source line, that is set as a note (no marker word)
body = list(B)
for i, b in enumerate(body):
    if b.tag == q("w:p") and get(b) == "Table-title":
        group_, seen = [b], False
        for c in body[i + 1:]:
            if c.tag == q("w:tbl") or xp(c, ".//w:drawing"): group_.append(c); seen = True
            elif c.tag == q("w:p") and (get(c) in ("Table-notes", "Table-source") or not seen or re.match(r"^\s*[\*†‡]|^\s*[a-z]\s", txt(c)) and seen and len(txt(c)) < 400): group_.append(c)
            else: break
            if c.tag == q("w:p") and get(c) == "Table-source": break
        for c in group_[:-1]:
            if c.tag == q("w:p"): setp(c, "keepNext"); setp(c, "keepLines")
            else:
                for pz in xp(c, ".//w:p"): setp(pz, "keepNext")
        if not any(c.tag == q("w:p") and get(c) == "Table-source" for c in group_): warn.append("no “Source:” line under " + txt(b)[:40])
        last = group_[-1]
        if last.tag == q("w:p") and get(last) == "Table-notes": setp(last, "spacing", before=120, after=360)
# tables: horizontal rules, no shading; picture grids without rules
lastcol = None
for t in xp(B, ".//w:tbl"):
    pr = t.find(q("w:tblPr")); grid = bool(xp(t, ".//w:drawing"))
    for n in ["tblStyle", "tblBorders", "tblLook", "tblLayout", "tblCellMar", "jc", "tblCaption", "tblDescription"]:
        for x in pr.findall(q("w:" + n)): pr.remove(x)
    w = pr.find(q("w:tblW"))
    if w is None: w = el("tblW"); pr.append(w)
    w.set(q("w:type"), "pct"); w.set(q("w:w"), "5000")
    rows = t.findall(q("w:tr")); 
    br = el("tblBorders")
    if not grid: br.append(el("top", val="single", sz=8, space=0, color="000000")); br.append(el("bottom", val="single", sz=8, space=0, color="000000"))
    pr.append(br)
    cm = el("tblCellMar"); cm.append(el("left", w=57, type="dxa")); cm.append(el("right", w=57, type="dxa")); pr.append(cm)
    for x in xp(t, ".//w:tcPr/w:tcBorders|.//w:tcPr/w:shd"): x.getparent().remove(x)
    head = [i for i, r_ in enumerate(rows) if xp(r_, "./w:trPr/w:tblHeader")]
    hr = head[-1] if head else None
    if hr is None and rows and not grid: hr = 0; warn.append("table without a marked header row: rule placed under the first row")
    if not grid and hr is not None and len(rows) > 1:
        for tc in rows[hr].findall(q("w:tc")):
            tp = tc.find(q("w:tcPr"))
            if tp is None: tp = el("tcPr"); tc.insert(0, tp)
            b_ = el("tcBorders"); b_.append(el("bottom", val="single", sz=4, space=0, color="000000"))
            at = len(tp)
            for j, c in enumerate(tp):
                if E.QName(c).localname in ("shd", "noWrap", "tcMar", "textDirection", "tcFitText", "vAlign", "hideMark"): at = j; break
            tp.insert(at, b_)
    for r_ in rows:
        tp = r_.find(q("w:trPr"))
        if tp is None: tp = el("trPr"); r_.insert(0, tp)
        if tp.find(q("w:cantSplit")) is None: tp.insert(0, el("cantSplit"))
        cs = r_.findall(q("w:tc"))
        for p in xp(r_, ".//w:p"):
            if xp(p, ".//w:drawing"): setp(p, "jc", val="center"); setp(p, "spacing", before=0, after=60)
    # column widths in proportion to their longest text
    cols = t.find(q("w:tblGrid")); n = len(cols) if cols is not None else 0
    if n and not grid:
        wd = [4] * n
        for r_ in rows:
            j = 0
            for tc in r_.findall(q("w:tc")):
                sp = xp(tc, "./w:tcPr/w:gridSpan/@w:val"); k = int(sp[0]) if sp else 1; L = len(txt(tc)) + 2 * len(xp(tc, ".//m:oMath"))
                if k == 1 and j < n: wd[j] = max(wd[j], min(L, 60 if j == 0 else 40))
                j += k
        tot = sum(wd); W_ = 9026
        lw = [4] * n
        for r_ in rows:
            j = 0
            for tc in r_.findall(q("w:tc")):
                sp = xp(tc, "./w:tcPr/w:gridSpan/@w:val"); k = int(sp[0]) if sp else 1
                if k == 1 and j < n: lw[j] = max([lw[j]] + [len(y) + 0.2 * sum(z.isupper() for z in y) for y in re.split(r"[\s/–]+", txt(tc))])
                j += k
        lo = [int(min(1900, 130 + 108 * x)) for x in lw]
        if sum(lo) > W_: lo = [x * W_ // sum(lo) for x in lo]
        dx = [max(l_, round(W_ * x / tot)) for x, l_ in zip(wd, lo)]; over = sum(dx) - W_
        if over > 0:
            b_ = [max(0, x - l_) for x, l_ in zip(dx, lo)]; s_ = sum(b_) or 1; dx = [x - round(over * y / s_) for x, y in zip(dx, b_)]
        for g, x in zip(cols, dx): g.set(q("w:w"), str(x))
        for r_ in rows:
            j = 0
            for tc in r_.findall(q("w:tc")):
                sp = xp(tc, "./w:tcPr/w:gridSpan/@w:val"); k = int(sp[0]) if sp else 1; tp = tc.find(q("w:tcPr"))
                if tp is None: tp = el("tcPr"); tc.insert(0, tp)
                for x in tp.findall(q("w:tcW")): tp.remove(x)
                tp.insert(0, el("tcW", w=sum(dx[j:j + k]), type="dxa")); j += k
    elif grid:
        for g in cols: g.set(q("w:w"), str(9026 // n))
        for tc in xp(t, ".//w:tc"):
            tp = tc.find(q("w:tcPr"))
            if tp is None: tp = el("tcPr"); tc.insert(0, tp)
            for x in tp.findall(q("w:tcW")): tp.remove(x)
            tp.insert(0, el("tcW", w=9026 // n, type="dxa"))
        lim = 9026 // n * 635 - 2 * 57 * 635
        for dr in xp(t, ".//wp:inline"):
            ex = dr.find(q("wp:extent"))
            if int(ex.get("cx")) > lim:
                f = lim / int(ex.get("cx"))
                for x in [ex] + xp(dr, ".//a:xfrm/a:ext"): x.set("cx", str(int(int(x.get("cx")) * f))); x.set("cy", str(int(int(x.get("cy")) * f)))
for dr in xp(B, ".//wp:inline"):        # nothing taller than a page with its title and notes
    ex = dr.find(q("wp:extent")); cx = int(ex.get("cx"))
    if abs(cx - 5334000) < 3000 and not any(True for _ in dr.iterancestors(q("w:tbl"))):      # Pandoc's own page width: use ours
        for x in [ex] + xp(dr, ".//a:xfrm/a:ext"): x.set("cx", str(int(int(x.get("cx")) * 5731510 / cx))); x.set("cy", str(int(int(x.get("cy")) * 5731510 / cx)))
    f = min(1, 5731510 / int(ex.get("cx")), 7200000 / int(ex.get("cy")))
    if f < 1:
        for x in [ex] + xp(dr, ".//a:xfrm/a:ext"): x.set("cx", str(int(int(x.get("cx")) * f))); x.set("cy", str(int(int(x.get("cy")) * f)))
# runs: no theme colours or fonts in the text itself
for c in xp(D, "//m:acc/m:accPr/m:chr"):
    if c.get(q("m:val")) == "‾": c.set(q("m:val"), "\u0305")          # shown as an accent otherwise
for c in xp(D, "//m:nor/../m:sty"): c.getparent().remove(c)
for c in xp(D, "//m:mcPr"):
    a, b = c.find(q("m:count")), c.find(q("m:mcJc"))
    if a is not None and b is not None and list(c).index(a) > list(c).index(b): c.remove(a); c.insert(0, a)
for nary in xp(D, "//w:p//m:nary"):     # limits beside the sign in running text, as LaTeX sets them
    p = next(nary.iterancestors(q("w:p")))
    if get(p) == "Equation": continue
    npr = nary.find(q("m:naryPr")); l = npr.find(q("m:limLoc")) if npr is not None else None
    if l is not None: l.set(q("m:val"), "subSup")
for rp in xp(D, "//w:r/w:rPr"):
    for n in ["rFonts", "color", "sz", "szCs"]:
        for x in rp.findall(q("w:" + n)): rp.remove(x)
# title page
first = None
if not A.no_front and (WK / "front.json").exists():
    f = json.loads((WK / "front.json").read_text(encoding="utf-8"))
    def plain(s):
        if not s.strip(): return ""
        r = subprocess.run([PD, "-f", "latex", "-t", "plain", "--wrap=none"], input=s, capture_output=True, text=True); return " ".join(r.stdout.split())
    fields = [("title", "Title"), ("subtitle", "Subtitle"), ("authors", "Author(s)"), ("corresponding", "Corresponding author and email address"), ("affiliations", "All affiliations"), ("abstract", "Abstract"), ("keywords", "Keywords"), ("jel", "JEL codes"), ("acknowledgements", "Acknowledgements"), ("note", "Note")]
    ps = []
    for k, l in fields:
        v = plain(f.get(k, "") or "")
        if v: p = para("", "Normal"); [p.remove(x) for x in p.findall(q("w:r"))]; run(p, l + ": ", True); run(p, v); ps.append(p)
    for i, p in enumerate(ps): B.insert(i, p)
    first = ps[-1] if ps else None
# A4, 1-inch margins; title page unnumbered, then page numbers from 1
end = B.find(q("w:sectPr"))
if end is None: end = el("sectPr"); B.append(end)
for x in list(end): end.remove(x)
def geom(s, start):
    s.append(el("pgSz", w=11906, h=16838)); s.append(el("pgMar", top=1440, right=1440, bottom=1440, left=1440, header=709, footer=709, gutter=0))
    if start: s.append(el("pgNumType", start=1))
fr = E.SubElement(end, q("w:footerReference")); fr.set(q("w:type"), "default"); fr.set(q("r:id"), "rIdFooterL2W"); geom(end, True)
P["word/footerL2W.xml"] = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr xmlns:w="%s"><w:p><w:pPr><w:pStyle w:val="Normal"/><w:spacing w:after="0"/><w:jc w:val="center"/></w:pPr><w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>1</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p></w:ftr>' % N["w"]).encode()
P["word/_rels/document.xml.rels"] = P["word/_rels/document.xml.rels"].replace(b"</Relationships>", b'<Relationship Id="rIdFooterL2W" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footerL2W.xml"/></Relationships>')
P["[Content_Types].xml"] = P["[Content_Types].xml"].replace(b"</Types>", b'<Override PartName="/word/footerL2W.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>')
for ext, ct in [("png", "image/png"), ("jpg", "image/jpeg"), ("jpeg", "image/jpeg")]:
    if any(n.endswith("." + ext) for n in P) and ('Extension="%s"' % ext).encode() not in P["[Content_Types].xml"]: P["[Content_Types].xml"] = re.sub(rb"(<Types[^>]*>)", lambda m: m[1] + ('<Default Extension="%s" ContentType="%s"/>' % (ext, ct)).encode(), P["[Content_Types].xml"], count=1)
if first is not None:
    s = el("sectPr"); ty = el("type", val="nextPage"); s.append(ty); geom(s, False); pp(first).append(s)
# footnotes
if "word/footnotes.xml" in P:
    F = E.fromstring(P["word/footnotes.xml"])
    for rp in xp(F, "//w:r/w:rPr"):
        for n in ["rFonts", "color", "sz", "szCs"]:
            for x in rp.findall(q("w:" + n)): rp.remove(x)
    for p in xp(F, "//w:footnote[not(@w:type)]//w:p"): sty(p, "FootnoteText")
    P["word/footnotes.xml"] = E.tostring(F, xml_declaration=True, encoding="UTF-8", standalone=True)
left = sorted(set(re.findall(r"⟦[^⟧]{0,60}⟧?|\?\?", txt(B))))
if left: warn.append("unresolved markers in the text: " + ", ".join(left[:12]))
P["word/document.xml"] = E.tostring(D, xml_declaration=True, encoding="UTF-8", standalone=True); P["word/styles.xml"] = E.tostring(ST, xml_declaration=True, encoding="UTF-8", standalone=True)
out = Path(A.out)
if out.exists(): print(f"Replacing {out}")
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for n, v in P.items(): z.writestr(n, v)
print(f"Wrote {out}")
for x in msg + warn: print(" -", x)
(WK / "convert_log.json").write_text(json.dumps(msg + warn, indent=1, ensure_ascii=False), encoding="utf-8")
