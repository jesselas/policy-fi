#!/usr/bin/env python3
"""Step 1. Turn a LaTeX paper into one clean file that Pandoc converts well.

    python3 prepare.py path/to/main.tex -o work/

Writes work/flat.tex, work/front.json (title page, edit by hand), work/report.json (what was
found, what needs a look) and work/figures/*.png. The source folder is never changed.
"""
import argparse, json, re, subprocess, sys, unicodedata
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("tex"); ap.add_argument("-o", "--out", default="work")
ap.add_argument("--dpi", type=int, default=300)
ap.add_argument("--textwidth", type=float, default=6.27, help="text width in inches (A4, 1-inch margins)")
ap.add_argument("--labels", action="store_true", help=argparse.SUPPRESS)
A = ap.parse_args()
MAIN = Path(A.tex).resolve(); ROOT = MAIN.parent; OUT = Path(A.out).resolve(); FIG = OUT / "figures"
FIG.mkdir(parents=True, exist_ok=True)
warn = []
def W(x):
    if x not in warn: warn.append(x)

# ---------- small parsing tools ----------
def group(s, i, o="{", c="}"):
    """Content of the balanced group that starts at or after s[i], and the position after it."""
    while i < len(s) and s[i].isspace(): i += 1
    if i >= len(s) or s[i] != o: return None, i
    d, k = 0, i
    while k < len(s):
        ch = s[k]
        if ch == "\\": k += 2; continue
        if o == "[" and ch == "{":
            _, k = group(s, k); continue
        if ch == o: d += 1
        elif ch == c:
            d -= 1
            if d == 0: return s[i + 1:k], k + 1
        k += 1
    return None, i
def opt(s, i):
    j = i
    while j < len(s) and s[j] in " \t": j += 1
    if j < len(s) and s[j] == "[":
        v, k = group(s, j, "[", "]")
        if v is not None: return v, k
    return None, i
def command(s, name, nargs, fn, star=True):
    """Replace every \\name[opt]{a1}..{an} by fn(opt, args, starred)."""
    out, pos = [], 0
    for m in re.finditer(r"\\" + name + r"(?![A-Za-z@])" + (r"(\*?)" if star else r"()"), s):
        if m.start() < pos: continue
        i = m.end(); o, i = opt(s, i); args = []; ok = True
        for _ in range(nargs):
            v, i = group(s, i)
            if v is None: ok = False; break
            args.append(v)
        if not ok: continue
        out.append(s[pos:m.start()]); out.append(fn(o, args, bool(m[1]))); pos = i
    out.append(s[pos:]); return "".join(out)
def env(s, name, fn):
    """Replace every \\begin{name}..\\end{name} (no nesting of the same name) by fn(body, starred)."""
    return re.sub(r"\\begin\{(" + name + r")(\*?)\}(.*?)\\end\{\1\2\}", lambda m: fn(m[3], bool(m[2]), m[1]), s, flags=re.S)
def uncomment(s):
    s = re.sub(r"\\begin\{comment\}.*?\\end\{comment\}", "", s, flags=re.S)
    s = re.sub(r"\\iffalse\b.*?\\fi\b", "", s, flags=re.S)
    s = re.sub(r"(?m)^[ \t]*%.*\n?", "", s)
    return re.sub(r"(?<!\\)%.*", "", s)

def find(name, exts):
    name = name.strip().strip('"')
    for base in [ROOT] + PATHS:
        for e in [""] + exts:
            p = base / (name + e)
            if p.is_file(): return p
    hits = [p for p in ROOT.rglob("*") if p.is_file() and (p.name == Path(name).name or p.stem == Path(name).name and p.suffix.lower() in exts)]
    return hits[0] if hits else None
PATHS = []
def read(p):
    b = p.read_bytes()
    try: return b.decode("utf-8")
    except UnicodeDecodeError: return b.decode("latin-1")
def flatten(p, depth=0):
    s = uncomment(read(p))
    if depth > 12: return s
    def sub(o, a, st):
        q = find(a[0], [".tex"])
        if q is None:
            W(f"input file not found: {a[0]}"); return ""
        return flatten(q, depth + 1)
    s = re.sub(r"\\(?:input|include|subfile|estauto|tabinput)\s+([^\s\\{}]+)", lambda m: "\\input{" + m[1] + "}", s)
    s = re.sub(r"(\\(?:re|provide)?newcommand\*?\s*\{?)\\(" + "|".join(INPUTS or ["@"]) + r")(\}?\s*\[1\])", r"\1\\UNUSED\3", s)
    for c in ["input", "include", "subfile"] + INPUTS: s = command(s, c, 1, sub, star=False)
    for c in ["import", "subimport"]: s = command(s, c, 2, lambda o, a, st: sub(o, [a[0] + a[1]], st))
    return s

raw_ = "\n".join(uncomment(read(p)) for p in [MAIN] + [p for p in ROOT.glob("*.tex") if p != MAIN])
INPUTS = [m[1] for m in re.finditer(r"\\(?:re|provide)?newcommand\*?\s*\{?\\([A-Za-z]+)\}?\s*\[1\]\s*\{[^\n]*?\\@{0,2}input\b", raw_)]   # \tabinput{..} and the like
src = flatten(MAIN)
pre, sep, body = src.partition("\\begin{document}")
if not sep: pre, body = "", src
body = body.split("\\end{document}")[0]
body = re.sub(r"\\makeatletter.*?\\makeatother", "", body, flags=re.S)
for m in re.finditer(r"\\graphicspath\{((?:\s*\{[^}]*\})+)\s*\}", src):
    PATHS += [(ROOT / x) for x in re.findall(r"\{([^}]*)\}", m[1])]

# ---------- macros ----------
defs, simple = [], {}
for m in re.finditer(r"\\(?:re|provide)?newcommand\*?\s*\{?\s*\\([A-Za-z]+)\s*\}?", src):
    i = m.end(); n, i = opt(src, i); d, i = opt(src, i); v, i = group(src, i)
    if v is None or m[1] in {"familydefault", "baselinestretch", "UrlFont", "href", "arraystretch", "abstractname", "refname", "bibname", "section", "subsection", "note"} and "renew" in m[0]: continue
    if re.match(r"the(?:(?:sub)*section|table|figure|equation|page|footnote)$|th[a-z]+head$", m[1]):
        continue
    if "@" in v: continue
    if n is None: simple[m[1]] = v
    else: defs.append("\\newcommand{\\%s}[%s]%s{%s}" % (m[1], n, f"[{d}]" if d is not None else "", v))
for m in re.finditer(r"\\def\s*\\([A-Za-z]+)\s*(?=\{)", src):
    v, _ = group(src, m.end())
    if v is not None: simple[m[1]] = v
ops = re.findall(r"\\DeclareMathOperator(\*?)\{\\([A-Za-z]+)\}\{([^}]*)\}", src)
for st, n, v in ops: simple[n] = "\\operatorname%s{%s}" % (st, v)
for m in re.finditer(r"\\DeclarePairedDelimiter\{?\\([A-Za-z]+)\}?\{(.*?)\}\{(.*?)\}", src): defs.append("\\newcommand{\\%s}[1]{\\left%s #1\\right%s}" % m.groups())
body = re.sub(r"\\(?:re|provide)?newcommand\*?\s*\{?\\(?!the[a-z]+\b)[A-Za-z]+\}?", "\\\\GONE", body)
def gone(s):
    while "\\GONE" in s:
        i = s.index("\\GONE"); k = i + 5
        _, k = opt(s, k); _, k = opt(s, k); _, k = group(s, k); s = s[:i] + s[k:]
    return s
body = gone(body)
body = re.sub(r"\\def\s*\\[A-Za-z]+(?=\{)", "\\\\GONE", body); body = gone(body)
for _ in range(6):                       # parameterless macros, also inside one another
    before = body
    for k, v in simple.items():
        if re.search(r"\\" + k + r"(?![A-Za-z@])", v): continue
        x = "\\xspace" in v; val = v.replace("\\xspace", "")
        def put(m, val=val, x=x):
            tail = m[1]
            if x and tail.startswith(" "): return val + " "
            if tail.startswith("{}"): return val
            # keep a letter that followed the macro apart from a command at its end
            return val + (" " if tail and re.search(r"\\[A-Za-z]+$", val) else "")
        body = re.sub(r"\\" + k + r"(?![A-Za-z@])(\{\}|[ \t]*)", put, body)
    if body == before: break

# ---------- layout that Word does not need ----------
body = re.sub(r"\\begin\{(?:landscape|adjustbox|adjustwidth|center|flushleft|flushright|spacing|singlespace|singlespacing|doublespace|onehalfspace|small|footnotesize|scriptsize|tiny|normalsize|large|minipage|threeparttable|ThreePartTable|measuredfigure|subtable|widepage|sidewaystable|sideways|samepage|raggedright|titlepage|frontmatter|justify|mdframed|framed)\}(?:\[[^\]]*\])*(?:\{[^{}]*\})*",
              lambda m: ("\\begin{table}" if "sidewaystable" in m[0] else "\n\n" if "minipage" in m[0] or "titlepage" in m[0] else ""), body)
body = re.sub(r"\\end\{(?:landscape|adjustbox|adjustwidth|center|flushleft|flushright|spacing|singlespace|singlespacing|doublespace|onehalfspace|small|footnotesize|scriptsize|tiny|normalsize|large|minipage|threeparttable|ThreePartTable|measuredfigure|subtable|widepage|sidewaystable|sideways|samepage|raggedright|titlepage|frontmatter|justify|mdframed|framed)\}",
              lambda m: "\\end{table}" if "sidewaystable" in m[0] else "\n\n", body)
body = re.sub(r"\\begin\{sidewaysfigure\}", r"\\begin{figure}", body); body = re.sub(r"\\end\{sidewaysfigure\}", r"\\end{figure}", body)
for c, n in [("resizebox", 3), ("scalebox", 2), ("rotatebox", 2), ("adjustbox", 2), ("makebox", 1), ("parbox", 2), ("raisebox", 2), ("colorbox", 2), ("textcolor", 2), ("captionsetup", 1), ("vspace", 1), ("setlength", 2), ("addtolength", 2), ("thispagestyle", 1), ("pagestyle", 1), ("pagenumbering", 1), ("addcontentsline", 3), ("bibliographystyle", 1), ("counterwithin", 2), ("numberwithin", 2), ("phantomsection", 0), ("linespread", 1), ("fontsize", 2), ("color", 1), ("footnotetext", 1), ("pdfbookmark", 2), ("hypersetup", 1), ("titleformat", 5), ("FloatBarrier", 0), ("usetikzlibrary", 1)]:
    keep = c in {"resizebox", "scalebox", "rotatebox", "adjustbox", "makebox", "parbox", "raisebox", "colorbox", "textcolor"}
    if c == "footnotetext":
        body = command(body, c, 1, lambda o, a, st: "\\FNTEXT{" + a[0] + "}"); continue
    body = command(body, c, n, lambda o, a, st, keep=keep: a[-1] if keep else "")
body = re.sub(r"\\(?:centering|raggedright|raggedleft|noindent|indent|clearpage|cleardoublepage|newpage|pagebreak|nopagebreak|linebreak|FloatBarrier|medskip|smallskip|bigskip|vfill|hfill|maketitle|tableofcontents|listoffigures|listoftables|doublespacing|onehalfspacing|singlespacing|footnotesize|scriptsize|normalsize|small|tiny|large|Large|LARGE|huge|Huge|selectfont|makeatletter|makeatother|allowbreak|sloppy|fussy|par(?=\s*\\end)|protect|ignorespaces|unskip|xspace|bfseries(?=\s*\\section)|hypertarget\{[^}]*\}|phantomsection|appendixpage|flushbottom|raggedbottom|nohyphens|nolinenumbers|linenumbers)(?![A-Za-z])(?:\[[^\]]*\])?", " ", body)
body = re.sub(r"\\(?:small|med|big)break\b|\\vskip\s*-?[\d.]+\s*\w+|\\hskip\s*-?[\d.]+\s*\w+", " ", body)

# a \footnotemark followed later by \footnotetext becomes an ordinary footnote
texts = []
def ft(o, a, st): texts.append(a[0]); return ""
body = command(body, "FNTEXT", 1, ft)
body = re.sub(r"\\footnotemark(?:\[[^\]]*\])?", lambda m: ("\\footnote{" + texts.pop(0) + "}") if texts else "", body)
if texts: W(f"{len(texts)} \\footnotetext without a matching \\footnotemark: check footnotes")

# ---------- title page ----------
front = {"title": "", "subtitle": "", "authors": "", "corresponding": "", "affiliations": "", "abstract": "", "keywords": "", "jel": "", "acknowledgements": "", "date": ""}
def grab(name):
    for s in (body, pre):
        m = re.search(r"\\" + name + r"(?![A-Za-z])", s)
        if m:
            i = m.end(); _, i = opt(s, i); v, _ = group(s, i)
            if v: return v.strip()
    return ""
for k in ["title", "author", "date", "subtitle"]: front["authors" if k == "author" else k] = grab(k)
thanks = []
for k in ["title", "authors"]: front[k] = command(front[k], "thanks", 1, lambda o, a, st: (thanks.append(a[0].strip()), "")[1])
front["acknowledgements"] = " ".join(thanks)
front["authors"] = re.sub(r"\s*\\(?:and|And|AND)\b\s*", "; ", front["authors"]); front["authors"] = re.sub(r"\s*\\\\\s*(?:\[[^\]]*\])?", ", ", front["authors"])
m = re.search(r"\\begin\{abstract\}(.*?)\\end\{abstract\}", body, re.S)
if m and not front["title"]: body = body.replace(m[0], "\n\n\\textbf{Abstract:} " + m[1].strip() + "\n\n"); m = None
if m: front["abstract"] = m[1].strip(); body = body.replace(m[0], "\n\n")
for k in ["title", "author", "date", "subtitle"]: body = command(body, k, 1, lambda o, a, st: "")
for k, pat in [("keywords", r"\\(?:textbf|emph|textit)\{\s*Key\s?words?:?\s*\}\s*:?(.*?)(?=\n\s*\n|\\\\|$)"), ("jel", r"\\(?:textbf|emph|textit)\{\s*JEL[^}]*\}\s*:?(.*?)(?=\n\s*\n|\\\\|$)")]:
    for where in ("abstract", None):
        t = front["abstract"] if where else body
        m = re.search(pat, t, re.S | re.I)
        if m and not front[k] and front["title"]:
            front[k] = m[1].strip(); t = t.replace(m[0], "")
            if where: front["abstract"] = t.strip()
            else: body = t

# ---------- numbering ----------
kinds = {}      # theorem-like environments: name -> (title, shared counter)
for m in re.finditer(r"\\newtheorem(\*?)\{([A-Za-z]+)\}(?:\[([A-Za-z]+)\])?\{([^}]*)\}(?:\[([A-Za-z]+)\])?", src): kinds[m[2]] = (m[4], m[3] or m[2], m[1] == "*", m[5])
for k, t in [("theorem", "Theorem"), ("lemma", "Lemma"), ("proposition", "Proposition"), ("corollary", "Corollary"), ("assumption", "Assumption"), ("definition", "Definition"), ("remark", "Remark"), ("hypothesis", "Hypothesis")]: kinds.setdefault(k, (t, k, False, None))
def noamp(r):
    """Drop alignment marks, keeping those inside matrices and cases."""
    out, d, i = [], 0, 0
    for t in re.finditer(r"\\begin\{[^}]*\}|\\end\{[^}]*\}|(?<!\\)&", r):
        out.append(r[i:t.start()]); i = t.end()
        if t[0] == "&": out.append("&" if d else ""); continue
        d += 1 if t[0].startswith("\\begin") else -1; out.append(t[0])
    return "".join(out) + r[i:]
eqs = {"equation", "align", "gather", "multline", "eqnarray", "alignat", "flalign"}
labels, lists = {}, {"section": [], "table": [], "figure": [], "equation": []}
tokre = re.compile(r"\\appendix(?![A-Za-z])|\\(?P<sec>part|chapter|section|subsection|subsubsection|paragraph)(?P<st>\*?)(?=\s*[\[{])|\\(?P<be>begin|end)\{(?P<env>[A-Za-z]+)(?P<est>\*?)\}|\\label\{(?P<lab>[^}]*)\}|\\caption(?P<cst>\*?)(?=\s*[\[{])|\\renewcommand\{?\\the(?P<the>[a-z]+)\}?|\\(?P<cn>setcounter|addtocounter)\s*\{(?P<ctr>\w+)\}\s*\{(?P<val>[^}]*)\}")
eqbysec = bool(re.search(r"\\numberwithin\{equation\}\{section\}|\\counterwithin\{equation\}\{section\}", src))
appreset = bool(re.search(r"\\(?:numberwithin|counterwithin)\*?\{(?:table|figure)\}\{section\}|\\the(?:table|figure)\}?\s*\{[^}]*\\(?:the)?(?:section|Alph)", src)) or True
cnt = {k: 0 for k in ["section", "subsection", "subsubsection", "table", "figure", "equation", "subfigure"]}; cnt.update({v[1]: 0 for v in kinds.values()})
app, cur, stack = False, "", []
fmt = {}
def number(c, default):
    """Number of counter c, using \\theC when the paper redefines it."""
    f = fmt.get(c)
    if f is None: return default
    f = f.replace("\\thesection", secno()).replace("\\thesubsection", secno() + "." + str(cnt["subsection"]))
    roman = lambda n: "".join(a * 1 for a in ["", "i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x", "xi", "xii"][n:n + 1])
    def v(m):
        n = cnt.get(m[2], 0); return {"arabic": str(n), "Alph": chr(64 + n) if n else "", "alph": chr(96 + n) if n else "", "Roman": roman(n).upper(), "roman": roman(n)}[m[1]]
    f = re.sub(r"\\(arabic|Alph|alph|Roman|roman)\{(\w+)\}", v, f)
    return re.sub(r"[{}~]", "", f) if "\\" not in f else default
def redefine(c, v):
    if c in ("table", "figure", "equation") or c == "subsection" and "section}" in v.replace("subsection}", "") or c == "subsection" and "\\thesection" in v: fmt[c] = v
def secno():
    a = chr(64 + cnt["section"]) if app and cnt["section"] else str(cnt["section"])
    return a
out, pos = [], 0
for m in re.finditer(r"\\(?:renewcommand\*?\s*\{?|def\s*)\\the(table|figure|equation|subsection)\}?\s*(?=\{)", pre):
    v_, _ = group(pre, m.end()); redefine(m[1], v_ or "")
for m in tokre.finditer(body):
    if m.start() < pos: continue
    out.append(body[pos:m.start()]); pos = m.end(); keep = m[0]
    if m[0].startswith("\\appendix"):
        app = True; cnt["section"] = 0; keep = ""
    elif m["sec"]:
        i = m.end(); _, i = opt(body, i); t, i = group(body, i); lv = m["sec"]; pos = i
        t = re.sub(r"\\label\{[^}]*\}", lambda a: (out.append(a[0]), "")[1], t); t = " ".join(t.split()); t = re.sub(r"\\footnote\{", r"\\footnote{", t)
        lab = re.findall(r"\\label\{([^}]*)\}", "".join(out[-3:])) if False else []
        if lv in ("part", "chapter"): lv = "section"
        if lv == "paragraph": keep = "\n\n\\textbf{" + t + "} "; out.append(keep); continue
        if m["st"]: num = ""; cur = t
        else:
            if lv == "section":
                cnt["section"] += 1; cnt["subsection"] = cnt["subsubsection"] = 0
                if eqbysec: cnt["equation"] = 0
                if app and appreset: cnt["table"] = cnt["figure"] = 0
                for v in kinds.values():
                    if v[3] == "section" or app: cnt[v[1]] = 0
                num = secno()
            elif lv == "subsection": cnt["subsection"] += 1; cnt["subsubsection"] = 0; num = number("subsection", secno() + "." + str(cnt["subsection"]))
            else: cnt["subsubsection"] += 1; num = secno() + f".{cnt['subsection']}.{cnt['subsubsection']}"
            cur = num
        shown = ("Appendix " + num if app and lv == "section" and not m["st"] else num)
        if lv == "section" and re.match(r"(?i)appendix\s*$", t) and m["st"]: shown = ""
        lists["section"].append((shown + " " + t).strip())
        keep = "\n\n\\%s*{%s%s}\n\n" % (lv, (shown + "⇥") if shown else "", t)
    elif m["be"] == "begin":
        e = m["env"]; stack.append([e, cur])
        if e in kinds and not m["est"]:
            t, c, st, _ = kinds[e]; i = m.end(); o, i = opt(body, i); pos = i
            if not st: cnt[c] += 1; cur = (secno() + "." if kinds[e][3] == "section" or app and False else "") + str(cnt[c])
            keep = "\n\n\\textbf{%s%s%s.}⟦RUNIN⟧ " % (t, " " + cur if not st else "", f" ({o})" if o else "")
        elif e == "proof": i = m.end(); o, i = opt(body, i); pos = i; keep = "\n\n\\emph{%s.} " % (o or "Proof")
        elif e in eqs and not m["est"]:
            end = body.find("\\end{" + e + "}", m.end()); inner = body[m.end():end]
            if e == "alignat": _, j = group(inner, 0); inner = inner[j:]
            rows, d, last = [], 0, 0
            for t in re.finditer(r"\\begin\{[^}]*\}|\\end\{[^}]*\}|\\\\(?:\[[^\]]*\])?", inner):
                if t[0].startswith("\\begin"): d += 1
                elif t[0].startswith("\\end"): d -= 1
                elif d == 0 and e != "equation" and e != "multline": rows.append(inner[last:t.start()]); last = t.end()
            rows.append(inner[last:]); done = []
            for r in rows:
                if not r.strip(): continue
                tag = re.search(r"\\tag\{([^}]*)\}", r); num = ""
                if tag: num = tag[1]
                elif not re.search(r"\\(?:nonumber|notag)\b", r): cnt["equation"] += 1; num = number("equation", (secno() + "." if eqbysec else "") + str(cnt["equation"]))
                for l in re.findall(r"\\label\{([^}]*)\}", r): labels[l] = ("Equation", num or cur)
                r = re.sub(r"\\label\{[^}]*\}|\\tag\{[^}]*\}|\\(?:nonumber|notag)\b", "", r).strip()
                if num: lists["equation"].append(num)
                done.append((r, num))
            nnum = sum(1 for r, n in done if n); txt = ""
            if len(done) > 1 and nnum <= 1:
                txt = "\\[\\begin{aligned}" + r" \\ ".join(r for r, n in done) + "\\end{aligned}\\]" + "".join(f"⟦EQ {n}⟧" for r, n in done if n)
            else:
                for r, n in done: txt += "\\[" + noamp(r) + "\\]" + (f"⟦EQ {n}⟧" if n else "") + "\n\n"
            keep = "\n\n" + txt.strip() + "\n\n"; pos = end + len("\\end{" + e + "}"); stack.pop()
        elif e in eqs or e == "displaymath" or e == "math":
            end = body.find("\\end{" + e + m["est"] + "}", m.end()); inner = re.sub(r"\\(?:label\{[^}]*\}|nonumber|notag)", "", body[m.end():end]).strip()
            if e == "alignat": _, j = group(inner, 0); inner = inner[j:]
            if e in ("align", "alignat", "flalign", "eqnarray", "gather") and "\\\\" in inner: inner = "\\begin{aligned}" + inner + "\\end{aligned}"
            else: inner = noamp(inner)
            keep = "\n\n\\[" + inner + "\\]\n\n"; pos = end + len("\\end{" + e + m["est"] + "}"); stack.pop()
        elif e in ("subequations",): keep = ""
        elif e in ("subfigure", "subcaptionblock"): pass
        if e in ("table", "figure", "longtable", "wrapfigure"): cnt["subfigure"] = 0
    elif m["be"] == "end":
        e = m["env"]
        while stack:
            x = stack.pop()
            if x[0] == e: cur = x[1] if e in ("table", "figure") else cur; break
        if e in kinds or e in ("proof",): keep = "\n\n"
        if e == "subequations": keep = ""
    elif m["lab"] is not None:
        k = next((x[0] for x in reversed(stack) if x[0] in ("table", "figure", "longtable", "subfigure", "wrapfigure") or x[0] in kinds), None)
        name = {"longtable": "Table", "table": "Table", "figure": "Figure", "subfigure": "Figure", "wrapfigure": "Figure"}.get(k) or (kinds[k][0] if k in kinds else "Section")
        if k in ("table", "figure", "longtable", "subfigure", "wrapfigure") and not cur:
            W(f"label before caption: {m['lab']}")
        labels[m["lab"]] = ("Appendix" if name == "Section" and re.match(r"[A-Z]", cur or "") else name, cur); keep = ""
    elif m["cn"]:
        keep = ""
        if m["ctr"] in cnt and re.fullmatch(r"\s*-?\d+\s*", m["val"]): cnt[m["ctr"]] = int(m["val"]) + (cnt[m["ctr"]] if m["cn"][0] == "a" else 0)
    elif m["the"] == "section" and not app:
        g_, i = group(body, m.end())
        if g_ and "Alph" in g_: app = True; cnt["section"] = 0
        if g_ is not None: pos = i
        keep = ""
    elif m["the"]:
        g_, i = group(body, m.end()); pos = i if g_ is not None else pos; keep = ""
        if g_:
            redefine(m["the"], g_)
            if m["the"] in ("table", "figure", "equation"): cnt[m["the"]] = 0
    elif m[0].startswith("\\caption"):
        i = m.end(); _, i = opt(body, i); t, i = group(body, i); pos = i
        labs = re.findall(r"\\label\{([^}]*)\}", t); t = re.sub(r"\\label\{[^}]*\}", "", t).strip()
        k = next((x[0] for x in reversed(stack) if x[0] in ("table", "figure", "longtable", "subfigure", "wrapfigure")), "figure")
        if k == "subfigure":
            cnt["subfigure"] += 1; cur = chr(96 + cnt["subfigure"]); keep = "⟦SUB (%s) %s⟧" % (cur, t)
            full = (secno() if app else "") + str(cnt["figure"] + 1) + cur
            for l in labs: labels[l] = ("Figure", full)
            cur = full
        else:
            kk = "table" if k in ("table", "longtable") else "figure"
            if m["cst"]: num = ""
            else: cnt[kk] += 1; num = number(kk, (secno() if app else "") + str(cnt[kk]))
            cur = num; lists[kk].append(num)
            for l in labs: labels[l] = (kk.title(), num)
            keep = "⟦CAP %s⟧%s⟦/CAP⟧" % (kk.title() + (" " + num if num else ""), t)
    out.append(keep)
out.append(body[pos:]); body = "".join(out)

# compare with the compiled paper when its .aux file is there
aux = {}
for p in [MAIN.with_suffix(".aux"), ROOT / "output.aux"]:
    if p.is_file():
        for line in read(p).splitlines():
            if line.startswith("\\newlabel{"):
                k, i = group(line, 9); v, _ = group(line, i)
                if v:
                    n, _ = group(v, 0); aux[k] = n
        break
diff = {k: (labels[k][1], aux[k]) for k in labels if k in aux and aux[k] and labels[k][1] != aux[k] and "@" not in k}
if diff:
    W(f"numbers differ from the compiled .aux file (label: here, compiled). Fine for roman sections and for A1, A2 in appendices, otherwise correct flat.tex: {diff}")

# labels of a separate online appendix, \\externaldocument[OA-]{online_appendix}
for m in re.finditer(r"\\externaldocument(?:\[([^\]]*)\])?\{([^}]*)\}", src):
    q_ = find(m[2], [".tex"])
    if q_ is None or A.labels: continue
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        subprocess.run([sys.executable, __file__, str(q_), "-o", td, "--labels"], capture_output=True)
        f_ = Path(td) / "report.json"
        if f_.exists():
            for k, v in json.loads(f_.read_text(encoding="utf-8"))["labels"].items(): labels[(m[1] or "") + k] = v
            W(f"numbers of {q_.name} were worked out from its source: compare them with its PDF")

# ---------- references to numbered things ----------
def lab(k, f=lambda n, t: n):
    k = k.strip()
    if k in labels: return f(labels[k][1], labels[k][0])
    W(f"reference without a label: {k}"); return "??"
def names(a, cap):
    by = {}
    for k in [x.strip() for x in a.split(",")]:
        n = lab(k); t = labels.get(k, ("", ""))[0]; by.setdefault(t, []).append(f"({n})" if t == "Equation" else n)
    return " and ".join((t + ("s" if len(v) > 1 else "") + "~" if t else "") + (v[0] if len(v) == 1 else ", ".join(v[:-1]) + " and " + v[-1]) for t, v in by.items())
body = command(body, "eqref", 1, lambda o, a, st: "(" + lab(a[0]) + ")")
for c in ["ref", "subref", "cref", "Cref", "autoref", "vref", "pageref", "nameref", "Autoref"]:
    body = command(body, c, 1, lambda o, a, st, c=c: ("⟦PAGE?⟧" if c == "pageref" else lab(a[0]) if c in ("ref", "subref", "vref", "nameref") else names(a[0], c[0] in "CA" or True)))
body = re.sub(r"\\hyperref\[[^\]]*\]\{", "{", body); body = re.sub(r"\\label\{[^}]*\}", "", body)
if "⟦PAGE?⟧" in body: W("\\pageref found: replace the page reference by hand")

# ---------- citations: everything becomes natbib, which Pandoc reads ----------
body = re.sub(r"\\(shortcite(?:A|NP)?|cite(?:A|NP)?)\s*<([^>]*)>\s*(?:\[([^\]]*)\])?\s*\{", lambda m: "\\" + m[1] + "[" + m[2] + "][" + (m[3] or "") + "]{", body)
apa = bool(re.search(r"\{apacite\}", src))
for a, b in [("shortciteNP", "citealp"), ("citeNP", "citealp"), ("shortciteA", "citet"), ("citeA", "citet"), ("shortcite", "citep")]: body = re.sub(r"\\" + a + r"(?![A-Za-z])", lambda m, b=b: "\\" + b, body)
for a, b in [("parencite", "citep"), ("Parencite", "citep"), ("textcite", "citet"), ("Textcite", "citet"), ("autocite", "citep"), ("footcite", "citep"), ("citealt", "citealp"), ("Citet", "citet"), ("Citep", "citep"), ("citeyearpar", "CITEYP"), ("possessivecite", "citet")]: body = re.sub(r"\\" + a + r"(?![A-Za-z])", lambda m, b=b: "\\" + b, body)
if apa or re.search(r"\{natbib\}|harvard", src): body = re.sub(r"\\cite(?![A-Za-z])(\*?)", (r"\\citep" if apa else r"\\citet"), body)
def nopar(m):
    return "\\href{nopar:}{\\citet" + m[1] + "}"
body = re.sub(r"\\citealp\*?((?:\[[^\]]*\])*\{[^}]*\})", nopar, body)
body = re.sub(r"\\CITEYP\*?((?:\[[^\]]*\])*)\{([^}]*)\}", r"\\href{yearpar:}{\\citep\1{\2}}", body)
body = re.sub(r"\\(citet|citep)\*", r"\\\1", body)
body = re.sub(r"\\citeauthor\*?\{([^}]*)\}", r"\\href{author:}{\\citet{\1}}", body)
body = re.sub(r"\\citeyear\*?\{([^}]*)\}", r"\\href{year:}{\\citep{\1}}", body)
cited = set()
for m in re.finditer(r"\\cite[a-z]*\*?(?:\[[^\]]*\])*\{([^}]*)\}", body): cited |= {k.strip() for k in m[1].split(",")}
bibs = []
for m in re.finditer(r"\\(?:bibliography|addbibresource)(?:\[[^\]]*\])?\{([^}]*)\}", src):
    for n in m[1].split(","):
        p = find(n, [".bib"])
        if p: bibs.append(str(p))
        else: W(f"bibliography file not found: {n}")
body = re.sub(r"\\(?:bibliography|nocite|addbibresource)(?:\[[^\]]*\])?\{[^}]*\}", lambda m: "⟦REFS⟧" if "bibliography{" in m[0] else "", body)
body = re.sub(r"\\printbibliography(?:\[[^\]]*\])?", "⟦REFS⟧", body)
typed = bool(re.search(r"\\begin\{thebibliography\}", body))
if not bibs and not typed and cited:
    bbl = next((p for p in [MAIN.with_suffix(".bbl")] + list(ROOT.glob("*.bbl")) if p.is_file()), None)
    if bbl: body = body.replace("⟦REFS⟧", read(bbl)); typed = True; W("no .bib file: citations and references come from the .bbl file")
    else: W("no .bib or .bbl file: citations cannot be resolved automatically")
if typed:                                # reference list typed in the paper, natbib labels
    bl = {}
    for m in re.finditer(r"\\bibitem", body):
        o, i = opt(body, m.end()); k, _ = group(body, i)
        if not k: continue
        mm = re.match(r"\{?(.*?)\(([^()]*)\)(.*)$", (o or "").replace("\n", " "), re.S)
        if mm: bl[k] = (mm[1].strip("{} "), mm[2].strip("{} "))
    def one(k): return bl.get(k.strip()) or (W(f"citation without an entry: {k}"), (k.strip(), "??"))[1]
    def cit(m):
        o = re.findall(r"\[([^\]]*)\]", m[2]); pre_, post = (o + [""])[:2] if len(o) == 2 else ("", o[0] if o else "")
        ks = [one(k) for k in m[3].split(",")]; post = ": " + post if post else ""; pre_ = pre_ + " " if pre_ else ""
        if m[1] == "citet": return pre_ + "; ".join(f"{a} ({y}{post})" for a, y in ks)
        return "(" + pre_ + "; ".join(f"{a} {y}" for a, y in ks) + post + ")"
    body = re.sub(r"\\href\{nopar:\}\{\\citet((?:\[[^\]]*\])*)\{([^}]*)\}\}", lambda m: "; ".join(" ".join(one(k)) for k in m[2].split(",")), body)
    body = re.sub(r"\\(citet|citep|cite)((?:\[[^\]]*\])*)\{([^}]*)\}", cit, body)
    def bibenv(m):
        t = m[1]; o_ = []; i = 0
        for x in re.split(r"\\bibitem", t)[1:]:
            o, j = opt(x, 0); k, j = group(x, j); o_.append("\n\n" + " ".join(x[j:].replace("\\newblock", " ").split()))
        return "\n\n\\section*{References}\n\n" + "".join(o_) + "\n\n"
    body = re.sub(r"\\begin\{thebibliography\}\{[^}]*\}(.*?)\\end\{thebibliography\}", bibenv, body, flags=re.S)
keys = set()
for b in bibs: keys |= set(re.findall(r"@\w+\s*[{(]\s*([^,\s]+)\s*,", read(Path(b))))
if bibs and cited - keys: W(f"cited but not in the .bib file: {sorted(cited - keys)}")

# ---------- figures ----------
nfig = 0
def to_png(name):
    global nfig
    p = find(name, [".pdf", ".png", ".jpg", ".jpeg", ".eps", ".svg", ".tif", ".tiff"])
    if p is None: W(f"figure file not found: {name}"); return None
    nfig += 1; out = FIG / (re.sub(r"[^A-Za-z0-9]+", "_", str(Path(name).with_suffix("")))[-60:].strip("_") + ".png")
    try:
        if p.suffix.lower() in (".png", ".jpg", ".jpeg"):
            out = out.with_suffix(p.suffix.lower()); out.write_bytes(p.read_bytes()); return out
        if p.suffix.lower() == ".pdf":
            try:
                import fitz
                d = fitz.open(p); d[0].get_pixmap(dpi=A.dpi).save(out)
            except ImportError:
                import pypdfium2
                pypdfium2.PdfDocument(str(p))[0].render(scale=A.dpi / 72).to_pil().save(out)
        elif p.suffix.lower() == ".eps": subprocess.run(["gs", "-q", "-dSAFER", "-dBATCH", "-dNOPAUSE", "-dEPSCrop", "-sDEVICE=png16m", f"-r{A.dpi}", f"-sOutputFile={out}", str(p)], check=True)
        elif p.suffix.lower() == ".svg": subprocess.run(["rsvg-convert", "-z", "3", "-o", str(out), str(p)], check=True)
        else:
            from PIL import Image
            Image.open(p).save(out)
        return out
    except Exception as ex:
        W(f"could not convert figure {p.name}: {ex}"); return None
def frac(o):
    o = o or ""
    m = re.search(r"width\s*=\s*([\d.]*)\s*\\(?:text|line|column|hsize|paper)\w*", o)
    if m: return float(m[1] or 1)
    m = re.search(r"width\s*=\s*([\d.]+)\s*(cm|mm|in|pt)", o)
    if m: return min(1, float(m[1]) * {"cm": 1 / 2.54, "mm": 1 / 25.4, "in": 1, "pt": 1 / 72.27}[m[2]] / A.textwidth)
    return None
def img(o, a, st, scale=1.0):
    if a[0].startswith(str(FIG)): return "\\includegraphics[%s]{%s}" % (o, a[0])   # already converted
    p = to_png(a[0])
    if p is None: return "⟦MISSING FIGURE %s⟧" % a[0].replace("_", "\\_")
    f = frac(o); f = min(1.0, (f if f else 1.0) * scale)
    return "\\includegraphics[width=%.2fin]{%s}" % (A.textwidth * f, p)
def figure(t, st, e):
    t = re.sub(r"^\s*\[[^\]]*\]", "", t)
    if e == "wrapfigure": t = re.sub(r"^\s*(\[[^\]]*\])?\{[^}]*\}\{[^}]*\}", "", t)
    caps = re.findall(r"⟦CAP (.*?)⟧(.*?)⟦/CAP⟧", t, re.S); t = re.sub(r"⟦CAP (.*?)⟧(.*?)⟦/CAP⟧", "", t, flags=re.S)
    if "\\begin{tikzpicture}" in t: W("TikZ picture found: compile it to PDF or PNG and insert it by hand"); t = re.sub(r"\\begin\{tikzpicture\}.*?\\end\{tikzpicture\}", "⟦MISSING FIGURE TikZ⟧", t, flags=re.S)
    subs = []
    def sub(m):
        o = re.match(r"\s*(?:\[[^\]]*\])*\{\s*([\d.]*)\s*\\\w+\s*\}", m[2]); f = float((o[1] if o and o[1] else 1) or 1); inner = m[2][o.end():] if o else m[2]
        inner = command(inner, "subcaption", 1, lambda o, a, st: "⟦SUB " + a[0] + "⟧"); sc = re.search(r"⟦SUB (.*?)⟧", inner, re.S); g = command(inner, "includegraphics", 1, lambda o, a, st: img(o, a, st, f))
        g = re.sub(r"⟦SUB .*?⟧", "", g, flags=re.S).strip(); subs.append((f, " ".join(sc[1].split()) if sc else "", " ".join(g.split())))
        return "⟦SUBHERE⟧"
    t = re.sub(r"\\begin\{(subfigure|subcaptionblock)\}(.*?)\\end\{\1\}", sub, t, flags=re.S)
    def subfloat(o, a, st):
        subs.append((0.48, o or "", command(a[0], "includegraphics", 1, lambda o2, a2, st2: img(o2, a2, st2)))); return "⟦SUBHERE⟧"
    for c in ["subfloat", "subcaptionbox"]: t = command(t, c, 2 if c == "subcaptionbox" else 1, (lambda o, a, st: subfloat(a[0], a[1:], st)) if c == "subcaptionbox" else subfloat)
    t = command(t, "includegraphics", 1, img)
    grid = ""
    if subs:
        n = max(1, min(4, int(1.02 / max(0.2, sum(s[0] for s in subs) / len(subs))))); rows = [subs[i:i + n] for i in range(0, len(subs), n)]
        if n == 1: grid = "\n\n".join((s[1] + "\n\n" if s[1] else "") + s[2] for s in subs)
        else:
            grid = "\\begin{tabular}{" + "c" * n + "}\n" + "\\\\\n".join(" & ".join(s[1] for s in r) + " &" * (n - len(r)) + "\\\\\n" + " & ".join(s[2] for s in r) + " &" * (n - len(r)) for r in rows) + "\n\\end{tabular}"
        t = re.sub(r"⟦SUBHERE⟧(?:(?:\s|~|&|\\\\(?:\[[^\]]*\])?|\\q?quad|\\hspace\*?\{[^}]*\}|\\[,;])*⟦SUBHERE⟧)*(?:\s*\\\\(?:\[[^\]]*\])?)*", lambda m: "\n\n" + "⟦GRID⟧" + "\n\n", t, count=1).replace("⟦SUBHERE⟧", "").replace("⟦GRID⟧", grid)
    t = notes(t)
    return "\n\n" + "".join(f"⟦TITLE⟧{n}⟦:⟧{' '.join(c.split())}\n\n" for n, c in caps) + t.strip() + "\n\n"
def notes(t):
    t = re.sub(r"(?:\\\\(?:\[[^\]]*\])?|\\newline|\\par(?![A-Za-z]))\s*(?=(?:\{?\\(?:textit|emph|textbf|textsc|it|bf|textsf)\b\s*\{?)?\s*(?:Sources?|Notes?)\s*[:.}])", "\n\n", t)
    if "tabular" not in t: t = re.sub(r"(?m)^\s*\\\\(?:\[[^\]]*\])?", "", t)
    t = re.sub(r"\\begin\{tablenotes\}(?:\[[^\]]*\])*|\\end\{tablenotes\}|\\begin\{TableNotes\}(?:\[[^\]]*\])*|\\end\{TableNotes\}", "\n\n", t)
    t = re.sub(r"\\(?:floatfoot|legend|fnote|figurenotes?|tabnotes?|tablenote)\s*\{", r"{", t)
    t = re.sub(r"\\item\s*(?:\[([^\]]*)\])?", lambda m: "\n\n" + (m[1] or "") + " ", t) if "tabular" not in t or "\\begin{itemize}" not in t else t
    return t

# ---------- tables ----------
COLS = {}
for m in re.finditer(r"\\newcolumntype\{(\w)\}(?:\[\d\])?\s*(?=\{)", src):
    v, _ = group(src, m.end()); COLS[m[1]] = "c" if "centering" in (v or "") else "r" if "raggedleft" in (v or "") or re.search(r"\br\b", v or "") else "l"
def spec(s):
    s = re.sub(r"[@!><]\s*\{(?:[^{}]|\{[^{}]*\})*\}", "", s)
    s = re.sub(r"\*\s*\{(\d+)\}\s*\{((?:[^{}]|\{[^{}]*\})*)\}", lambda m: m[2] * int(m[1]), s)
    s = re.sub(r"S\s*\[[^\]]*\]|[SDdn.](?:\{[^}]*\}){0,3}", "c", s); s = re.sub(r"[pmbLCRXJYZP]\s*\{[^}]*\}", lambda m: "c" if m[0][0] == "C" else "r" if m[0][0] == "R" else "l", s)
    for k, v in COLS.items():
        if k in "SDXlcr": continue
        s = re.sub(k + r"(?:\{[^{}]*\})*", v, s)
    s = re.sub(r"[XLJYZ]", "l", s); s = s.replace("C", "c").replace("R", "r")
    return re.sub(r"[^lcr]", "", s)
def cells(t):
    t = re.sub(r"\\(?:addlinespace|specialrule|morecmidrules|noalign)(?:\[[^\]]*\])?(?:\{[^}]*\})*", "", t)
    t = re.sub(r"\\(?:cmidrule|cline)\s*(?:\[[^\]]*\])?(?:\([^)]*\))?\s*\{[^}]*\}", "", t)
    t = re.sub(r"\\(?:toprule|midrule|bottomrule|hline|hhline\{[^}]*\})(?:\[[^\]]*\])?", r"\\hline ", t)
    t = re.sub(r"\\(?:endhead|endfirsthead|endfoot|endlastfoot|rowcolor(?:\[[^\]]*\])?\{[^}]*\}|cellcolor(?:\[[^\]]*\])?\{[^}]*\}|tabularnewline)", lambda m: r"\\" if "newline" in m[0] else "", t)
    t = re.sub(r"(^|\\\\(?:\[[^\]]*\])?|&|\\hline)(\s*)((?:\\q?quad(?![A-Za-z])|\\hspace\*?\{[^}]*\}|\\indent(?![A-Za-z])|\\ |\\enspace(?![A-Za-z]))+)\s*", lambda m: m[1] + m[2] + "~~~~", t)
    t = re.sub(r"\\sym\{([^}]*)\}", r"$^{\1}$", t); t = re.sub(r"\\(?:num|tablenum)\s*(?:\[[^\]]*\])?\{([^}]*)\}", r"\1", t)
    t = re.sub(r"\\multirow(?:\[[^\]]*\])?\{(-?\d+)\}(?:\[[^\]]*\])?\{[^}]*\}(?:\[[^\]]*\])?", r"\\multirow{\1}{*}", t)
    t = command(t, "shortstack", 1, lambda o, a, st: " ".join(re.split(r"\\\\", a[0]))); t = command(t, "makecell", 1, lambda o, a, st: " ".join(re.split(r"\\\\(?:\[[^\]]*\])?", a[0])))
    t = re.sub(r"\\begin\{tabular\}(?:\[[^\]]*\])?\{[^{}]*(?:\{[^}]*\}[^{}]*)*\}((?:(?!\\begin\{tabular\}).)*?)\\end\{tabular\}", lambda m: " ".join(re.split(r"\\\\", m[1])) if "&" not in m[1] else m[0], t, flags=re.S)
    return t
def tab(m_env, t):
    i = 0
    if m_env in ("tabularx", "tabulary", "tabular*"): _, i = group(t, i)
    _, i = opt(t, i); sp, i = group(t, i); inner = cells(t[i:])
    if m_env == "longtable":
        # keep the first head only, drop "continued" heads and feet
        raw = t[i:]
        if "\\endfirsthead" in raw:
            h = raw.split("\\endfirsthead")[0]; rest = raw.split("\\endfirsthead")[1]
            for mk in ("\\endlastfoot", "\\endfoot", "\\endhead"):
                if mk in rest: rest = rest.split(mk, 1)[1] if mk != "\\endhead" or True else rest; 
            inner = cells(h + "\\hline " + rest)
        elif "\\endhead" in raw:
            h, rest = raw.split("\\endhead", 1)
            for mk in ("\\endlastfoot", "\\endfoot"):
                if mk in rest: rest = rest.split(mk, 1)[1]
            inner = cells(h + "\\hline " + rest)
    inner = re.sub(r"⟦CAP (.*?)⟧(.*?)⟦/CAP⟧\s*(?:\\\\)?", "", inner, flags=re.S)
    if re.search(r"\\multirow", inner) and not re.search(r"\\multirow\{\d", inner): W("unusual \\multirow: check the table")
    sp = spec(sp or "l"); need = 0
    for row in re.split(r"\\\\", re.sub(r"\\\\\[[^\]]*\]", r"\\\\", inner)):
        row = re.sub(r"\\&", "", row); need = max(need, len(re.findall("&", row)) + 1 + sum(int(x) - 1 for x in re.findall(r"\\multicolumn\{(\d+)\}", row)))
    sp += "c" * (need - len(sp))
    inner = re.sub(r"\\multicolumn\{(\d+)\}\{((?:[^{}]|\{[^{}]*\})*)\}", lambda m: "\\multicolumn{" + m[1] + "}{" + (spec(m[2])[:1] or "l") + "}", inner)
    return "\\begin{tabular}{" + sp + "}\n" + inner.strip() + "\n\\end{tabular}"
def tables(t): return re.sub(r"\\begin\{(tabularx|tabulary|tabular\*|tabular|longtable)\}((?:(?!\\begin\{(?:tabularx|tabulary|tabular\*|tabular|longtable)\}).|\\begin\{tabular\}(?:(?!\\end\{tabular\}).)*?\\end\{tabular\}(?=[^\\]*[&\\]))*?)\\end\{\1\}", lambda m: tab(m[1], m[2]), t, flags=re.S)
def table(t, st, e):
    if e == "longtable":
        caps = re.findall(r"⟦CAP (.*?)⟧(.*?)⟦/CAP⟧", t, re.S)[:1]; t = tab("longtable", t)
    else:
        t = re.sub(r"^\s*\[[^\]]*\]", "", t); caps = re.findall(r"⟦CAP (.*?)⟧(.*?)⟦/CAP⟧", t, re.S); t = re.sub(r"⟦CAP (.*?)⟧(.*?)⟦/CAP⟧", "", t, flags=re.S)
        t = tables(t); t = command(t, "includegraphics", 1, img)
    if "\\includegraphics" in t: W(f"{caps[0][0] if caps else 'a table'} is an image: retype it as a table if it can be read")
    return "\n\n" + "".join(f"⟦TITLE⟧{n}⟦:⟧{' '.join(c.split())}\n\n" for n, c in caps) + notes(t).strip() + "\n\n"
body = env(body, "figure|wrapfigure", figure); body = env(body, "table", table)
body = re.sub(r"\\begin\{longtable\}(.*?)\\end\{longtable\}", lambda m: table(m[1], False, "longtable"), body, flags=re.S)
body = tables(body); body = command(body, "includegraphics", 1, img)
body = re.sub(r"⟦CAP (.*?)⟧(.*?)⟦/CAP⟧", lambda m: f"\n\n⟦TITLE⟧{m[1]}⟦:⟧{' '.join(m[2].split())}\n\n", body, flags=re.S)
body = re.sub(r"\\captionof\{(\w+)\}\{", r"{", body)

# ---------- last text details ----------
body = re.sub(r"\\(?:SI|qty)(?:\[[^\]]*\])?\{([^}]*)\}\{([^}]*)\}", lambda m: m[1] + ("\\%" if "percent" in m[2] else " " + re.sub(r"\\", "", m[2])), body)
body = re.sub(r"\\num(?:\[[^\]]*\])?\{([^}]*)\}", r"\1", body)
body = re.sub(r"\\(?:enquote)\{", r"\\textquote{", body); body = command(body, "textquote", 1, lambda o, a, st: "‘" + a[0] + "’")
body = re.sub(r"\\xspace\b", "", body)
body = re.sub(r"\$\s*\{?\}?\^\{?\s*(?:\\(?:text|mathrm|textit|it)\{)?([A-Za-z*†‡\d,]{1,4}|\\dagger|\\ast)\}?\}?\s*\$", lambda m: "\\textsuperscript{" + {"\\dagger": "†", "\\ast": "*"}.get(m[1], m[1]) + "}", body)
body = re.sub(r"(?<![\\$])\$\s*([+-]?)\s*(\d[\d.,]*)\s*((?:\\%)?)\s*\$(?!\$)", lambda m: {"-": "−", "+": "+", "": ""}[m[1]] + m[2] + m[3], body)   # plain numbers need no equation
body = re.sub(r"\\\(\s*([+-]?)\s*(\d[\d.,]*)\s*\\\)", lambda m: {"-": "−", "+": "+", "": ""}[m[1]] + m[2], body)
body = re.sub(r"⟦RUNIN⟧\s*", " ", body); body = re.sub(r"\n{3,}", "\n\n", body)
if "⟦REFS⟧" in body:
    i = body.index("⟦REFS⟧"); has = bool(re.search(r"\\section\*\{[^}]*(References|Bibliography)\}\s*$", body[:i]))
    body = body.replace("⟦REFS⟧", ("" if has else "\n\n\\section*{References}\n\n") + "⟦REFLIST⟧\n\n", 1).replace("⟦REFS⟧", "")
elif bibs: body += "\n\n\\section*{References}\n\n⟦REFLIST⟧\n"
used = [d for d in defs if re.search(r"\\" + re.search(r"\\newcommand\{\\([A-Za-z]+)", d)[1] + r"(?![A-Za-z])", body + " ".join(x for x in defs if x != d))]
flat = "\n".join(used) + "\n\n" + body.strip() + "\n"
(OUT / "flat.tex").write_text(flat, encoding="utf-8")
if not front["title"]: W("no \\title found: fill in front.json by hand, and move any title-page text that is still at the top of flat.tex")
if not (OUT / "front.json").exists(): (OUT / "front.json").write_text(json.dumps(front, indent=1, ensure_ascii=False), encoding="utf-8")
def foot(s): return len(re.findall(r"\\footnote(?![A-Za-z])", s))
inline = len(re.findall(r"(?<!\\)\$[^$]+\$", body)); disp = body.count("\\[") 
rep = {"main": str(MAIN), "sections": lists["section"], "tables": lists["table"], "figures": lists["figure"], "images": nfig, "equation_numbers": lists["equation"], "displayed_equations": disp,
       "footnotes": foot(body), "cited_works": len(cited), "bib": bibs, "labels": labels, "to_check": warn}
(OUT / "report.json").write_text(json.dumps(rep, indent=1, ensure_ascii=False), encoding="utf-8")
print(f"{len(lists['section'])} headings, {len(lists['table'])} tables, {len(lists['figure'])} figures ({nfig} images), {len(lists['equation'])} numbered equations, {rep['footnotes']} footnotes, {len(cited)} cited works")
print("To check:" if warn else "Nothing flagged."); [print(" -", x) for x in warn]
