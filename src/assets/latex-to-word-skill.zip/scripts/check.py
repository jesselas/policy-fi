#!/usr/bin/env python3
"""Step 3. Compare the Word file with the original paper and list what may have been lost.

    python3 check.py paper.docx --work work/ [--pdf original.pdf]

With --pdf (recommended: the compiled paper, or the PDF that was converted) every word and number
of the PDF is looked for in the Word file. Exit code 1 means something needs a look.
"""
import argparse, json, re, subprocess, sys, unicodedata, zipfile
from collections import Counter
from pathlib import Path
from lxml import etree as E
ap = argparse.ArgumentParser(); ap.add_argument("docx"); ap.add_argument("--work"); ap.add_argument("--pdf"); A = ap.parse_args()
N = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main", "m": "http://schemas.openxmlformats.org/officeDocument/2006/math"}
z = zipfile.ZipFile(A.docx); names = z.namelist(); assert z.testzip() is None
D = E.fromstring(z.read("word/document.xml")); F = E.fromstring(z.read("word/footnotes.xml")) if "word/footnotes.xml" in names else None
def xp(e, s): return e.xpath(s, namespaces=N)
def text(tree):
    out = []
    for p in xp(tree, "//w:p"): out.append("".join("\t" if x.tag.endswith("}tab") else " " if x.tag.endswith("}br") else x.text or "" for x in xp(p, ".//w:t|.//m:t|.//w:r/w:tab|.//w:br")))
    return "\n".join(out)
body = text(D); notes = text(F) if F is not None else ""; body = body.replace("\u00a0", " "); notes = notes.replace("\u00a0", " "); allt = body + "\n" + notes
bad = []
c = {"headings": len(xp(D, "//w:p[w:pPr/w:pStyle[starts-with(@w:val,'Heading')]]")), "tables": len([t for t in xp(D, "//w:tbl") if not xp(t, ".//w:drawing")]), "images": len(xp(D, "//w:drawing")), "equations": len(xp(D, "//m:oMath")) + (len(xp(F, "//m:oMath")) if F is not None else 0), "footnotes": len(xp(D, "//w:footnoteReference")), "titles of tables and figures": len(xp(D, "//w:p[w:pPr/w:pStyle[@w:val='Table-title']]"))}
print("In the Word file:", ", ".join(f"{v} {k}" for k, v in c.items()))
if A.work and (Path(A.work) / "report.json").exists():
    R = json.loads((Path(A.work) / "report.json").read_text(encoding="utf-8"))
    for k, a, b in [("headings", len(R["sections"]), c["headings"]), ("images", R["images"], c["images"]), ("footnotes", R["footnotes"], c["footnotes"]), ("titles of tables and figures", len(R["tables"]) + len(R["figures"]), c["titles of tables and figures"])]:
        if b < a: bad.append(f"{k}: {a} in the source, {b} in the Word file")
    nb_ = len(xp(D, "//w:p[w:pPr/w:pStyle[@w:val='Biblio']]"))
    if nb_ < R["cited_works"]: bad.append(f"references: {R['cited_works']} works cited, {nb_} entries in the list")
    for n in R["equation_numbers"]:
        if f"({n})" not in body: bad.append(f"equation number ({n}) is missing")
    flat = (Path(A.work) / "flat.tex").read_text(encoding="utf-8")
    nm = (Path(A.work) / "paper.json").read_text(encoding="utf-8").count('"t": "Math"') if (Path(A.work) / "paper.json").exists() else 0
    if c["equations"] < nm: bad.append(f"equations: {nm} in the source, {c['equations']} in the Word file (a lost equation, or math set as text)")
    bad += ["prepare.py: " + x for x in R["to_check"]]
for pat, what in [(r"⟦[^\n]{0,50}", "unresolved marker"), (r"\?\?", "unresolved reference"), (r"\\[A-Za-z]{2,}", "LaTeX command left as text"), (r"(?<!\w)@[\w:-]{3,}", "input or citation key left as text"), (r"\[[\d.]+\s*(?:em|ex|pt|cm|mm)\]", "LaTeX spacing left as text"), (r"(?<=\s)&(?=\s)[^\n]*&", "table cells left as text"), (r"\bMISSING FIGURE\b", "missing figure")]:
    for m in sorted(set(re.findall(pat, allt)))[:8]: bad.append(f"{what}: {m[:70]}")
for m in xp(D, "//m:oMath"):
    t = "".join(m.xpath(".//m:t/text()", namespaces=N))
    if "\\" in t or "&" in t: bad.append("equation not converted: " + t[:70])
for p in xp(D, "//w:p[w:pPr/w:pStyle[@w:val='Table-title']]"):
    t = "".join(p.xpath(".//w:t/text()", namespaces=N)).replace("\u00a0", " "); m = re.match(r"(Table|Figure)\s+[\w.]+", t)
    if m and len(re.findall(re.escape(m[0]) + r"(?![\w.]*\d)", body)) + len(re.findall(m[1] + r"s[^.]{0,40}\b" + re.escape(m[0].split()[-1]) + r"\b", body)) < 2: bad.append(f"{m[0]} is not mentioned in the text")
if A.pdf:
    try:
        import fitz
        pages = [p.get_text() for p in fitz.open(A.pdf)]
    except ImportError:
        pages = subprocess.run(["pdftotext", A.pdf, "-"], capture_output=True, text=True).stdout.split("\f")
    # running heads and page numbers: short lines that return on many pages
    cnt = Counter(l.strip() for p in pages for l in set(p.splitlines()) if l.strip())
    rep = {l for l, k in cnt.items() if k > max(3, len(pages) // 3)}
    t = "\n".join(l for p in pages for l in p.splitlines() if l.strip() not in rep and not re.fullmatch(r"\s*\d{1,3}\s*", l))
    t, *rest = re.split(r"(?m)^\s*(?:References|Bibliography)\s*$", t, maxsplit=1)      # names are shortened there: entries are counted instead
    if rest:
        nb = len(xp(D, "//w:p[w:pPr/w:pStyle[@w:val='Biblio']]")); print(f"Reference list: {nb} entries in the Word file")
        tail = re.split(r"(?m)^\s*(?:(?:Online )?Appendi(?:x|ces)\b.{0,60}|[A-C]\s{1,3}[A-Z][a-z].{2,60})$", rest[0], maxsplit=1); t += "\n" + (tail[1] if len(tail) > 1 else "")
    def norm(s):
        s = unicodedata.normalize("NFKC", s).replace("­", "").replace("−", "-"); s = re.sub(r"(\w)[-‐]\n(\w)", r"\1\2", s); return s.lower()
    joined = re.sub(r"[^\w]", "", norm(allt))
    words = Counter(re.findall(r"[^\W\d_]{4,}", norm(t))); have = Counter(re.findall(r"[^\W\d_]{4,}", norm(allt)))
    miss = sorted(w for w in words if w not in have and w not in joined)
    few = sorted(((words[w] - have[w], w) for w in words if w in have and words[w] - have[w] >= max(3, 0.25 * words[w])), reverse=True)[:25]
    nums = Counter(re.findall(r"\d+(?:[.,]\d+)+", t)); hn = Counter(re.findall(r"\d+(?:[.,]\d+)+", allt)); mn = [(n, k - hn[n]) for n, k in nums.items() if hn[n] < k]
    ni = Counter(re.findall(r"(?<![\d.,])\d{2,4}(?![\d.,]*\d)", t)); hi = Counter(re.findall(r"(?<![\d.,])\d{2,4}(?![\d.,]*\d)", allt)); mi = [(n, k - hi[n]) for n, k in ni.items() if hi[n] < k]
    print(f"Against the PDF: {sum(words.values())} words, {len(miss)} distinct words not found; {sum(nums.values())} decimal numbers, {len(mn)} distinct ones found less often")
    if miss: bad.append("words not found (text inside figures is expected here): " + ", ".join(miss[:80]))
    if few: bad.append("words found less often: " + ", ".join(f"{w} (−{k})" for k, w in few))
    if mn: bad.append("numbers found less often (axis labels in figures are expected here): " + ", ".join(f"{n} (−{k})" for n, k in mn[:60]))
if A.pdf and mi: bad.append("whole numbers found less often (page numbers, axis labels, and years from author lists are expected here): " + ", ".join(f"{n} (−{k})" for n, k in mi[:60]))
print(f"{len(bad)} points to look at" if bad else "Nothing to look at"); [print(" -", x) for x in bad]; sys.exit(bool(bad))
