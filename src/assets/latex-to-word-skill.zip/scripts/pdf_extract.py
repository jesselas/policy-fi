#!/usr/bin/env python3
"""For a paper that exists only as a PDF: take out the text, the pages and the figures.

    python3 pdf_extract.py paper.pdf -o work/

Writes work/pages/*.png (to read equations and tables from), work/text.txt (text with font sizes
and footnote-size lines marked), work/figures/*.png (cropped at 300 dpi, vector figures included)
and work/inventory.json (headings, captions, equation numbers, footnotes: the list that the
rebuilt paper must match). Needs PyMuPDF: pip install pymupdf
"""
import argparse, json, re, sys
from collections import Counter
from pathlib import Path
try: import fitz
except ImportError: sys.exit("PyMuPDF is needed: pip install pymupdf")
ap = argparse.ArgumentParser(); ap.add_argument("pdf"); ap.add_argument("-o", "--out", default="work"); ap.add_argument("--dpi", type=int, default=300); ap.add_argument("--page-dpi", type=int, default=130)
ap.add_argument("--crop", action="append", default=[], metavar="PAGE:X0,Y0,X1,Y1:NAME", help="crop one area by hand, in PDF points from the top left")
A = ap.parse_args(); OUT = Path(A.out); (OUT / "pages").mkdir(parents=True, exist_ok=True); (OUT / "figures").mkdir(exist_ok=True)
doc = fitz.open(A.pdf)
if A.crop:
    for c in A.crop:
        pg, box, name = c.split(":"); r = fitz.Rect(*[float(x) for x in box.split(",")]); doc[int(pg) - 1].get_pixmap(dpi=A.dpi, clip=r).save(OUT / "figures" / f"{name}.png"); print("cropped", name)
    sys.exit()
def trim(f):
    """Cut white margins."""
    try: from PIL import Image, ImageChops
    except ImportError: return
    im = Image.open(f).convert("RGB"); b = ImageChops.difference(im, Image.new("RGB", im.size, (255, 255, 255))).point(lambda v: 255 if v > 12 else 0).getbbox()
    if b: m = 12; im.crop((max(0, b[0] - m), max(0, b[1] - m), min(im.width, b[2] + m), min(im.height, b[3] + m))).save(f)
sizes = Counter(); cap_re = re.compile(r"^\s*((?:Online\s+)?(?:Appendix\s+)?(Figure|Fig\.|Table)\s+([A-Z]{0,2}\.?\d+(?:\.\d+)?))\s*[.:—–|]?\s*(.*)", re.S)
P = []
for pg in doc:
    d = pg.get_text("dict", flags=fitz.TEXT_PRESERVE_WHITESPACE | fitz.TEXT_PRESERVE_LIGATURES); lines = []
    for b in d["blocks"]:
        for l in b.get("lines", []):
            t = "".join(s["text"] for s in l["spans"]); 
            if not t.strip(): continue
            w_ = Counter()
            for s in l["spans"]: w_[round(s["size"], 1)] += len(s["text"].strip())
            sz = w_.most_common(1)[0][0]; bold = all(("bold" in s["font"].lower() or "bx" in s["font"].lower() or s["flags"] & 16) for s in l["spans"] if s["text"].strip())
            sizes[sz] += len(t); bb = fitz.Rect(l["bbox"])
            if lines and lines[-1]["block"] == b["number"] and abs(lines[-1]["bb"].y1 - bb.y1) < 2 and bb.x0 > lines[-1]["bb"].x0:      # number and title of a heading
                lines[-1]["t"] += "  " + t; lines[-1]["bb"].include_rect(bb); lines[-1]["sz"] = max(sz, lines[-1]["sz"]); lines[-1]["bold"] &= bold; continue
            fs = next(s for s in l["spans"] if s["text"].strip()); lines.append({"sup": bool(fs["flags"] & 1) or fs["size"] < sz - 1, "t": t, "bb": fitz.Rect(l["bbox"]), "sz": sz, "bold": bold, "block": b["number"]})
    P.append(lines)
if not sizes: sys.exit("The PDF has no text layer (a scan). Run OCR first, for example: ocrmypdf in.pdf out.pdf")
main = sizes.most_common(1)[0][0]
inv = {"pages": len(doc), "main_text_size": main, "headings": [], "captions": [], "equation_numbers": [], "footnote_lines": [], "figures": [], "to_check": []}
out = []
for n, (pg, lines) in enumerate(zip(doc, P), 1):
    pg.get_pixmap(dpi=A.page_dpi).save(OUT / "pages" / f"page_{n:02d}.png")
    W, H = pg.rect.width, pg.rect.height; out.append(f"\n===== page {n} =====")
    body = [l for l in lines if l["sz"] >= main - 0.6]; caps = []
    for l in lines:
        t = l["t"].rstrip(); tag = ""
        if l["sz"] > main + 0.8 or (l["bold"] and len(t) < 110 and re.match(r"^\s*(?:\d+(?:\.\d+)*\.?|[A-Z]\.?(?:\d+(?:\.\d+)*)?|[IVX]+\.?)\s+\S", t)):
            tag = "[heading] "; inv["headings"].append({"page": n, "text": t.strip(), "size": l["sz"]})
        elif l["sup"] and l["sz"] < main - 0.8 and l["bb"].y0 > H * 0.55 and re.match(r"^\s*\d{1,3}\s*\S", t): tag = "[footnote?] "; inv["footnote_lines"].append({"page": n, "text": t.strip()[:90]})
        m = cap_re.match(t)
        # a caption starts its line, and is not a sentence such as "Figure 2 shows"
        if m and not re.match(r"^(?:shows?|plots?|reports?|presents?|illustrates?|depicts?|and|gives?|lists?|compares?|is|are|displays?|summari[sz]es|in|of|also|indicates?|uses?|provides?|describes?|contains?|repeats?|replicates?)\b", m[4].strip()):
            cl = [k for k in lines if k["block"] == l["block"] and k["bb"].y0 >= l["bb"].y0 - 1]
            r = fitz.Rect(l["bb"]); [r.include_rect(k["bb"]) for k in cl]
            caps.append({"label": re.sub(r"Fig\.", "Figure", m[1]), "kind": "Figure" if m[2].startswith("Fig") else "Table", "bb": r, "text": " ".join(k["t"].strip() for k in cl)}); tag = "[caption] "
        ml = [k["bb"].x0 for k in body if k["bb"].width > W * 0.5]; lm0 = min(ml, default=0)
        if not tag and l in body and (6 < l["bb"].x0 - lm0 < 40 and l["bb"].width > W * 0.3): tag = "[para] "
        out.append(f"{tag}{t}" + (f"   ‹{l['sz']:g}pt›" if abs(l["sz"] - main) > 0.6 else ""))
    rm = max([l["bb"].x1 for l in lines], default=W); lm = min([l["bb"].x0 for l in lines], default=0); ws = pg.get_text("words")
    for w in sorted(ws, key=lambda w: w[1]):     # equation numbers: alone at the right margin, with a gap before them
        e = re.fullmatch(r"\((\d{1,3}|[A-Z]{1,2}\.?\d{1,3}|\d+\.\d+)\)", w[4])
        row = [v for v in ws if v is not w and abs((v[1] + v[3]) / 2 - (w[1] + w[3]) / 2) < 5]
        if e and (w[2] > rm - 8 and not any(0 < w[0] - v[2] < 12 for v in row) or w[0] < lm + 8 and not any(0 < v[0] - w[2] < 12 for v in row)): inv["equation_numbers"].append({"page": n, "number": e[1]})
    for c in caps: inv["captions"].append({"page": n, "label": c["label"], "text": c["text"]})
    # graphics on the page: pictures and clusters of vector drawing
    boxes = [fitz.Rect(i["bbox"]) for i in pg.get_image_info() if i["bbox"][2] - i["bbox"][0] > 20 and i["bbox"][3] - i["bbox"][1] > 20]
    dr = []
    for g in pg.get_drawings():
        r = fitz.Rect(g["rect"])
        if r.width > W * 0.97 and r.height > H * 0.97: continue        # page background
        if r.height < 1.5 and r.width > W * 0.1 and not g.get("fill"): dr.append((r, True)); continue   # a rule (table or footnote line)
        dr.append((r, False))
    try: cl = [fitz.Rect(r) for r in pg.cluster_drawings(x_tolerance=12, y_tolerance=12)]
    except Exception: cl = []
    for r in cl:
        inside = [x for x, rule in dr if r.intersects(x) or r.contains(x)]; rules = sum(1 for x, rule in dr if rule and r.contains(x))
        if r.width < 40 or r.height < 40 or len(inside) < 6 or rules >= 0.8 * len(inside): continue
        boxes.append(r)
    merged = True
    while merged:
        merged = False
        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                if (boxes[i] + (-14, -14, 14, 14)).intersects(boxes[j]) and not any(min(boxes[i].y1, boxes[j].y1) - 2 <= c["bb"].y0 <= max(boxes[i].y0, boxes[j].y0) + 2 for c in caps): boxes[i] |= boxes[j]; boxes.pop(j); merged = True; break
            if merged: break
    figs = [c for c in caps if c["kind"] == "Figure"]; used = set()
    for c in sorted(figs, key=lambda c: c["bb"].y0):
        # the caption is above or below its figure: take the side with the nearer graphic
        free = [i for i in range(len(boxes)) if i not in used]
        below = [i for i in free if boxes[i].y0 >= c["bb"].y0 - 4]; above = [i for i in free if boxes[i].y1 <= c["bb"].y1 + 4]
        db = min([boxes[i].y0 - c["bb"].y1 for i in below], default=1e9); da = min([c["bb"].y0 - boxes[i].y1 for i in above], default=1e9)
        lo = max([k["bb"].y1 for k in caps if k["bb"].y1 < c["bb"].y0], default=0); hi = min([k["bb"].y0 for k in caps if k["bb"].y0 > c["bb"].y1], default=H)
        pick = [i for i in below if boxes[i].y1 <= hi + 4] if db <= da else [i for i in above if boxes[i].y0 >= lo - 4]
        # panels of one figure sit together: stop at body text between them
        pick.sort(key=lambda i: boxes[i].y0 if db <= da else -boxes[i].y1); grp = []
        for i in pick:
            if grp:
                r0 = boxes[grp[-1]]; a, b = (r0.y1, boxes[i].y0) if db <= da else (boxes[i].y1, r0.y0)
                if any(a - 2 < l["bb"].y0 and l["bb"].y1 < b + 2 and l["bb"].width > W * 0.5 for l in body): break
            grp.append(i)
        if not grp:
            inv["to_check"].append(f"page {n}: {c['label']} has a caption but no picture was found (on the next page, or drawn without a frame): crop it by hand with --crop"); inv["figures"].append({"label": c["label"], "page": n, "file": None}); continue
        used |= set(grp); r = fitz.Rect(boxes[grp[0]]); [r.include_rect(boxes[i]) for i in grp]
        # axis labels, legends, and panel titles around the drawing
        for _ in range(3):
            for l in lines:
                if l["bb"].y0 >= c["bb"].y0 - 1 and l["bb"].y1 <= c["bb"].y1 + 1: continue
                if re.match(r"\s*(?:Notes?|Sources?)\b", l["t"]) : continue
                near = (r + (-16, -13, 16, 13)).intersects(l["bb"]); txtline = abs(l["sz"] - main) < 0.6 and any(k["bb"].width > W * 0.55 and (k["block"] == l["block"] or abs(k["sz"] - l["sz"]) < 0.3 and abs(k["bb"].x0 - l["bb"].x0) < 4 and abs(k["bb"].y0 - l["bb"].y0) < 2 * main) for k in lines)
                if near and not txtline and (l["bb"].width < r.width * 1.05 or r.contains(l["bb"])): r.include_rect(l["bb"])
        top = max([k["bb"].y1 for k in caps if k["bb"].y1 <= r.y0 + 12] + [0]); bot = min([k["bb"].y0 for k in caps if k["bb"].y0 >= r.y1 - 12] + [H])
        nt = min([l["bb"].y0 for l in lines if re.match(r"\s*(?:Notes?|Sources?)\s*[:.]", l["t"]) and l["bb"].y0 > r.y0 + 20] + [H]); r.y1 = min(r.y1 + 3, bot - 1, nt - 1); r.y0 = max(r.y0 - 3, top + 1); r.x0 -= 3; r.x1 += 3; r &= pg.rect
        f = re.sub(r"[^A-Za-z0-9]+", "_", c["label"]).strip("_").lower() + ".png"
        pg.get_pixmap(dpi=A.dpi, clip=r).save(OUT / "figures" / f); trim(OUT / "figures" / f); inv["figures"].append({"label": c["label"], "page": n, "file": f"figures/{f}", "box": [round(x, 1) for x in r], "width_share_of_text": round(min(1, r.width / (W * 0.76)), 2)})
    for i in range(len(boxes)):
        if i in used: continue
        r = boxes[i] & pg.rect
        if r.width * r.height < 6000: continue
        f = f"extra_p{n:02d}_{i}.png"; pg.get_pixmap(dpi=A.dpi, clip=r).save(OUT / "figures" / f); inv["to_check"].append(f"page {n}: a picture without its own caption was saved as figures/{f} (a second panel, a table drawn as a picture, or a logo)")
labs = [c["label"] for c in inv["captions"]]
for l, k in Counter(labs).items():
    if k > 1: inv["to_check"].append(f"{l} has {k} captions: one may be a continued table, a list of figures, or a sentence")
for kind in ("Figure", "Table"):
    ns = sorted({int(x.split()[-1]) for x in labs if re.fullmatch(kind + r" \d+", x)})
    if ns and ns != list(range(1, ns[-1] + 1)): inv["to_check"].append(f"{kind} numbers found: {ns}. Look for the missing ones")
(OUT / "text.txt").write_text("\n".join(out), encoding="utf-8"); (OUT / "inventory.json").write_text(json.dumps(inv, indent=1, ensure_ascii=False), encoding="utf-8")
print(f"{len(doc)} pages, {len(inv['headings'])} heading lines, {sum(1 for x in labs if 'Table' in x)} tables, {len(inv['figures'])} figures ({sum(1 for f in inv['figures'] if f['file'])} cropped), {len(inv['equation_numbers'])} equation numbers, {len(inv['footnote_lines'])} footnotes")
print("To check:" if inv["to_check"] else "Nothing flagged."); [print(" -", x) for x in inv["to_check"]]
