LATEX TO WORD (latex-to-word)
An AI skill that converts a LaTeX paper, or a PDF made with LaTeX, into Word in the UNU-WIDER
working paper style, and checks that nothing was lost. Unofficial. By Jesse Lastunen, policy.fi.

Claude Code      unzip into ~/.claude/skills/latex-to-word/
Codex            unzip into ~/.codex/skills/latex-to-word/
Copilot Cowork   Plugins > Add > Upload, and choose the zip
Any other AI     put the zip (or its unzipped folder) next to the paper and ask the AI to read
                 SKILL.md in it and follow it

Example prompt
Convert the paper main.tex in this folder into Word. Read SKILL.md in latex-to-word-skill.zip and
follow it. Save the result as main.docx in the same folder, and list anything I need to check.
