---
name: latex-to-word
description: Convert a LaTeX paper (an Overleaf project, a folder or zip with main.tex, or only the compiled PDF of a LaTeX paper) into an editable Word document in the UNU-WIDER working paper style, with native equations, editable tables, real footnotes, figures, numbered headings and cross-references, and a formatted reference list, then check that nothing was lost. Use whenever someone asks to turn LaTeX, Overleaf, .tex, or a LaTeX-based PDF into Word or .docx, for copy-editing, comments, or tracked changes, including “convert this paper to Word”, “LaTeX to docx”, or “put this PDF into the WIDER template”. Another Word template can be given.
---

# LaTeX to Word

Produce a Word file that an editor can work in: every word, number, equation, table, figure, footnote, and reference of the original, in the UNU-WIDER style. Convert only. Don’t edit the text, correct numbers, or shorten anything. List problems you notice in your reply.

## Before you start

1. Find this skill’s folder. If you were given a zip, unzip it. Paths below are relative to that folder.
2. Copy the paper’s folder to a working area. Never change the originals, and never overwrite an existing Word file without asking.
3. Set up: `pip install lxml pymupdf pypandoc_binary` (Pandoc may already be installed: `pandoc --version`). If Pandoc can’t be installed, read `references/without-pandoc.md`.
4. Read `references/wider-style.md`.

| You have | Do |
|---|---|
| LaTeX source, ideally with its PDF | Steps 1 to 5 |
| Only a PDF | `references/pdf-route.md` first: it rebuilds a small LaTeX source, then steps 1 to 5 |

If there are several .tex files, the main one contains `\documentclass`. Ask only if two papers could be meant. If LaTeX is installed and there is no PDF, compile one: it is the best thing to check against. A PDF of another version of the paper is no use for that.

## 1. Prepare

```
python3 scripts/prepare.py path/to/main.tex -o work/
```

It joins the input files, expands macros, works out section, table, figure, equation, and theorem numbers, resolves references, simplifies tables, and turns figures into PNG. It writes `work/flat.tex`, `work/front.json`, and `work/report.json`.

Deal with every line under “To check”. Edit `work/flat.tex` directly where needed. Common cases:

- **Title page.** Fill in `work/front.json` (title, subtitle, authors, corresponding, affiliations, abstract, keywords, jel, acknowledgements) from the paper, in LaTeX notation. If the paper types its title page by hand, move that text out of the top of `flat.tex` into `front.json`. Leave a field empty if the paper doesn’t give it.
- **Reference without a label, or a number that may differ.** Compare with the PDF.
- **Missing figure, TikZ.** Compile or crop the picture from the PDF (`scripts/pdf_extract.py`), then put `\includegraphics[width=6in]{full path}` in its place.
- **A table that is an image.** Retype it as a table if every number can be read. Otherwise keep the image and say so.
- **Editorial notes, change marks, commented versions** in the source: keep what the PDF shows.

Running `prepare.py` again rewrites `flat.tex`, so make fixes to the source copy first and hand edits last. `front.json` is kept.

## 2. Convert

```
python3 scripts/convert.py work/ -o paper.docx
```

Add `--template file.dotx` if the user supplies a current WIDER template or another template. Deal with each message: “Could not convert TeX math” means an equation is still LaTeX, so rewrite it in `flat.tex` with plainer commands and convert again.

The script sets A4 pages with 1-inch margins, the WIDER styles, typed heading numbers followed by a tab, titles above tables and figures, notes and source below, horizontal table rules, and an equation number after a right tab.

## 3. Check against the original

```
python3 scripts/check.py paper.docx --work work/ --pdf original.pdf
```

Fix or explain every point. Words and numbers that occur only inside figures are expected. Letters from split equations (such as “tiβt”) are too. Any other missing word, number, equation, footnote, or reference is an error.

## 4. Look at the pages

Turn the Word file into images and look at every page next to the PDF:

```
soffice --headless --convert-to pdf paper.docx && pdftoppm -r 70 -png paper.pdf page
```

Look for: tables with shifted, merged, or missing cells (compare each one cell by cell), headers that lost a spanning row, panel titles, signs and stars, broken words in narrow columns, pictures that are cut or too small, figure panels in the wrong order, equations that read differently, notes in the wrong place, a title separated from its table, references with missing parts. LibreOffice breaks pages differently from Word, so page ends don’t matter.

Fix tables in `flat.tex` where possible. For last details, open the Word file with python-docx and change only what is needed.

If you can’t make images, compare the text of each table with the PDF instead, and say that the pages weren’t seen.

## 5. Report

Give the file and, briefly: counts (headings, tables, figures, equations, footnotes, references) in the original and in Word; what you fixed by hand; what still needs a person (missing sources, figures that stay pictures, unreadable parts, anything uncertain); and which checks were not run. List spelling or consistency problems you noticed separately, unchanged in the file. Remind the user that figures are images, so editable versions (Excel, or the original files) go separately if the editor asks.
